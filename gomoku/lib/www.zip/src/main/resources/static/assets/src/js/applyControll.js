/*
* 申请融资
*/


require("../sass/apply.scss");

require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var applyApp = angular.module("app", ["validation", "validation.rule", "dyDir", "dyService"]);
applyApp.controller("headUerCtrl",function($scope,$http,postUrl){
	$scope.formData = table_struct;
});
//订阅发布模式，接收方在这里订阅消息，发布方在这里发布消息
applyApp.factory("EventBus", function() {
    var eventMap = {};

    var EventBus = {
        on : function(eventType, handler) {
            //multiple event listener
            if (!eventMap[eventType]) {
                eventMap[eventType] = [];
            }
            eventMap[eventType].push(handler);
        },

        off : function(eventType, handler) {
            for (var i = 0; i < eventMap[eventType].length; i++) {
                if (eventMap[eventType][i] === handler) {
                    eventMap[eventType].splice(i, 1);
                    break;
                }
            }
        },

        fire : function(event) {
            var eventType = event.type;
            if (eventMap && eventMap[eventType]) {
                for (var i = 0; i < eventMap[eventType].length; i++) {
                    eventMap[eventType][i](event);
                }
            }
        }
    };
    return EventBus;
});
applyApp.controller("businessCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = table_struct;

    var initbtnText = table_struct.btnText ? table_struct.btnText : "签名确认";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.loan = {};
    var tmp = true;
    var jump = false;
    if($scope.formData.signPageInfo != null){
        for(var i=0;i<$scope.formData.signPageInfo.length;i++){
            if($scope.formData.signPageInfo[i].status==false){
                tmp = false;
            }
            if($scope.formData.signPageInfo[i].jump==true){
                jump = true;
            }
        }
        if(jump){
            window.location.href = "/member/loan/submitResultMoney?id=" + $scope.formData.loanId;
        }else {
            if (tmp) {
                window.location.href = "/member/loan/submitResult?id=" + $scope.formData.loanId;
            }
        }
    }
    $scope.submitSign = function(){
        $scope.btnText = initbtnText + "中...";
        $scope.btnStatus = true;
        postUrl.events('/member/loan/submitSign', {content: $scope.formData.content, id: $scope.formData.id, protocolType: $scope.formData.protocolType}).success(function(_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    var result = _data.data.every(function(item, index, array){
                        return item.status;
                    })
                    if(result){
                        parent.location.href = "/member/loan/submitResult?id=" + _data.id;
                    } else {
                        parent.location.reload();
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
});
applyApp.controller("businessWHCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = table_struct;

    var initbtnText = table_struct.btnText ? table_struct.btnText : "签名确认";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.loan = {};
    var tmp = true;
    var jump = false;
    if($scope.formData.signPageInfo != null){
        for(var i=0;i<$scope.formData.signPageInfo.length;i++){
            if($scope.formData.signPageInfo[i].status==false){
                tmp = false;
            }
            if($scope.formData.signPageInfo[i].jump==true){
                jump = true;
            }
        }
        if(jump){
            window.location.href = "/member/warehouse/submitResultMoney?id=" + $scope.formData.loanId;
        }else {
            if (tmp) {
                window.location.href = "/member/warehouse/submitResult?id=" + $scope.formData.loanId;
            }
        }
    }
    $scope.submitSign = function(){
        $scope.btnText = initbtnText + "中...";
        $scope.btnStatus = true;
        postUrl.events('/member/warehouse/submitSign', {content: $scope.formData.content, id: $scope.formData.id, protocolType: $scope.formData.protocolType}).success(function(_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    var result = _data.data.every(function(item, index, array){
                        return item.status;
                    })
                    if(result){
                        parent.location.href = "/member/warehouse/submitResult?id=" + _data.id;
                    } else {
                        parent.location.reload();
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
});
applyApp.controller("businessAgpurCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = table_struct;

    var initbtnText = table_struct.btnText ? table_struct.btnText : "签名确认";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.loan = {};
    var tmp = true;
    var jump = false;
    if($scope.formData.signPageInfo != null){
        for(var i=0;i<$scope.formData.signPageInfo.length;i++){
            if($scope.formData.signPageInfo[i].status==false){
                tmp = false;
            }
            if($scope.formData.signPageInfo[i].jump==true){
                jump = true;
            }
        }
        if(jump){
            window.location.href = "/member/agpur/loan/submitResultMoney?id=" + $scope.formData.loanId;
        }else {
            if (tmp) {
                window.location.href = "/member/agpur/loan/submitResult?id=" + $scope.formData.loanId;
            }
        }
    }
    $scope.submitSign = function(){
        $scope.btnText = initbtnText + "中...";
        $scope.btnStatus = true;
        postUrl.events('/member/agpur/loan/submitSign', {content: $scope.formData.content, id: $scope.formData.id, protocolType: $scope.formData.protocolType}).success(function(_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    var result = _data.data.every(function(item, index, array){
                        return item.status;
                    })
                    if(result){
                        parent.location.href = "/member/agpur/loan/submitResult?id=" + _data.id;
                    } else {
                        parent.location.reload();
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
});
applyApp.controller("b2bAuditCtrl",function($scope, $http, postUrl){
    $scope.formData = table_struct;
    $scope.submitSign = function(){
        postUrl.events('/member/loan/b2b/readAndAudit', {id: $scope.formData.id}).success(function(_data) {
            if(_data.status==200){
                window.location.href = "/member/loan/b2b/submitResult";
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                });
            }
        });
    }
});
applyApp.controller("businessB2BCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = table_struct;

    var initbtnText = table_struct.btnText ? table_struct.btnText : "签名确认";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.loan = {};

    var tmp = true;
    var jump = false;
    if($scope.formData.signPageInfo != null){
        for(var i=0;i<$scope.formData.signPageInfo.length;i++){
            if($scope.formData.signPageInfo[i].status==false){
                tmp = false;
            }
            if($scope.formData.signPageInfo[i].jump==true){
                jump = true;
            }
        }
        if(jump){
            window.location.href = "/member/loan/b2b/submitResultMoney?id=" + $scope.formData.loanId;
        }else {
            if (tmp) {
                window.location.href = "/member/loan/b2b/submit?id=" + $scope.formData.loanId;
            }
        }
    }
    $scope.submitSign = function(){
        $scope.btnText = initbtnText + "中...";
        $scope.btnStatus = true;
        postUrl.events('/member/loan/b2b/submitSign', {content: $scope.formData.content, id: $scope.formData.id, protocolType: $scope.formData.protocolType}).success(function(_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    var result = _data.data.every(function(item, index, array){
                        return item.status;
                    })
                    if(result){
                        parent.location.href = "/member/loan/b2b/submit?id=" + _data.id;
                    } else {
                        parent.location.reload();
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
});
applyApp.controller("selectCoreCtrl",function($scope, $http, postUrl){
	$scope.formData = table_struct;
	$scope.formData.btnDisabled=true;
	if($scope.formData.companies){
		for(var i=0;i<$scope.formData.companies.length;i++){
			if($scope.formData.companies[i].status&&$scope.formData.companies[i].status==1){
				$scope.formData.btnDisabled=false;
			}
		}
	}
	
	$scope.submitRelation = function(coreId,productId,type,businessId){
		var url='/member/loan/submitRelation';
		if(type=='reSubmit'){
			url='/member/loan/reSubmitRelation';
		}
		postUrl.events(url, {'coreId':coreId,'productId':productId,'businessId':businessId}).success(function(_data) {
			if(_data.status==200){
				$scope.formData.companies=_data.data.companies;
				if($scope.formData.companies){
					for(var i=0;i<$scope.formData.companies.length;i++){
						if($scope.formData.companies[i].status&&$scope.formData.companies[i].status==1){
							$scope.formData.btnDisabled=false;
						}
					}
				}
			}else{
				parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
			}
		});
	}
});

applyApp.controller("requestLoanCtrl",function($scope, $http, postUrl, $filter, $timeout, EventBus){
	$scope.formData = table_struct;
	$scope.process = 1;
	$scope.loan = {};
	$scope.loan.files = [];
	$scope.loan.productId = $scope.formData.productId;
	$scope.btnStatus = false;
    $scope.billData = {};
        $scope.billList = [];
        
        if ($scope.formData.product.dataChannel > 0) {
            // 直接对接核心企业
            $scope.process = 2;
            $scope.billData.showBill = false;
        }
        
        // 改变选择的数据
        $scope.changeData = function(){
            $scope.formData.notice = [];
            angular.forEach($scope.billList, function(item){
                var notice_obj = item.id;
                $scope.formData.notice.push(notice_obj);
            })
        }
        
        $scope.changeTotal = function(){
            $scope.loan.validMoney = "0.00";
            $scope.formData.validTotal = "0.00";
            angular.forEach($scope.billList, function(item){
                $scope.loan.validMoney = ($scope.loan.validMoney * 1 + item.validMoney).toFixed(2);
            })
            
            var financeRate = !isNaN($scope.formData.product.maxFinanceRate) ? $scope.formData.product.maxFinanceRate : 0;
            $scope.formData.maxMoney = ($scope.loan.validMoney*financeRate/100).toFixed(2);
        }
        
        EventBus.on("selectBillCtrl", function(evt){
            if(evt.list){
                $scope.billList = evt.list;
            } else if(evt.item){
                $scope.billList.push(evt.item);
            }
            
            $scope.changeData();
            $scope.changeTotal();
        });
        
        // 添加
        $scope.loan.buyerId = $scope.formData.product.coreCompanyIds.split(",")[0];
        $scope.selectBill = function(){
            var index = layer.load();
            var param = {
                        companyId: $scope.formData.companyId,
                        coreCompanyId:$scope.loan.buyerId,
                        notices:$scope.formData.notice
                        }
            postUrl.events("/member/bill/getBills", param).success(function(_data){
                if(_data.status == 200){
                    $timeout(function() {
                        layer.close(index);
                        EventBus.fire({type: "requestLoanCtrl", showBill: true, params : param, bills : _data.data});
                    }, 1000);
                } else {
                    layer.close(index);
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            })
        }
        
        // 删除
        $scope.removeBill = function(index){
            $scope.billList.splice(index, 1);
            $scope.changeData();
            $scope.changeTotal();
        }
        
        $scope.closePopup = function(){
            $scope.billData.showBill = false;
        }
	/** 
	* 加法运算，避免数据相加小数点后产生多位数和计算精度损失。 
	* 
	* @param num1加数1 | num2加数2 
	*/ 
	$scope.numAdd = function(num1, num2) { 
		var baseNum, baseNum1, baseNum2; 
		try { 
			baseNum1 = num1.toString().split(".")[1].length; 
		} catch (e) { 
			baseNum1 = 0; 
		} 
		try { 
			baseNum2 = num2.toString().split(".")[1].length; 
		} catch (e) { 
			baseNum2 = 0; 
		} 
		baseNum = Math.pow(10, Math.max(baseNum1, baseNum2)); 
		return ($scope.numMulti(num1,baseNum) + $scope.numMulti(num2,baseNum)) / baseNum; 
	} 
	/** 
	* 加法运算，避免数据相减小数点后产生多位数和计算精度损失。 
	* 
	* @param num1被减数 | num2减数 
	*/ 
	$scope.numSub = function(num1, num2) { 
		var baseNum, baseNum1, baseNum2; 
		var precision;// 精度 
		try { 
			baseNum1 = num1.toString().split(".")[1].length; 
		} catch (e) { 
			baseNum1 = 0; 
		} 
		try { 
			baseNum2 = num2.toString().split(".")[1].length; 
		} catch (e) { 
			baseNum2 = 0; 
		} 
		baseNum = Math.pow(10, Math.max(baseNum1, baseNum2)); 
		precision = (baseNum1 >= baseNum2) ? baseNum1 : baseNum2; 
		return (($scope.numMulti(num1,baseNum) - $scope.numMulti(num2,baseNum)) / baseNum).toFixed(precision); 
	} 
	/** 
	* 乘法运算，避免数据相乘小数点后产生多位数和计算精度损失。 
	* 
	* @param num1被乘数 | num2乘数 
	*/ 
	$scope.numMulti = function (num1, num2) { 
		var baseNum = 0; 
		try { 
		baseNum += num1.toString().split(".")[1].length; 
		} catch (e) { 
		} 
		try { 
		baseNum += num2.toString().split(".")[1].length; 
		} catch (e) { 
		} 
		return Number(num1.toString().replace(".", "")) * Number(num2.toString().replace(".", "")) / Math.pow(10, baseNum); 
	} 
	/** 
	* 除法运算，避免数据相除小数点后产生多位数和计算精度损失。 
	* 
	* @param num1被除数 | num2除数 
	*/ 
	$scope.numDiv = function(num1, num2) { 
		var baseNum1 = 0, baseNum2 = 0; 
		var baseNum3, baseNum4; 
		try { 
			baseNum1 = num1.toString().split(".")[1].length; 
		} catch (e) { 
			baseNum1 = 0; 
		} 
		try { 
			baseNum2 = num2.toString().split(".")[1].length; 
		} catch (e) { 
			baseNum2 = 0; 
		} 
		with (Math) { 
			baseNum3 = Number(num1.toString().replace(".", "")); 
			baseNum4 = Number(num2.toString().replace(".", "")); 
			return (baseNum3 / baseNum4) * pow(10, baseNum2 - baseNum1); 
		} 
	}

	//新增应收账款-到期日、最迟付款日
    function getNowFormatDate() {
        var date = new Date();
        var seperator1 = "-";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
        return currentdate;
    }
    $scope.getEndTime1 = function(number1, number2, date1){
        // number1 = number1 || 0;
        // number2 = number2 || 0;
        // date1 = date1 || getNowFormatDate();
        if(!!number1 && !!number2 && !!date1){
        	var date_date1 = date1.substring(8);
        	$scope.loan.billEndTime = $filter("date")(new Date(date1).setDate(Number(date_date1) + Number(number1)), "yyyy-MM-dd");

        	$scope.getEndTime2(number2, $scope.loan.billEndTime);
        }
    }
    $scope.getEndTime2 = function(number2, date2){
        if(!!date2){
            // if(number2 == 0){
            //     $scope.loan.lastPayTime = date2;
            //     return;
            // }
            var date_date2 = date2.substring(8);
            $scope.loan.lastPayTime = $filter("date")(new Date(date2).setDate(Number(date_date2) + Number(number2)), "yyyy-MM-dd");
        }
    }

    /*应收账款凭证跳融资需求*/
	$scope.requestLoan = function(){
		if($scope.loan.files.length == 0){
			layer.msg("请先上传凭证附件", {icon: 2, shade: 0.3, time: 1500})
			return false;
		}
		postUrl.events('/member/loan/checkNumber', {"creditNo":$scope.loan.creditNo,"bussContractNo":$scope.loan.bussContractNo}).success(function(_data) {
			if(_data.status==200){
				$timeout(function(){
		            $scope.process = 2;//切换
		        }, 1000)
			}else{
				parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
			}
		});
	}

    /*融资需求-年息总额、服务费计算*/
	//初始化
	//贷款金额  loan.contractMoney
	//日利率  formData.dayRate
	//期限id  loan.feeValueId
	//期限  formData.feeList[i]["loanTime"]  1、天，2、月
	//年息总额  formData.yearFee = 贷款金额*90天*日利率
	//服务费率  formData.serviceRate
	//服务费  formData.serviceFee = 1、固定费用，2、贷款金额*服务费率
	$scope.loan.feeValueId = $scope.formData.feeList[0].id;
	$scope.changeTotalFee = function(feeValueId){
		var index = 0;
		$timeout(function(){
			for(var key in $scope.formData.feeList){
				if($scope.formData.feeList[key]["id"] == feeValueId){
					var obj = $scope.formData.feeList[key];  //数组中的对象
					 index = $scope.formData.feeList.indexOf(obj);  //对象在数组中的位置
				}
			}
			if($scope.formData.feeList){
				$scope.formData.dayRate = $scope.formData.feeList[index].loanDayRate;
				if($scope.loan.contractMoney){
					if($scope.formData.product.mortgageType == 1){  //按天  100为%转化
						$scope.formData.yearFee = $scope.numDiv($scope.numMulti($scope.numMulti($scope.loan.contractMoney,$scope.formData.feeList[index].loanDay),$scope.formData.feeList[index].loanDayRate),100);
					}else{  //按月需要*30
						$scope.formData.yearFee = $scope.numDiv($scope.numMulti($scope.numMulti($scope.numMulti($scope.loan.contractMoney,$scope.formData.feeList[index].loanDay),30),$scope.formData.feeList[index].loanDayRate),100);
					}
				}
				if($scope.formData.product.loanFeeStatus){
					//if($scope.formData.product.loanFeeType == 2){
					//	$scope.formData.serviceRate = $scope.numMulti($scope.formData.feeList[index].loanFeeValue,100);
					//	if($scope.loan.contractMoney){
					//		$scope.formData.serviceFee = $scope.numMulti($scope.loan.contractMoney,$scope.formData.feeList[index].loanFeeValue);
					//	}
					//}else if($scope.formData.product.loanFeeType == 1){  //固定费用
					//	$scope.formData.serviceFee = $scope.formData.feeList[index].loanFeeValue;
					//}
				}
			}
		}, 500);
	}
	$scope.changeTotalFee($scope.loan.feeValueId);
	$scope.selectTime = function(col){
		if(col){
			$scope.loan.feeValueId = col.id;

			$scope.formData.dayRate = col.loanDayRate;
			if($scope.loan.contractMoney){
				if($scope.formData.product.mortgageType == 1){  //按天  100为%转化
					$scope.formData.yearFee = $scope.numDiv($scope.numMulti($scope.numMulti($scope.loan.contractMoney,col.loanDay), col.loanDayRate),100);
				}else{  //按月需要*30
					$scope.formData.yearFee = $scope.numDiv($scope.numMulti($scope.numMulti($scope.numMulti($scope.loan.contractMoney,col.loanDay), 30) , col.loanDayRate),100);
				}
			}
			if($scope.formData.product.loanFeeStatus){
				//if($scope.formData.product.loanFeeType == 2){
				//	$scope.formData.serviceRate = $scope.numMulti(col.loanFeeValue,100);
				//	if($scope.loan.contractMoney){
				//		$scope.formData.serviceFee = $scope.numMulti($scope.loan.contractMoney,col.loanFeeValue);
				//	}
				//}else if($scope.formData.product.loanFeeType == 1){  //固定费用
				//	$scope.formData.serviceFee = col.loanFeeValue;
				//}
			}
		}
	}
	$scope.$watch("loan.validMoney", function(newVal, oldVal, scope, $timeout){
        if(newVal === oldVal){
            return;
        } else {
            var maxRate = Number($scope.formData.product.maxFinanceRate);
            if(!maxRate) maxRate = 1;
    		$scope.formData.maxMoney = $scope.numMulti(maxRate, $scope.loan.validMoney);
    		if($scope.formData.maxMoney > $scope.formData.limit){
    			$scope.formData.maxMoney = $scope.formData.limit;
    		}
        }
    });

    $scope.$watch("loan.bookMoney", function(newVal, oldVal, scope, $timeout){
        if(newVal === oldVal){
            return;
        } else {
            if(Number($scope.loan.bookMoney) >= Number($scope.loan.validMoney)){
            	$("#max").removeClass("ng-invalid").siblings(".error-block").hide();
            } else {
            	$("#max").siblings(".error-block").show();
            }
        }
    });

	$scope.save = function(){
		$scope.btnStatus = true;
		if($scope.loan.files && $scope.loan.files.length){
			$scope.loan.files=angular.toJson($scope.loan.files, true);
		}else{
			$scope.loan.files=null;
		}
        if ($scope.formData.product.dataChannel > 0) {
            $scope.loan.billJson = "";
            angular.forEach($scope.billList, function(item){
                $scope.loan.billJson = $scope.loan.billJson + item.id + ",";
            });
            $scope.loan.billJson = $scope.loan.billJson.substring(0, $scope.loan.billJson.length - 1); 
        }
		postUrl.events('/member/loan/saveReceiveBill', $scope.loan).success(function(_data) {
            $scope.btnStatus = false;
            if(_data.status==200){
                if(_data.data.redirect){
                    window.location.href = "/member/loan/submitResult?id=" + _data.data.id;
                }else {
                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function () {
                        window.location.href = "/member/loan/signContract?loanId=" + _data.data.id + "&productId=" + $scope.loan.productId;
                    });
                }
            }else{
                $scope.loan.files=angular.fromJson($scope.loan.files, true);
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
            }
		});
	}
	//删除凭证附件
    $scope.removeApprove = function(index){
    	$scope.loan.files.splice(index, 1);
    }

    $scope.example = false;
    $scope.toggleExample = function(){
    	$scope.example = !$scope.example
    }

});
// 选择应收账款
    applyApp.controller("selectBillCtrl", function($scope, $http, $timeout, postUrl, scopeService, EventBus){
        $scope.formStruct = {};
        $scope.billData = {};
        $scope.billData.showBill = false; // 默认隐藏
        EventBus.on("requestLoanCtrl", function(evt){
            $scope.billData.showBill = evt.showBill; // 显示应收账单
            $scope.billData.params = evt.params;  // 查询参数
            $scope.billData.bills = evt.bills;  // 账单列表
            $scope.checkAll = false;
            $scope.checkvalue = [];
            if (evt.params.notices) {
                
                angular.forEach($scope.billData.bills, function(i){
                    angular.forEach(evt.params.notices, function(j){
                        if (i.id == j) {
                            $scope.checkvalue.push(i.id);
                            i.checked = true;
                        }
                    })
                })

                if($scope.billData.bills.length === $scope.checkvalue.length){
                    $scope.checkAll = true;
                } else {
                    $scope.checkAll = false;
                }
            }
        });

        // 全选
        $scope.checkvalue = [];
        $scope.selectAll = function(){
            if($scope.checkAll){
                $scope.checkvalue = [];
                angular.forEach($scope.billData.bills, function(i){
                    i.checked = true;
                    $scope.checkvalue.push(i.id);
                })
            } else {
                angular.forEach($scope.billData.bills, function(i){
                    i.checked = false;
                    $scope.checkvalue = [];
                })
            }
        };
        $scope.selectOne = function($event){
            $event.stopPropagation();
            angular.forEach($scope.billData.bills, function(i){
                var index = $scope.checkvalue.indexOf(i.id);
                if(i.checked && index === -1){
                    $scope.checkvalue.push(i.id);
                } else if (!i.checked && index !== -1){
                    $scope.checkvalue.splice(index, 1);
                };
            })

            if($scope.billData.bills.length === $scope.checkvalue.length){
                $scope.checkAll = true;
            } else {
                $scope.checkAll = false;
            }
        }

        $scope.closePopup = function(){
            $scope.billData.showBill = false;
        }

        $scope.tableArray = [];
        $scope.addBillInfo = function(){
            $scope.tableArray = [];
            angular.forEach($scope.billData.bills, function(i){
                if(i.checked){
                    $scope.tableArray.push(i);
                };
            })
            if($scope.checkvalue.length == 0){
                layer.msg("请至少选择一项应收账款", {icon: 2, shade: 0.3, time: 1500});
            } else {
                $timeout(function() {
                    EventBus.fire({type: "selectBillCtrl", list: $scope.tableArray});
                    $scope.billData.showBill = false;
                }, 1000);
            }
        }
    });

applyApp.controller("requestB2BLoanCtrl",function($scope, $http, postUrl, $filter, $timeout){
	$scope.formData = table_struct;
	$scope.process = 1;
	$scope.loan = {};
	$scope.loan.files = [];
	$scope.loan.productId = $scope.formData.productId;


    /*融资需求-年息总额、服务费计算*/
	//初始化
	//贷款金额  loan.contractMoney
	//日利率  formData.dayRate
	//期限id  loan.feeValueId
	//期限  formData.feeList[i]["loanTime"]  1、天，2、月
	//年息总额  formData.yearFee = 贷款金额*90天*日利率
	//服务费率  formData.serviceRate
	//服务费  formData.serviceFee = 1、固定费用，2、贷款金额*服务费率
    $scope.changeTotalFee = function(){
		$timeout(function(){
			if($scope.formData.feeList){
				if($scope.formData.product.loanFeeStatus){
					//if($scope.formData.product.loanFeeType == 2){
					//	if($scope.loan.contractMoney){
					//		$scope.formData.serviceFee = $scope.loan.contractMoney * $scope.formData.serviceRate;
					//	}
					//}else if($scope.formData.product.loanFeeType == 1){  //固定费用
					//	$scope.formData.serviceFee = $scope.formData.serviceVal ;
					//}
				}
			}
		}, 500);
	}

	$scope.save = function(){
		postUrl.events('/member/loan/b2b/saveFinance', $scope.loan).success(function(_data) {
			if(_data.status==200){
				parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
					window.location.href = "/member/loan/b2b/signB2BContract?loanId="+_data.data.id + "&productId=" + $scope.loan.productId;
				});
			}else{
				parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
			}
		});
	}

});

applyApp.controller("requestWHLoanCtrl",function($scope, $http, postUrl, $filter, $timeout){
	$scope.formData = table_struct;
	$scope.process = 1;
	$scope.loan = {};
	$scope.loan.files = [];
	$scope.loan.productId = $scope.formData.productId;
	$scope.loan.transferId = $scope.formData.transferId;

    /*融资需求-年息总额、服务费计算*/
	//初始化
	//贷款金额  loan.contractMoney
	//日利率  formData.dayRate
	//期限id  loan.feeValueId
	//期限  formData.feeList[i]["loanTime"]  1、天，2、月
	//年息总额  formData.yearFee = 贷款金额*90天*日利率
	//服务费率  formData.serviceRate
	//服务费  formData.serviceFee = 1、固定费用，2、贷款金额*服务费率
    $scope.changeTotalFee = function(){
        $timeout(function(){
            if($scope.formData.contractMoney){
                //$scope.formData.serviceFee = $scope.formData.contractMoney * $scope.formData.loanFeeValue;
                $scope.formData.yearFee = $scope.formData.contractMoney * $scope.formData.loanApr / 100 * 365;
                $scope.loan.contractMoney = $scope.formData.contractMoney;
            }
        }, 500);
    }

	$scope.save = function(){
		postUrl.events('/member/warehouse/saveFinance', $scope.loan).success(function(_data) {
			if(_data.status==200){
				parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
					window.location.href = "/member/warehouse/signContract?loanId="+_data.data.id + "&productId=" + $scope.loan.productId;
				});
			}else{
				parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
			}
		});
	}

});


//选择出质仓单
applyApp.controller("qualityCtrl", function($scope, $http, $timeout, postUrl, scopeService, EventBus){
	$scope.formStruct = table_struct;
	$scope.formData = {};

	$scope.formData.receipts = [];
    $scope.formData.contractMoney = 0;  //贷款金额
    $scope.formStruct.product.total = 0;  //仓单总价值

	//选择监管企业
	$scope.changeCompany = function(){
		$scope.formData.receipts = [];
        $scope.formStruct.product.total = 0;
	}

	//选择仓单
	$scope.selectQuality = function(){
		if($scope.formData.company == "" || $scope.formData.company == null || typeof $scope.formData.company == "undefined"){
			layer.msg("请先选择监管企业", {icon: 2, shade: 0.3, time: 1500});
		} else {
			var index = layer.load();
	        postUrl.events("/member/warehouse/selectByCompany", {id: $scope.formData.company}).success(function(_data){
	        	if(_data.status == 200){
	        		$timeout(function() {
			            layer.close(index);
			            //传递控制显示隐藏原有业务信息到copyInfoCtrl
			            EventBus.fire({
                            type: "qualityCtrl",
                            showQuality: true,
                            warehouse: _data.data.depots,
                            tableArray: $scope.formData.receipts,
                            total: $scope.formStruct.product.total
                        });
			        }, 1000);
	        	} else {
		            layer.close(index);
	        		layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
	        	}
	        })
		}
    }

    //展开押品
    $scope.collateralToggle = function(index){
    	$scope.formData.receipts[index].toggle = !$scope.formData.receipts[index].toggle;
    }

    //删除仓单
    $scope.deleteReceipt = function(index){
        $scope.formData.receipts.splice(index, 1);
        $scope.formStruct.product.total = 0;
        for(var key=0; key<$scope.formData.receipts.length; key++){
            $scope.formStruct.product.total += Number($scope.formData.receipts[key]["checked_amount"]);
        }
    }

    //删除附件
    $scope.removeApprove = function(index){
    	$scope.formData.files.splice(index, 1);
    }

    $scope.$watch("formData.contractMoney", function(){
        $scope.formStruct.year = Number($scope.formStruct.product.loanAprStart)/360 / 100 * Number($scope.formData.contractMoney) * Number($scope.formStruct.product.mortgageTimeEnd);
        //$scope.formStruct.fee.service = $scope.formStruct.fee.loan_fee_value * $scope.formData.contractMoney
    })


    $scope.$watch("formStruct.product.total", function(){
	    var tmp = ($scope.formStruct.product.total * $scope.formStruct.product.maxFinanceRate).toFixed(2);
	    //if(tmp >= $scope.formStruct.product.loanAmountStart && tmp <= $scope.formStruct.product.loanAmountEnd){
	    //    $scope.formStruct.product.financing = tmp;  //可融资金额
	    if(tmp > $scope.formStruct.product.loanAmountEnd){
	        $scope.formStruct.product.financing = $scope.formStruct.product.loanAmountEnd;
	    }else if(tmp < $scope.formStruct.product.loanAmountStart){
	        $scope.formStruct.product.financing = $scope.formStruct.product.loanAmountStart;
	    }else{
	    	$scope.formStruct.product.financing = tmp;
	    }

	})

    EventBus.on("selectQualityCtrl", function(evt){
        if(evt.list){
            $scope.formData.receipts = evt.list;
        }
        if(evt.total > 0 || evt.total == 0){
            $scope.formStruct.product.total = evt.total;
        }
    });

    var idArray = [], ids;
	$scope.saveQuality = function(){
        $scope.formData.files = angular.toJson($scope.formData.files_temp,true);
        angular.forEach($scope.formData.receipts, function(item){
            idArray.push(item.id);
            ids = idArray.join(",");
        })
        postUrl.events("/member/warehouse/savePledgeFinance", {productId: $scope.formStruct.productId, contractMoney: $scope.formData.contractMoney, ids: ids}).success(function(_data){
            if(_data.status==200){
                if(_data.data.redirect){
                    window.location.href = "/member/warehouse/submitResult?id=" + _data.data.id;
                }else {
                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function () {
                        window.location.href = "/member/warehouse/signContract?loanId=" + _data.data.id + "&productId=" + _data.data.productId;
                    });
                }
            } else {
                $scope.formData.files = angular.fromJson($scope.formData.files_temp,true);
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
            }
        })
	}
})
//添加出质仓单
applyApp.controller("selectQualityCtrl", function($scope, $http, $timeout, postUrl, scopeService, EventBus){
	$scope.formStruct = table_struct;
	$scope.qualityData = {};

	$scope.qualityData.showQuality = false;  //隐藏选择仓单

	EventBus.on("qualityCtrl", function(evt){
        $scope.qualityData.showQuality = evt.showQuality;  //传递选择仓单显示隐藏的状态
        $scope.formStruct.warehouse = evt.warehouse;  //传递选择仓单的仓库
        $scope.tableArray = evt.tableArray;  //出质仓单列表数据
        $scope.total = evt.total;  //仓单总价值
    });

    //选择仓库
    $scope.changeWarehouse = function(){
    	$scope.checkvalue = [];
    	$scope.checkAll = false;
    	postUrl.events("/member/warehouse/selectWarehouse", {id: $scope.qualityData.warehouse}).success(function(_data){
        	if(_data.status == 200){
        		$scope.formStruct.receipts = _data.data.receipts;
        	} else {
        		layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
        	}
        })
    }

    //展开押品
    $scope.collateralToggle = function(index){
    	$scope.formStruct.receipts[index].toggle = !$scope.formStruct.receipts[index].toggle;
    }


	//全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.formStruct.receipts, function(i){
                i.checked = true;
                $scope.checkvalue.push(i.id);
            })
        } else {
            angular.forEach($scope.formStruct.receipts, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.formStruct.receipts, function(i){
            var index = $scope.checkvalue.indexOf(i.id);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i.id);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.formStruct.receipts.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

	$scope.closePopup = function(){
		$scope.qualityData.showQuality = false;
	}

	$scope.addQualityInfo = function(){
        $scope.collaterals = [];
        var collaterals;
		angular.forEach($scope.formStruct.receipts, function(i){
            if(i.checked){
                $scope.collaterals.push(i.collaterals);
                collaterals = $scope.collaterals.every(function(item, index, array){
                    return (item.length != 0);
                })
                if(collaterals){
                    if($scope.tableArray.length > 0){
                        var result = $scope.tableArray.every(function(item, index, array){
                            return (item.id != i.id);
                        })
                        if(result){
                            $scope.tableArray.push(i);
                            $scope.total += Number(i.checked_amount);
                        }
                    } else {
                        $scope.tableArray.push(i);
                        $scope.total += Number(i.checked_amount);
                    }
                }
            };
        })
        if($scope.checkvalue.length == 0){
        	layer.msg("请至少选择一项仓单", {icon: 2, shade: 0.3, time: 1500});
        } else if(!collaterals){
            layer.msg("没有押品的仓单无法添加", {icon: 2, shade: 0.3, time: 2000});
        } else {
        	$timeout(function() {
	            EventBus.fire({type: "selectQualityCtrl", list: $scope.tableArray, total: $scope.total});
	            $scope.qualityData.showQuality = false;
	        }, 1000);
        }
	}
})
//出质仓单信息确认
applyApp.controller("confirmCtrl", function($scope, $http, $timeout, postUrl, scopeService, EventBus){
	$scope.formStruct = table_struct;
	$scope.formData = table_struct.formData || {};

	//展开押品
    $scope.collateralToggle = function(index){
    	$scope.formStruct.receipts[index].toggle = !$scope.formStruct.receipts[index].toggle;
    }
})

//选择采购货物
applyApp.controller("selectPurchaseCtrl", function($scope, $http, postUrl, scopeService){
	$scope.formStruct = table_struct;
	$scope.formData = {};

	var initbtnText = table_struct.btnText ? table_struct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

	$scope.formData.tableB = [];
	$scope.formStruct.selectLink = [{"category1": []}];  //初始化selectLink
    $scope.number = 0;
    //添加采购清单
	$scope.addPurchase = function(){
		var purchase_list = {}
		$scope.formData.tableB.push(purchase_list);

    	var category = $scope.formStruct.selectLink[0].category1;
		if(category.length == 0){  //初始化selectLink一级分类
			postUrl.events("/member/agpur/category/options", {}).success(function(_data){
	        	if(_data.status == 200){
	        		$scope.formStruct.selectLink[0].category1 = _data.data;  //缓存一级分类
	        	}
	        })
		} else {
			$scope.formStruct.selectLink.push({"category1": []});
			var i = $scope.number;
			$scope.formStruct.selectLink[i].category1 = $scope.formStruct.selectLink[0].category1;
		}
		$scope.number++;

        $scope.getTotal();
	}

	//产品联动
	$scope.getCategory = function(index, type, value){
		switch(type){
			case "category1":
				if(typeof value == "number" || typeof value == "string"){
					postUrl.events("/member/agpur/category/options", {"category1": value}).success(function(_data){
						$scope.formStruct.selectLink[index].category2 = _data.data;
					})
				} else {
					$scope.formStruct.selectLink[index].category2 = [];
	        		$scope.formStruct.selectLink[index].category3 = [];
	        		$scope.formStruct.selectLink[index].product = [];
				}
				break;
			case "category2":
				if(typeof value == "number" || typeof value == "string"){
					postUrl.events("/member/agpur/category/options", {"category2": value}).success(function(_data){
						$scope.formStruct.selectLink[index].category3 = _data.data;
					})
					postUrl.events("/member/agpur/category/products", {"category2": value}).success(function(product){
						$scope.formStruct.selectLink[index].product = product.data;
					})
				} else {
					$scope.formStruct.selectLink[index].category3 = [];
	        		$scope.formStruct.selectLink[index].product = [];
				}
				break;
			case "category3":
				if(typeof value == "number" || typeof value == "string"){
					postUrl.events("/member/agpur/category/products", {"category3": value}).success(function(product){
						$scope.formStruct.selectLink[index].product = product.data;
					})
				} else {
					$scope.formStruct.selectLink[index].product = [];
				}
				break;
		}
	}

	$scope.productChange = function(index,pur){
		var prod = {};
        var product = $scope.formStruct.selectLink[index].product;
		for(var i=0;i<product.length;i++){
			if(product[i].value == pur.goodsProductId){
				prod = product[i];
				break;
			}
		}
		pur.price = prod.last_price;

        $scope.getAmount(index, pur);
	}

    //清单总价
    $scope.getAmount = function(index, pur){
        var price = Number($scope.formData.tableB[index].price) ? Number($scope.formData.tableB[index].price) : 0;
        var num = Number($scope.formData.tableB[index].num) ? Number($scope.formData.tableB[index].num) : 0;
        $scope.formData.tableB[index].totalPay = (price * num).toFixed(2);

        $scope.getTotal();
    }

    //商品总价值、融资总额
    $scope.getTotal = function(){
        //console.log(2);
        $scope.formStruct.product.total = 0;
        for(var i=0, len=$scope.formData.tableB.length; i<len; i++){
            $scope.formStruct.product.total += Number($scope.formData.tableB[i]["totalPay"]);
        }
        if($scope.formStruct.product.depositType == 0){
            $scope.formStruct.product.financing = $scope.formStruct.product.total - $scope.formStruct.product.total * $scope.formStruct.product.minFinanceRate/100.0;
        }
        if($scope.formStruct.product.useCreditLimit == 1 && $scope.formStruct.product.financing > $scope.formStruct.limit.unusedLimit){
            $scope.formStruct.product.financing = $scope.formStruct.limit.unusedLimit;
        }
    }

	//删除采购清单
	$scope.delPurchase = function(index){
		$scope.formData.tableB.splice(index, 1);

		$scope.number--;  //重置selectLink的添加序号
		if($scope.formStruct.selectLink.length == 1){
			$scope.formStruct.selectLink = [{"category1": []}];
		} else {
			$scope.formStruct.selectLink.splice(index, 1);
		}

        $scope.getTotal();
	}

	$scope.savePurchase = function(){
		$scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;

        var subFormData = {};
        for(var att in $scope.formData){
        	if(angular.isArray($scope.formData[att])){
        		subFormData[att] = angular.toJson($scope.formData[att],true);
        	}else {
        		subFormData[att] = $scope.formData[att];
        	}
        }
        subFormData.productId = $scope.formStruct.productId;
        subFormData.productName = $scope.formStruct.productName;

        postUrl.events("/member/agpur/loan/create", subFormData).success(function(_data){
            if(_data.status == 200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function(){
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    window.location.href = "/member/agpur/loan/submitCheck";
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function(){
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
	}






	/*
    FileReader共有4种读取方法：
    1.readAsArrayBuffer(file)：将文件读取为ArrayBuffer。
    2.readAsBinaryString(file)：将文件读取为二进制字符串
    3.readAsDataURL(file)：将文件读取为Data URL
    4.readAsText(file, [encoding])：将文件读取为文本，encoding缺省值为'UTF-8'
	*/
    var wb;//读取完成的数据
    var rABS = false; //是否将文件读取为二进制字符串

    $scope.importf = function(obj) {//导入
        if(!obj.files) {
            return;
        }
        var f = obj.files[0];
        var reader = new FileReader();
        reader.onload = function(e) {
            var data = e.target.result;
            if(rABS) {
                wb = XLSX.read(btoa(fixdata(data)), {//手动转化
                    type: 'base64'
                });
            } else {
                wb = XLSX.read(data, {
                    type: 'binary'
                });
            }
            //wb.SheetNames[0]是获取Sheets中第一个Sheet的名字
            //wb.Sheets[Sheet名]获取第一个Sheet的数据
            // document.getElementById("demo").innerHTML= JSON.stringify( XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]) );
            $scope.$apply(function() {
               $scope.formData.tableB = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]) ;
            });
        };
        if(rABS) {
            reader.readAsArrayBuffer(f);
        } else {
            reader.readAsBinaryString(f);
        }
    }

    function fixdata(data) { //文件流转BinaryString
        var o = "",
            l = 0,
            w = 10240;
        for(; l < data.byteLength / w; ++l) o += String.fromCharCode.apply(null, new Uint8Array(data.slice(l * w, l * w + w)));
        o += String.fromCharCode.apply(null, new Uint8Array(data.slice(l * w)));
        return o;
    }
})


//头部专用控制器
applyApp.controller("headUerCtrl", function($scope, $http, postUrl){
	$scope.formData = table_struct;
})

//ng-bind-html后台返回html数据格式的过滤器
applyApp.filter("to_trusted", ["$sce", function($sce){
    return function(text){
        return $sce.trustAsHtml(text || "");
    };
}]);
module.exports = applyApp;
