
require("../sass/credit.scss");

require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var creditApp = angular.module("app", ["validation", "validation.rule", "dyDir", "dyService"]);
creditApp.controller("headUerCtrl", function($scope, $http, postUrl){
	$scope.formData = table_struct;
});
creditApp.controller("creditIndexCtrl", function($scope, $http, postUrl){
	$scope.formData = table_struct;
	$scope.formData.currentStatus = 1;
	$scope.selectTab = function(type){
		$scope.formData.currentStatus = type;
	}
	if($scope.formData.account){
		$scope.accountBalance = $scope.formData.account.accBalance;
	}
	//开户跳转  判断未实名认证
	$scope.openBank=function(){
		if($scope.formData.approveStatus){
			window.open("/member/api/trust/openBank");
		}else{
			parent.layer.msg("企业还未实名认证,即将跳转到实名认证页面", {icon: 1, shade: 0.3, time: 1500},function(){
                parent.location.href = "/member/manager/companySafe";
				parent.layer.closeAll();
			});
		}
	}
    //转出
	$scope.toCash=function(){
		postUrl.events("/member/manager/bindBankCard/countCard", null).success(function (_data) {
	        if(_data.status==200){
	        	if(_data.data.result){
	        	    parent.location.href="/member/manager/companyTransfer";
	        	}else{
	        	  	parent.layer.msg("还未添加银行卡,即将跳转到添加银行卡页面", {icon: 1, shade: 0.3, time: 1500},function(){
	                    parent.location.href = "/member/manager/bindBankCard/add";
						parent.layer.closeAll();
					});
				}
	        }else{
                layer.msg(_data.description, {icon: 2, time: 1500});
	        }
	    })
    }
    //请求本地接口的余额(刷新页面触发)
	$scope.queryLocalAccount=function(){
    	postUrl.events("/member/manager/accBalance", null).success(function (_data) {
            if(_data.status == 200){
            	$scope.accountBalance = _data.data.acc_balance;
                $scope.money = _data.data.acc_balance;
            	if(_data.data.update_time){
            		$scope.updateTime = _data.data.update_time*1000;
                }
                if(_data.data.account&&$scope.money<=0){//新开户刷新
	                $scope.refreshMoney();
	            }
            }else{
            	$scope.accountBalance = 0.00;  //_data.description;
            	parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 2000},function(){
					parent.layer.closeAll();
				});
            }
        })
    }
    //显示金额
    $scope.showMoney = true;
    $scope.amountTotal = $scope.formData.amountTotal;
    $scope.toggleMoney = function(){
        $scope.showMoney = !$scope.showMoney;
        if($scope.showMoney){
            $scope.accountBalance = $scope.money;
            $scope.formData.amountTotal = $scope.amountTotal;
        } else {
            $scope.accountBalance = "******";
            $scope.formData.amountTotal = "******";
        }
    }
    //请求银行接口的余额(刷新按钮触发)
	$scope.refreshMoney = function(){
        $scope.refreshStatus = true;
    	postUrl.events("/member/api/trust/qcard", {}).success(function(_data){
            if(_data.status == 200){
                $scope.refreshStatus = false;
            	$scope.accountBalance = _data.data;
            	$scope.updateTime = new Date().getTime();
                $scope.money = _data.data;
            }else{
                $scope.refreshStatus = false;
                layer.msg(_data.description, {icon: 2, time: 1500});
            }
        })
    }
    //进度条的位置
    $scope.$watch("accountBalance + formData.amountTotal", function(){
        $scope.processBar = Number($scope.accountBalance) / (Number($scope.accountBalance) + Number($scope.formData.amountTotal)) * 180;  //半圆180deg
        $scope.processBar = Number($scope.money) / (Number($scope.money) + Number($scope.amountTotal)) * 180;  //半圆180deg
    })
});

creditApp.controller("bankInfoCtrl", function($scope, $http, postUrl){
	$scope.formData = formData;
	$scope.toAddBankCard=function(id){
        window.location.href="/member/manager/bindBankCard/add?id="+(id==undefined?'':id);
    }

    //删除银行卡
    $scope.deleteBank = function(id){
        parent.layer.confirm("是否确认删除？", {
            time: 0, //不自动关闭
            icon: 3,
            shade: 0.3,
            title: "确认",
            btn: ["确定", "取消"]
        }, function(){
            postUrl.events("/member/manager/bindBankCard/delete", {id: id}).success(function(_data){
                if(_data.status == 200){
                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                        window.location.reload();
                        parent.layer.closeAll();
                    });
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                        //window.location.reload();
                    });
                }
            });
        })
    }
});

creditApp.controller("addBankCtrl", function($scope, $http, postUrl,scopeService){
	$scope.formData = table_struct;
	$scope.list = {};
	$scope.list.linklist=table_struct.linklist;
	$scope.list.dataparams=[{'pid':'pid_province',"index":0},{'pid':'pid_city',"index":1},{'pid':'areaId',"index":2}];
	
	var initbtnText = table_struct.btnText ? table_struct.btnText : "提交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

	$scope.submit = function(){
		$scope.btnText = initbtnText + "中...";
        $scope.btnStatus = true;
        if($scope.formData.card.account != $scope.formData.card.reaccount){
            parent.layer.msg("请填写相同的银行卡卡号", {icon: 2, shade: 0.3, time: 1500}, function(){
                scopeService.safeApply($scope, function () {
                    $scope.btnText = initbtnText;
                    $scope.btnStatus = false;
                });
            });
            return false;
        }
		postUrl.events('/member/manager/bindBankCard/save', $scope.formData.card).success(function(_data) {
			if(_data.status==200){
				parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
					scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    parent.location.href = "/member/manager/bindBankCard/list";
					parent.layer.closeAll();
				});
			}else{
				parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
					scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
				});
			}
		});
	}
});


//编辑数据
creditApp.controller("editCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    $scope.formStruct = formStruct;
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    if($scope.formlist){
    	for(var i=0,len=$scope.formlist.length;i<len;i++){
	        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
	            var dataResult = [];
	            $.each($scope.formlist[i].options,function(n,v){
	                dataResult.push({"text":v,"value":n});
	            });
	            //console.log(dataResult);
	            $scope.formlist[i].options = dataResult;
	        }
	    }
    }
    
     //控制表单内容显示隐藏
    var hideAndShow = {
        init: function () {
            var that = this,
                l = $scope.formlist.length;
            for (var i = 0; i < l; i++) {
                if ($scope.formlist[i].haschild) {
                    that.hideFn(i);
                }
            }
        },
        hideFn: function (i) {
            var n = "",
                m = "",
                lm = "",
                lms=[]; //用于存放复选框的值的数组
            m = $scope.formlist[i].name;

            $scope.$watch("formData." + m + "", function () {
                if($scope.formlist[i].type=="checkbox"&&$scope.formData[m]){ //适用于checkbox的联动，scope.formData[m]为一个数组
                    lms = [];
                    $.each($scope.formData[m], function (n, e) {
                        $.each($scope.formlist[i].options, function (n1, e1) {
                            if(e == e1.value&&typeof e1.childmark!="undefined"){
                                lms.push(e1.childmark); //先将复选框的所有选中的值存储起来
                            }
                        });
                    });
                    for (var k in $scope.formlist) {
                        if ($scope.formlist[k].parentname == m) {
                            if(lms.in_array($scope.formlist[k].mark)){
                                $scope.formlist[k].hide = false;
                            }else{
                                $scope.formlist[k].hide = true;
                            }
                        }
                    }
                }else{
                    $.each($scope.formlist[i].options, function (n, e) {
                        if($scope.formData[m] == $scope.formlist[i].options[n].value)
                        lm = $scope.formlist[i].options[n].childmark;
                    });
                    for (var k in $scope.formlist) {
                        if ($scope.formlist[k].parentname == m) {
                            if ($scope.formlist[k].mark == lm) {
                                $scope.formlist[k].hide = false;
                            } else {
                                $scope.formlist[k].hide = true;
                            }
                        }
                    }
                }
            }, true);
        }
    };
    if(data.hasShowandhide){
        hideAndShow.init(); //初始化控制显示隐藏联动，可在后台构建表单的时候，当有显示隐藏存在表单的时候，传一个字段过来，方便判断，提高js性能
    }
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
  //删除上传文件
    $scope.removeFile = function(){
    	$scope.formData.import_file = {};
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        $scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    parent.location.reload();
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
   
});

creditApp.controller("creditFinanceCtrl", function($scope, $http, postUrl){
    $scope.formData = formData;
    $scope.selectBusiness = function(id, code){
    	
    	if (Number(code) == 1) { // 应收
    		var url="/member/realname/companyApprove";
    		if($scope.formData.company.approveStatus==2||$scope.formData.company.approveStatus==4){
    			parent.layer.msg('请先进行实名认证',{icon: 2,shade: 0.3,time:2000},function(){
    				window.location.href = "/member/manager/companySafe";
    			});
    		}else if($scope.formData.company.approveStatus==3){
    			if(!$scope.formData.isOpenBank){
    				window.open("/member/api/trust/openBank");
    				return;
    			}
    			window.location.href = "/member/loan/selectCoreCompany?businessId=" + id;
    		}else{
    			window.location.href = url;
    		}
    	} else {
    		window.location.href = "/member/manager/companyFinance?businessId=" + id;
    	}
    }
    
    $scope.selectProduct=function(productId,productName,type){
        var url="/member/realname/companyApprove";
        if($scope.formData.company.approveStatus==2||$scope.formData.company.approveStatus==4){
            parent.layer.msg('请先进行实名认证',{icon: 2,shade: 0.3,time:2000},function(){
                window.location.href = "/member/manager/companySafe";
            });
        }else if($scope.formData.company.approveStatus==3){
            if(!$scope.formData.isOpenBank){
                window.open("/member/api/trust/openBank");
                return;
            }
            if (type == 1) {
            	window.location.href = "/member/loan/requestLoan?productId=" + productId;
            } else {
            	window.location.href = "/member/loan/selectCoreCompany?productId="+productId+"&productName="+productName;
            }
        }else{
            window.location.href = url;
        }
    }
});

creditApp.controller("creditLoanCtrl", function($scope, $http, postUrl){
	$scope.formData = table_struct;
	$scope.search={};
	$scope.search.businessTypeId=$scope.formData.businessTypes[0].id;
	$scope.search.selectDate=0;
	$scope.selectTab=function(typeId){
		$scope.search.businessTypeId=typeId;
		var url="member/manager/companyLoan/listData";
		$scope.getData(url,$scope.search);
	}
	$scope.selectTime=function(selDate){
		$scope.search.selectDate=selDate;
		var url="member/manager/companyLoan/listData";
		$scope.getData(url,$scope.search);
	}
	$scope.selectTimeBet=function(){
		var url="member/manager/companyLoan/listData";
		$scope.getData(url,$scope.search);
	}
    $scope.srcData = {};
    $scope.filterListData = {};
    /****************
        *获取列表数据
        *params：1、url =>请求地址；
                 2、params：参数，
                    （1）、srcData =>搜索框数据；
                    （2）、filterListData =>筛选内容数据；
                    （3）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            layer.closeAll("loading");
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct != "undefined" && table_struct != ""){
    	/*if(table_struct.list.search && angular.isArray(table_struct.list.search)){
    		$scope.search = table_struct.list.search[0]; //搜索框
    	}else{
    		$scope.search = table_struct.list.search; //搜索框
    	}*/
        $scope.showPager = table_struct.list.pager; //是否显示分页
        $scope.pageOptions = table_struct.list.page_options; //分页条数的配置项
        $scope.tableHeader = table_struct.list.tableHeader; //列表表头
        $scope.rowLink = table_struct.list.rowLink;  //操作栏中的多个操作处理

    $scope.formList = table_struct.list.header_data;
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

        $scope.listUrl = table_struct.list.listUrl;
        if($scope.listUrl){
            $scope.getData($scope.listUrl, $scope.search); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": currentPage, "limit": itemsPerPage}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": 1, "limit": itemsPerPage}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    /*** 处理搜索栏搜索数据 ***/
    $scope.srcSubmit = function(){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": $scope.currentPage || 1, "limit": $scope.itemsPerPage || 10}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    $scope.srcKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            $scope.srcSubmit();
        }
    }
});

creditApp.controller("loanDetailCtrl", function($scope, $http, postUrl){
    $scope.formData = table_struct;
    
    $scope.save = function(){
        $scope.btnStatus = true;
        postUrl.events('/member/manager/companyCheck/confirmsettle', {id : $scope.formData.id}).success(function(_data) {
            $scope.btnStatus = false;
            if(_data.status==200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
                	parent.location.reload();
                });
            }else{
                $scope.loan.files=angular.fromJson($scope.loan.files, true);
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
            }
        });
    }
});

creditApp.controller("loanWHDetailCtrl", function($scope, $http, postUrl){
    $scope.formStruct = table_struct;
    $scope.formData = table_struct.form_data;
});

creditApp.controller("creditRepaymentCtrl", function($scope, $http, postUrl,$sce,$filter){
    $scope.formData = table_struct;
    //待还明细
        
    $scope.changeType=function(type){
        var url = '/member/manager/companyRepayment/list/'+type;
        window.location.href=url;
        //$scope.getData(url);
    }

    $scope.srcData = {};
    $scope.filterListData = {};
    /****************
        *获取列表数据
        *params：1、url =>请求地址；
                 2、params：参数，
                    （1）、srcData =>搜索框数据；
                    （2）、filterListData =>筛选内容数据；
                    （3）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            layer.closeAll("loading");
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct != "undefined" && table_struct != ""){
        if(table_struct.list.search && angular.isArray(table_struct.list.search)){
            $scope.search = table_struct.list.search[0]; //搜索框
        }else{
            $scope.search = table_struct.list.search; //搜索框
        }
        $scope.showPager = table_struct.list.pager; //是否显示分页
        $scope.pageOptions = table_struct.list.page_options; //分页条数的配置项
        $scope.tableHeader = table_struct.list.tableHeader; //列表表头
        $scope.rowLink = table_struct.list.rowLink;  //操作栏中的多个操作处理

        $scope.formData = table_struct;
        $scope.formList = table_struct.list.header_data;
        var initformdata = $scope.formList;
        if(initformdata != ""){
            for (var key in initformdata) {
                $scope.formData[key] = initformdata[key];
            }
        }

        $scope.listUrl = table_struct.list.listUrl;
        if($scope.listUrl){
            $scope.getData($scope.listUrl, $scope.formData); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": currentPage, "limit": itemsPerPage}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": 1, "limit": itemsPerPage}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    /*** 处理搜索栏搜索数据 ***/
    $scope.srcSubmit = function(){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": $scope.currentPage || 1, "limit": $scope.itemsPerPage || 10}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    $scope.srcKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            $scope.srcSubmit();
        }
    }
    
    /*** 处理自定义列 ***/
    $scope.render = function(value,col,list){
        if(col.name == 'loan_contract_no'){
            if(list.business_type == 1){
                return $sce.trustAsHtml('<a href="/member/loan/view?id='+list.debit_id+'" class="tool"  target="_blank">'+list['loan_contract_no']+'</a><br>'+$filter('number')(list['loan_apr'],3)+'% '+list['loan_repay_type']);
            }else if(list.business_type == 3){
                return $sce.trustAsHtml('<a href="/member/warehouse/viewWH?id='+list.debit_id+'" class="tool"  target="_blank">'+list['loan_contract_no']+'</a><br>'+$filter('number')(list['loan_apr'],3)+'% '+list['loan_repay_type']);
            }else if(list.business_type == 4){
            	return $sce.trustAsHtml('<a href="/member/agpur/loan/viewAG?id='+list.debit_id+'" class="tool"  target="_blank">'+list['loan_contract_no']+'</a><br>'+$filter('number')(list['loan_apr'],3)+'% '+list['loan_repay_type']);
            }else{
                return $sce.trustAsHtml('<a href="/member/loan/b2b/viewB2B?id='+list.debit_id+'" class="tool"  target="_blank">'+list['loan_contract_no']+'</a><br>'+$filter('number')(list['loan_apr'],3)+'% '+list['loan_repay_type']);
            }
        }
        return value;
    }
   
});
creditApp.controller("creditCheckCtrl", function($scope, $http, postUrl,$sce,$filter){
	$scope.formData = table_struct;
	//待还明细
		
    $scope.changeType=function(type){
    	var url = '/member/manager/companyCheck/check/'+type;
    	window.location.href=url;
    	//$scope.getData(url);
    }

	$scope.srcData = {};
    $scope.filterListData = {};
    /****************
        *获取列表数据
        *params：1、url =>请求地址；
                 2、params：参数，
                    （1）、srcData =>搜索框数据；
                    （2）、filterListData =>筛选内容数据；
                    （3）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            layer.closeAll("loading");
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct != "undefined" && table_struct != ""){
    	if(table_struct.list.search && angular.isArray(table_struct.list.search)){
    		$scope.search = table_struct.list.search[0]; //搜索框
    	}else{
    		$scope.search = table_struct.list.search; //搜索框
    	}
        $scope.showPager = table_struct.list.pager; //是否显示分页
        $scope.pageOptions = table_struct.list.page_options; //分页条数的配置项
        $scope.tableHeader = table_struct.list.tableHeader; //列表表头
        $scope.rowLink = table_struct.list.rowLink;  //操作栏中的多个操作处理

        $scope.formData = table_struct;
        $scope.formList = table_struct.list.header_data;
        var initformdata = $scope.formList;
        if(initformdata != ""){
            for (var key in initformdata) {
                $scope.formData[key] = initformdata[key];
            }
        }

        $scope.listUrl = table_struct.list.listUrl;
        if($scope.listUrl){
            $scope.getData($scope.listUrl, $scope.formData); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": currentPage, "limit": itemsPerPage}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": 1, "limit": itemsPerPage}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    /*** 处理搜索栏搜索数据 ***/
    $scope.srcSubmit = function(){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": $scope.currentPage || 1, "limit": $scope.itemsPerPage || 10}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    $scope.srcKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            $scope.srcSubmit();
        }
    }
    
});

creditApp.controller("warehouseManagerCtrl", function($scope, $http, postUrl,$sce,$filter){
	$scope.formStruct = table_struct;
	$scope.formData = {};
		
    $scope.changeType=function(type){
    	var url = '/member/warehouse/receipt/list/'+type;
    	window.location.href=url;
    	//$scope.getData(url);
    }
    
    $scope.collateralToggle = function(index){
    	$scope.tableB[index]["toggle"] = !$scope.tableB[index]["toggle"];
    }

    $scope.srcData = {};
    /****************
        *获取列表数据
        *params：1、url =>请求地址；
                 2、params：参数，
                    （1）、srcData =>搜索框数据；
                    （2）、filterListData =>筛选内容数据；
                    （3）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            layer.closeAll("loading");
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct != "undefined" && table_struct != ""){

        $scope.listUrl = table_struct.listUrl;
        if($scope.listUrl){
            $scope.getData($scope.listUrl, $scope.formData); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": currentPage, "limit": itemsPerPage}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": 1, "limit": itemsPerPage}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    
});

creditApp.controller("repayInfoCtrl", function($scope, $http, postUrl){
    $scope.formStruct = table_struct;
    $scope.btnStatus = false;
    //展开押品
    $scope.collateralToggle = function(index){
        $scope.formStruct.receipts[index].toggle = !$scope.formStruct.receipts[index].toggle;
    }
    //全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.formStruct.receipts, function(i){
                i.checked = true;
                $scope.checkvalue.push(i.id);
            })
        } else {
            angular.forEach($scope.formStruct.receipts, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.formStruct.receipts, function(i){
            var index = $scope.checkvalue.indexOf(i.id);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i.id);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.formStruct.receipts.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

    //还款
    $scope.repaySub = function(){
        $scope.btnStatus = true;
        var ids = $scope.checkvalue.join(",");
        if(ids == "" || ids == ''){
            ids = $scope.formStruct.ids;
        }
        var amount=$scope.formStruct.amount;
        
        if($scope.formStruct.useTrust){
            parent.location.href="/member/api/trust/transfer?id="+$scope.formStruct.period_id + "&ids=" + ids+"&amount="+amount;
        }else{
            var url = "/member/manager/companyRepayment/repay";
            if($scope.formStruct.buss_type == '2'){
                url = 'member/loan/b2b/repay';
            }
            postUrl.events(url,{'periodId':$scope.formStruct.period_id,'ids':ids,"amount":amount}).success(function(_data) {
                $scope.btnStatus = false;
                if(_data.status==200){
                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
                        parent.location.reload();
                    });
                }else{
                    parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            });
        }
    };

    //解压还款
    $scope.repayWH = function(){
        $scope.btnStatus = true;
        var ids = $scope.checkvalue.join(",");
        if(ids == "" || ids == ''){
            ids = $scope.formStruct.ids;
        }
        if($scope.formStruct.useTrust && $scope.formStruct.repay.principal){
            parent.location.href="/member/warehouse/receipt/repayByTrust?debitId="+$scope.formStruct.debit_id + "&ids=" + ids;
        }else{
            postUrl.events('/member/warehouse/receipt/repay',{'debitId':$scope.formStruct.debit_id,'ids':ids}).success(function(_data) {
                $scope.btnStatus = false;
                if(_data.status==200){
                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500},function(){
                        parent.location.reload();
                    });
                }else{
                    parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            });
        }
    };

    $scope.next = function(){
        if($scope.checkvalue.length > 0){
            var ids = $scope.checkvalue.join(",");
            postUrl.events("/member/warehouse/receipt/repayWH", {ids: ids, id: $scope.formStruct.period_id}).success(function(_data){
                if(_data.status == 200){
                    $scope.formStruct.normal = _data.data.normal;
                    $scope.formStruct.repay = _data.data.repay;
                    $scope.formStruct.receipts = _data.data.receipts;
                }
            })
        } else {
            parent.layer.msg("请至少选择一个仓单", {icon: 2, time: 1500, shade: 0.3});
        }
    }
});

//资金管理
creditApp.controller("creditFundsCtrl", function($scope, $http, postUrl,$sce){
	$scope.formData = table_struct;	
	$scope.search={};
	if($scope.formData.currentStatus==1){
		$scope.search.type=99;
	}else if($scope.formData.currentStatus==2){
		$scope.search.type=1;
	}else if($scope.formData.currentStatus==3){	
		$scope.search.type=0;
	}

	$scope.selectTab=function(type){
		var url="";
		if(type==1){
			url="/member/manager/companyFunds/list";
		}else if(type==2){
			url="/member/manager/companyFunds/tradeIn";
		}else if(type==3){
			url="/member/manager/companyFunds/tradeOut";
		}
		window.location.href =url;
	}

	$scope.search.selectDate=0;
	$scope.selectTime=function(selDate){
		$scope.search.selectDate=selDate;
		var url="member/manager/companyFunds/listData/"+$scope.search.type;
		if($scope.search.type==0){
			url="member/manager/companyFunds/tradeOutData";
		}
		$scope.getData(url,$scope.search);
	}
	$scope.selectTimeBet=function(){
		var url="member/manager/companyFunds/listData/"+$scope.search.type;
		if($scope.search.type==0){
			url="member/manager/companyFunds/tradeOutData";
		}
		$scope.getData(url,$scope.search);
	}
    $scope.srcData = {};
    $scope.filterListData = {};
    /****************
        *获取列表数据
        *params：1、url =>请求地址；
                 2、params：参数，
                    （1）、srcData =>搜索框数据；
                    （2）、filterListData =>筛选内容数据；
                    （3）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            layer.closeAll("loading");
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct != "undefined" && table_struct != ""){
    	/*if(table_struct.list.search && angular.isArray(table_struct.list.search)){
    		$scope.search = table_struct.list.search[0]; //搜索框
    	}else{
    		$scope.search = table_struct.list.search; //搜索框
    	}*/
        $scope.showPager = table_struct.list.pager; //是否显示分页
        $scope.pageOptions = table_struct.list.page_options; //分页条数的配置项
        $scope.tableHeader = table_struct.list.tableHeader; //列表表头
        $scope.rowLink = table_struct.list.rowLink;  //操作栏中的多个操作处理

        $scope.formData = table_struct;
        $scope.formList = table_struct.list.header_data;
        var initformdata = $scope.formList;
        if(initformdata != ""){
            for (var key in initformdata) {
                $scope.formData[key] = initformdata[key];
            }
        }

        $scope.listUrl = table_struct.list.listUrl;
        if($scope.listUrl){
            $scope.getData($scope.listUrl, $scope.search); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": currentPage, "limit": itemsPerPage}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": 1, "limit": itemsPerPage}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    /*** 处理搜索栏搜索数据 ***/
    $scope.srcSubmit = function(){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": $scope.currentPage || 1, "limit": $scope.itemsPerPage || 10}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    $scope.srcKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            $scope.srcSubmit();
        }
    }
    
    /*** 处理自定义列 ***/
    $scope.render = function(value,col,list){
        if(col.name == 'bank_name_type'){
        	if(list['bank_name_type']&&list['account']){
        		return $sce.trustAsHtml(list['bank_name_type']+'<br>'+list['account']);
        	}
        }
        return value;
    }
});

//价格行情
creditApp.controller("creditPriceCtrl", function($scope, $http, postUrl,$sce){
	$scope.formData = table_struct;	
	$scope.search={};
	if($scope.formData.currentStatus==1){
		$scope.search.type=99;
	}else if($scope.formData.currentStatus==2){
		$scope.search.type=1;
	}else if($scope.formData.currentStatus==3){	
		$scope.search.type=0;
	}

	$scope.selectTab=function(type){
		var url="";
		if(type==1){
			url="/member/manager/companyFunds/list";
		}else if(type==2){
			url="/member/manager/companyFunds/tradeIn";
		}else if(type==3){
			url="/member/manager/companyFunds/tradeOut";
		}
		window.location.href =url;
	}

	$scope.search.selectDate=0;
	$scope.selectTime=function(selDate){
		$scope.search.selectDate=selDate;
		var url="member/warehouse/product/listData/"+$scope.search.type;
		if($scope.search.type==0){
			url="member/manager/companyFunds/tradeOutData";
		}
		$scope.getData(url,$scope.search);
	}
	$scope.selectTimeBet=function(){
		var url="member/warehouse/product/listData/"+$scope.search.type;
		if($scope.search.type==0){
			url="member/manager/companyFunds/tradeOutData";
		}
		$scope.getData(url,$scope.search);
	}
    $scope.srcData = {};
    $scope.filterListData = {};
    /****************
        *获取列表数据
        *params：1、url =>请求地址；
                 2、params：参数，
                    （1）、srcData =>搜索框数据；
                    （2）、filterListData =>筛选内容数据；
                    （3）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            layer.closeAll("loading");
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct != "undefined" && table_struct != ""){
    	/*if(table_struct.list.search && angular.isArray(table_struct.list.search)){
    		$scope.search = table_struct.list.search[0]; //搜索框
    	}else{
    		$scope.search = table_struct.list.search; //搜索框
    	}*/
        $scope.showPager = table_struct.list.pager; //是否显示分页
        $scope.pageOptions = table_struct.list.page_options; //分页条数的配置项
        $scope.tableHeader = table_struct.list.tableHeader; //列表表头
        $scope.rowLink = table_struct.list.rowLink;  //操作栏中的多个操作处理

        $scope.formData = table_struct;
        $scope.formList = table_struct.list.header_data;
        var initformdata = $scope.formList;
        if(initformdata != ""){
            for (var key in initformdata) {
                $scope.formData[key] = initformdata[key];
            }
        }

        $scope.listUrl = table_struct.list.listUrl;
        if($scope.listUrl){
            $scope.getData($scope.listUrl, $scope.search); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": currentPage, "limit": itemsPerPage}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": 1, "limit": itemsPerPage}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    /*** 处理搜索栏搜索数据 ***/
    $scope.srcSubmit = function(){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": $scope.currentPage || 1, "limit": $scope.itemsPerPage || 10}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    $scope.srcKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            $scope.srcSubmit();
        }
    }
    
    /*** 处理自定义列 ***/
    $scope.render = function(value,col,list){
        if(col.name == 'bank_name_type'){
        	if(list['bank_name_type']&&list['account']){
        		return $sce.trustAsHtml(list['bank_name_type']+'<br>'+list['account']);
        	}
        }
        return value;
    }
});

//合同信息
creditApp.controller("contractInfoCtrl", function($scope, $http, postUrl,$sce){
    $scope.formData = table_struct;
    $scope.search={};
    $scope.search.productId = $scope.formData.productId;
    $scope.search.loanContractNo = $scope.formData.loanContractNo;
    $scope.search.signStatus = $scope.formData.signStatus;
    $scope.selectTimeBet=function(){
        var url="member/manager/contract/listData";
        $scope.getData(url,$scope.search);
    }
    $scope.srcData = {};
    $scope.filterListData = {};
    /****************
     *获取列表数据
     *params：1、url =>请求地址；
     2、params：参数，
     （1）、srcData =>搜索框数据；
     （2）、filterListData =>筛选内容数据；
     （3）、page =>页码参数
     *****************/
    $scope.getData = function(url, params){
        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            layer.closeAll("loading");
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct != "undefined" && table_struct != ""){
        /*if(table_struct.list.search && angular.isArray(table_struct.list.search)){
         $scope.search = table_struct.list.search[0]; //搜索框
         }else{
         $scope.search = table_struct.list.search; //搜索框
         }*/
        $scope.showPager = table_struct.list.pager; //是否显示分页
        $scope.pageOptions = table_struct.list.page_options; //分页条数的配置项
        $scope.tableHeader = table_struct.list.tableHeader; //列表表头
        $scope.rowLink = table_struct.list.rowLink;  //操作栏中的多个操作处理

        $scope.formData = table_struct;
        $scope.formList = table_struct.list.header_data;
        var initformdata = $scope.formList;
        if(initformdata != ""){
            for (var key in initformdata) {
                $scope.formData[key] = initformdata[key];
            }
        }

        $scope.listUrl = table_struct.list.listUrl;
        if($scope.listUrl){
            $scope.getData($scope.listUrl, $scope.search); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": currentPage, "limit": itemsPerPage}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": 1, "limit": itemsPerPage}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    /*** 处理搜索栏搜索数据 ***/
    $scope.srcSubmit = function(){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": $scope.currentPage || 1, "limit": $scope.itemsPerPage || 10}, $scope.search);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    $scope.srcKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            $scope.srcSubmit();
        }
    }

    /*** 处理自定义列 ***/
    $scope.render = function(value,col,list){
        if(col.name == 'bank_name_type'){
            if(list['bank_name_type']&&list['account']){
                return $sce.trustAsHtml(list['bank_name_type']+'<br>'+list['account']);
            }
        }
        return value;
    }
});


//价格行情-监测图表
creditApp.controller("priceChartCtrl", function($scope, $http, postUrl){
    $scope.formData = table_struct;
    $scope.search = {};
    $scope.search.selectDate = 1;
    $scope.search.id = $scope.formData.id;

    $scope.getData = function(url, params){
        postUrl.events("/" + url, params).success(function(_data){
            $scope.chartData = _data.data;
            $scope.price_Data = {
                title: {
                    text: "价格行情监测图表",
                    x: "center"
                },
                tooltip : {
                    trigger: "axis",
                    axisPointer: {
                        type: "cross",
                        label: {
                            backgroundColor: "#6a7985"
                        }
                    }
                },
                legend: {
                    data:[$scope.chartData.name],
                    bottom: "bottom"
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                grid: {
                    left: "3%",
                    right: "3%",
                    bottom: "10%",
                    containLabel: true
                },
                xAxis : [
                    {
                        type : "category",
                        boundaryGap : false,
                        axisLabel: {
                            interval: $scope.chartData.interval, //显示的间隔
                            rotate: 40  //倾斜角度-90到90
                        },
                        data : $scope.chartData.x_axis
                    }
                ],
                yAxis : [
                    {
                        type : "value"
                    }
                ],
                series : [
                    {
                        name:$scope.chartData.name,
                        type:"line",
                        stack: "总量",
                        areaStyle: {normal: {}},
                        data:$scope.chartData.y_axis
                    }
                ]
            };
        });
    }
    $scope.getData($scope.formData.url, $scope.search);

    $scope.selectTime=function(selDate){
        $scope.search.selectDate = selDate;
        // $scope.search.id = $scope.formData.id;
        $scope.getData($scope.formData.url, $scope.search);
    }
});

creditApp.controller("creditCertificateCtrl", function($scope, $http, postUrl){
	$scope.formData = formData;
});

creditApp.controller("creditSafeCtrl", function($scope, $http, postUrl){
    $scope.formData = table_struct;
    $scope.submitData={};
    $scope.btnStatus = false;
    $scope.togglePassword=false;
    $scope.editEmail=true;

    $scope.openBank=function(){
	    	if($scope.formData.approveStatus){
				window.open("/member/api/trust/openBank");
			}else{
				parent.layer.msg("企业还未实名认证，必须在实名认证通过后，才能继续操作！", {icon: 1, shade: 0.3, time: 1500},function(){
//                    parent.location.href = "/member/manager/companyCertificate";
//					parent.layer.closeAll();
				});
			}
	}
	    
    $scope.toLogin=function(){
        window.open("/member/api/trust/toLogin");
    }

    if(!$scope.formData.email){
    	$scope.editEmail=false;
    }
    $scope.changePwd = function(){
    	if($scope.togglePassword){
    		$scope.togglePassword=false;
    	}else{
    		$scope.togglePassword=true;
    	}
    	
    }
    $scope.togglePhone=false;
    $scope.changePhone = function(){
    	if($scope.togglePhone){
    		$scope.togglePhone=false;
    	}else{
    		$scope.togglePhone=true;
    	}
    	
    }
    
    $scope.toggleEmail=false;
    $scope.changeEmail = function(){
    	if($scope.toggleEmail){
    		$scope.toggleEmail=false;
    	}else{
    		$scope.toggleEmail=true;
    	}
    	
    }
	$scope.changePwdSub = function(){
		$scope.btnStatus = true;
        postUrl.events("/member/manager/companySafe/updatePwd", $scope.submitData).success(function(_data){
            if(_data.status == 200){
            	$scope.changePwdSuccess=true;
            	$scope.btnStatus = false;
            	$scope.submitData.oldPassword="";
            	$scope.submitData.newPassword="";
            	$scope.submitData.confirmPassword="";
            }else{
                layer.msg(_data.description, {icon: 2, time: 1000}, function(){
                	 $scope.btnStatus = false;
                });
            }
        });
	}
    $scope.closePwd = function(){
    	$scope.togglePassword=false;
    	$scope.changePwdSuccess=false;
    }
    
    
    $scope.time = 60;
    $scope.sendCodeStatus = false;
    var time = $scope.time;
    $scope.submitData.phoneStep=1;
    $scope.sendPhoneCode = function($event, phone){
        $scope.sendCodeStatus = true;
        postUrl.events("/common/public/getPhoneCode/4/1", {"phone": phone}).success(function (_data) {
            if(_data.status==200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    $($event.target).val("重新获取(" + time + ")");
                    var timer = setInterval(function() {
                        time--;
                        if (time < 0) {
                            $scope.sendCodeStatus = false;
                            $($event.target).prop("disabled", false).val("重新获取");
                            clearInterval(timer);
                            time = $scope.time;
                        } else {
                            $($event.target).val("重新获取(" + time + ")");
                        }
                    }, 1000);
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    if (_data.discription != "send_too_frequent") {
                        $scope.sendCodeStatus = false;
                        $($event.target).prop("disabled", false).val("获取验证码");
                    } else {
                        time = 300;
                        $($event.target).val("重新获取(" + time + ")");
                        var timer = setInterval(function() {
                            time--;
                            if (time < 0) {
                                $scope.sendCodeStatus = false;
                                $($event.target).prop("disabled", false).val("重新获取");
                                clearInterval(timer);
                            } else {
                                $($event.target).val("重新获取(" + time + ")");
                            }
                        }, 1000);
                    }
                });
            }
        });
    }
    $scope.checkPhone = function($event, phone){
        if(!phone){
            layer.msg("请先填写正确的手机号码", {icon: 2, shade: 0.3, shade: 0.3, time: 1500});
            return;
        }
        if($scope.submitData.phoneStep==2){
	        //校验手机号是否绑定
			postUrl.events('/member/manager/companySafe/checkPhone', {"phone":phone}).success(function(_data) {				
				if(_data.status==200){
					$scope.sendPhoneCode($event, phone);
				}else{
					parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
				}
			});
        }else{
        	$scope.sendPhoneCode($event, phone);
        }
    }
    
	$scope.changePhoneSub = function(){
		$scope.btnStatus = true;
        if($scope.submitData.phoneStep==1) {
            $scope.submitData.phone = $scope.formData.phone;
        }
        postUrl.events("/member/manager/companySafe/updatePhone", $scope.submitData).success(function(_data){
            if(_data.status == 200){
            	$scope.btnStatus = false;
            	$scope.submitData.phoneStep=_data.data.phoneStep;
            	if($scope.submitData.phoneStep==2){
                    $scope.submitData.phone = "";
                    $scope.sendCodeStatus = false;
                    $scope.submitData.phoneCode = "";
            	}else if($scope.submitData.phoneStep==3){
            		$scope.submitData.phoneCode = "";
            		$scope.formData.phone=_data.data.phone;
            	}
            }else{
                layer.msg(_data.description, {icon: 2, time: 1000}, function(){
                	 $scope.btnStatus = false;
                });
            }
        });
	}
	
	$scope.closePhone = function(){
		$scope.togglePhone=false;
		$scope.submitData.phoneStep==1;
		$scope.sendCodeStatus = false;
		$scope.submitData.phoneCode = "";
		$scope.submitData.phone = "";
	}
	
	$scope.submitData.emailStep=1;
    $scope.sendEmailCode = function($event, email){
        if(!email){
            layer.msg("请先填写正确的邮箱！", {icon: 2, shade: 0.3, shade: 0.3, time: 1500});
            return;
        }
        $scope.sendEmailStatus = true;
        postUrl.events("/common/public/email/sendemail", {"email": email,"type":3}).success(function (_data) {
            if(_data.status==200){
                $scope.toggleSendEmail = true;
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    $($event.target).val("重新获取(" + time + ")");
                    var timer = setInterval(function() {
                        time--;
                        if (time < 0) {
                            $scope.sendEmailStatus = false;
                            $($event.target).prop("disabled", false).val("重新获取");
                            clearInterval(timer);
                            time = $scope.time;
                        } else {
                            $($event.target).val("重新获取(" + time + ")");
                        }
                    }, 1000);
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    if (_data.discription != "send_too_frequent") {
                        $scope.sendEmailStatus = false;
                        $($event.target).prop("disabled", false).val("获取验证码");
                    } else {
                        time = 300;
                        $($event.target).val("重新获取(" + time + ")");
                        var timer = setInterval(function() {
                            time--;
                            if (time < 0) {
                                $scope.sendEmailStatus = false;
                                $($event.target).prop("disabled", false).val("重新获取");
                                clearInterval(timer);
                            } else {
                                $($event.target).val("重新获取(" + time + ")");
                            }
                        }, 1000);
                    }
                });
            }
        });
    }
    
    $scope.bindEmailSub = function(){
		$scope.btnStatus = true;
        postUrl.events("/member/manager/companySafe/bindEmail", $scope.submitData).success(function(_data){
            if(_data.status == 200){
            	$scope.btnStatus = false;
            	$scope.toggleSendEmail=false;
            	$scope.submitData.emailStep=_data.data.emailStep;
            	if($scope.submitData.emailStep==2){
            		$scope.submitData.email=_data.data.newEmail;
            	}else if($scope.submitData.emailStep==3){
            		$scope.submitData.emailCode = "";
            		$scope.formData.email=_data.data.email;	            		
            	}
            }else{
                layer.msg(_data.description, {icon: 2, time: 1000}, function(){
                	 $scope.btnStatus = false;
                	 $scope.toggleSendEmail=false;
                });
            }
        });
	}
    
	$scope.changeEmailSub = function(){
		$scope.btnStatus = true;
        postUrl.events("/member/manager/companySafe/updateEmail", $scope.submitData).success(function(_data){
            if(_data.status == 200){
            	$scope.btnStatus = false;
            	$scope.toggleSendEmail=false;
            	$scope.submitData.emailStep=_data.data.emailStep;
            	if($scope.submitData.emailStep==2){
            		$scope.sendEmailStatus = false;
            		$scope.submitData.emailCode = "";
            		$scope.submitData.email=_data.data.newEmail;
            	}else if($scope.submitData.emailStep==3){
            		$scope.submitData.emailCode = "";
            		$scope.formData.email=_data.data.email;
            	}
            }else{
                layer.msg(_data.description, {icon: 2, time: 1000}, function(){
                	 $scope.btnStatus = false;
                	 $scope.toggleSendEmail=false;
                });
            }
        });
	}
	
	$scope.closeEmail = function(){
		$scope.toggleSendEmail=false;
		$scope.toggleEmail=false;
		$scope.submitData.emailStep==1;
		$scope.sendEmailStatus = false;
		$scope.submitData.emailCode = "";
		$scope.submitData.email = "";
		$scope.editEmail=true;
	}
});

creditApp.controller("creditInfoCtrl", function($scope, $http, postUrl){
	$scope.formData = table_struct;
});


creditApp.controller("turnOutCtrl", function($scope, $http, postUrl, scopeService){
	$scope.formData = table_struct;

    $scope.transferData = {};
    $scope.transferData.bankCardId = $scope.formData.cards[0]['id'];

    var initbtnText = table_struct.btnText ? table_struct.btnText : "提交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.submit = function(){
        $scope.btnText = initbtnText + "中...";
        $scope.btnStatus = true;
        postUrl.events('/member/api/trust/transferOut', $scope.transferData).success(function(_data) {
            if(_data.status==200){
                scopeService.safeApply($scope, function () {
                    $scope.btnText = initbtnText;
                    $scope.btnStatus = false;
                });
                var eps = parent.$("#easypaysubmit");
                if(eps.length > 0){
                    eps.remove();
                }
                parent.$('body').append(_data.data);
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
});

creditApp.controller("turnInCtrl", function($scope, $http, postUrl){
    $scope.formData=table_struct;
});

creditApp.controller("depositCtrl", function($scope, $http, postUrl, scopeService){
    $scope.formData=table_struct;
    var initbtnText = table_struct.btnText ? table_struct.btnText : "立即转入";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    $scope.submit = function(){
        $scope.btnText = initbtnText + "中...";
        $scope.btnStatus = true;
        postUrl.events("/member/agpur/loan/transDeposit", $scope.formData).success(function(_data){
            if(_data.status == 200){
                if(_data.data){
                    parent.location.href = _data.data;
                }else if(_data.description){
                    layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                        scopeService.safeApply($scope, function () {
                            $scope.btnText = initbtnText;
                            $scope.btnStatus = false;
                        });
                        window.parent.location.reload();
                    });
                }
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
});

creditApp.controller("commonTableCtrl", function($scope, $http, postUrl){
    $scope.formStruct = table_struct;

    $scope.submit = function(){

    }
});

creditApp.factory("EventBus", function() {
    var eventMap = {};

    var EventBus = {
        on : function(eventType, handler) {
            //multiple event listener
            if (!eventMap[eventType]) {
                eventMap[eventType] = [];
            }
            eventMap[eventType].push(handler);
        },

        off : function(eventType, handler) {
            for (var i = 0; i < eventMap[eventType].length; i++) {
                if (eventMap[eventType][i] === handler) {
                    eventMap[eventType].splice(i, 1);
                    break;
                }
            }
        },

        fire : function(event) {
            var eventType = event.type;
            if (eventMap && eventMap[eventType]) {
                for (var i = 0; i < eventMap[eventType].length; i++) {
                    eventMap[eventType][i](event);
                }
            }
        }
    };
    return EventBus;
});

//赎货管理
creditApp.controller("redemptionCtrl", function($scope, $http, postUrl, $timeout, scopeService, EventBus){
    $scope.formStruct = formStruct;
    $scope.formData = {};

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.formData.goodsList = [];
    $scope.formData.repayList = [];
    $scope.formData.takeAmount = 0;

    $scope.selectGoods = function(){
        var index = layer.load();
        postUrl.events("/" + formStruct.selectSpa_url, {}).success(function(_data){
            if(_data.status == 200){
                $timeout(function() {
                    layer.close(index);
                    //传递控制显示隐藏原有业务信息到copyInfoCtrl
                    EventBus.fire({
                        type: "redemptionCtrl",
                        showGoods: true,
                        business: _data.data,
                        goodsList: $scope.formData.goodsList,
                        repayList: $scope.formData.repayList,
                        businessModel: "",
                        emptyList: [],
                        boolean: false
                    });
                    $scope.overflowClass = true;
                }, 1000);
            } else {
                layer.close(index);
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
            }
        })
    }

    $scope.deleteGoods = function(index){
        $scope.formData.takeAmount = 0;

        for(var key in $scope.formData.repayList){
            if($scope.formData.repayList[key]["businessText"] == $scope.formData.goodsList[index]["businessText"]){
                var total = Number($scope.formData.goodsList[index]["takeNum"]) * Number($scope.formData.goodsList[index]["price"]);
                $scope.formData.repayList[key]["takeAmount"] = $scope.formData.repayList[key]["takeAmount"] - total * Number(100-$scope.formData.repayList[key]["deposit_ratio"]) / 100;
                $scope.formData.repayList[key]["total"] = $scope.formData.repayList[key]["total"] - total * Number(100-$scope.formData.repayList[key]["deposit_ratio"]) / 100;
            }
            if(Number($scope.formData.repayList[key]["takeAmount"]).toFixed(2) == 0.00){
                $scope.formData.repayList.splice(key, 1);
            }
        }

        for(var keys=0; keys<$scope.formData.repayList.length; keys++){
            $scope.formData.takeAmount += Number($scope.formData.repayList[keys]["total"]);
        }

        $scope.formData.goodsList.splice(index, 1);

    }

    EventBus.on("selectGoodsCtrl", function(evt){
        if(evt.goods){
            $scope.formData.goodsList = evt.goods;
        }
        if(evt.repayment){
            $scope.formData.repayList = evt.repayment;
            $scope.formData.takeAmount = 0;
            for(var keys=0; keys<$scope.formData.repayList.length; keys++){
                $scope.formData.takeAmount += Number($scope.formData.repayList[keys]["total"]);
            }
        }
        $scope.overflowClass = evt.overflowClass;
    });

    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;

        $scope.formData.goodsListJson = angular.toJson($scope.formData.goodsList, false);
        $scope.formData.repayListJson = angular.toJson($scope.formData.repayList, false);

        postUrl.events("/" + formStruct.submit_url, {
            "takeNo": $scope.formStruct.takeGoods.takeNo,
            "takeAmount": $scope.formData.takeAmount,
            "takeGoodsDetail": $scope.formData.goodsListJson,
            "goodsRepay": $scope.formData.repayListJson
        }).success(function(_data){
            if(_data.status == 200){
            	if(_data.data){
            		parent.location.href = _data.data;
            	}else if(_data.description){
            		parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
            			parent.location.reload();
            		});
            	}
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
});
creditApp.controller("selectGoodsCtrl", function($scope, $http, postUrl, $timeout, scopeService, EventBus){
    $scope.formStruct = formStruct;
    $scope.goodsData = {};

    $scope.goodsData.showGoods = false;  //隐藏选择货物

    EventBus.on("redemptionCtrl", function(evt){
        $scope.goodsData.showGoods = evt.showGoods;  //传递选择货物显示隐藏的状态
        $scope.formStruct.business = evt.business;  //传递选择业务编号
        $scope.goodsList = evt.goodsList;
        $scope.repayList = evt.repayList;
        $scope.goodsData.business = evt.businessModel;
        $scope.goodsData.goodsList = evt.emptyList;
        $scope.checkAll = evt.boolean;
    });

    $scope.changeGoodsList = function(){
        $scope.checkvalue = [];
        $scope.checkAll = false;
        if($scope.goodsData.business){
            postUrl.events("/" + formStruct.select_url, {"id": $scope.goodsData.business}).success(function(_data){
                if(_data.status == 200){
                    $scope.goodsData.goodsList = _data.data;
                    for(var index in $scope.goodsData.goodsList){
                        $scope.goodsData.goodsList[index]["takeNum"] = 1;
                        $scope.goodsData.goodsList[index]["purchaseId"] = _data.data[index].id;
                        $scope.goodsData.goodsList[index]["pledgeId"] = $scope.goodsData.business;
                    }
                    for(var key in $scope.formStruct.business){
                        if($scope.goodsData.business == $scope.formStruct.business[key]["id"]){
                            $scope.goodsData.businessText = $scope.formStruct.business[key]["pledge_no"]
                        }
                    }
                } else {
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            })
        }
    }

    //全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.goodsData.goodsList, function(i){
                i.checked = true;
                $scope.checkvalue.push(i.id);
            })
        } else {
            angular.forEach($scope.goodsData.goodsList, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.goodsData.goodsList, function(i){
            var index = $scope.checkvalue.indexOf(i.id);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i.id);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.goodsData.goodsList.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

    $scope.addGoodsInfo = function(){
        $scope.principal = 0;
        if($scope.checkvalue.length == 0){
            layer.msg("请至少选择一项货物", {icon: 2, shade: 0.3, time: 1500});
        } else {
            postUrl.events("/" + formStruct.calcFee_url, {"id": $scope.goodsData.business}).success(function(_data){
                if(_data.status == 200){
                    angular.forEach($scope.goodsData.goodsList, function(i){
                        if(i.checked){
                            i.businessText = $scope.goodsData.businessText;
                            var takeNum = i.takeNum ? i.takeNum : 0;
                            var price = i.price ? i.price : 0;
                            $scope.principal += Number(takeNum) * Number(price);
                            if($scope.goodsList.length > 0){
                                var result = $scope.goodsList.every(function(item, index, array){
                                    return (item.id != i.id);
                                })
                                if(result){
                                    $scope.goodsList.push(i);
                                } else {
                                    var k;
                                    for(var j in $scope.goodsList){
                                        if($scope.goodsList[j]["id"] == i.id){
                                            k = j;
                                        }
                                    }
                                    $scope.principal = $scope.principal - Number($scope.goodsList[k]["takeNum"]) * Number($scope.goodsList[k]["price"]);
                                    $scope.goodsList.splice(k, 1);
                                    $scope.goodsList.push(i);
                                }
                            } else {
                                $scope.goodsList.push(i);
                            }
                        };
                    })

                    _data.data.businessText = $scope.goodsData.businessText;
                    _data.data.takeAmount = $scope.principal * Number(100-_data.data.deposit_ratio) / 100;
                    _data.data.total = _data.data.takeAmount + Number(_data.data.fee) + Number(_data.data.interest) + Number(_data.data.overdouFee);
                    _data.data.pledgeId = $scope.goodsData.business;

                    if($scope.repayList.length > 0){
                        var repay = $scope.repayList.every(function(item, index, array){
                            return (item.businessText != $scope.goodsData.businessText);
                        })
                        if(repay){
                            $scope.repayList.push(_data.data);
                        } else {
                            var indexs;
                            for(var keys in $scope.repayList){
                                if($scope.repayList[keys]["businessText"] == $scope.goodsData.businessText){
                                    indexs = keys;

                                    _data.data.takeAmount = $scope.repayList[keys]["takeAmount"] + _data.data.takeAmount;
                                    _data.data.total = _data.data.takeAmount + Number(_data.data.fee) + Number(_data.data.interest) + Number(_data.data.overdouFee);
                                }
                            }
                            $scope.repayList.splice(indexs, 1);
                            $scope.repayList.push(_data.data);
                        }
                    } else {
                        $scope.repayList.push(_data.data);
                    }

                    $timeout(function() {
                        EventBus.fire({type: "selectGoodsCtrl", goods: $scope.goodsList, repayment: $scope.repayList, overflowClass: false});
                        $scope.goodsData.showGoods = false;
                    }, 500);
                } else {
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            })
        }
    }

    $scope.closePopup = function(){
        EventBus.fire({type: "selectGoodsCtrl", overflowClass: false});
        $scope.goodsData.showGoods = false;
    }
})



creditApp.controller("redeemGoodsCtrl", function($scope, $http, postUrl,submitForm){
    $scope.formStruct = formStruct;
    $scope.formData = formStruct.form_data || {};

    $scope.checkMax = function(rec){
    	if(rec.redeem_num > rec.num-rec.take_num){
    		rec.redeem_num = rec.num-rec.take_num;
    	}
    }
    
    $scope.next = function(){
        $scope.btnStatus = true;

        var submData = {}
        var takeGoodsDetail = [];
        var ids = "";
        var takeAmount = 0;
        for(var i=0;i<$scope.formStruct.purList.length;i++){
            var purlist = $scope.formStruct.purList[i];
            if(purlist.redeem_num && purlist.redeem_num>0){
                takeGoodsDetail.push({purchaseId:purlist.id,takeNum:purlist.redeem_num});
                ids += ","+purlist.id;
                takeAmount += purlist.redeem_num*purlist.price
            }
        }
        if(ids.length <= 0){
            $scope.btnStatus = false;
            return;
        }
        submData.takeGoodsDetail = angular.toJson(takeGoodsDetail,true);
        submData.ids = ids.substring(1);
        submData.id = $scope.formStruct.id;
        submData.takeAmount = takeAmount;
        submitForm.submit("/"+$scope.formStruct.submit_url,submData);
    }

    $scope.repaySub = function(){
        var submData = {}
        angular.copy($scope.formData,submData)
        submData.takeGoodsDetail = $scope.formStruct.takeGoodsDetail;
        submData.ids = $scope.formStruct.ids;
        postUrl.events("/"+$scope.formStruct.submit_url, submData).success(function(_data){
            if(_data.status == 200){
            	if(_data.data){
            		parent.location.href = _data.data;
            	}else if(_data.description){
            		layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
            			parent.location.reload();
            		});
            	}
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    //window.location.reload();
                });
            }
        });
    }

});

creditApp.controller("messageCtrl", function($scope, $http, postUrl){

	$scope.tableB = table_struct.list;

    //全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.tableB, function(i){
                i.checked = true;
                $scope.checkvalue.push(i.id);
            })
        } else {
            angular.forEach($scope.tableB, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.tableB, function(i){
            var index = $scope.checkvalue.indexOf(i.id);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i.id);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.tableB.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

    //删除消息
    $scope.deleteItems = function(){
    	if($scope.checkvalue.length > 0){
            layer.confirm("确定是否删除消息", {
                time: 0, //不自动关闭
                icon: 3,
                shade: 0.3,
                title: "删除消息",
                btn: ["确定", "取消"]
            }, function(){
                postUrl.events("/member/manager/messageLog/delete", {'ids': $scope.checkvalue.join(',')}).success(function(_data){
                    if(_data.status == 200){
                        layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                            window.location.reload();
                        });
                    }else{
                        layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                            //window.location.reload();
                        });
                    }
                });
            })
    	}else{
    		layer.msg("请至少选择一条数据！", {icon: 2, shade: 0.3, time: 1500}, function(){});
    	}
	}

    //查看消息
    $scope.viewItems = function(index){
        if($scope.tableB[index]['read_status'] == 0){
            postUrl.events("/member/manager/messageLog/reader", {'id': $scope.tableB[index]['id']}).success(function(_data){
                if(_data.status == 200){
                    for(var key in $scope.tableB){
                        $scope.tableB[key]['show'] = false;
                    }
                    $scope.tableB[index]['show'] = true;
                    $scope.tableB[index]['read_status'] = 1;
                } else {
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                        //window.location.reload();
                    });
                }
            });
        } else {
            for(var key in $scope.tableB){
                $scope.tableB[key]['show'] = false;
            }
            $scope.tableB[index]['show'] = true;
        }
    }
});

module.exports = creditApp;
