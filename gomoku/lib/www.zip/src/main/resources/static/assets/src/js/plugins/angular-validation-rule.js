(function() {
   /**
     * 校验正则方法
     * @param value
     * @param rule
     * @returns {*|boolean}
     */
    function patternFU(value, rule) {
        if(typeof value != "undefined" && String(value).indexOf(",") > -1){
            value = Number(value.split(",").join(""));
        }
        return rule.test(value);
    }

    /**
     * 反校验正则方法
     * @param value
     * @param rule
     * @returns {boolean}
     */
    function noPatternFU(value, rule) {
        return !(rule.test(value));
    }

    /**
     * 时间戳（毫秒数）
     * @param value
     * @returns {number}
     */
    function timestampFU(value) {
        return new Date(value).getTime();
    }

    /**
     * 校验最小值
     * @param value
     * @param param
     * @returns {boolean}
     */
    function minFU(value, param) {
        var param = parseFloat(param),
            value = parseFloat(value);
        if (value == 0 || value) {
            return value >= param;
        } else {
            return !value;
        }
    }

    /**
     * 校验最大值
     * @param value
     * @param param
     * @returns {boolean}
     */
    function maxFU(value, param) {
        var param = parseFloat(param),
            value = parseFloat(value);
        if (value == 0 || value) {
            return value <= param;
        } else {
            return !value;
        }
    }

    /**
     * 正则变量
     */
    var dyRule = {
        tel: /^0\d{2,3}-?\d{7,8}$/, //固定电话
        mobile: /^1[3|4|5|7|8][0-9]\d{8}$/, //手机号码
        qq: /^[1-9][0-9]{4,}$/, //qq
        telService: /^(400)-?(\d{3})-?(\d{4})$/, //客服电话
        noAllNumber: /^[0-9]*$/, //不能输入纯数字
        noAllLetter: /^[A-Za-z]*$/, //不能输入纯字母
        noSpecialStr: new RegExp("[%`~!@#$^&*()=|{}':;',\\[\\].<> /?~！@#￥……&*（）&;—|{}【】‘；：”“'。，、？\"\\\\+-]"), //不能含有特殊字符
        noZh: /^[^\u4E00-\u9FA5]{0,}$/, //不能含有中文字符
        inChar: /^[\@A-Za-z0-9\!\#\$\%\^\&\*\.\~]{1,}$/, //非法字符
        noRepeat: new RegExp(/^(.)\1+$/), //同一个字符
        re_decimals: /^\d+(\.\d{1,2})?$/,  //保留两位小数
        decimals: /^([1-9]\d{0,}||\d+\.\d{1,2})$/,  //正整数或保留两位小数
        pinter: /^[1-9]\d*$/,
        allNumber: /^[0-9]+(\.\d{1,2})?$/
    }; 
  angular
    .module('validation.rule', ['validation'])
    .config(['$validationProvider', function($validationProvider) {
      var expression = {
                    required: function (value, scope, element, attrs, param) {
                    	return !!value || value == "0";
                    },
                    required_nomsg: function (value, scope, element, attrs, param) {
                        var value = $.isArray(value) ? value.length : $.trim(value);
                        return !!value;
                    },
                    minlength: function (value, scope, element, attrs) {
                        return value.length >= attrs.minlength;
                    },
                    maxlength: function (value, scope, element, attrs) {
                        return value.length <= attrs.maxlength;
                    },
                    min: function (value, scope, element, attrs) {
                        return minFU(value, attrs.min);
                    },
                    max: function (value, scope, element, attrs) {
                        return maxFU(value, attrs.max);
                    },
                    minlimt: function (value, scope, element, attrs) {
                        return minFU(value, attrs.minlimt);
                    },
                    maxlimt: function (value, scope, element, attrs) {
                        return maxFU(value, attrs.maxlimt);
                    },
                    range: function (value, scope, element, attrs, param) {
                        var param = param.replace(new RegExp("\\[\|\\]", "g"), '').split('|'),
                            value = parseFloat(value);
                        return value >= parseFloat(param[0]) && value <= parseFloat(param[1]);
                    },
                    rangelength: function (value, scope, element, attrs, param) {
                        var param = param.replace(new RegExp("\\[\|\\]", "g"), '').split('|');
                        return value.length >= param[0] && value.length <= param[1];
                    },
                    idcard: function (value) {
                        // 构造函数，变量为15位或者18位的身份证号码
                        function clsIDCard(CardNo) {
                            this.Valid = false;
                            this.ID15 = '';
                            this.ID18 = '';
                            this.Local = '';
                            if (CardNo != null) this.SetCardNo(CardNo);
                        }

                        // 设置身份证号码，15位或者18位
                        clsIDCard.prototype.SetCardNo = function (CardNo) {
                            this.ID15 = '';
                            this.ID18 = '';
                            this.Local = '';
                            CardNo = CardNo.replace(" ", "");
                            var strCardNo;
                            if (CardNo.length == 18) {
                                pattern = /^\d{17}(\d|x|X)$/;
                                if (pattern.exec(CardNo) == null) return;
                                strCardNo = CardNo.toUpperCase();
                            } else {
                                pattern = /^\d{15}$/;
                                if (pattern.exec(CardNo) == null) return;
                                strCardNo = CardNo.substr(0, 6) + '19' + CardNo.substr(6, 9)
                                strCardNo += this.GetVCode(strCardNo);
                            }
                            this.Valid = this.CheckValid(strCardNo);
                        }
                        // 校验身份证有效性
                        clsIDCard.prototype.IsValid = function () {
                            return this.Valid;
                        }
                        // 返回生日字符串，格式如下，1981-10-10
                        clsIDCard.prototype.GetBirthDate = function () {
                            var BirthDate = '';
                            if (this.Valid) BirthDate = this.GetBirthYear() + '-' + this.GetBirthMonth() + '-' + this.GetBirthDay();
                            return BirthDate;
                        }
                        // 返回生日中的年，格式如下，1981
                        clsIDCard.prototype.GetBirthYear = function () {
                            var BirthYear = '';
                            if (this.Valid) BirthYear = this.ID18.substr(6, 4);
                            return BirthYear;
                        }
                        // 返回生日中的月，格式如下，10
                        clsIDCard.prototype.GetBirthMonth = function () {
                            var BirthMonth = '';
                            if (this.Valid) BirthMonth = this.ID18.substr(10, 2);
                            if (BirthMonth.charAt(0) == '0') BirthMonth = BirthMonth.charAt(1);
                            return BirthMonth;
                        }
                        // 返回生日中的日，格式如下，10
                        clsIDCard.prototype.GetBirthDay = function () {
                            var BirthDay = '';
                            if (this.Valid) BirthDay = this.ID18.substr(12, 2);
                            return BirthDay;
                        }
                        // 返回性别，1：男，0：女
                        clsIDCard.prototype.GetSex = function () {
                            var Sex = '';
                            if (this.Valid) Sex = this.ID18.charAt(16) % 2;
                            return Sex;
                        }
                        // 返回15位身份证号码
                        clsIDCard.prototype.Get15 = function () {
                            var ID15 = '';
                            if (this.Valid) ID15 = this.ID15;
                            return ID15;
                        }
                        // 返回18位身份证号码
                        clsIDCard.prototype.Get18 = function () {
                            var ID18 = '';
                            if (this.Valid) ID18 = this.ID18;
                            return ID18;
                        }
                        // 返回所在省，例如：上海市、浙江省
                        clsIDCard.prototype.GetLocal = function () {
                            var Local = '';
                            if (this.Valid) Local = this.Local;
                            return Local;
                        }
                        clsIDCard.prototype.GetVCode = function (CardNo17) {
                            var Wi = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1);
                            var Ai = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                            var cardNoSum = 0;
                            for (var i = 0; i < CardNo17.length; i++) cardNoSum += CardNo17.charAt(i) * Wi[i];
                            var seq = cardNoSum % 11;
                            return Ai[seq];
                        }
                        clsIDCard.prototype.CheckValid = function (CardNo18) {
                            if (this.GetVCode(CardNo18.substr(0, 17)) != CardNo18.charAt(17)) return false;
                            if (!this.IsDate(CardNo18.substr(6, 8))) return false;
                            var aCity = {
                                11: "北京",
                                12: "天津",
                                13: "河北",
                                14: "山西",
                                15: "内蒙古",
                                21: "辽宁",
                                22: "吉林",
                                23: "黑龙江 ",
                                31: "上海",
                                32: "江苏",
                                33: "浙江",
                                34: "安徽",
                                35: "福建",
                                36: "江西",
                                37: "山东",
                                41: "河南",
                                42: "湖北 ",
                                43: "湖南",
                                44: "广东",
                                45: "广西",
                                46: "海南",
                                50: "重庆",
                                51: "四川",
                                52: "贵州",
                                53: "云南",
                                54: "西藏 ",
                                61: "陕西",
                                62: "甘肃",
                                63: "青海",
                                64: "宁夏",
                                65: "新疆",
                                71: "台湾",
                                81: "香港",
                                82: "澳门",
                                91: "国外"
                            };
                            if (aCity[parseInt(CardNo18.substr(0, 2))] == null) return false;
                            this.ID18 = CardNo18;
                            this.ID15 = CardNo18.substr(0, 6) + CardNo18.substr(8, 9);
                            this.Local = aCity[parseInt(CardNo18.substr(0, 2))];
                            return true;
                        }
                        clsIDCard.prototype.IsDate = function (strDate) {
                            var r = strDate.match(/^(\d{1,4})(\d{1,2})(\d{1,2})$/);
                            if (r == null) return false;
                            var d = new Date(r[1], r[2] - 1, r[3]);
                            return (d.getFullYear() == r[1] && (d.getMonth() + 1) == r[2] && d.getDate() == r[3]);
                        }
                        var checkFlag = new clsIDCard(value);
                        // console.log(checkFlag.IsValid(), value);
                        if (!checkFlag.IsValid() && value != "" && typeof value != "undefined") {
                            return false;
                        } else {
                            return true;
                        }
                    },
                    inchar: function (value, scope, element, attrs, param) {
                        return !value || noPatternFU(value, dyRule.inChar);
                    },
                    pwdchar: function (value, scope, element, attrs, param) {
                        var paramArr = param.replace(new RegExp("\\[\|\\]", "g"), '').split('|'),
                            valeg = value.length >= paramArr[0] && value.length <= paramArr[1];
                        if (value && (patternFU(value, dyRule.noAllNumber) || patternFU(value, dyRule.noRepeat) || patternFU(value, dyRule.noSpecialStr) || patternFU(value, dyRule.noAllLetter))) {
                            return false;
                        } else if (value && !valeg) {
                            return false;
                        } else {
                            return true;
                        }
                    },
                    equals: function (value, scope, element, attrs, param) {
                        var val = document.getElementsByName(param)[0].value;
                        return !val || value === val;
                    },
                    multiple: function (value, scope, element, attrs, param) {
                        return value % param == 0;
                    },
                    mul: function (value, scope, element, attrs, param) {
                        return value % param == 0;
                    },
                    themultiple: function (value, scope, element, attrs, param) {
                        return param % value == 0;
                    },
                    url: function (value) {
                        if (!value) {
                            return true;
                        } else
                            return /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value);
                    },
                    email: function (value) {
                        if (!value) {
                            return true;
                        } else
                            return /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/.test(value);
                    },
                    timeCode: function(value){
                        if(!value){
                            return true;
                        }else{
                            return /^[1-9]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/.test(value);
                        }
                    },
                    number: /^\d+$/,
                    phone: function (value) {
                        return !value || patternFU(value, dyRule.mobile);
                    },
                    decimals: function (value, scope, element, attrs, param) {
                        // return param == 'no' ? !value || patternFU(value, dyRule.decimals) : patternFU(value, dyRule.decimals);
                        return !value || patternFU(value, dyRule.decimals);
                    },
                    re_decimals: function (value, scope, element, attrs, param) {
                        return !value || patternFU(value, dyRule.re_decimals);
                    },
                    decimals_nomsg: /^\d+(\.\d{1,2})?$/,
                    gt_decimals: /^(?!0(\d|\.0+$|$))\d+(\.\d{1,2})?$/,
                    ne_decimals: /^(-)?(?!0(\d|\.0+$|$))\d+(\.\d{1,2})?$/,
                    gt_decimals_nomsg: /^(?!0(\d|\.0+$|$))\d+(\.\d{1,2})?$/,
                    qq: function (value) {
                        return !value || patternFU(value, dyRule.qq);
                    },
                    inter: /^[0-9]\d*$/,
                    inter_nomsg: /^[0-9]\d*$/,
                    // pinter: /^[1-9]\d*$/,
                    pinter: function (value, scope, element, attrs, param) {
                        // return param == 'no' ? !value || patternFU(value, dyRule.decimals) : patternFU(value, dyRule.decimals);
                        return !value || patternFU(value, dyRule.pinter);
                    },
                    noZh: function (value, scope, element, attrs, param) {
                        return !value || patternFU(value, dyRule.noZh);
                    },
                    allNumber: function (value, scope, element, attrs, param) {
                        return !value || patternFU(value, dyRule.allNumber);
                    },
                    pinter_nomsg: /^[1-9]\d*$/,
                    username: /^[a-zA-Z][a-zA-Z0-9]{3,15}$/,
                    decimals_unit: /^\d+(\.\d{1,2})?[元|%]$/,
                    tel: /^0\d{2,3}-?\d{7,8}$/,
                    telephone: function (value, element) {
                        function telTodo(val) {
                            if (patternFU(val, dyRule.tel) || patternFU(val, dyRule.mobile)) {
                                return true;
                            } else {
                                return false;
                            }
                        }

                        return telTodo(value);
                    },
                    telservice: function (value, element) {
                        function telTodo(val) {
                            if (patternFU(val, dyRule.tel) || patternFU(val, dyRule.mobile) || patternFU(val, dyRule.telService)) {
                                return true;
                            } else {
                                return false;
                            }
                        }

                        return telTodo(value);
                    },
                    watchUser: function (value, scope, element, attrs, param, $injector) {
                        var _results,
                            _url = '/common/public/member',
                            _def = {
                                member_name: value
                            },
                            postUrl = $injector.get('postUrl');
                        _def = angular.extend(_def, scope.$eval(param));
                        if (value !== undefined) {
                            return postUrl.events(_url, _def).then(function (response) {
                                if (response && response.data.status == 200) {
                                    _results = true;
                                    _data = response.data.data;
                                } else {
                                    defaultMsg.watchUser.error = response.data.description;
                                    _results = false;
                                }
                                return _results;
                            });
                        } else {
                            return !value || false;
                        }
                    },
                    watchUserName: function (value, scope, element, attrs, param, $injector) {
                        /**
                         * _param[字段|url|...]
                         */
                        var _results,
                            _data,
                            _param = param.split('|'),
                            _url = _param[1] || '/loan/first/getAmount',
                            postUrl = $injector.get('postUrl');
                        if (value !== undefined) {
                            return postUrl.events(_url, {member_name: value}).then(function (response) {
                                if (response && response.data.status == 200) {
                                    _results = true;
                                    _data = response.data.data;
                                } else {
                                    defaultMsg.watchUserName.error = response.data.description;
                                    _results = false;
                                    _data = null;
                                }
                                if (_param[0]) {
                                    scope.$parent[_param[0]] = _data;
                                }
                                return _results;
                            });
                        } else {
                            return !value || false;
                        }
                    }
                };

                var defaultMsg = {
                    required: {
                        error: '不能为空',
                        success: ''
                    },
                    required_nomsg: {
                        error: '',
                        success: ''
                    },
                    minlength: {
                        error: '填写长度不能小于{0}字符',
                        success: ''
                    },
                    maxlength: {
                        error: '填写长度不能大于{0}字符',
                        success: ''
                    },
                    min: {
                        error: '输入值不能小于{0}',
                        success: ''
                    },
                    max: {
                        error: '输入值不能大于{0}',
                        success: ''
                    },
                    minlimt: {
                        error: '输入值不能小于{0}',
                        success: ''
                    },
                    maxlimt: {
                        error: '输入值不能大于{0}',
                        success: ''
                    },
                    range: {
                        error: '请填写{0}~{1}之间值',
                        success: ''
                    },
                    rangelength: {
                        error: '请填写{0}~{1}之间字符长度',
                        success: ''
                    },
                    idcard: {
                        error: '请填写有效身份证号码',
                        success: ''
                    },
                    inchar: {
                        error: '包含非法字符',
                        success: ''
                    },
                    pwdchar: {
                        error: '密码长度{0}~{1}之间且密码为英文、数字的组合',
                        success: ''
                    },
                    equals: {
                        error: '两次输入不一致',
                        success: ''
                    },
                    multiple: {
                        error: '请输入{0}的倍数',
                        success: ''
                    },
                    mul: {
                        error: '请输入{0}的倍数',
                        success: ''
                    },
                    themultiple: {
                        error: '请输入{0}的倍数',
                        success: ''
                    },
                    url: {
                        error: '请填写正确的url地址!',
                        success: ''
                    },
                    email: {
                        error: '请填写正确的邮箱地址!',
                        success: ''
                    },
                    timeCode: {
                        error: '请填写正确的时间格式!',
                        success: ''
                    },
                    number: {
                        error: '请填写整数格式!',
                        success: ''
                    },
                    allNumber: {
                        error: '请填写数字并且最多保留两位小数格式!',
                        success: ''
                    },
                    phone: {
                        error: '请填写正确手机格式!',
                        success: ''
                    },
                    decimals: {
                        error: '请填写正整数或保留两位小数格式!',
                        success: ''
                    },
                    re_decimals: {
                        error: '请填写整数或最多保留两位小数格式!',
                        success: ''
                    },
                    decimals_nomsg: {
                        error: '',
                        success: ''
                    },
                    gt_decimals: {
                        error: '请填写大于0的数值或最多保留两位小数格式!',
                        success: ''
                    },
                    ne_decimals: {
                        error: '请填写非0的数值或最多保留两位小数格式!',
                        success: ''
                    },
                    gt_decimals_nomsg: {
                        error: '',
                        success: ''
                    },
                    qq: {
                        error: '请填写正确QQ格式!',
                        success: ''
                    },
                    inter: {
                        error: '只能填写数字格式!',
                        success: ''
                    },
                    inter_nomsg: {
                        error: '',
                        success: ''
                    },
                    pinter: {
                        error: '请填写正整数格式!',
                        success: ''
                    },
                    noZh: {
                        error: '不允许填写中文!',
                        success: ''
                    },
                    pinter_nomsg: {
                        error: '',
                        success: ''
                    },
                    username: {
                        error: '请填写以字母开头4-16位的英文、数字或组合!',
                        success: ''
                    },
                    decimals_unit: {
                        error: '',
                        success: ''
                    },
                    tel: {
                        error: '电话格式有误',
                        success: ''
                    },
                    telephone: {
                        error: '电话格式有误',
                        success: ''
                    },
                    telservice: {
                        error: '电话格式有误',
                        success: ''
                    },
                    watchUser: {
                        error: '用户名不存在',
                        success: ''
                    },
                    watchUserName: {
                        error: '用户名不存在',
                        success: ''
                    }
                };
      $validationProvider.setExpression(expression).setDefaultMsg(defaultMsg);
    }]);
}).call(this);
