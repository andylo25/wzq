/*
* 融资
*/

require("../sass/finance.scss");

require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var financeApp = angular.module("financeApp", ["validation", "validation.rule", "dyDir", "dyService"]);
financeApp.controller("headUerCtrl", function($scope, $http, postUrl){
	$scope.formData = table_struct;
});
financeApp.controller("financeCtrl", function($scope, $http, postUrl){
	$scope.switch = 1;
});
module.exports = financeApp;
