/*
* 登录、注册、找回密码
*/


require("../sass/user.scss");

require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var userApp = angular.module("app",["validation", "validation.rule","dyDir","dyService"]);
userApp.controller("headUerCtrl",function($scope,$http,postUrl){
	$scope.formData = table_struct;
});
userApp.controller("loginCtrl",function($scope,$http,postUrl){
	$scope.loginData = {};

    $scope.showOnce = true;
    $scope.showTxt = function(){
        $scope.showOnce = false;
    }
    $scope.loginData.companyRoleType = 1;

	$scope.loginSub = function(){
        postUrl.events("/member/public/login", $scope.loginData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    window.location.href = "/";
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    //window.location.reload();
                });
            }
        });
	}
});


userApp.controller("getPwdCtrl",function($scope, $http, postUrl, scopeService){
	$scope.formData = formData;

    var initbtnText = formData.btnText ? formData.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.time = 60;
    $scope.sendCodeStatus = false;
    var time = $scope.time;

    $scope.sendPhoneCode = function($event, phone){
        if(!phone){
            layer.msg("请先填写正确的手机号码", {icon: 2, shade: 0.3, shade: 0.3, time: 1500});
            return;
        }
        $scope.sendCodeStatus = true;
        postUrl.events("/common/public/getPhoneCode/1/1", {"phone": phone}).success(function (_data) {
            if(_data.status==200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    $($event.target).val("重新获取(" + time + ")");
                    var timer = setInterval(function() {
                        time--;
                        if (time < 0) {
                            $scope.sendCodeStatus = false;
                            $($event.target).prop("disabled", false).val("重新获取");
                            clearInterval(timer);
                            time = $scope.time;
                        } else {
                            $($event.target).val("重新获取(" + time + ")");
                        }
                    }, 1000);
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    if (_data.discription != "send_too_frequent") {
                        $scope.sendCodeStatus = false;
                        $($event.target).prop("disabled", false).val("获取验证码");
                    } else {
                        time = 300;
                        $($event.target).val("重新获取(" + time + ")");
                        var timer = setInterval(function() {
                            time--;
                            if (time < 0) {
                                $scope.sendCodeStatus = false;
                                $($event.target).prop("disabled", false).val("重新获取");
                                clearInterval(timer);
                            } else {
                                $($event.target).val("重新获取(" + time + ")");
                            }
                        }, 1000);
                    }
                });
            }
        });
    }
    
    $scope.sendEmailCode = function($event, email){
        if(!email){
            layer.msg("请先填写正确的邮箱！", {icon: 2, shade: 0.3, shade: 0.3, time: 1500});
            return;
        }
        $scope.sendEmailStatus = true;
        postUrl.events("/common/public/email/sendemail", {"email": email,"type":2,"userId":$scope.formData.userId}).success(function (_data) {
            if(_data.status==200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    $($event.target).val("重新获取(" + time + ")");
                    var timer = setInterval(function() {
                        time--;
                        if (time < 0) {
                            $scope.sendEmailStatus = false;
                            $($event.target).prop("disabled", false).val("重新获取");
                            clearInterval(timer);
                            time = $scope.time;
                        } else {
                            $($event.target).val("重新获取(" + time + ")");
                        }
                    }, 1000);
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    if (_data.discription != "send_too_frequent") {
                        $scope.sendEmailStatus = false;
                        $($event.target).prop("disabled", false).val("获取验证码");
                    } else {
                        time = 300;
                        $($event.target).val("重新获取(" + time + ")");
                        var timer = setInterval(function() {
                            time--;
                            if (time < 0) {
                                $scope.sendEmailStatus = false;
                                $($event.target).prop("disabled", false).val("重新获取");
                                clearInterval(timer);
                            } else {
                                $($event.target).val("重新获取(" + time + ")");
                            }
                        }, 1000);
                    }
                });
            }
        });
    }
    
	$scope.changePwdSub = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/public/getpasswd/submit", $scope.formData).success(function(_data){
            if(_data.status == 200){
                scopeService.safeApply($scope, function(){
                    $scope.btnText = initbtnText;
                    $scope.btnStatus = false;
                });
            	$scope.formData.userId = _data.data.userId;
            	$scope.formData.email = _data.data.email;
            	$scope.formData.phone = _data.data.phone;
            	$scope.formData.step = _data.data.step;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function(){
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
	}
});

userApp.controller("registerCtrl",function($scope, $http, postUrl, scopeService){
	$scope.formData = formData;
	$scope.workArea = workArea;

    var initbtnText = formData.btnText ? formData.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.time = 60;
    $scope.sendCodeStatus = false;
    var time = $scope.time;

    $scope.sendPhoneCode = function($event, phone){
        if(!phone){
            layer.msg("请先填写正确的手机号码", {icon: 2, shade: 0.3, shade: 0.3, time: 1500});
            return;
        }
        $scope.sendCodeStatus = true;
        postUrl.events("/common/public/getPhoneCode/1/1", {"phone": phone}).success(function (_data) {
            if(_data.status==200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    $($event.target).val("重新获取(" + time + ")");
                    var timer = setInterval(function() {
                        time--;
                        if (time < 0) {
                            $scope.sendCodeStatus = false;
                            $($event.target).prop("disabled", false).val("重新获取");
                            clearInterval(timer);
                            time = $scope.time;
                        } else {
                            $($event.target).val("重新获取(" + time + ")");
                        }
                    }, 1000);
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    if (_data.discription != "send_too_frequent") {
                        $scope.sendCodeStatus = false;
                        $($event.target).prop("disabled", false).val("获取验证码");
                    } else {
                        time = 300;
                        $($event.target).val("重新获取(" + time + ")");
                        var timer = setInterval(function() {
                            time--;
                            if (time < 0) {
                                $scope.sendCodeStatus = false;
                                $($event.target).prop("disabled", false).val("重新获取");
                                clearInterval(timer);
                            } else {
                                $($event.target).val("重新获取(" + time + ")");
                            }
                        }, 1000);
                    }
                });
            }
        });
    }

    $scope.sendEmailCode = function($event, email){
        if(!email){
            layer.msg("请先填写正确的邮箱！", {icon: 2, shade: 0.3, shade: 0.3, time: 1500});
            return;
        }
        $scope.sendEmailStatus = true;
        postUrl.events("/common/public/email/sendemail", {"email": email,"type":1}).success(function (_data) {
            if(_data.status==200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    $($event.target).val("重新获取(" + time + ")");
                    var timer = setInterval(function() {
                        time--;
                        if (time < 0) {
                            $scope.sendEmailStatus = false;
                            $($event.target).prop("disabled", false).val("重新获取");
                            clearInterval(timer);
                            time = $scope.time;
                        } else {
                            $($event.target).val("重新获取(" + time + ")");
                        }
                    }, 1000);
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    if (_data.discription != "send_too_frequent") {
                        $scope.sendEmailStatus = false;
                        $($event.target).prop("disabled", false).val("获取验证码");
                    } else {
                        time = 300;
                        $($event.target).val("重新获取(" + time + ")");
                        var timer = setInterval(function() {
                            time--;
                            if (time < 0) {
                                $scope.sendEmailStatus = false;
                                $($event.target).prop("disabled", false).val("重新获取");
                                clearInterval(timer);
                            } else {
                                $($event.target).val("重新获取(" + time + ")");
                            }
                        }, 1000);
                    }
                });
            }
        });
    }
    
	$scope.registerSubmit = function(){
        postUrl.events("/public/register/save", $scope.formData).success(function (_data) {
            if(_data.status==200){
                layer.msg(_data.description,{icon: 1, shade: 0.3, time: 1000},function(){
                    scopeService.safeApply($scope, function(){
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    window.location.href = "/public/register/result";
                });
            }else{
                layer.msg(_data.description,{icon: 2, shade: 0.3, time: 1000},function(){
                    scopeService.safeApply($scope, function(){
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
	}
});

userApp.controller("verifyCtrl",function($scope, $http, postUrl, scopeService){
	$scope.formData = formData;
	$scope.area = area;
	$scope.workArea = workArea;
	$scope.formData.approves=[];
	$scope.formData.credits=[];
    var initbtnText = formData.btnText ? formData.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.time1 = 60;
    $scope.time2 = 60;
    $scope.sendCodeStatus1 = false;
    $scope.sendCodeStatus2 = false;
    var time1 = $scope.time1;
    var time2 = $scope.time2;

    $scope.sendPhoneCode = function($event, phone, type){
        if(!phone){
            layer.msg("请先填写正确的手机号码", {icon: 2, shade: 0.3, time: 1500});
            return;
        }
        if(type==1){
        	$scope.sendCodeStatus1 = true;
            $scope.ajaxPhoneCode($event, phone, type, time1, $scope.time1);
        }else{
        	$scope.sendCodeStatus2 = true;
            $scope.ajaxPhoneCode($event, phone, type, time2, $scope.time2);
        }
    }
    $scope.ajaxPhoneCode = function($event, phone, type, time, times){
        postUrl.events("/common/public/getPhoneCode/6/" + type, {"phone": phone}).success(function (_data) {
            if(_data.status==200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    $($event.target).val("重新获取(" + time + ")");
                    var timer = setInterval(function() {
                        time--;
                        if (time < 0) {
                            if(type==1){
                                $scope.sendCodeStatus1 = false;
                            }else{
                                $scope.sendCodeStatus2 = false;
                            }
                            $($event.target).prop("disabled", false).val("重新获取");
                            clearInterval(timer);
                            time = times;
                        } else {
                            $($event.target).val("重新获取(" + time + ")");
                        }
                    }, 1000);
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    if (_data.discription != "send_too_frequent") {
                        if(type==1){
                            $scope.sendCodeStatus1 = false;
                        }else{
                            $scope.sendCodeStatus2 = false;
                        }
                        $($event.target).prop("disabled", false).val("获取验证码");
                    } else {
                        time = 300;
                        $($event.target).val("重新获取(" + time + ")");
                        var timer = setInterval(function() {
                            time--;
                            if (time < 0) {
                                if(type==1){
                                    $scope.sendCodeStatus1 = false;
                                }else{
                                    $scope.sendCodeStatus2 = false;
                                }
                                $($event.target).prop("disabled", false).val("重新获取");
                                clearInterval(timer);
                            } else {
                                $($event.target).val("重新获取(" + time + ")");
                            }
                        }, 1000);
                    }
                });
            }
        });
    }
    //公司证件类型
    $scope.changeCompanyApprove = function(){
    	for(var key in $scope.formData.businessLicTypes){
    		if($scope.formData.businessLicTypes[key]["value"] == $scope.formData.businessLicType){
    			$scope.formData.businessLicTypeName = $scope.formData.businessLicTypes[key]["text"];
    		}
    	}
        postUrl.events("/member/realname/companyApprove/approve", {"businessLicType": $scope.formData.businessLicType}).success(function(_data){
            if(_data.status==200){
                $scope.formData.approves = _data.data.approves;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                });
            }
        });
    }

    if($scope.formData.businessLicType){
        $scope.changeCompanyApprove();
    }

    //查看证件示意
    $scope.showExample = function(index){
        for(var key in $scope.formData.approves){
            $scope.formData.approves[key]["example"] = false;
        }
        $scope.formData.approves[index]["example"] = !$scope.formData.approves[index]["example"];
    }
    $scope.hideExample = function(index){
        $scope.formData.approves[index]["example"] = false;
    }

    //删除证件图
    $scope.removeApprove = function(index){
    	$scope.formData.approves[index].credit = "";
    }
    
    //删除印章
    $scope.removeDoc = function(){
    	$scope.formData.companyDoc = "";
    }

	$scope.companySubmit = function(){
		var paramData = angular.copy($scope.formData);
		//公司印章
		if(!paramData.companyDoc){
			// layer.msg("请上传公司印章！", {icon: 2, shade: 0.3, time: 1500}, function(){});
			// return;
		}else{
			paramData.docId=paramData.companyDoc.did;
			paramData.companyDoc=null;
		}
		if(paramData.approves){
			for(var i=0;i<paramData.approves.length;i++){
				if(paramData.approves[i].useRequired==1&&(!paramData.approves[i].credit || !paramData.approves[i].credit.url)){
					layer.msg("请上传"+paramData.approves[i].showName, {icon: 2, shade: 0.3, time: 1500}, function(){});
					return;
				}
				var credit=paramData.approves[i].credit;
				credit.premiseMaterialId=paramData.approves[i].premiseMaterialId;
				paramData.credits.push(credit);
			}
			paramData.credits = angular.toJson(paramData.credits, true);
		}else{
			paramData.credits = null;
		}
		paramData.approves=null;
        postUrl.events("/member/realname/companyApprove/update", paramData).success(function(_data){
            if(_data.status==200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function(){
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    window.location.href = "/member/realname/result";
                });
            }else{
            	paramData.credits = angular.fromJson(paramData.credits, true);
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function(){
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
	}
});
//ng-bind-html后台返回html数据格式的过滤器
userApp.filter("to_trusted", ["$sce", function($sce){
    return function(text){
        return $sce.trustAsHtml(text || "");
    };
}]);
module.exports = userApp;
