package com.dy.ia.www.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;

@Controller
public class IndexController extends FrontBaseController {

	@RequestMapping("/")
	public ModelAndView index(HttpServletRequest request) throws Exception {
		return createSuccessModelAndView("forward:member/login", null);
	}
	
	@RequestMapping("/templates/test/{page}")
	public ModelAndView toPage(HttpServletRequest request,@PathVariable("page") String page) throws Exception {
		return createSuccessModelAndView(page,null);
	}
}