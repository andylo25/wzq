package com.dy.sc.www.controller.member.manager;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.cache.SysCacheUtil;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.Constant;
import com.dy.core.utils.Converter;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.LoanUtil;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.RepayUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.sc.admin.bussmodule.ReciveBillModule;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.fund.FundLoanRepay;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Maps;

/**
 * 用户管理
 *
 * @author Administrator
 */
@Controller
@RequestMapping("/member/manager/companyRepayment")
public class CompanyRepaymentController extends FrontBaseController {
    @Autowired
    private ReciveBillModule reciveBillModule;
    @Autowired
    private CommonBussUtil commonBussUtil;
    private static final int TYPE_ONE = 1;

    @RequestMapping(value = "/list/{type}")
    public ModelAndView list(@PathVariable("type") int type) throws Exception {
        ModelAndView view = new ModelAndView("member/manager/companyRepayment");
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        QueryItem queryItem = new QueryItem(Where.eq("company_id", user.getCompanyId()));
        queryItem.setWhere(Where.eq("status", -1));// 未还完的数据
        queryItem.setFields("sum(principal_total) as principalTotal,sum(amount_total-amount_yes) as amountTotal,sum(interest_total-interest_yes) as interestTotal");
        FundLoanRepay loanRepay = this.getOneByEntity(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAY, FundLoanRepay.class);
        Map<String, Object> viewData = Maps.newHashMap();
        viewData.put("loanRepay", loanRepay);
        TableHeader tableHeader = new TableHeader();
        if (type == TYPE_ONE) {
            tableHeader.setNames(new String[]{"loan_contract_no", "principal", "interest", "amount", "repay_time", "overdue_days", "action"});
            tableHeader.setTexts(new String[]{"借款合同号", "借贷金额(元)", "应还利息(元)", "应还总额(元)", "应还款日期", "逾期天数", "操作"});
            tableHeader.setTypes(new String[]{"customize", "number", "number", "number", "date", "", "openwin"});
        } else {
            tableHeader.setNames(new String[] { "loan_contract_no", "loan_amount", "interest_yes", "principal_yes", "overdue_fee",
                    "fee", "create_time" });
            tableHeader.setTexts(
                    new String[] { "借款合同号", "借贷金额(元)", "还款利息(元)", "还款本金(元)", "逾期罚息(元)", "服务费(元)", "还款日期" });
            tableHeader.setTypes(
                    new String[] { "customize", "number", "number", "number", "number", "number", "date" });
        }
        PageStructure data = PageUtil.createTablePageStructure("member/manager/companyRepayment/listData/" + type,
                "member/loan/view", "id", tableHeader, null, null);
        viewData.put("list", data);
        viewData.put("currentStatus", type);
        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;
    }

    /**
     * 还款页面
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "/repayInfo")
    public ModelAndView repayInfo(Long id, String ids) throws Exception {
        ModelAndView view = new ModelAndView("member/manager/repayInfo");
        Map<String, Object> viewData = Maps.newHashMap();
        // 还款期数表数据
        QueryItem item = new QueryItem();
        item.setWhere(Where.eq("id", id));
        Map<String, Object> period = this.getOneByMap(item, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
        // 信贷记录表
        Map<String, Object> record = this.getById((Serializable) period.get("debit_id"), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
        // 逾期费用
        Map<String, Object> repay = Maps.newHashMap();
        viewData.put("period_id", period.get("id"));
        repay.put("loan_contract_no", period.get("loan_contract_no"));// 借款合同
        repay.put("principal", period.get("principal"));// 授信金额

        Long repayTime = MapUtils.getLong(period, "repay_time");
        repay.put("repay_time", DateUtil.dateFormat(repayTime));// 应还款日期

        int overdueDays = DateUtil.daysBetween(repayTime, DateUtil.getCurrentDateLong());
        if (overdueDays < 0)
            overdueDays = 0;
        repay.put("overdue_days", overdueDays);

        FundLoanRepay loanRepay = this.getById(MapUtils.getLong(period, "repay_id"), SCModule.FUND,
                SCFunction.FUND_LOAN_REPAY, FundLoanRepay.class);

        BigDecimal principal = Converter.toBigdecimal(period.get("principal")).subtract(Converter.toBigdecimal(period.get("principal_yes")));
        BigDecimal interest = Converter.toBigdecimal(period.get("interest")).subtract(Converter.toBigdecimal(period.get("interest_yes")));
        repay.put("interest", interest);// 应还利息
        repay.put("principal", principal);// 应还本金
        BigDecimal overdueFee = LoanUtil.getPeriodOverdueFee(period, record);
        repay.put("overdueFee", overdueFee);// 逾期手续费
        BigDecimal fee = RepayUtil.calFeeRepay(loanRepay, record);
        repay.put("fee", fee);// 服务费

        repay.put("allAmount", NumberUtils.add(principal, interest, overdueFee, fee));// 还款总额
        repay.put("buss_type", record.get("business_type"));// 业务类型
        if (commonBussUtil.repayAhead(period.get("id").toString()) == ScConstants.REPAY_AHEAD_YES) {
            BigDecimal fx = commonBussUtil.repayAheadMoney(record.get("id").toString());
            repay.put("beforeInterest", fx);
            repay.put("allAmount", new BigDecimal(record.get("loan_amount").toString()).add(fx).add(fee));// 还款总额
        }

        // 账户余额
        AccAccount accAccount = BaseInfoUtils.getCompAccountEntity(record.get("company_id"));
        if (accAccount != null) {
            repay.put("balanceAmount", accAccount.getAccBalance());
        } else {
            repay.put("balanceAmount", 0);
        }
        viewData.put("repay", repay);
        boolean useTrust = SysCacheUtil.useTrust();
        viewData.put("useTrust", useTrust);
        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;
    }

    /**
     * 待还明细列表
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("/listData/{type}")
    public DyResponse listData(Integer page, Integer limit, @PathVariable("type") int type) throws Exception {
        OrgFrontUser user = getUser();
        QueryItem item = new QueryItem();
        item.setPage(page == null ? 1 : page);
        item.setLimit(limit == null ? 10 : limit);
        item.getWhere().add(Where.eq("company_id", user.getCompanyId()));
        Page pageObj = null;
        if (type == TYPE_ONE) {
        	item.setOrders("repay_time asc");
        	item.getWhere().add(Where.eq("status", -1));
            pageObj = this.getPageByMap(item, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
            List<Map> periodLogList = pageObj.getItems();
            if (periodLogList != null && periodLogList.size() > 0) {
            	this.idToName(periodLogList, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD, "debit_id:business_type,loan_apr,loan_repay_type");
            	for (Map map : periodLogList) {
            		int overdue_days = DateUtil.daysBetween(DateUtil.dateParse(DateUtil.getCurrentTime()), DateUtil.dateParse(Long.valueOf(map.get("repay_time").toString())));
            		if (overdue_days < 0) {
            			map.put("overdue_days", Math.abs(overdue_days));
            		} else {
            			map.put("overdue_days", 0);
            		}
            		map.put("repay_time", DateUtil.dateFormat(map.get("repay_time")));
            		map.put("repay_time_yes", DateUtil.dateFormat(map.get("repay_time_yes")));
            		map.put("url", "member/manager/companyRepayment/repayInfo");
            		Integer bussType = MapUtils.getInteger(map, "business_type");
            		if (bussType == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
            			map.put("action", "仓单还款");
            			map.put("url", "member/warehouse/receipt/repayInfo");
            		} else if (bussType == ScConstants.CONTRACT_TYPE_B2B) {
            			int before = commonBussUtil.repayAhead(map.get("id").toString());
            			map.put("action", before == ScConstants.REPAY_AHEAD_YES ? "提前还款" : (before == ScConstants.REPAY_AHEAD_NOT_IN_PERIOD ? "" : "还款"));
            		} else if(bussType == ScConstants.CONTRACT_TYPE_RECEIVE){
            			map.put("action", "还款");
            		}
            		map.put("loan_repay_type", DictUtils.getDictLabel(map.get("loan_repay_type").toString(), "loan_repay_type"));
            	}
            }
        } else {
        	item.setOrders("create_time desc");
            pageObj = this.getPageByMap(item, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD_LOG);
            List<Map> periodLogList = pageObj.getItems();
            if (periodLogList != null && periodLogList.size() > 0) {
            	this.idToName(periodLogList, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD, "debit_id:loan_amount,loan_apr,loan_repay_type");
            	for (Map map : periodLogList) {
            	    if(map.get("create_time") != null) {
                        map.put("create_time", Long.valueOf(map.get("create_time").toString()) * 1000);
                    }
            		map.put("loan_repay_type", DictUtils.getDictLabel(map.get("loan_repay_type").toString(), "loan_repay_type"));
            	}
            }
        }
        return createSuccessJsonResonse(pageObj);
    }

    /**
     * 还款操作
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/repay", method = RequestMethod.POST)
    public DyResponse repay(Long periodId, BigDecimal amount) throws Exception {
        if (periodId == null) {
            return createErrorJsonResonse("还款期数ID不能为空");
        }
        reciveBillModule.billRepay(periodId, amount, true);
        return createSuccessJsonResonse(null, "还款成功");
    }
}