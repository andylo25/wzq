package com.dy.sc.www.controller.member.manager;

import com.dy.core.adapter.AdapterManager;
import com.dy.core.adapter.FrontLoanAdapter;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 用户管理
 *
 * @author Administrator
 */
@Controller
@RequestMapping("/member/manager/companyLoan")
public class CompanyLoanController extends FrontBaseController {
    private static final int SELECT_DATE_ONE = 1;
    private static final int SELECT_DATE_TWO = 2;
    private static final int SELECT_DATE_THREE = 3;

    @RequestMapping(value = "/list")
    public ModelAndView list() throws Exception {
        Map<String, Object> viewData = Maps.newHashMap();
        QueryItem loanInfoQuery = new QueryItem();
        loanInfoQuery.setFields("sum(loan_amount) as loan_amount");
        loanInfoQuery.getWhere().add(Where.eq("company_id", getUser().getCompanyId()));
        loanInfoQuery.getWhere().add(Where.eq("status", 5));
        Map loanAmount = this.getOneByMap(loanInfoQuery, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
        if (loanAmount != null) {
            viewData.put("loan_amount", loanAmount.get("loan_amount"));
        } else {
            viewData.put("loan_amount", 0);
        }

        loanInfoQuery = new QueryItem();
        loanInfoQuery.setFields("sum(loan_amount) as total_amount");
        loanInfoQuery.getWhere().add(Where.eq("company_id", getUser().getCompanyId()));
        loanInfoQuery.getWhere().add(Where.in("status", "5,6"));
        Map totalAmount = this.getOneByMap(loanInfoQuery, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
        if (totalAmount != null) {
            viewData.put("total_amount", totalAmount.get("total_amount"));
        } else {
            viewData.put("total_amount", 0);
        }

        loanInfoQuery = new QueryItem();
        loanInfoQuery.setFields("count(id) as loan_count");
        loanInfoQuery.getWhere().add(Where.eq("company_id", getUser().getCompanyId()));
        loanInfoQuery.getWhere().add(Where.in("status", "1,2,3,4,8"));
        Map loanCount = this.getOneByMap(loanInfoQuery, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
        if (loanCount != null) {
            viewData.put("loan_count", loanCount.get("loan_count"));
        } else {
            viewData.put("loan_count", 0);
        }

        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"create_time", "loan_contract_no", "business_name", "loan_amount", "detail", "pledge_status"});
        tableHeader.setTexts(new String[]{"获贷时间", "信贷合同号", "业务名称", "获贷金额(元)", "详情$放款信息确认$合同签署$查看签署$缴交保证金", "状态"});
        tableHeader.setTypes(new String[]{"", "link2", "", "number", "link", ""});
        PageStructure data = PageUtil.createTablePageStructure("member/manager/companyLoan/listData", "member/loan/view", "id", tableHeader, null, null);
        viewData.put("list", data);

        QueryItem queryItem = new QueryItem();
        queryItem.setFields("id,name");
        queryItem.getWhere().add(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
        List<Map> businessType = this.getListByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        Map all = Maps.newHashMap();
        all.put("id", 0);
        all.put("name", "所有业务");
        businessType.add(0, all);
        viewData.put("businessTypes", businessType);
        return createSuccessModelAndView("member/manager/companyLoan", JsonUtils.object2JsonString(viewData));

    }

    /**
     * 获取借贷记录数据
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings({"unchecked"})
    @ResponseBody
    @RequestMapping("/listData")
    public DyResponse listData(Integer page, Integer limit, Long businessTypeId, Integer status, Integer selectDate,
                               @RequestParam(value = "startDate", required = false) String startDate, @RequestParam(value = "endDate", required = false) String endDate) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 10 : limit);
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        queryItem.setFields("id,loan_contract_no,loan_amount,status,create_time,product_id,business_type,loan_id,sign_status");
        queryItem.setWhere(Where.eq("company_id", user.getCompanyId()));
        if (status != null) {
            queryItem.getWhere().add(Where.eq("status", status));
        }
        if (businessTypeId != null && businessTypeId != 0) {
            queryItem.getWhere().add(Where.eq("business_type", businessTypeId));
        }
        if (StringUtils.isNotBlank(startDate)) {
            String end = null;
            if (StringUtils.isNotBlank(endDate)) {
                end = DateUtil.dateFormat(DateUtil.addDay(DateUtil.dateParse(endDate), 1));
            }
            Where where = this.addAndWhereCondition(null, "create_time", startDate, end);
            if (where != null) {
                queryItem.getWhere().add(where);
            }
        }
        if (selectDate != null) {
            Where timeWhere = null;
            Date today = new Date();
            String startTime = DateUtil.dateFormat(DateUtil.addDay(today, 1));
            if (selectDate == SELECT_DATE_ONE) {
                //一个月
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -1)), startTime);
            } else if (selectDate == SELECT_DATE_TWO) {
                //三个月
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -3)), startTime);
            } else if (selectDate == SELECT_DATE_THREE) {
                //一年
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -12)), startTime);
            }
            if (timeWhere != null) {
                queryItem.getWhere().add(timeWhere);
            }
        }
        queryItem.setOrders("id desc");
        Page recordPage = this.getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
        List<Map> data = recordPage.getItems();
        if (businessTypeId == 0) {// 所有业务特殊处理
            List<Map> rlt = Lists.newArrayList();
            for (Map map : data) {
                List<Map> maps = Lists.newArrayList();
                maps.add(map);
                FrontLoanAdapter loanAdapter = AdapterManager.getFrontLoanAdapter(Integer.valueOf(map.get("business_type").toString()));
                loanAdapter.buildLoanItem(maps);
                rlt.add(maps.get(0));
            }
            recordPage.setItems(rlt);
        } else {
            FrontLoanAdapter loanAdapter = AdapterManager.getFrontLoanAdapter(businessTypeId.intValue());
            loanAdapter.buildLoanItem(data);
        }

        return createSuccessJsonResonse(recordPage);
    }


}