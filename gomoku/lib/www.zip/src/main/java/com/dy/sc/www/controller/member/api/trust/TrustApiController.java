package com.dy.sc.www.controller.member.api.trust;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.exception.DyWebException;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.RepayUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.Company;
import com.dy.sc.bussmodule.loan.LoanModule;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.bussmodule.utils.TrustApiUtil;
import com.dy.sc.entity.account.AccBankCard;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.CompanyApproveStatus;
import com.dy.sc.entity.enumeration.ProdBusinessTypeEnum;
import com.dy.sc.entity.fund.FundLoanRepay;
import com.dy.sc.entity.fund.FundLoanRepayPeriod;
import com.dy.sc.entity.fund.FundLoanRepayPeriodLog;
import com.dy.sc.entity.loan.LoanDebitRecord;
import com.dy.sc.entity.money.MoneyWithdrawalsRecord;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/member/api/trust")
public class TrustApiController extends FrontBaseController {

	private static Logger log = LoggerFactory.getLogger(TrustApiController.class);
	
    @Autowired
    private TrustApiUtil trustApiUtil;
    @Autowired
    private CommonBussUtil commonBussUtil;
    @Autowired
    private LoanModule loanModule;
    
    private Company getCompany(Long companyId) throws Exception{
        return this.getById(companyId, SCModule.SYSTEM,SCFunction.SYS_COMPANY,Company.class);
    }
    
    /**
     * 
     * 开户 跳转到资管系统开户页面
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "/openBank")
    public String openBank(String type,Model model) throws Exception {
        OrgFrontUser user=getUser();
        Company comp=getCompany(user.getCompanyId());
        if(CompanyApproveStatus.PASS.getIndex()!=comp.getApproveStatus()){
            throw new DyWebException("请先进行实名认证");
        }
        type="3";//授信企业开户
        
        String redirectPath = trustApiUtil.openBank(type, comp);
        return "redirect:"+redirectPath;
    }
    
    /**
     * 读取银行卡
     * @param bankCardId
     * @param companyId
     * @return
     * @throws Exception
     * @author likf
     */
    private AccBankCard getBankCard(Long bankCardId,Long companyId) throws Exception{
        QueryItem queryItem=new QueryItem();
        queryItem.setWhere(Where.eq("company_id", companyId));
        queryItem.setWhere(Where.eq("id", bankCardId));
        return this.getOneByEntity(queryItem, SCModule.ACCOUNT,SCFunction.ACC_BANK_CARD, AccBankCard.class);
    }
    
    /**
     * 
     * 提现
     * @param bankCardId
     * @param amount
     * @return
     * @throws Exception
     * @author likf
     */
    @ResponseBody
    @RequestMapping(value = "/transferOut",method=RequestMethod.POST)
    public DyResponse transferOut(Long bankCardId,Double amount) throws Exception {
        OrgFrontUser user=getUser();
        Company comp=getCompany(user.getCompanyId());
        AccBankCard bankCard= getBankCard(bankCardId, comp.getId());
        String trn_id=UUID.randomUUID().toString();
        
        MoneyWithdrawalsRecord record=new MoneyWithdrawalsRecord();
        record.setUid(user.getId());
        record.setFlowNum(trn_id);
        record.setAccount(bankCard.getAccount());
        record.setAccountName(bankCard.getAccountName());
        record.setBankNameType(bankCard.getBankNameType());
        record.setBankCardId(bankCard.getId());
        record.setCounterFee(BigDecimal.ZERO);
        record.setDealAmount(new BigDecimal(amount));
        record.setRealAmount(new BigDecimal(amount));
//        record.setRemark();
        record.setStatus(0);
        
        String form = trustApiUtil.transferOut(trn_id,comp,bankCard,amount);
        
        this.insert(SCModule.MONEY,SCFunction.MONEY_WITHDRAWALS_RECORD, record);
        
        return createSuccessJsonResonse(form);
    }
    
    /**
     * 
     * 查询余额
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "/qcard")
    @ResponseBody
    public DyResponse qcard() throws Exception {
        OrgFrontUser user=getUser();
        BigDecimal balance=trustApiUtil.qcard(user.getCompanyId());
        return createSuccessJsonResonse(balance);
    }
    
    private FundLoanRepayPeriod getLoanRepayPeriod(Long periodId) throws Exception{
        return this.getById(periodId, SCModule.FUND,SCFunction.FUND_LOAN_REPAYPERIOD, FundLoanRepayPeriod.class);
    }
    
    private LoanDebitRecord getDebitRecord(Long debitId) throws Exception{
        return this.getById(debitId, SCModule.LOAN,SCFunction.LOAN_DEBIT_RECORD, LoanDebitRecord.class);
    }
    
    private Object[] translateFees(List<Map> fees, AccAccount creditAccount, AccAccount capitalAcc,
            AccAccount platAccount) throws Exception {

        List<Map> result = Lists.newArrayList();
        BigDecimal total = BigDecimal.ZERO;
        for (Map fee : fees) {
            Map<String, Object> item = Maps.newHashMap();

            item.put("amount", NumberUtils.format((BigDecimal) fee.get("fee_total"), NumberUtils.FORMAT));
            item.put("payerAccount", loanModule.getPayerAccount(MapUtils.getInteger(fee, "payer_type"), creditAccount,
                    capitalAcc, platAccount).getAccount());
            item.put("payeeAccount", loanModule.getPayeeAccount(MapUtils.getInteger(fee, "payee_type"), creditAccount,
                    capitalAcc, platAccount).getAccount());
            result.add(item);
            total = total.add((BigDecimal) fee.get("fee_total"));
        }
        return new Object[] { JsonUtils.object2JsonString(result), total };
    }

    /**
     * 
     * 资金划拨 还款（支持应收、B2B）
     * @param id periodId 分期id
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "/transfer")
    public String transfer(Long id, String ids, BigDecimal amount) throws Exception {
        OrgFrontUser user=getUser();
        Company comp=getCompany(user.getCompanyId());
        //借贷合同 授信企业 -> 资方
        Long fromId=null;
        FundLoanRepayPeriod period = getLoanRepayPeriod(id);
        
        LoanDebitRecord record= getDebitRecord(period.getDebitId());
        fromId=record.getCompanyId();
        
        //查询银行卡
        // AccAccount fromAccount=BaseInfoUtils.getCompAccountEntity(fromId);
        // AccAccount toAccount=BaseInfoUtils.getPlatAccount();

        AccAccount creditAccount = BaseInfoUtils.getCompAccountEntity(fromId);
        AccAccount capitalAcc = BaseInfoUtils.getCompAccountEntity(record.getCapitalId());
        AccAccount platAccount = BaseInfoUtils.getPlatAccount();
        
        AccAccount fromAccount = creditAccount;
        AccAccount toAccount = capitalAcc;

        Map<String,String> data=Maps.newHashMap();
        Long amountId = id;
        
        // 加上提前还款罚息 B2B
        BigDecimal aheadMoney = BigDecimal.ZERO;
        if (record.getBusinessType() == ProdBusinessTypeEnum.B2B.getIndex()) {
            aheadMoney = commonBussUtil.repayAheadMoney(period.getDebitId().toString());
            if (!NumberUtils.greaterEqualZero(aheadMoney)) {
                aheadMoney = BigDecimal.ZERO;
            }
        }
        FundLoanRepay repay = this.getById(period.getRepayId(), SCModule.FUND, SCFunction.FUND_LOAN_REPAY,
                FundLoanRepay.class);
        List<Map> fees = RepayUtil.calFeeDetail(repay, record.getId(), record.getLoanAmount(), record.getLoanApr(),
                record.getLoanRepayType(), record.getContractStartTime(), record.getContractEndTime(),
                RepayUtil.ON_NORMAL_REPAY);
        Object[] feeResult = translateFees(fees, creditAccount, capitalAcc, platAccount);
        String feeJson = (String) feeResult[0];// 服务费明细
        BigDecimal feeTotal = (BigDecimal) feeResult[1];// 服务费总额
        log.debug("转账费用feeJson:{}", feeJson);
        // 非足额还款
        if (amount != null) {
            FundLoanRepayPeriodLog periodLog = new FundLoanRepayPeriodLog();

            loanModule.getRepayDetail(periodLog, amount, period, repay, record, feeTotal);

            // 提前还款
            if (aheadMoney.compareTo(BigDecimal.ZERO) > 0) {
                periodLog.setInterestYes(periodLog.getInterestYes().add(aheadMoney));
                amount = amount.add(aheadMoney);
            }
            data.put("amount", NumberUtils.format(periodLog.getPrincipalYes(), NumberUtils.FORMAT));
            data.put("interest", NumberUtils.format(periodLog.getInterestYes(), NumberUtils.FORMAT));
            data.put("overdue_fee", NumberUtils.format(periodLog.getOverdueFee(), NumberUtils.FORMAT));
            data.put("feeJson", feeJson);
            data.put("fee", NumberUtils.format(feeTotal, NumberUtils.FORMAT));
            data.put("totalAmount", NumberUtils.format(amount, NumberUtils.FORMAT));
        } else {
            // 逾期费用
            int days = DateUtil.daysBetween(DateUtil.dateParse(period.getRepayTime()), DateUtil.getCurrentDate());
            BigDecimal overdueFee = null;
            try {
                overdueFee = RepayUtil.calOverdueFeeAnyTime(record.getOverdueRateValue().toString(),
                        period.getPrincipal(), period.getPrincipalYes(), days);
            } catch (Exception e) {
            }

            BigDecimal princYes = period.getPrincipalYes() == null ? BigDecimal.ZERO : period.getPrincipalYes();
            BigDecimal interYes = period.getInterestYes() == null ? BigDecimal.ZERO : period.getInterestYes();
            // BigDecimal overdueYes = period.getOverdueFee() == null ?
            // BigDecimal.ZERO : period.getOverdueFee();
            BigDecimal principal = period.getPrincipal().subtract(princYes);
            // 加上提前罚息
            BigDecimal interest = period.getInterest().subtract(interYes).add(aheadMoney);
            if(aheadMoney.compareTo(BigDecimal.ZERO) > 0){
                interest = aheadMoney.add(feeTotal);// 只算罚息和服务费不计算利息
            }
            // BigDecimal fee = period.getFee();
            // totalAmount = NumberUtils.add(principal, interest, overdueFee,
            // fee, aheadMoney);

            data.put("amount", NumberUtils.format(principal, NumberUtils.FORMAT));
            data.put("interest", NumberUtils.format(interest, NumberUtils.FORMAT));
            data.put("overdue_fee", NumberUtils.format(overdueFee, NumberUtils.FORMAT));
            data.put("feeJson", feeJson);
            data.put("fee", NumberUtils.format(feeTotal, NumberUtils.FORMAT));
            data.put("totalAmount", NumberUtils.format(principal.add(interest), NumberUtils.FORMAT));
        }

        data.put("mobile", comp.getLegalPhoneNumber());
        data.put("available_account", NumberUtils.format(fromAccount.getAccBalance()));
        data.put("ids", ids);
        
        String redirectPath = trustApiUtil.transferAsyn(fromAccount, toAccount, data, amountId, ScConstants.TRANS_TXN_TYPE_1, record.getBusinessType().toString());
        return "redirect:"+redirectPath;
    }
    
    @RequestMapping(value = "/toLogin")
    public String toLogin() throws Exception {
        OrgFrontUser user=getUser();
        String redirectPath = trustApiUtil.toLogin(user);
        return "redirect:"+redirectPath;
    }
}
