package com.dy.ia.www.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.sc.entity.common.SystemInfo;

@Controller
@RequestMapping("/public")
public class PublicController extends FrontBaseController {

	@RequestMapping("/")
	public ModelAndView index(HttpServletRequest request) throws Exception {
		return createSuccessModelAndView("forward:common/member/login", null);
	}
	
	/**
	 * 消息提示页面
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/public/msg", method = RequestMethod.GET)
	public ModelAndView toTrustMsg(@ModelAttribute("status") String status,
			@ModelAttribute("message") String message,
			@ModelAttribute("url") String url) throws Exception {
		ModelAndView view = new ModelAndView();
		SystemInfo system = new SystemInfo();
		system.setContentPage("trust/msg.html");

		view = initSystemPageView(system);
		view.addObject("status", status);
		view.addObject("message", message);
		view.addObject("url", url);
		return view;
	}
}