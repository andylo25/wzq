package com.dy.ia.www.controller.member;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.GenNumUtil;
import com.dy.core.utils.sms.SmsUtil;
import com.dy.ia.entity.common.SysSystemConfig;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;

/**
 * 手机认证
 */
@Controller
@RequestMapping("/member")
public class PhoneAuthController extends FrontBaseController {
	@Autowired
	private SmsUtil smsUtil;
	
	/**
	 * 发送短信
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/phone/sendsms")
	public DyResponse sendSms(String type, Long phone) throws Exception {
		Long sendPhone = phone;
		OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
		Long userId = null;
		String userName = null;
		if (user != null) {
			user = getMember(user.getId());
			if (sendPhone == null) {
				sendPhone = user.getPhone();
			}
			userId = user.getId();
			userName = user.getRealName();
		}
		if (sendPhone == null) {
			return this.createErrorJsonResonse("短信发送失败");
		}
		
		//发送短信
		String msgCode = GenNumUtil.sixCode();

		Integer smsType = null;
		if ("reset".equals(type)) {//解绑手机
			smsType = 2;
		} else if ("approve".equals(type)) {//认证手机
			smsType = 3;
			
			//判断手机是否被占用
			DyResponse response = validatePhoneExist(phone);
			if(response != null) return response;
		} else {
			smsType = 3;
		}
		Map<String, String> templateParam = new HashMap<String,String>();
		templateParam.put("#code#", msgCode);
		templateParam.put("#service_tel#", getSysValue("service_tel"));
		
		smsUtil.send(sendPhone.toString(), 10L, templateParam, smsType, 1, userId, userName);
		
		this.setSessionAtrribute("sys_code", msgCode);
		this.setSessionAtrribute("cur_time", DateUtil.getCurrentTime());
		this.setSessionAtrribute("click_count", null);
		this.setSessionAtrribute(Constant.SESSION_PHONE_CODE,msgCode);
		return createSuccessJsonResonse(null, "短信发送成功");
	}
	
	/**
	 * 解绑
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/phone/resetphone")
	public DyResponse resetphone(String type,String phone_code) throws Exception {
		
		String sessionCode =  (String) this.getSessionAttribute("sys_code");
		if(!phone_code.equals(sessionCode))return createErrorJsonResonse("验证码错误!");
		//解绑
		OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
		user = getMember(user.getId());
		user.setPhone(0L);
		this.update(SCModule.SYSTEM, SCFunction.SYS_USER, user);
		//更新session
		OrgFrontUser cus = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		cus.setPhone(0L);
		this.setSessionAtrribute(Constant.SESSION_USER, cus);
		
		return createSuccessJsonResonse(null,"approve_reset_success");
	}
	
	/**
	 * 绑定手机
	 */
	@ResponseBody
	@RequestMapping("/phone/approvephone")
	public DyResponse approvephone(Long phone,String phone_code) throws Exception {
		String sessionCode = (String) this.getSessionAttribute("sys_code");
		Integer count = null == (Integer)this.getSessionAttribute("click_count")?1:(Integer)this.getSessionAttribute("click_count");
		
		//最多输入5次验证码
 		if(count == 6){
			this.setSessionAtrribute("sys_code", "");
			return createErrorJsonResonse("验证码输入超过5次，请重新获取!");
		}
		
		if(!phone_code.equals(sessionCode)){
			this.setSessionAtrribute("click_count", ++count);
			return createErrorJsonResonse("验证码错误");
		}
		
		//判断手机是否被占用
		DyResponse response = validatePhoneExist(phone);
		if(response != null) return response;
		
		//验证码过期(5mins)
		Long getTime = (Long) this.getSessionAttribute("cur_time");
		if(DateUtil.getCurrentTime() - getTime > 300){
			return createErrorJsonResonse("验证码输入超时,请重新获取!");
		}
		
		//更新用户
		OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
		user = getMember(user.getId());
		user.setPhone(phone);
//		user.setIsPhone(1);
		this.update(SCModule.SYSTEM, SCFunction.SYS_USER, user);
		
		//重新设置session
		this.removeSessionAttribute(Constant.SESSION_USER);
		this.setSessionAtrribute(Constant.SESSION_USER, user);
		String returnPhone =String.valueOf(phone);
		returnPhone = returnPhone.substring(0,returnPhone.length()-(returnPhone.substring(3)).length())+"****"+returnPhone.substring(7);
		return createSuccessJsonResonse(returnPhone,"认证成功!");
	}
	
	private DyResponse validatePhoneExist(Long phone) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.getWhere().add(Where.eq("phone", phone));
		OrgFrontUser muser = getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
		
//		QueryItem phoneQueryItem = new QueryItem();
//		List<Where> where = new ArrayList<Where>();
//		where.add(Where.eq("phone", phone));
//		List<NameValue> ands = new ArrayList<NameValue>();
//		ands.add(new NameValue("status",1,"=",true));
//		ands.add(new NameValue("status",-2,"=",true));
//		where.add(new Where(ands));
//		phoneQueryItem.setWhere(where);
//		List<MbApprovePhone> mphone = getListByEntity(phoneQueryItem, SCModule.MEMBER, SCFunction.MB_PHONE, MbApprovePhone.class);
		if(muser != null)return createErrorJsonResonse("该手机已存在!");
		
		return null;
	}
	
	public static boolean isPhoneLegal(String str) throws PatternSyntaxException {  
        String regExp = "^((13[0-9])|(15[^4])|(18[0,2,3,5-9])|(17[0-8])|(147))\\d{8}$";  
        Pattern p = Pattern.compile(regExp);  
        Matcher m = p.matcher(str);  
        return m.matches();  
    } 
	
	/**
	 * 根据id获取用户
	 * @throws Exception 
	 */
	public OrgFrontUser getMember(Long memberId) throws Exception{
		QueryItem userItem = new QueryItem();
		userItem.getWhere().add(Where.eq("id", memberId));
		OrgFrontUser user = this.getOneByEntity(userItem, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
		return user;
	}
	
	/**
	 * 根据nid获取系统配置
	 * @throws Exception 
	 */
	private String getSysValue(String nid) throws Exception{
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("nid", nid));
		item.setFields("value");
		SysSystemConfig config = this.getOneByEntity(item, SCModule.SYSTEM, SCFunction.SYS_CONFIG, SysSystemConfig.class);
		return config == null ? "": config.getValue();
	}
}