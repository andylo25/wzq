package com.dy.sc.www.controller.member.company;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.*;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.common.FlowProcInst;
import com.dy.ia.www.controller.common.VerifyCodeController;
import com.dy.sc.bussmodule.utils.workflow.WorkflowUtil;
import com.dy.sc.entity.constant.SCFlow;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.CommonStatus;
import com.dy.sc.entity.enumeration.CompanyApproveStatus;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.entity.system.CompanyCredit;
import com.dy.sc.entity.system.PremiseMaterial;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 用户管理
 *
 * @author Administrator
 */
@Controller
@RequestMapping("/member")
public class CompanyController extends FrontBaseController {

    @Autowired
    private WorkflowUtil workflowUtil;
    @Autowired
    private FDDUtils utils;

    /**
     * 授信记录 详情页
     *
     * @param id
     * @return
     * @throws Exception
     */

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/realname/companyApprove")
    public ModelAndView companyApprove() throws Exception {
        //id
        //OrgFrontUser user=(OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
        Long id = getUser().getCompanyId();
        ModelAndView view = new ModelAndView("member/realname/companyApprove");
        Map<String, Object> viewData = Maps.newHashMap();
        Company company = this.getById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        Map<String, Object> companytMap = (Map<String, Object>) new DataConvertUtil(company, false).convert();
        if (company.getDocId() != null) {
            Map<String, Object> doc = this.getById(company.getDocId(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT);
            if (doc != null) {
                Map<String, Object> file = Maps.newHashMap();
                file.put("name", doc.get("file_name"));
                file.put("url", doc.get("file_path"));
                file.put("did", doc.get("id"));
                viewData.put("companyDoc", file);
            }
        }
        viewData.putAll(companytMap);
        viewData.put("id", id);
        viewData.put("companyCreateTime1", DateUtil.dateFormat(DateUtil.dateParse(company.getCompanyCreateTime())));
        //省市id
        if (company.getCompanyAreaId() != null) {
            Long cityId = getAreaPidByAeraId(company.getCompanyAreaId());
            viewData.put("cityId", cityId);
            viewData.put("provinceId", getAreaPidByAeraId(cityId));
        }

        if (company.getWorkAreaId() != null) {
            Long workCityId = getAreaPidByAeraId(company.getWorkAreaId());
            viewData.put("workCityId", workCityId);
            viewData.put("workProvinceId", getAreaPidByAeraId(workCityId));
        }
        //下拉框、单选按钮
        viewData.put("businessLicTypes", DictUtils.getOptionsInt("business_lic_type"));
        viewData.put("types", DictUtils.getOptionsInt("company_type"));
        viewData.put("scales", DictUtils.getOptionsInt("company_scale"));
        viewData.put("categorys", DictUtils.getOptionsInt("company_category"));
        viewData.put("credTypes", DictUtils.getOptions("cred_type"));
        viewData.put("commonStatus", DictUtils.getOptionsInt("common_status"));
        viewData.put("fdd_open", utils.fadadaOpen());
        //省市区
        List workList = Lists.newArrayList();
        Map item = Maps.newHashMap();
        item.put("name", "workProvinceId");
        workList.add(item);
        item = Maps.newHashMap();
        item.put("name", "workCityId");
        workList.add(item);
        item = Maps.newHashMap();
        item.put("name", "workAreaId");
        workList.add(item);

        List areaList = Lists.newArrayList();
        item = Maps.newHashMap();
        item.put("name", "provinceId");
        areaList.add(item);
        item = Maps.newHashMap();
        item.put("name", "cityId");
        areaList.add(item);
        item = Maps.newHashMap();
        item.put("name", "companyAreaId");
        areaList.add(item);

        viewData.put("workList", workList);
        viewData.put("areaList", areaList);
        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;

    }

    /**
     * 更新用户
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/realname/companyApprove/update")
    public DyResponse update(Company company, String companyCreateTime1, String legalPhoneCode, String financialPhoneCode,
                             @RequestParam("credits") String credits) throws Exception {

        if (isCompanyExists(company.getId(), company.getCompanyName())) {
            return createErrorJsonResonse("企业名称已存在，不能更改，请重新输入！");
        }
        if (isBusinessLicNoExists(company.getId(), company.getBusinessLicNo())) {
            return createErrorJsonResonse("证件号码已存在，不能更改，请重新输入！");
        }
        //短信验证码
        String sessionLegalCode = (String) VerifyCodeController.getPhoneCode(company.getLegalPhoneNumber(),1L);
        String sessionFinancialCode = (String) VerifyCodeController.getPhoneCode(company.getFinancialPhoneNumber(), 2L);
        if (StringUtils.isBlank(legalPhoneCode) || StringUtils.isBlank(sessionLegalCode) || !legalPhoneCode.equalsIgnoreCase(sessionLegalCode)) {
            return createErrorJsonResonse("法人手机校验码不正确！");
        }
        if (StringUtils.isBlank(financialPhoneCode) || StringUtils.isBlank(sessionFinancialCode) || !financialPhoneCode.equalsIgnoreCase(sessionFinancialCode)) {
            return createErrorJsonResonse("财务手机校验码不正确！");
        }
        //处理地区字段
        String ids = null;
        if (company.getWorkAreaId() != null) {
            ids = company.getWorkAreaId().toString();
        }
        if (company.getCompanyAreaId() != null) {
            if (ids != null) {
                ids += "," + company.getCompanyAreaId();
            } else {
                ids = company.getCompanyAreaId().toString();
            }
        }

        if (ids != null) {
            QueryItem queryItem = new QueryItem();
            queryItem.setFields("id,province,city");
            queryItem.setWhere(Where.in("id", ids));
            List<Map> areaList = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS);
            ids = "";
            String[] workAreaIds = null;
            String[] companyAreaIds = null;
            for (Map item : areaList) {
                //获取省市
                if (ids != null && !"".equals(ids))
                    ids += ",";
                ids += item.get("province") + "," + item.get("city") + "," + item.get("id");
                Long areaId = Long.parseLong(item.get("id").toString());
                if (areaId.equals(company.getWorkAreaId())) {
                    workAreaIds = new String[3];
                    workAreaIds[0] = item.get("province").toString();
                    workAreaIds[1] = item.get("city").toString();
                    workAreaIds[2] = item.get("id").toString();
                } else if (areaId.equals(company.getCompanyAreaId())) {
                    companyAreaIds = new String[3];
                    companyAreaIds[0] = item.get("province").toString();
                    companyAreaIds[1] = item.get("city").toString();
                    companyAreaIds[2] = item.get("id").toString();
                }
            }
            queryItem = new QueryItem();
            queryItem.setFields("id,name");
            queryItem.setWhere(Where.in("id", ids));
            areaList = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS);
            Map<String, String> areaResult = Maps.newHashMap();
            for (Map item : areaList) {
                //获取省市中文
                areaResult.put(item.get("id").toString(), item.get("name").toString());
            }
            if (workAreaIds != null) {
                String tempStr0 = areaResult.get(workAreaIds[0]);
                String tempStr1 = areaResult.get(workAreaIds[1]);
                company.setWorkArea((tempStr1.startsWith(tempStr0) ? tempStr1 : tempStr0 + tempStr1) + areaResult.get(workAreaIds[2]));
            }
            if (companyAreaIds != null) {
                String tempStr0 = areaResult.get(companyAreaIds[0]);
                String tempStr1 = areaResult.get(companyAreaIds[1]);
                company.setCompanyArea((tempStr1.startsWith(tempStr0) ? tempStr1 : tempStr0 + tempStr1) + areaResult.get(companyAreaIds[2]));
            }
        }
        company.setCompanyCreateTime(DateUtil.convert(companyCreateTime1));
        //认证状态置为待审核
        company.setApproveStatus(CompanyApproveStatus.SUBMIT.getIndex());


        Map<String, Object> cond = Maps.newHashMap();
        cond.put("cond1", company.getId());
        cond.put("cond2", company.getCompanyName());
        // 有业务员并配置为自动审批时自动审批，没业务员后台人工审批，审批时提示分配业务员
        Company comp = getById(company.getId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        if (comp.getSalerId() == null) {
            cond.put(WorkflowUtil.AUTO_SUBMIT_COND_KEY, WorkflowUtil.MAN_SUBMIT);
        }
        FlowProcInst procInst = workFlowUtil.startFlowPub(SCFlow.FLOW_SHIMING, company.getBusinessLicNo(), "实名认证申请", company.getId(), cond);
        //记录审批流id
        if (StringUtils.isNotBlank(company.getProcInstIds())) {
            company.setProcInstIds(company.getProcInstIds() + "," + procInst.getId());
        } else {
            company.setProcInstIds(procInst.getId().toString());
        }
        this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);

        if (StringUtils.isNotBlank(credits)) {
            List<Map> items = JsonUtils.jsonToList(credits, Map[].class);
            if (CollectionUtils.isNotEmpty(items)) {
                for (Map item : items) {
                    if (item.get("id") == null) {
                        CompanyCredit cc = new CompanyCredit();
                        cc.setCompanyId(company.getId());
                        cc.setFileName(item.get("name").toString());
                        cc.setFilePath(item.get("url").toString());
                        Double pid = Double.parseDouble(item.get("premiseMaterialId").toString());
                        cc.setPremiseMaterialId(pid.longValue());
                        this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT, cc);
                    } else {
                        Double id = Double.parseDouble(item.get("id").toString());
                        CompanyCredit cc = new CompanyCredit();
                        cc.setId(id.longValue());
                        cc.setFileName(item.get("name").toString());
                        cc.setFilePath(item.get("url").toString());
                        this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT, cc);
                    }
                }
            }
        }
        return createSuccessJsonResonse(null, "提交成功！");
    }


    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/realname/result")
    public ModelAndView result(Long id) throws Exception {
        ModelAndView view = new ModelAndView("member/realname/approveResult");
        return view;

    }

    private Long getAreaPidByAeraId(Long areaId) throws Exception {
        Map<String, Object> area = this.getById(areaId, SCModule.SYSTEM, SCFunction.SYS_AREAS);
        return Long.parseLong(area.get("pid").toString());
    }

    /**
     * 前台界面数据：根据证件类型获取准入材料数据
     *
     * @param businessLicType
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/realname/companyApprove/approve")
    public DyResponse approve(Integer businessLicType) throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("del_flag", 0));
        //后台配置是否前台显示
        item.getWhere().add(Where.eq("use_display", CommonStatus.TRUE.getIndex()));
        item.setFields(" id, name, use_required as useRequired, use_display as useDisplay, remark, file_path as filePath, file_name as fileName, business_lic_type as businessLicType ");
        List<PremiseMaterial> premiseMaterials = this.getListByEntity(item, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, PremiseMaterial.class);
        //已经提交过认证的公司,提交的认证文件

        QueryItem creditItem = new QueryItem();
        creditItem.getWhere().add(Where.eq("del_flag", 0));
        creditItem.getWhere().add(Where.eq("company_id", getUser().getCompanyId()));
        List<CompanyCredit> credits = this.getListByEntity(creditItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT, CompanyCredit.class);
        List<Map> approves = Lists.newArrayList();
        //businessLicType多个使用逗号分割，判断存在相同的值的准入材料数据
        if (premiseMaterials != null && premiseMaterials.size() > 0) {
            for (PremiseMaterial pm : premiseMaterials) {
                String typeStr = pm.getBusinessLicType();
                if (StringUtils.isNoneBlank(typeStr)) {
                    String[] typeIds = typeStr.split(",");
                    for (String typeId : typeIds) {
                        if (businessLicType == Integer.parseInt(typeId)) {
                            Map<String, Object> data = Maps.newHashMap();
                            data.put("premiseMaterialId", pm.getId());
                            data.put("showUrl", pm.getFilePath());
                            data.put("showName", pm.getName());
                            data.put("showRemark", pm.getRemark());
                            //是否必须上传
                            data.put("useRequired", pm.getUseRequired());
                            //已经提交过认证
                            if (credits != null && credits.size() > 0) {
                                for (CompanyCredit credit : credits) {
                                    if (pm.getId().equals(credit.getPremiseMaterialId())) {
                                        Map file = Maps.newHashMap();
                                        file.put("url", credit.getFilePath());
                                        file.put("name", credit.getFileName());
                                        file.put("id", credit.getId());
                                        data.put("credit", file);
                                    }
                                }
                            } else {
                                data.put("credit", "");
                            }

                            approves.add(data);
                        }
                    }
                }
            }
        }
        Map<String, Object> data = Maps.newHashMap();
        data.put("approves", approves);
        return createSuccessJsonResonse(data);
    }

    private boolean isCompanyExists(Long id, String companyName) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields("count(1) as count");
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "company_name", companyName);
        this.addWhereCondition(where, "del_flag", 0);
        query.setWhere(where);
        if (id != null) {
            query.getWhere().add(Where.notEq("id", id));
        }
        Map<String, Object> result = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        if (result != null && result.size() > 0 && Integer.parseInt(result.get("count").toString()) > 0) {
            return true;
        }
        return false;
    }

    private boolean isBusinessLicNoExists(Long id, String businessLicNo) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields("count(1) as count");
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "business_lic_no", businessLicNo);
        this.addWhereCondition(where, "del_flag", 0);
        query.setWhere(where);
        if (id != null) {
            query.getWhere().add(Where.notEq("id", id));
        }
        Map<String, Object> result = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        if (result != null && result.size() > 0 && Integer.parseInt(result.get("count").toString()) > 0) {
            return true;
        }
        return false;
    }
}