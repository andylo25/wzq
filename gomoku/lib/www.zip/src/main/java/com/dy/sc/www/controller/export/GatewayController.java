package com.dy.sc.www.controller.export;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.entity.DyResponse;

@Controller
@RequestMapping("ast/gateway")
public class GatewayController extends FrontBaseController{
	
	private static final Logger logger = Logger.getLogger(GatewayController.class);
	
	/**
	 * 获取资产溯源信息
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("getAssetsInfo")
	public DyResponse getAssetsInfo(@RequestAttribute(AccConstants.DECRYPT_DATA_REQUEST) Map<String,Object> paramMap) throws Exception {
		
//		paramMap.get("")
		
		return createSuccessJsonResonse(null);
	}
	
	
}
