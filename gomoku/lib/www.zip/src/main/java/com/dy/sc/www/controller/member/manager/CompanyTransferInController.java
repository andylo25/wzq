package com.dy.sc.www.controller.member.manager;

import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.utils.Converter;
import com.dy.core.utils.JsonUtils;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.org.OrgFrontUser;

/**
 * 
 * 立即转入
 * @ClassName: CompanyTransferInController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年9月1日 上午10:25:48 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/member/manager/companyTransferIn")
public class CompanyTransferInController extends FrontBaseController {
	
	/**
	 * 
	 * 立即转入
	 * @return
	 * @throws Exception
	 * @author likf
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(method=RequestMethod.GET)
    public ModelAndView view() throws Exception {
	    OrgFrontUser user=this.getUser();
		
        Map<String, Object> accountMap= BaseInfoUtils.getCompAccountMap(user.getCompanyId());
        accountMap.put("openFullName", Converter.toString(accountMap.get("open_full_name")));
        String account=MapUtils.getString(accountMap, "account");
        accountMap.put("account", split(account));
        
        return createSuccessModelAndView("member/manager/companyTransferIn", JsonUtils.object2JsonNoEscaping(accountMap));
    }
	
	private String split(String account){
	    if(StringUtils.isNoneBlank(account)){
	        StringBuffer sb=new StringBuffer();
	        for(int i=0;i<account.length()/4.0;i++){
	            if((i+1)*4>=account.length()){
	                sb.append(account.substring(i*4,account.length()));
	            }else{
	                sb.append(account.substring(i*4,(i+1)*4)).append(" ");
	            }
	        }
	        return sb.toString();
	    }
	    return null;
	}
	
}