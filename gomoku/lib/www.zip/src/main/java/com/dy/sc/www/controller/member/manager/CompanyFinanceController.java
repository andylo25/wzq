package com.dy.sc.www.controller.member.manager;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.cache.SysCacheUtil;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.utils.Constant;
import com.dy.core.utils.Converter;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.ia.entity.common.Company;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.enumeration.MortgageType;
import com.dy.sc.entity.enumeration.Status;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.entity.product.ProdBusinessType;
import com.dy.sc.entity.product.ProdProductB2B;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 用户管理
 *
 * @author Administrator
 */
@Controller
@RequestMapping("/member/manager")
public class CompanyFinanceController extends FrontBaseController {

    @SuppressWarnings({"rawtypes"})
    @RequestMapping(value = "/businessList")
    public ModelAndView businessList() throws Exception {

        ModelAndView view = new ModelAndView("member/manager/businessList");
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Map<String, Object> viewData = Maps.newHashMap();
        Company company = this.getById(user.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("*");
        queryItem.setWhere(Where.eq("del_flag", 0));
        List<Map> businessList = this.getListByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        viewData.put("businessList", businessList);
        viewData.put("company", company);
        //是否开户
        Map account = getAccount(company.getId());
        if (!SysCacheUtil.useTrust() || (account != null && StringUtils.isNotBlank(Converter.toString(account.get("account"))))) {
            viewData.put("isOpenBank", true);
        } else {
            viewData.put("isOpenBank", false);
        }
        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/companyFinance")
    public ModelAndView companyLoan(Integer businessId) throws Exception {

        ModelAndView view = new ModelAndView("member/manager/companyFinance");
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Map<String, Object> viewData = Maps.newHashMap();
        Company company = this.getById(user.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("*");
        queryItem.getWhere().add(Where.eq("status", Status.OPEN.getIndex()));
        queryItem.getWhere().add(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
        if (businessId != null) {
            queryItem.getWhere().add(Where.eq("business_type_id", businessId));
            if (businessId == ScConstants.CONTRACT_TYPE_RECEIVE) {
                queryItem.getWhere().add(Where.in("core_company_ids", BaseInfoUtils.getCheckedCoreCompanys(getUser())));
            }
        }
        queryItem.setWhere(Where.eq("release_status", ScConstants.RELEASE_STATUS_YES));
        queryItem.setOrders(" create_time desc");
        List<Map> products = this.getListByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO);
        if (products != null && products.size() > 0) {
            List<Long> productIds = Lists.newArrayList();
            for (Map map : products) {
                productIds.add(Long.parseLong(map.get("id").toString()));
            }
            //前台显示子表
            QueryItem feeValueQuery = new QueryItem();
            feeValueQuery.getWhere().add(Where.in("product_id", productIds));
            feeValueQuery.getWhere().add(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
            feeValueQuery.setFields(" id, product_id, loan_day, loan_apr ");
            feeValueQuery.setOrders(" product_id desc");
            List<Map> feeValues = this.getListByMap(feeValueQuery, SCModule.PRODUCT, SCFunction.PROD_FEE_VALUE);
            for (Map map : products) {
                Integer businessType = MapUtils.getInteger(map, "business_type_id");
                String unit = "个月";
                //质押类型
                String mortgageType = map.get("mortgage_type").toString();
                if (StringUtils.isNotBlank(mortgageType)) {
                    if (MortgageType.DAY.getIndex() == Integer.parseInt(mortgageType)) {//按天
                        unit = "天";
                    }
                }
                Long id = Long.parseLong(map.get("id").toString());
                Integer maxLoanDay = 0;

                QueryItem query1 = new QueryItem(Where.in("id", map.get("repay_type_id")));
                query1.setFields("id,name,contents,status");
                List<Map> repayTypeMap = this.getListByMap(query1, SCModule.FUND, SCFunction.FUND_REPAYTYPE);
                String desc = "";
                for (Map m : repayTypeMap) {
                    desc += m.get("name") + ",";
                }
                map.put("repay_type_desc", desc.substring(0, desc.length() - 1));

                if (businessType == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
                    QueryItem queryWH = new QueryItem();
                    queryWH.setWhere(Where.eq("product_id", map.get("id")));
                    maxLoanDay = Integer.parseInt(map.get("mortgage_time_end").toString());
                }
                BigDecimal minLoanApr = new BigDecimal(0);
                for (Map feeValue : feeValues) {
                    if (id.equals(Long.parseLong(feeValue.get("product_id").toString()))) {
                        Integer loanDay = feeValue.get("loan_day") == null ? 0 : Integer.parseInt(feeValue.get("loan_day").toString());
                        BigDecimal loanApr = feeValue.get("loan_apr") == null ? BigDecimal.ZERO : new BigDecimal(feeValue.get("loan_apr").toString());
                        if (loanDay > maxLoanDay) {
                            maxLoanDay = loanDay;
                        }
                        if (loanApr.compareTo(minLoanApr) == -1) {
                            minLoanApr = loanApr;
                        }
                    }
                }
                if (businessType == ScConstants.CONTRACT_TYPE_RECEIVE) {
                    map.put("mortgage_time_end", maxLoanDay);
                }
                map.put("unit", unit);
                map.put("max_loan_day", maxLoanDay);
                map.put("business_type", this.getById(map.get("business_type_id").toString(),
                        SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class).getName());
                if (Integer.parseInt(map.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_B2B) {
                    QueryItem query = new QueryItem(Where.eq("product_id", map.get("id")));
                    ProdProductB2B b2b = this.getOneByEntity(query, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B, ProdProductB2B.class);
                    map.put("min_loan_apr", b2b.getDayInterest());

                    int settleMonth = b2b.getSettleMonthType();
                    int settleEndDay = b2b.getSettleEndDay();
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.MONTH, settleMonth - 1);
                    cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), settleEndDay);
                    Date s = cal.getTime();
                    Date day = new Date();
                    map.put("mortgage_time_end", DateUtil.daysBetween(day, s));
                } else if (Integer.parseInt(map.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
                    map.put("min_loan_apr", MapUtils.getDouble(map, "loan_apr_start") / 360D);// 日利率
                    // Map fee = null;
                    // for (Map feeValue : feeValues) {
                    // if
                    // (id.equals(Long.parseLong(feeValue.get("product_id").toString())))
                    // {
                    // fee = feeValue;
                    // }
                    // }
                    // if (fee == null) {
                    // map.put("min_loan_apr", 0);
                    // } else {
                    // Object apr = MapUtils.getObject(fee, "loan_apr");
                    // if (apr != null) {
                    // map.put("min_loan_apr",
                    // NumberUtils.mul(NumberUtils.div(new
                    // BigDecimal(fee.get("loan_apr").toString()), new
                    // BigDecimal(360)), new BigDecimal(100)));
                    // } else {
                    // map.put("min_loan_apr", 0);
                    // }
                    // }
                } else {
                    map.put("min_loan_apr",
                            NumberUtils.div(new BigDecimal(map.get("loan_apr_start").toString()), new BigDecimal(360)));
                }
            }
        }
        viewData.put("products", products);
        viewData.put("company", company);
        //是否开户
        Map account = getAccount(company.getId());
        if (!SysCacheUtil.useTrust() || (account != null && account.get("account") != null && StringUtils.isNotBlank(account.get("account").toString()))) {
            viewData.put("isOpenBank", true);
        } else {
            viewData.put("isOpenBank", false);
        }
        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;

    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private Map getAccount(Object companyId) throws Exception {
        if (companyId != null) {
            Map data = BaseInfoUtils.getCompAccountMap(companyId);
            data.put("openBank", Converter.toString(data.get("pid")));
            return data;
        }
        return null;
    }
}