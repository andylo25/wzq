package com.dy.sc.www.controller.member.manager;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.utils.JsonUtils;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.account.AccBankCard;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;

/**
 * 
 * 提现界面
 * @ClassName: CompanyTransferController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年8月24日 下午2:01:33 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/member/manager/companyTransfer")
public class CompanyTransferController extends FrontBaseController {
	
	/**
	 * 
	 * 提现界面
	 * @return
	 * @throws Exception
	 * @author likf
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(method=RequestMethod.GET)
    public ModelAndView view() throws Exception {
	    OrgFrontUser user=this.getUser();
		QueryItem queryItem=new QueryItem();
		queryItem.setWhere(Where.eq("company_id", user.getCompanyId()));
        List<AccBankCard> cards= this.getListByEntity(queryItem, SCModule.ACCOUNT,SCFunction.ACC_BANK_CARD,AccBankCard.class);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("cards", dataConvert(cards, "bankNameType:bank_code"));
		
        Map<String, Object> account = BaseInfoUtils.getCompAccountMap(user.getCompanyId());
        result.put("acc_balance", com.dy.core.utils.NumberUtils.format(new BigDecimal(MapUtils.getString(account, "acc_balance"))));
		return createSuccessModelAndView("member/manager/companyTransferOut", JsonUtils.object2JsonNoEscaping(result));
    }
	
}