package com.dy.sc.www.conf;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.dy.core.adapter.AdapterManager;
import com.dy.core.adapter.FrontLoanAdapter;
import com.dy.core.adapter.LoanAdapter;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.entity.constant.CommonConstant;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;

@Component
public class StartupListener implements ApplicationListener<ApplicationReadyEvent> {

    @Value("${diyou.siteName}")
    private String siteName;
    
    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
    	
        initModule();
        
        // 扩展点加载
        initAdapter(event);
    }
    
    private void initModule() {
        
        //写入系统变量
        BaseInfoUtils.getSystemInfo(0);
        
        //供应链菜单先独立开来 查询表sys_menu_supplychain;
        Function.SYS_MENU="menu_supplychain";
        
        //指向供应链数据库
        Module.ACCOUNT="sc_"+Module.ACCOUNT;
        Module.CREDIT="sc_"+Module.CREDIT;
        Module.FLOW="sc_"+Module.FLOW;
        Module.LOAN="sc_"+Module.LOAN;
        Module.MEMBER="sc_"+Module.MEMBER;
        Module.REPORT="sc_"+Module.REPORT;
        Module.SYSTEM="sc_"+Module.SYSTEM;
        
        //common jar中system模块
        CommonConstant.MODULE_SYSTEM="sc_"+CommonConstant.MODULE_SYSTEM;
        CommonConstant.MODULE_BUSINESS="sc_fund";
	}

    private void initAdapter(ApplicationReadyEvent event) {
    	Map<String, FrontLoanAdapter> frontLoadAdapters = event.getApplicationContext().getBeansOfType(FrontLoanAdapter.class);
    	if(frontLoadAdapters != null){
    		for(FrontLoanAdapter adapter:frontLoadAdapters.values()){
    			AdapterManager.instance().addFrontLoanAdapter(adapter);
    		}
    	}
    	
    	Map<String, LoanAdapter> loadAdapters = event.getApplicationContext().getBeansOfType(LoanAdapter.class);
    	if(loadAdapters != null){
    		for(LoanAdapter adapter:loadAdapters.values()){
    			AdapterManager.instance().addLoanAdapter(adapter);
    		}
    	}
	}

}
