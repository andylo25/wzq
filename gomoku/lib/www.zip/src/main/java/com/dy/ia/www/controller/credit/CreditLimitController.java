package com.dy.ia.www.controller.credit;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.GenNumUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.CreApplyRecord;
import com.dy.ia.entity.common.CreLimitInfo;
import com.dy.ia.entity.common.FlowProcInst;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Maps;
/**
 * 交易记录
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/limit")
public class CreditLimitController extends FrontBaseController {
	
	/**
	 * 界面结构:内部额度变动记录
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("inside/log")
	public ModelAndView insideLog() throws Exception {
		
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"id", "create_time","action_type","credit_limit","temp_limit","remark"});
			tableHeader.setTexts(new String[]{"ID", "时间","类型","授信限额","临时额度","摘要"});
			tableHeader.setTypes(new String[]{"int","", "","","",""});
			
			PageStructure data = PageUtil.createTablePageStructure("limit/inside/logData", "id", tableHeader,null,null);
			SystemInfo system = new SystemInfo("backup/member/innerLimitRec.html");
			system.setSiteName("内部额度变动记录");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			
			Map<String,Object> formData = Maps.newHashMap();
			QueryItem queryItem = new QueryItem(Where.eq("user_id", getUserId()));
			queryItem.setFields("temp_limit as tempLimit,avail_limit as availLimit,credit_limit as creditLimit");
			CreLimitInfo creLimitInfo = this.getOneByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
			formData.put("availLimit", creLimitInfo.getAvailLimit());
			formData.put("creditLimit", creLimitInfo.getCreditLimit());
			formData.put("tempLimit", creLimitInfo.getTempLimit());
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	/**
	 * 获取数据:内部额度变动记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("inside/logData")
	public DyResponse deptDetailData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setFields("id,action_type,credit_limit,temp_limit,remark,create_time");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.like("account_name", "%"+search+"%"));
		}
		queryItem.setWhere(Where.eq("user_id", getUserId()));
		queryItem.setOrders("id desc");
		
		return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT_LOG),"action_type:inner_cre_chag_type","create_time"));
	}
	
	/**
	 * 界面结构：外部额度授信记录
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="external/log")
	public ModelAndView externalLog() throws Exception {
		
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"id", "create_time","action_type","deal_limit","avail_limit","done_limit","torecover_limit","remark"});
			tableHeader.setTexts(new String[]{"ID", "时间","操作类型","操作额度","可用授信","已放授信","待回授信","摘要"});
			tableHeader.setTypes(new String[]{"int","", "","","","","",""});
			
			PageStructure data = PageUtil.createTablePageStructure("limit/external/logData", "id", tableHeader,null,null);
			
			SystemInfo system = new SystemInfo("backup/member/externalLimitRec.html");
			system.setSiteName("外部额度变动记录");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			
			Map<String,Object> formData = Maps.newHashMap();
			QueryItem queryItem = new QueryItem(Where.eq("user_id", getUserId()));
			queryItem.setFields("pay_limit as payLimit,tobe_recovered as tobeRecovered");
			CreLimitInfo creLimitInfo = this.getOneByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
			formData.put("tobeRecovered", creLimitInfo.getTobeRecovered());
			formData.put("payLimit", creLimitInfo.getPayLimit());
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	/**
	 * 获取数据：外部额度授信记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="external/logData")
	public DyResponse externalLogData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setFields("id,user_name,action_type,avail_limit,deal_limit,done_limit,torecover_limit,create_time,remark");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.like("account_name", "%"+search+"%"));
		}
		queryItem.setWhere(Where.eq("uid", getUserId()));
		queryItem.setWhere(Where.eq("rec_type", AccConstants.REC_TYPE_DEPT));
		queryItem.setOrders("id desc");
		
		Object data = dataConvert(getPageByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_CHANGE_LOG),"action_type:cus_cre_action_type","create_time");
		return createSuccessJsonResonse(data);
	}
	
	/**
	 * 界面结构：额度记录
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="custLimitLog")
	public ModelAndView custLimitLog() throws Exception {
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"create_time","action_type","deal_limit","avail_limit","remark"});
			tableHeader.setTexts(new String[]{"时间","操作类型","操作额度","可用授信额度","摘要"});
			tableHeader.setTypes(new String[]{"","","","",""});
			
			PageStructure data = PageUtil.createTablePageStructure("limit/custLimitLogData", "id", tableHeader,null,null);
			
			SystemInfo system = new SystemInfo("backup/finance/custLimitRec.html");
			system.setSiteName("额度记录");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			Map<String,Object> formData = Maps.newHashMap();
			QueryItem queryItem = new QueryItem(Where.eq("user_id", getUserId()));
			queryItem.setFields("pay_limit as payLimit,avail_limit as availLimit");
			CreLimitInfo creLimitInfo = this.getOneByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
			formData.put("curAvailLimit", creLimitInfo.getAvailLimit());
			formData.put("totalLimit", creLimitInfo.getPayLimit());
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 获取数据：额度记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="custLimitLogData")
	public DyResponse custLimitLogData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setFields("action_type,avail_limit,deal_limit,create_time,remark");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.like("account_name", "%"+search+"%"));
		}
		queryItem.setWhere(Where.eq("user_id", getUserId()));
		queryItem.setOrders("id desc");
		queryItem.setWhere(Where.eq("rec_type", AccConstants.REC_TYPE_CUST));
		Object data = dataConvert(getPageByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_CHANGE_LOG),"action_type:cus_cre_action_type","create_time");
		return createSuccessJsonResonse(data);
	}
	
	/**
	 * 界面结构：临时额度申请记录
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="tempLimitApplyLog")
	public ModelAndView tempLimitApplyLog() throws Exception {
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"id","create_time","apply_limit","pass_limit","reason","status","pass_date","remark"});
			tableHeader.setTexts(new String[]{"ID","时间","申请金额（元）","通过金额（元）","申请原因","状态","审核时间","审核备注"});
			tableHeader.setTypes(new String[]{"","datetime","","","","","datetime",""});
			
			PageStructure data = PageUtil.createTablePageStructure("limit/tempLimitApplyLogData", "id", tableHeader,null,null);
			
			SystemInfo system = new SystemInfo("backup/finance/tempLimitApplyRec.html");
			system.setSiteName("临时额度申请记录");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			Map<String,Object> formData = Maps.newHashMap();
			QueryItem queryItem = new QueryItem(Where.eq("user_id", getUserId()));
			queryItem.setFields("credit_limit as creditLimit,avail_limit as availLimit,temp_limit as tempLimit");
			CreLimitInfo creLimitInfo = this.getOneByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
			formData.put("availLimit", creLimitInfo.getAvailLimit());
			formData.put("creditLimit", creLimitInfo.getCreditLimit());
			formData.put("tempLimit", creLimitInfo.getTempLimit());
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 获取数据：临时额度申请记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="tempLimitApplyLogData")
	public DyResponse tempLimitApplyLogData(Integer page,Integer limit) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setFields("id,apply_limit,pass_limit,remark,reason,create_time,status,pass_user,pass_date");
		queryItem.setWhere(Where.eq("user_id", getUserId()));
		queryItem.setOrders("id desc");
		
		return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_APPLY_REC),"status:flow_status"));

	}
	
	/**
	 * 申请临时额度弹窗
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="toApplyTempLimit")
	public ModelAndView toApplyTempLimit() throws Exception {
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo("backup/member/applyTempLimitDia.html");
			view = this.initDialogPageView(system);
			Map<String,Object> formData = Maps.newHashMap();
			QueryItem queryItem = new QueryItem(Where.eq("user_id", getUserId()));
			queryItem.setFields("temp_limit as tempLimit,credit_limit as creditLimit");
			CreLimitInfo creLimitInfo = this.getOneByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
			formData.put("tempLimit", creLimitInfo.getTempLimit());
			formData.put("creditLimit", creLimitInfo.getCreditLimit());
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		
		return view;
		
	}
	
	
	/**
	 * 申请临时额度
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="applyTempLimit")
	public DyResponse applyTempLimit(@RequestParam("applyLimit") BigDecimal applyLimit,@RequestParam("msg") String msg,@RequestParam("verifycode") String verifycode) throws Exception {
		this.checkVerifyCode(verifycode);
		OrgFrontUser user = this.getUser();
		String flowNum = GenNumUtil.genNum("SQLE");
		
		Map<String, Object> cond = Maps.newHashMap();
		cond.put("cond1", user.getUsername());
		FlowProcInst procInst = workFlowUtil.startFlowPub(AccConstants.FLOW_DEF_SQLE,flowNum, msg,user.getCompanyId(), cond );
		
		QueryItem queryItem = new QueryItem(Where.eq("user_id", user.getId()));
		CreLimitInfo creditLimit = this.getOneByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
		
		CreApplyRecord applyRecord = new CreApplyRecord();
		applyRecord.setApplyLimit(applyLimit);
		applyRecord.setAvailLimit(creditLimit.getAvailLimit());
		applyRecord.setCreditLimit(creditLimit.getCreditLimit());
		applyRecord.setDeptName(creditLimit.getAccountName());
		applyRecord.setUserName(user.getUsername());
		applyRecord.setUserId(user.getId());
		applyRecord.setFlowNum(flowNum);
		applyRecord.setReason(msg);
		applyRecord.setStatus(AccConstants.FLOW_STATUS_APRVING);
		applyRecord.setTempLimit(creditLimit.getTempLimit());
		applyRecord.setProcInstId(procInst.getId());
		this.insert(SCModule.CREDIT, SCFunction.CRE_APPLY_REC, applyRecord);
		
		
		return createSuccessJsonResonse(null,"申请提交成功");
	}
	
}
