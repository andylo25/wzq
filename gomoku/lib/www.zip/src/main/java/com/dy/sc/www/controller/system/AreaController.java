package com.dy.sc.www.controller.system;

import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Maps;

/**
 * 
 * 区域管理
 * @ClassName: AreaController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年7月3日 上午11:56:53 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/public/area/")
public class AreaController extends FrontBaseController{

    private static Map<Long,List> areaCache=Maps.newHashMap();
    
    /**
	 * 列表数据
	 * @return
	 * @throws Exception
	 */
    @ResponseBody
	@RequestMapping(value="listData",method=RequestMethod.POST)
	public DyResponse listData(HttpServletRequest request) throws Exception {
        Enumeration<String> params= request.getParameterNames();
        String param=null;
        Long pid = null;
        while(params.hasMoreElements()){
            param=params.nextElement();
            if(param.startsWith("pid")){
                pid=Long.parseLong(request.getParameter(param).toString());
                break;
            }
        }
        if(pid==null)
            pid=0L;
		return createSuccessJsonResonse(getArea(pid));
	}
	
    private List getArea(Long pid){
        List result=areaCache.get(pid);
        if(result==null){
            synchronized (areaCache) {
                if(result==null){
                    QueryItem queryItem=new QueryItem();
                    queryItem.setWhere(Where.eq("pid", pid));
                    queryItem.setFields("id as value,name as text");
                    try {
                        result=this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS);
                        areaCache.put(pid, result);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return result;
    }
    
}