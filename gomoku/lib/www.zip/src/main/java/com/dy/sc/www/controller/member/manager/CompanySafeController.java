package com.dy.sc.www.controller.member.manager;

import com.dy.core.cache.SysCacheUtil;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.Constant;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.SecurityUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.Company;
import com.dy.ia.www.controller.common.VerifyCodeController;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.CompanyApproveStatus;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.www.entity.EmailVerifyCode;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

/**
 * 用户管理
 *
 * @author Administrator
 */
@Controller
@RequestMapping("/member/manager/companySafe")
public class CompanySafeController extends FrontBaseController {

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView get() throws Exception {
        ModelAndView view = new ModelAndView("member/manager/companySafe");
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Company company = this.getById(user.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);

        Map<String, Object> viewData = Maps.newHashMap();
        viewData.put("email", company.getContactEmail());
        viewData.put("phone", company.getContactPhoneNumber());

        if (SysCacheUtil.useTrust()) {
            AccAccount account = BaseInfoUtils.getCompAccountEntity(company.getId());
            if (account != null && StringUtils.isNoneBlank(account.getAccount())) {
                viewData.put("bankOpen", true);
            } else {
                viewData.put("bankOpen", false);
            }
        }
        //是否实名认证
        if (CompanyApproveStatus.PASS.getIndex() != company.getApproveStatus()) {
            viewData.put("approveStatus", false);
        } else {
            viewData.put("approveStatus", true);
        }
        viewData.put("company", company);
        view.addObject("data", JsonUtils.object2JsonString(viewData));

        return view;

    }

    @RequestMapping("/updatePwd")
    @ResponseBody
    public DyResponse updatePwd(String oldPassword, String newPassword) throws Exception {
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        if (SecurityUtil.md5(SecurityUtil.sha1(oldPassword)).equals(user.getPassword())) {
            Map<String, Object> map = Maps.newHashMap();
            map.put("id", getUserId());
            map.put("password", SecurityUtil.md5(SecurityUtil.sha1(newPassword)));
            DyResponse res = this.update(SCModule.SYSTEM, SCFunction.SYS_USER, map);
            //成功更新session里的数据，防止多次更改校验失败
            user.setPassword(SecurityUtil.md5(SecurityUtil.sha1(newPassword)));
            this.setSessionAtrribute(Constant.SESSION_USER, user);
            return res;
        } else {
            return createErrorJsonResonse("原始密码错误！");
        }
    }

    @RequestMapping("/updatePhone")
    @ResponseBody
    public DyResponse updatePhone(Integer phoneStep, String phoneCode, String phone) throws Exception {
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Map<String, Object> viewData = Maps.newHashMap();
        if (phoneStep == 1) {//第几步
            //短信验证码
            String sessionPhoneCode = (String) VerifyCodeController.getPhoneCode(phone);
            if (StringUtils.isBlank(phoneCode) || StringUtils.isBlank(sessionPhoneCode) || !phoneCode.equalsIgnoreCase(sessionPhoneCode)) {
                return createErrorJsonResonse(this.getMessage("validate.phoneCodeError"));
            } else {
                viewData.put("phoneStep", 2);
            }
        } else if (phoneStep == 2) {
            String code = VerifyCodeController.getPhoneCode(phone);
            if(StringUtils.isBlank(code)){
                return createErrorJsonResonse("手机号码已更改，请重新获取验证码");
            }
            //短信验证码
            String sessionPhoneCode = VerifyCodeController.getPhoneCode(phone);
            if (StringUtils.isBlank(phoneCode) || StringUtils.isBlank(sessionPhoneCode) || !phoneCode.equalsIgnoreCase(sessionPhoneCode)) {
                return createErrorJsonResonse(this.getMessage("validate.phoneCodeError"));
            } else {
                Boolean exist = existUserByName(phone, user.getId());
                if (exist) {
                    return createErrorJsonResonse("该手机已经绑定其他企业，无法更改！");
                } else {
                    Map<String, Object> upUser = Maps.newHashMap();
                    upUser.put("id", getUserId());
                    upUser.put("phone", phone);
                    Map<String, Object> upCompany = Maps.newHashMap();
                    upCompany.put("id", getUser().getCompanyId());
                    upCompany.put("contact_phone_number", phone);
                    this.update(SCModule.SYSTEM, SCFunction.SYS_USER, upUser);
                    this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, upCompany);
                    //成功更新session里的数据，防止多次更改校验失败
                    this.setSessionAtrribute(Constant.SESSION_USER, user);
                    viewData.put("phoneStep", 3);
                    viewData.put("phone", phone);
                }
            }
        }
        return createSuccessJsonResonse(viewData);
    }

    @RequestMapping("/updateEmail")
    @ResponseBody
    public DyResponse updateEmail(Integer emailStep, String emailCode, String email) throws Exception {
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Map<String, Object> viewData = Maps.newHashMap();
        if (emailStep == 1) {//第几步
            //短信验证码
            Map<String, Object> sessionMap = (Map<String, Object>) this.getSessionAttribute("sessionMap");
            if (sessionMap == null) {//session已过期
                return createErrorJsonResonse("邮箱验证码错误！");
            } else {
                //session未过期
                String sessionCode = (String) sessionMap.get("sessionCode");
                String errorMsg = EmailVerifyCode.validate(user.getEmail(), emailCode, 5);
                if (errorMsg != null) return createErrorJsonResonse(errorMsg);
                if (!sessionCode.equals(emailCode)) {
                    return createErrorJsonResonse("邮箱验证码错误！");
                } else {
                    Boolean exist = existUserByName(email, user.getId());
                    if (exist) {
                        return createErrorJsonResonse("邮箱已经在系统中绑定其他企业，无法更改！");
                    } else {
                        viewData.put("newEmail", email);
                        viewData.put("emailStep", 2);
                    }
                }
            }

        } else if (emailStep == 2) {
            //短信验证码
            Map<String, Object> sessionMap = (Map<String, Object>) this.getSessionAttribute("sessionMap");
            if (sessionMap == null) {//session已过期
                return createErrorJsonResonse("邮箱验证码错误！");
            } else {
                //session未过期
                String sessionCode = (String) sessionMap.get("sessionCode");
                String errorMsg = EmailVerifyCode.validate(email, emailCode, 5);
                if (errorMsg != null) return createErrorJsonResonse(errorMsg);
                if (!sessionCode.equals(emailCode)) {
                    return createErrorJsonResonse("邮箱验证码错误！");
                } else {
                    Map<String, Object> upUser = Maps.newHashMap();
                    upUser.put("id", getUserId());
                    upUser.put("email", email);
                    Map<String, Object> upCompany = Maps.newHashMap();
                    upCompany.put("id", getUser().getCompanyId());
                    upCompany.put("contact_email", email);
                    this.update(SCModule.SYSTEM, SCFunction.SYS_USER, upUser);
                    this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, upCompany);
                    //成功更新session里的数据，防止多次更改校验失败
                    this.setSessionAtrribute(Constant.SESSION_USER, user);
                    viewData.put("emailStep", 3);
                    viewData.put("email", email);
                }
            }

        }
        return createSuccessJsonResonse(viewData);
    }

    @RequestMapping("/bindEmail")
    @ResponseBody
    public DyResponse bindEmail(Integer emailStep, String emailCode, String email) throws Exception {
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Map<String, Object> viewData = Maps.newHashMap();
        if (emailStep == 1) {//第几步
            //短信验证码
            Boolean exist = existUserByName(email, user.getId());
            if (exist) {
                return createErrorJsonResonse("邮箱已经在系统中绑定其他企业，无法更改！");
            } else {
                viewData.put("newEmail", email);
                viewData.put("emailStep", 2);
            }
        } else if (emailStep == 2) {
            //短信验证码
            Map<String, Object> sessionMap = (Map<String, Object>) this.getSessionAttribute("sessionMap");
            if (sessionMap == null) {//session已过期
                return createErrorJsonResonse("邮箱验证码错误！");
            } else {
                //session未过期
                String sessionCode = (String) sessionMap.get("sessionCode");
                String errorMsg = EmailVerifyCode.validate(email, emailCode, 5);
                if (errorMsg != null) return createErrorJsonResonse(errorMsg);
                if (!sessionCode.equals(emailCode)) {
                    return createErrorJsonResonse("邮箱验证码错误！");
                } else {
                    Map<String, Object> upUser = Maps.newHashMap();
                    upUser.put("id", getUserId());
                    upUser.put("email", email);
                    Map<String, Object> upCompany = Maps.newHashMap();
                    upCompany.put("id", getUser().getCompanyId());
                    upCompany.put("contact_email", email);
                    this.update(SCModule.SYSTEM, SCFunction.FRONT_USER, upUser);
                    this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, upCompany);
                    //成功更新session里的数据，防止多次更改校验失败
                    user.setEmail(email);
                    this.setSessionAtrribute(Constant.SESSION_USER, user);
                    viewData.put("emailStep", 3);
                    viewData.put("email", email);
                }
            }

        }
        return createSuccessJsonResonse(viewData);
    }

    //根据账号、邮箱、手机查找用户，true说明重复了。
    private Boolean existUserByName(String userName, Long userId) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields("id,username,email,phone");
        query.getWhere().add(Where.eq("username", userName));
        query.getWhere().add(Where.eq("del_flag", 0));
        query.getWhere().add(Where.notEq("id", userId));
        OrgFrontUser user = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
        if (user == null) {
            QueryItem email = new QueryItem();
            email.getWhere().add(Where.eq("email", userName));
            email.getWhere().add(Where.eq("del_flag", 0));
            email.getWhere().add(Where.notEq("id", userId));
            user = this.getOneByEntity(email, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
            if (user == null) {
                QueryItem phone = new QueryItem();
                phone.getWhere().add(Where.eq("phone", userName));
                phone.getWhere().add(Where.eq("del_flag", 0));
                phone.getWhere().add(Where.notEq("id", userId));
                user = this.getOneByEntity(phone, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
            }
        }
        return user != null;
    }

    @RequestMapping("/checkPhone")
    @ResponseBody
    public DyResponse checkPhone(String phone) throws Exception {
        Map<String, Object> data = Maps.newHashMap();
        Boolean exist = existUserByName(phone, getUserId());
        if (exist) {
            return createErrorJsonResonse("该手机已经绑定其他企业，无法更改！");
        }
        return createSuccessJsonResonse(data);
    }
}