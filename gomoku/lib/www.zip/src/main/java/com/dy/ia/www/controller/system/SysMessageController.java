package com.dy.ia.www.controller.system;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.SysMessageLog;

@Controller
@RequestMapping("/system")
public class SysMessageController extends FrontBaseController {

	/**
	 * 站内消息:界面
	 * @return
	 */
	@RequestMapping("/msg/list")
	public ModelAndView msgToRead() {
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"title","contents","create_time:datetime","action:confirm"});
			tableHeader.setTexts(new String[]{"标题","内容","发件时间","操作"});
			
			PageStructure data = PageUtil.createTablePageStructure("system/msg/listData", "id", tableHeader,null,null);
			data.setRightUrl("system/msg/delete");
			SystemInfo system = new SystemInfo("backup/member/msgRec.html");
			system.setSiteName("站内消息");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 获取数据:站内消息
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("msg/listData")
	public DyResponse listData(Integer page,Integer limit) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setFields("id,title,status,contents,create_time,read_status");
		queryItem.setWhere(Where.eq("member_id", getUserId()));
		queryItem.setWhere(Where.notEq("read_status", "-1"));
		queryItem.setOrders("id desc");
		Page<Map> page2 = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.MESSAGE_LOG);
		page2.getItems().forEach(ite->{
			ite.put("action","操作");
		});
		return createSuccessJsonResonse(page2);
	}
	
	/**
	 * 获取数据:站内消息
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("msg/read")
	public DyResponse read(Long id) throws Exception {
		SysMessageLog log = new SysMessageLog(id);
		log.setReadStatus(1);// 标志已读
		this.update(SCModule.SYSTEM, SCFunction.MESSAGE_LOG,log);
		return createSuccessJsonResonse("删除成功");
	}
	
	/**
	 * 获取数据:站内消息
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("msg/delete")
	public DyResponse delete(Long id) throws Exception {
		SysMessageLog log = new SysMessageLog(id);
		log.setReadStatus(-1);// 读取方标志删除
		this.update(SCModule.SYSTEM, SCFunction.MESSAGE_LOG,log);
		return createSuccessJsonResonse("删除成功");
	}
	
}