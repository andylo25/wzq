package com.dy.ia.www.controller.finance;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
/**
 * 交易记录
 * @author cuiwm
 *
 */
@Controller
@RequestMapping("/finance")
public class AccountLogController extends FrontBaseController {
	
	/**
	 * 界面结构：交易记录
	 * @return
	 */
    // @RequestMapping("trade/log")
    // public ModelAndView tradeLog() {
    // ModelAndView view = new ModelAndView();
    // try {
    // TableHeader tableHeader = new TableHeader();
    // tableHeader.setNames(new
    // String[]{"create_time","txn_type","deal_amount","amount_in","amount_out","balance","remark:links"});
    // tableHeader.setTexts(new
    // String[]{"交易时间","交易类型","操作金额","收入","支出","余额","备注"});
    //
    // PageStructure data =
    // PageUtil.createTablePageStructure("finance/trade/logData/99","member/customer/viewCreditRecord",
    // "id", tableHeader,null,null);
    // SystemInfo system = new SystemInfo("backup/finance/tradeRec.html");
    // system.setSiteName("交易记录");
    // view = this.initMemberPageView(system);
    // view.addObject("data", JsonUtils.object2JsonString(data));
    // Map<String,Object> formData = Maps.newHashMap();
    // formData.put("txnTypeList",
    // DictUtils.getOptionsByExclude("cap_detail_type","6,10"));
    // view.addObject("formData", JsonUtils.object2JsonString(formData ));
    // } catch (Exception e) {
    // logger.error(e.getMessage(), e);
    // }
    // return view;
    // }
	
	/**
	 * 获取数据：交易记录
	 */
	@ResponseBody
	@RequestMapping("trade/logData/{type}")
	public DyResponse tradeLogData(Integer page,@PathVariable("type") Integer type,Integer tradeType,@RequestParam(value="start_time",required=false) String startDate,@RequestParam(value="end_time",required=false) String endDate) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(10);
		
		if(type == AccConstants.TXN_DIR_IN || type == AccConstants.TXN_DIR_OUT){
			queryItem.setWhere(Where.eq("txn_dir", type));
		}
		if(type == AccConstants.TXN_DIR_OUT){
			tradeType = AccConstants.CAP_DETAIL_TYPE_TX;
		}
		queryItem.setFields("id,txn_type,loan_id as rid,deal_amount,amount_in,amount_out,balance,remark,create_time");
		if(StringUtils.isNotBlank(startDate)){
			Calendar   calendar   = Calendar.getInstance(); 
			SimpleDateFormat sdf =   new SimpleDateFormat( "yyyy-MM-dd" );
		    calendar.setTime(sdf.parse(endDate)); 
		    calendar.add(calendar.DATE,1);//把日期往后增加一天
			Where where = this.addAndWhereCondition(null,"create_time", startDate, sdf.format(calendar.getTime()));
			
			if(where != null){
				queryItem.setWhere(where);
			}
		}
		if(tradeType != null){
			queryItem.setWhere(Where.eq("txn_type", tradeType));
		}
		queryItem.setWhere(Where.eq("uid", getUserId()));
		queryItem.setOrders("id desc");
		Object data = dataConvert(getPageByMap(queryItem, SCModule.ACCOUNT, SCFunction.MONEY_DETAIL),"txn_type:cap_detail_type","create_time");
		return createSuccessJsonResonse(data);
	}
	
	
	/**
	 * 界面结构：转入记录
	 * @return
	 */
    // @RequestMapping("tradeIn/log")
    // public ModelAndView tradeInLog() {
    // ModelAndView view = new ModelAndView();
    // try {
    // TableHeader tableHeader = new TableHeader();
    // tableHeader.setNames(new
    // String[]{"create_time","txn_type","deal_amount","remark:links"});
    // tableHeader.setTexts(new String[]{"交易时间","交易类型","操作金额","备注"});
    // tableHeader.setTypes(new String[]{"", "","",""});
    //
    // PageStructure data =
    // PageUtil.createTablePageStructure("finance/trade/logData/"+AccConstants.TXN_DIR_IN,"member/customer/viewCreditRecord",
    // "id", tableHeader,null,null);
    //
    // SystemInfo system = new SystemInfo("backup/finance/transfer_in.html");
    // system.setSiteName("转入记录");
    // view = this.initMemberPageView(system);
    // view.addObject("data", JsonUtils.object2JsonString(data));
    // Map<String,Object> formData = Maps.newHashMap();
    // formData.put("txnTypeList",
    // DictUtils.getOptions("cap_detail_type","4,8"));
    // view.addObject("formData", JsonUtils.object2JsonString(formData ));
    // } catch (Exception e) {
    // logger.error(e.getMessage(), e);
    // }
    // return view;
    // }
	
	/**
	 * 界面结构：转出记录
	 * @return
	 */
	@RequestMapping("tradeOut/log")
	public ModelAndView tradeOutLog() {
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"create_time","out_bank","deal_amount","deal_amount","fee","status"});
			tableHeader.setTexts(new String[]{"交易时间","提现银行","提现总额","到账金额","手续费","状态"});
			tableHeader.setTypes(new String[]{"", "","","","",""});
			
			PageStructure data = PageUtil.createTablePageStructure("finance/trade/logData/"+AccConstants.TXN_DIR_OUT, "id", tableHeader,null,null);
			
			SystemInfo system = new SystemInfo("backup/finance/transfer_out.html");
			system.setSiteName("转出记录");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
}
