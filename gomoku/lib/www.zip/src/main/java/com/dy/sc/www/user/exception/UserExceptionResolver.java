package com.dy.sc.www.user.exception;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;

import com.dy.core.entity.DyResponse;
import com.dy.core.exception.DyUncheckedException;
import com.dy.core.exception.DyWebException;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;

@Component
public class UserExceptionResolver extends ExceptionHandlerExceptionResolver {
	protected Logger logger = Logger.getLogger(UserExceptionResolver.class);
	
	@Autowired
    private GsonHttpMessageConverter messageConverter;
	
	@Override
	protected ModelAndView doResolveHandlerMethodException(HttpServletRequest request, HttpServletResponse response, HandlerMethod handlerMethod, Exception exception) {
		if(handlerMethod == null) return null;
        if(handlerMethod.getMethod() == null) return null;
        
        if(!(exception instanceof DyUncheckedException)){
        	exception = new DyWebException("inner.tec.error",exception);
        }
        
        // 保存异常堆栈信息
        logger.error("error",exception);
        BaseInfoUtils.saveErrors(handlerMethod.getMethod(), exception);
        
		//获取错误信息
		String errorMsg = exception.getMessage();
		
		//判断是否配置@ResponseBody
        if(AnnotationUtils.findAnnotation(handlerMethod.getMethod(), ResponseBody.class) != null) {
        	MediaType jsonMediaType = MediaType.APPLICATION_JSON;
            response.setContentType("application/json;charset=utf-8");
            try {
            	Map<String, Object> result = new HashMap<String, Object>();
            	result.put("status", DyResponse.ERROR);
            	result.put("description", errorMsg);
            	
            	messageConverter.write(result, jsonMediaType, new ServletServerHttpResponse(response));
			} catch (Exception e) {
				logger.error("",e);
			}
			return new ModelAndView();
        }
        
        ModelAndView modelAndView = new ModelAndView("error");
        modelAndView.addObject("error", errorMsg);
		
    	return modelAndView;
	}
}