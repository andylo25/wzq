package com.dy.sc.www.controller.member.company;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.RowLink;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.event.DyEvent;
import com.dy.core.event.DyEventManager;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.Company;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.CheckStatus;
import com.dy.sc.entity.enumeration.TriggerTime;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.entity.system.CompanyRelation;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * 核实企业资质
 * @ClassName: CheckRelationController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年8月3日 上午11:23:34 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/member/core/checkRelation")
public class CheckRelationController extends FrontBaseController{
    
    private static int TYPE_NO_CHECK=0;
    private static int TYPE_CHECKED=1;
    private static int TYPE_REJECT=2;
    @Autowired
    private DyEventManager eventManager;

    @RequestMapping(value="/list/{type}",method=RequestMethod.GET)
    public ModelAndView list(@PathVariable("type")int type) throws Exception {
        TableHeader tableHeader = new TableHeader();
        if(TYPE_NO_CHECK==type){
            tableHeader.setNames(new String[]{"company_name","business_lic_type","business_lic_no","legal_name","create_time","view"});
            tableHeader.setTexts(new String[]{"企业名称","证件类型","证件号码","法人姓名","提交时间","证件$查看"});
            tableHeader.setTypes(new String[]{"", "","","","","multiPhoto"});
        }else if(TYPE_CHECKED==type){
            tableHeader.setNames(new String[]{"company_name","business_lic_type","business_lic_no","legal_name","create_time","view"});
            tableHeader.setTexts(new String[]{"企业名称","证件类型","证件号码","法人姓名","提交时间","证件$查看"});
            tableHeader.setTypes(new String[]{"", "","","","","multiPhoto"});
        }else if(TYPE_REJECT==type){
            tableHeader.setNames(new String[]{"company_name","business_lic_type","business_lic_no","legal_name","create_time","view"});
            tableHeader.setTexts(new String[]{"企业名称","证件类型","证件号码","法人姓名","提交时间","证件$查看"});
            tableHeader.setTypes(new String[]{"", "","","","","multiPhoto"});
        }
        
        Map<String,Object> headerData=Maps.newHashMap();
        headerData.put("currentStatus", type);
        PageStructure data = PageUtil.createTablePageStructure("member/core/checkRelation/listData/"+type,"member/core/checkRelation/", "id", tableHeader,null,null,headerData);
        if(TYPE_NO_CHECK==type){
            List<RowLink> rowLink=Lists.newArrayList();
            rowLink.add(new RowLink("通过","member/core/checkRelation/pass",RowLink.ROW_LINK_TYPE_CONFIRM,"提示","确认通过企业资质申请?"));
            rowLink.add(new RowLink("驳回","member/core/checkRelation/reject",RowLink.ROW_LINK_TYPE_CONFIRM,"提示","确认驳回企业资质申请?"));
            data.setRowLink(rowLink);
            data.setRowLinkTitle("操作");
        }
        return createSuccessModelAndView("member/core/checkRelation", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 获取数据:内部额度变动记录
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("/listData/{type}")
    public DyResponse listData(Integer page,Integer limit,String search,@PathVariable("type")int type) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 10 : limit);
        queryItem.setFields("*");
        if(type==TYPE_NO_CHECK){
            queryItem.setWhere(Where.eq("check_status", CheckStatus.CHECK_TODO.getIndex()));
        }else if(type==TYPE_CHECKED){
            queryItem.setWhere(Where.eq("check_status", CheckStatus.CHECK_PASS.getIndex()));
        }else if(type==TYPE_REJECT){
            queryItem.setWhere(Where.eq("check_status", CheckStatus.CHECK_REJECT.getIndex()));
        }else {
            return null;
        }
//        if(StringUtils.isNotBlank(search)){
//            queryItem.setWhere(Where.likeAll("company_name", search));
//        }
        
        queryItem.setWhere(Where.eq("core_company_id", getUser().getCompanyId()));
        queryItem.setOrders("id desc");
        Page pageData=getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
        List<Map> listData=pageData.getItems();
        for(Map item:listData){
            queryItem=new QueryItem();
            queryItem.setFields("file_path");
            queryItem.setWhere(Where.eq("company_id", item.get("company_id")));
//            queryItem.setWhere(Where.eq("premise_material_id", 2));
            List<Map> meterials=this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT);
            if(meterials!=null&&meterials.size()>0){
//                item.put("view", meterials.get(0).get("file_path"));
                item.put("view", meterials);
            }
        }
        this.idToName(listData, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name,business_lic_type,business_lic_no,legal_name");
        
        return createSuccessJsonResonse(dataConvert(pageData,"business_lic_type","create_time"));
    }
    
    /**
     * 
     * 通过驳回企业认证
     * @param id
     * @param type
     * @return
     * @throws Exception
     * @author likf
     */
    @ResponseBody
    @RequestMapping("/{type}/{id}")
    public DyResponse action(@PathVariable("id")Long id,@PathVariable("type")String type) throws Exception {
        if("pass".equals(type)){
            CompanyRelation relation=new CompanyRelation();
            relation.setId(id);
            relation.setCheckStatus(CheckStatus.CHECK_PASS.getIndex());
            this.update(SCModule.SYSTEM,SCFunction.SYS_COMPANY_RELATION, relation);
        }else if("reject".equals(type)){
            CompanyRelation relation=new CompanyRelation();
            relation.setId(id);
            relation.setCheckStatus(CheckStatus.CHECK_REJECT.getIndex());
            this.update(SCModule.SYSTEM,SCFunction.SYS_COMPANY_RELATION, relation);
            Map rel=this.getById(id, SCModule.SYSTEM,SCFunction.SYS_COMPANY_RELATION);
            List<Map> rels=Lists.newArrayList();
            rels.add(rel);
            this.idToName(rels, SCModule.SYSTEM,SCFunction.SYS_COMPANY, "company_id:company_name as creditName");
            this.idToName(rels, SCModule.SYSTEM,SCFunction.SYS_COMPANY, "core_company_id:company_name as coreName");
            String[] data=new String[]{id.toString(),null,rel.get("creditName").toString(),"身份审核",rel.get("coreName").toString()};
            int subType=TriggerTime.RELATION_REJECT.getIndex();
            publishMessage(data, subType);
        }
        
        return createSuccessJsonResonse(null,"提交成功");
    }
    
    public void publishMessage(String[] data,int subType){
        DyEvent event = new DyEvent();
        event.setType(ScConstants.EVENT_TYPE_3);
        event.setSubType(subType);
        event.setData(data);
        try {
            eventManager.trigger(event);
        } catch (Exception e) {
            logger.error("发布消息异常",e);
        }
    }
}
