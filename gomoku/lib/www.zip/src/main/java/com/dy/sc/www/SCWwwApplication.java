package com.dy.sc.www;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.MessageSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.aop.AopAutoConfiguration;
import org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration;
import org.springframework.boot.autoconfigure.web.DispatcherServletAutoConfiguration;
import org.springframework.boot.autoconfigure.web.EmbeddedServletContainerAutoConfiguration;
import org.springframework.boot.autoconfigure.web.ErrorMvcAutoConfiguration;
import org.springframework.boot.autoconfigure.web.HttpEncodingAutoConfiguration;
import org.springframework.boot.autoconfigure.web.HttpMessageConvertersAutoConfiguration;
import org.springframework.boot.autoconfigure.web.MultipartAutoConfiguration;
import org.springframework.boot.autoconfigure.web.ServerPropertiesAutoConfiguration;
import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.dy.core.utils.GlobalConf;

@Configuration
@ComponentScan("com.dy")
//@ImportResource("classpath:dubbo-*.xml")
//@ImportResource("classpath:spring-consumer.xml")
@Import({
	AopAutoConfiguration.class,
	DispatcherServletAutoConfiguration.class,
	EmbeddedServletContainerAutoConfiguration.class,
	ErrorMvcAutoConfiguration.class,
	HttpEncodingAutoConfiguration.class,
	HttpMessageConvertersAutoConfiguration.class,
	JacksonAutoConfiguration.class,
	MessageSourceAutoConfiguration.class,
	MultipartAutoConfiguration.class,
	ServerPropertiesAutoConfiguration.class,
	VelocityAutoConfiguration.class,
	WebMvcAutoConfiguration.class,
	CacheAutoConfiguration.class,
})
@EnableCaching
public class SCWwwApplication extends SpringBootServletInitializer{

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		GlobalConf.setAppId(GlobalConf.APP_ID_WWW);
		return application.sources(SCWwwApplication.class);
    }
	
	public static void main(String[] args) {
		GlobalConf.setAppId(GlobalConf.APP_ID_WWW);
		SpringApplication.run(SCWwwApplication.class, args);
	}
}
