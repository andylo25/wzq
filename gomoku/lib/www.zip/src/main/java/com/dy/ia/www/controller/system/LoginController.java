package com.dy.ia.www.controller.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.dy.sc.entity.enumeration.CompanyRoleType;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.Constant;
import com.dy.core.utils.SecurityUtil;
import com.dy.ia.entity.enumeration.AccountTypeEnum;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;

@Controller
@RequestMapping("/member")
public class LoginController extends FrontBaseController {

	@ResponseBody
	@RequestMapping("/public/login")
	public DyResponse login(String keywords,String password,String verifycode, Integer companyRoleType) throws Exception {
	    //非空校验
        if(StringUtils.isEmpty(keywords)) return createErrorJsonResonse("用户名不能为空");
        if(StringUtils.isEmpty(password)) return createErrorJsonResonse("密码不能为空");
        
		if(!keywords.equals(this.getSessionAttribute("username"))){
			this.removeSessionAttribute("login_error");	
		}
		
		//验证该用户是否存在
		QueryItem queryItem = new QueryItem(Where.eq("username", keywords));
		if(companyRoleType == 1) {
			queryItem.setWhere(Where.in("type", new Integer[]{CompanyRoleType.COMPANY_CREDIT.getIndex(),CompanyRoleType.COMPANY_NORMAL.getIndex()}));
		}else{
			queryItem.setWhere(Where.eq("type", CompanyRoleType.COMPANY_CORE.getIndex()));
		}
		OrgFrontUser member = (OrgFrontUser) this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
		if( member == null ){
			QueryItem q = new QueryItem(Where.eq("email", keywords));
			if(companyRoleType == 1) {
				queryItem.setWhere(Where.in("type", new Integer[]{CompanyRoleType.COMPANY_CREDIT.getIndex(),CompanyRoleType.COMPANY_NORMAL.getIndex()}));
			}else{
				queryItem.setWhere(Where.eq("type", CompanyRoleType.COMPANY_CORE.getIndex()));
			}
			member = (OrgFrontUser)this.getOneByEntity(q, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
			if( member == null ){
				if(!isMobileNO(keywords)){
					member = null;
				}else{
					QueryItem query = new QueryItem();
					List<Where> w = new ArrayList<Where>();
					this.addWhereCondition(w, "phone", keywords);
					this.addWhereCondition(w, "del_flag", 0);
					this.addWhereCondition(w, "type", NEQ, AccountTypeEnum.ADMIN.getIndex());
					query.setWhere(w);//设置where条件
					member = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
				}
			}
		}
		if (member == null) {
			return createErrorJsonResonse("用户不存在");
		}
		if (member.getType() == AccountTypeEnum.CUSTUMER.getIndex() && member.getCustStatus() != 1) {
			return createErrorJsonResonse("账号已被锁定,请联系管理员");
		}
		if(member.getType() != AccountTypeEnum.CUSTUMER.getIndex() && member.getStatus() != 1){
			return createErrorJsonResonse("账号已被锁定,请联系管理员");
		}
		//验证该用户是否为黑名单
//		String configValue = getConfigValue("site_blacklist_member");
//		if(configValue.contains(keywords))return createErrorJsonResonse("用户已加入黑名单,请联系管理员");
//		String pwdIsOpend = getConfigValue("error_pwd_isopen");
//		Long currentTime = DateUtil.getCurrentTime();
//		String errorPwdLong  = getConfigValue("error_pwd_long");
//		float pwdLong = (errorPwdLong == null || "".equals(errorPwdLong)) ? 0 : Float.parseFloat(errorPwdLong);
//		if ("1".equals(pwdIsOpend)) {
//			//验证用户是否锁定
//			if (member.getStatus() != 1) {
//				if (member.getLockTime() != null) {
//					//判断锁定时间是否大于系统时间
//					if (DateUtil.minuteBetween(member.getLockTime(), currentTime) < pwdLong) {
//						return createErrorJsonResonse("由于连续输入错误密码达到上限，账号已被锁定，请于"
//								+ (pwdLong - DateUtil.minuteBetween(member.getLockTime(), currentTime)) + "分钟后重新登录");
//					} else {
//						this.removeSessionAttribute("login_error");
//						member.setStatus(1);
//						this.updateById(SCModule.MEMBER, SCFunction.MB_MEMBER, member);
//					}
//				}
//			}
//		}
		//验证密码是否正确
		String encryptPassword = "";
		if (member != null) {
			encryptPassword = SecurityUtil.md5(SecurityUtil.sha1(password));
		}
		Integer login_error = (Integer) this.getSessionAttribute("login_error");
		if (!encryptPassword.equals(member.getPassword())) {
			//记录错误次数
			if (login_error == null) {
				login_error = 1;
			}
			login_error = login_error + 1;
			this.setSessionAtrribute("login_error", login_error);
			this.setSessionAtrribute("username", keywords);
			Map<String, Integer> map = new HashMap<String, Integer>();
			map.put("login_error", login_error);

			DyResponse response = new DyResponse();
			response.setData(map);
			response.setStatus(DyResponse.ERROR);
			response.setDescription("密码错误!");
//			if ("1".equals(pwdIsOpend)) {
//				int sysErrorTimes = (getConfigValue("error_pwd_times") == null || "".equals(getConfigValue("error_pwd_times"))) ? 0 : Integer.valueOf(getConfigValue("error_pwd_times"));
//				response.setDescription("密码错误" + (login_error - 1) + "次,达到" + sysErrorTimes + "次将锁定账户");
//				//连续输错密码N次，锁定用户
//				if (login_error >= sysErrorTimes + 1) {
//					member.setStatus(-2);
//					member.setLockTime(currentTime);
//					super.updateById("member", "member", member);
//					return createErrorJsonResonse("由于连续输入错误密码达到上限，账号已被锁定，请于" + pwdLong + "分钟后重新登录");
//				}
//			}
			return response;
		}
		//加入Shiro身份验证
		Subject subject = SecurityUtils.getSubject(); 
		UsernamePasswordToken token = new UsernamePasswordToken(keywords, password); 
		subject.login(token); 
		
		this.setSessionAtrribute(Constant.SESSION_USER, member);
		
		queryItem=new QueryItem();
		queryItem.setFields("id,approve_status");
		queryItem.setWhere(Where.eq("id", member.getCompanyId()));
		Map company = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
		this.setSessionAtrribute(Constant.SESSION_COMPANY, company);
		
		//登录成功
		//插入登录log信息
		//更新最后登录时间和ip
		Long memberId=member.getId();
		member=new OrgFrontUser();
		member.setId(memberId);
		member.setLastloginTime(System.currentTimeMillis() / 1000);
		member.setLastloginIp(this.getRemoteIp());
		member.setCount(member.getCount() + 1);
		this.update(SCModule.SYSTEM, SCFunction.SYS_USER, member);
		
		//把用户信息加入session
		
//		QueryItem infoQueryItem = new QueryItem();
//		queryItem.setModule(SCModule.SYSTEM);
//		queryItem.setFunction(SCFunction.SYS_USER);
//		infoQueryItem.getWhere().add(Where.eq("member_id", member.getId()));
//		MbMemberInfo memberInfo = (MbMemberInfo)super.getOne(infoQueryItem, MbMemberInfo.class);
//		this.setSessionAtrribute("member_info", memberInfo);
		
	    //从session中删除验证码信息
		this.removeSessionAttribute("login_error");
		return createSuccessJsonResonse(null,"登录成功");
	}
	
	public boolean isMobileNO(String mobiles) {
		Pattern p = Pattern.compile("^((13[0-9])|(15[^4,\\D])|(18[0-9]))\\d{8}$");
		Matcher m = p.matcher(mobiles);
		return m.matches();
	}
	
	@RequestMapping("/public/ajaxlogin")
	public ModelAndView ajaxLogin(){
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo("backup/member/loginajax.jsp");
			view = this.initDialogPageView(system);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
}
