package com.dy.ia.www.controller;

import java.util.Collections;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.autoconfigure.web.BasicErrorController;
import org.springframework.boot.autoconfigure.web.DefaultErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.utils.RequestUtil;
import com.dy.ia.entity.common.SysSystemSitepage;
import com.dy.sc.bussmodule.utils.SysSitepageUtil;
import com.dy.sc.entity.constant.ScConstants;
import com.google.common.collect.Maps;

@Controller
public class ContentErrorController extends BasicErrorController {


    public ContentErrorController(){
        super(new DefaultErrorAttributes(), new ErrorProperties());
    }

    private static final String PATH = "/error";

    @RequestMapping(produces = "text/html")
    public ModelAndView errorHtml(HttpServletRequest request,HttpServletResponse response) {
    	HttpStatus status = getStatus(request);
		Map<String, Object> model = Collections.unmodifiableMap(getErrorAttributes(
				request, isIncludeStackTrace(request, MediaType.TEXT_HTML)));
		if(status == HttpStatus.NOT_FOUND){
			// 404错误
			try {
				if(!contentHandle(request, response,model)){
					return null;
				}
			} catch (Exception e) {
			}
		}
		response.setStatus(status.value());
		ModelAndView modelAndView = resolveErrorView(request, response, status, model);
		return (modelAndView == null ? new ModelAndView("error", model) : modelAndView);
    }

    @Override
    public String getErrorPath() {
        return PATH;
    }
    
	public boolean contentHandle(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
		String path = (String) model.get("path");
		if(RequestUtil.isStaticFile(path))return true;
		SysSystemSitepage jumpPage = SysSitepageUtil.getSitePageByRouter(path);
		if (jumpPage != null && jumpPage.getType() != null) {
			Integer pageType = jumpPage.getType();
			if (pageType == ScConstants.NAV_TYPE_0 || pageType == ScConstants.NAV_TYPE_4) {
				return true;
			} else {
				String jumpPath = "";
				if (pageType == ScConstants.NAV_TYPE_3) {
					jumpPath = "/content/articles/index";
				} else if (pageType == ScConstants.NAV_TYPE_1 || pageType == ScConstants.NAV_TYPE_2) {
					jumpPath = "/content/page/getList";
				}
				Map<String,Object> param = Maps.newHashMap();
				param.put("id", jumpPage.getId());
				param.put("pid", jumpPage.getPid());
				param.put("site", path);
				request.setAttribute("page_param", param);
				response.setStatus(HttpStatus.OK.value());
				request.getRequestDispatcher(request.getContextPath() + jumpPath).forward(request, response);
				return false;
			}
		}
		return true;
	}
    
}