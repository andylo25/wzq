package com.dy.ia.www.controller.finance;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.GenNumUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.CapCapitalDetail;
import com.dy.ia.entity.common.CapRechargeRecord;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Maps;
/**
 * 充值/提现/更新余额
 * @author cuiwm
 *
 */
@Controller
@RequestMapping("/finance")
public class AccountController extends FrontBaseController {
	
	/**
	 * 界面结构：充值
	 * @return
	 */
	@RequestMapping("torecharge")
	public ModelAndView toRecharge() {
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"create_time","txn_type","deal_amount","amount_in","amount_out","balance","remark"});
			tableHeader.setTexts(new String[]{"交易时间","交易类型","操作金额","收入","支出","余额","备注"});
			tableHeader.setTypes(new String[]{"", "","","","","",""});
			
			PageStructure data = PageUtil.createTablePageStructure("finance/trade/logData", "id", tableHeader,null,null);
			
			SystemInfo system = new SystemInfo("backup/finance/recharge.html");
			system.setSiteName("充值");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			Map<String,Object> formData = Maps.newHashMap();
			formData.put("txnTypeList", DictUtils.getOptions("cap_detail_type"));
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 客户充值
	 */
	@ResponseBody
	@RequestMapping("doRecharge")
	public DyResponse doRecharge(BigDecimal amount,String payment,String verifycode) throws Exception {
		this.checkVerifyCode(verifycode);
		if(!NumberUtils.greaterThanZero(amount))return createErrorJsonResonse("金额必须大于0");
		AccAccount accAccount = BaseInfoUtils.getCompAccountEntity(getUser().getCompanyId());
		accAccount.setAccBalance(NumberUtils.add(accAccount.getAccBalance(),amount));
		
		String flowNum = GenNumUtil.genNum("KHCZ");
		// 插入充值交易明细
		insertDetail(accAccount, null, amount, flowNum, AccConstants.CAP_DETAIL_TYPE_CZ,true);
		
		BigDecimal fee = NumberUtils.mul(amount,new BigDecimal(0.01));
		BigDecimal realAmount = NumberUtils.sub(amount, fee);
		accAccount.setAccBalance(NumberUtils.sub(accAccount.getAccBalance(),fee));
		this.update(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, accAccount);
		
		
		// 充值手续费
		if(NumberUtils.greaterThanZero(fee)){
			AccAccount toAccount = this.getById(accAccount.getPid(), SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);
			toAccount.setAccBalance(NumberUtils.add(toAccount.getAccBalance(),fee));
			this.update(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, accAccount);
			
			insertDetail(accAccount, toAccount, fee, flowNum,AccConstants.CAP_DETAIL_TYPE_CZSXF,false);
			insertDetail(toAccount, accAccount, fee, flowNum,AccConstants.CAP_DETAIL_TYPE_CZSXF,true);
		}
		
		// 插入平台充值记录
		CapRechargeRecord record = new CapRechargeRecord();
		record.setDealAmount(amount);
		record.setFlowNum(flowNum);
		record.setRealAmount(realAmount);
		record.setRecharStatus(AccConstants.RECH_STATUS_SUCC);
		record.setRecCategory(AccConstants.REC_TYPE_CUST);
		record.setTxnType(AccConstants.RECHAR_TYPE_MANUAL);
		record.setCounterFee(fee);
		record.setUid(getUserId());
		record.setAccId(accAccount.getId());
		record.setRemark(MessageFormat.format("通过{0}支付充值{1}元",DictUtils.getDictLabel("1", "recharge_back"),realAmount));
		
		this.insert(SCModule.ACCOUNT, SCFunction.MONEY_RECHARGE_RECORD, record);
		
		return createSuccessJsonResonse(null,"充值成功");
	}
	
	// 插入交易明细，充值手续费(非平台充值)
	private void insertDetail(AccAccount accAccount,AccAccount toAccAccount, BigDecimal amount, String flowNum,int txnType, boolean isIn) throws Exception {
		if(accAccount != null){
			CapCapitalDetail detail = new CapCapitalDetail();
			detail.setAccount(accAccount.getAccount());
			detail.setDealAmount(amount);
			detail.setFlowNum(flowNum);
			if(isIn){
				detail.setAmountIn(amount);
				detail.setTxnDir(AccConstants.TXN_DIR_IN);
			}else{
				detail.setAmountOut(amount);
				detail.setTxnDir(AccConstants.TXN_DIR_OUT);
			}
			if(toAccAccount != null){
				detail.setOtherAccount(toAccAccount.getAccount());
			}
			detail.setUid(accAccount.getUserId());
			detail.setBalance(accAccount.getAccBalance());
			if(txnType == AccConstants.CAP_DETAIL_TYPE_CZSXF){
				detail.setRemark(MessageFormat.format("充值手续费{0}元",amount));
			}else{
				detail.setRemark(MessageFormat.format("通过{0}支付充值{1}元",DictUtils.getDictLabel("1", "recharge_back"),amount));
			}
			detail.setTxnType(txnType);
			this.insert(SCModule.ACCOUNT, SCFunction.MONEY_DETAIL, detail);
		}
	}
	
	/**
	 * 界面结构：开户
	 * @return
	 */
	@RequestMapping("toRegister")
	public ModelAndView toRegister() {
		ModelAndView view = new ModelAndView();
		try {
			
			SystemInfo system = new SystemInfo("backup/finance/register.html");
			system.setSiteName("个人开户");
			view = this.initMemberPageView(system);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 界面结构：开户
	 * @return
	 */
	@RequestMapping("towithdraw")
	public ModelAndView towithdraw() {
		ModelAndView view = new ModelAndView();
		try {
			
			SystemInfo system = new SystemInfo("backup/finance/withdraw.html");
			system.setSiteName("提现");
			view = this.initMemberPageView(system);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	
	
}
