package com.dy.ia.www.controller.member;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.sc.entity.common.SystemInfo;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/member")
public class GetPasswordController extends FrontBaseController {
	public static final String RESET_PASSWORD_TYPE = "resetPasswordType";
	public static final String RESET_PASSWORD_VALUE = "resetPasswordValue";
	
	/**
	 * 找回密码第一步
	 * @param model
	 * @return
	 */
	@RequestMapping("/public/getPwd")
	public ModelAndView getPwdPage(Model model) {
		ModelAndView view = new ModelAndView();
		try {
			//显示页面
//			SystemInfo system = new SystemInfo("backup/member/getpwd.jsp");
//			system.setSiteName("找回密码");
//			view = this.initSystemPageView(system);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		Map map=Maps.newHashMap();
		map.put("ctx", "");
		map.put("siteName", "hahhaa");
		map.put("businessName", "");
		view.addObject("aaa", map);
		view.setViewName("login/getpasswd");
		return view;
	}
	
}
