package com.dy.sc.www.controller.member.manager;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.*;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.common.SysDocument;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Maps;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

/**
 * 电子合同
 *
 * @author cuiwm
 */
@Controller
@RequestMapping("/member/manager/contract")
public class ContractController extends FrontBaseController {
    @Autowired
    private FDDUtils utils;
    @Autowired
    private CommonBussUtil bussUtil;

    /**
     * 界面结构：电子合同
     *
     * @return
     */
    @SuppressWarnings("unchecked")
    @RequestMapping("/list")
    public ModelAndView list() {
        Map<String, Object> formData = Maps.newHashMap();
        try {
            TableHeader tableHeader = new TableHeader();
            tableHeader.setNames(new String[]{"id", "product_name", "loan_contract_no", "sign_type", "sign_type1", "sign_time", "sign_status", "file_name", "action"});
            tableHeader.setTexts(new String[]{"序号", "产品名称", "信贷合同号", "签约类型", "签约方式", "签章时间", "状态", "合同名称", "签署$查看"});
            tableHeader.setTypes(new String[]{"", "", "", "", "", "", "", "", "link"});
            PageStructure data = PageUtil.createTablePageStructure("member/manager/contract/listData", null, "id", tableHeader, null, null);

            formData.put("list", data);
            formData.put("products", DictUtils.getOptions("sc_product"));
            formData.put("signStatus", DictUtils.getOptions("sign_status"));
            formData.put("currentStatus", 1);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return createSuccessModelAndView("member/manager/contractInfo", JsonUtils.object2JsonString(formData));
    }

    /**
     * 获取数据：电子合同
     */
    @ResponseBody
    @RequestMapping("/listData")
    public DyResponse listData(Integer page, Long productId, String loanContractNo, Integer signStatus) throws Exception {
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Company company = this.getById(user.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(10);
        queryItem.setFields("id,template_id,business_type,paper_id,sign_type1,protocol_type,company_id,product_id,loan_id,sign_status,loan_contract_no,last_did,update_time,create_time,sign_time,sign_type");
        queryItem.setWhere(Where.eq("company_id", user.getCompanyId()));
        queryItem.setOrders("id desc");
        if (productId != null) {
            queryItem.setWhere(Where.in("product_id", bussUtil.getProductIds(productId)));
        }
        if (StringUtils.isNotBlank(loanContractNo)) {
            queryItem.setWhere(Where.likeAll("loan_contract_no", loanContractNo));
        }
        if (signStatus != null) {
            queryItem.setWhere(Where.eq("sign_status", signStatus));
        }
        Page pageData = (Page) dataConvert(getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_PROTOCOL), "sign_type", "sign_time,create_time");
        for (Object item : pageData.getItems()) {
            Map pro = (Map) item;
            Integer s1 = Integer.parseInt(pro.get("sign_status").toString());
            Long loanId = Long.valueOf(pro.get("loan_id").toString());
            Integer signType1 = 0;
            if (pro.get("sign_type1") != null) {
                signType1 = Integer.valueOf(pro.get("sign_type1").toString());
                pro.put("sign_type1", DictUtils.getDictLabel(pro.get("sign_type1").toString(), "sign_type_1"));
            }
            if (signType1 == ScConstants.SIGN_TYPE_PAPER) {
                if (pro.get("paper_id") != null) {
                    SysDocument document = this.getById(pro.get("paper_id").toString(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
                    pro.put("type", "查看");
                    pro.put("action", document.getFilePath());
                }
            } else if (s1 == ScConstants.PROTOCOL_STATUS_UNSIGNED || s1 == ScConstants.PROTOCOL_STATUS_FAILURE) {
                pro.put("type", "签署");
                String returnUrl = "http://" + RequestUtil.getRequest().getServerName() + ":" + RequestUtil.getRequest().getServerPort() + "/member/loan/tmp/" + pro.get("business_type") + "?id=" + loanId + "&protocolId=" + pro.get("id") + "&templateId=" + pro.get("template_id");
                SysDocument document = this.getById(pro.get("last_did").toString(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
                String[] arrs = document.getFileName().split("\\.");
                Object no = pro.get("loan_contract_no");
                String url = utils.signContract(document.getFilePath(),
                        company.getFddCustomerId(), no == null ? "" : no.toString() + pro.get("id").toString(), company.getCompanyName(), returnUrl, "", arrs[arrs.length - 2]);
                pro.put("action", url);
            } else if (s1 == ScConstants.PROTOCOL_STATUS_SIGNED || s1 == ScConstants.PROTOCOL_STATUS_SUCCESS) {
                SysDocument document = this.getById(pro.get("last_did").toString(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
                pro.put("type", "查看");
                pro.put("action", document.getFilePath());
            }
        }
        dataConvert(pageData, "sign_status");
        this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
        this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, "last_did:file_path,file_name");
        this.idToName(pageData.getItems(), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "product_id:name as product_name");
        return createSuccessJsonResonse(pageData);
    }
}