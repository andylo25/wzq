package com.dy.sc.www.interceptor;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.dy.core.bussmodule.IBaseBussModule;
import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.IpUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.RequestUtil;
import com.dy.core.utils.common.SpringContextHolder;
import com.dy.core.utils.encrypt.MessageEncryptUtil;
import com.dy.ia.entity.common.TrustRequestLog;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;

public class JiuxinDecryptHandlerInterceptor extends HandlerInterceptorAdapter{
	
    private static final Logger logger=Logger.getLogger(JiuxinDecryptHandlerInterceptor.class);
    
    volatile static IBaseBussModule bussModule;

	public static IBaseBussModule getBussModule() {
		if (bussModule == null) {
			bussModule = SpringContextHolder.getBean(IBaseBussModule.class);
		}
		return bussModule;
	}
    
	private static final Long FIVE_MINUTES=5*60*1000L;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
	    String sign=request.getParameter("sign");
	    String data=request.getParameter("data");
	    String timestamp=request.getParameter("timestamp");
	    String nonce=request.getParameter("nonce");
	    String org_code=request.getParameter("org_code");
    	//判断参数是否正常
    	if (StringUtils.isBlank(sign)||StringUtils.isBlank(timestamp)||StringUtils.isBlank(org_code)||StringUtils.isBlank(nonce)||
    			StringUtils.isBlank(data)) {
    		sendResult(request, response,"请求无效");
    		return false;
    	}
    	//请求在5分钟前 过期
    	if(Long.parseLong(timestamp)<System.currentTimeMillis()-FIVE_MINUTES){
    		sendResult(request, response,"请求已失效");
    		return false;
    	}
    	String decryptData = null;
    	String resultMsg = "000";
    	try {
    		MessageEncryptUtil messageEncryptUtil = getAesKey(org_code);
    		decryptData = messageEncryptUtil.decryptMsg(sign, timestamp, nonce, data,org_code);
		} catch (Exception e) {
			resultMsg = e.getMessage();
		}
    	//添加请求日志
    	addTrustRequestLog(request,decryptData,resultMsg);
    	
    	request.setAttribute(AccConstants.DECRYPT_DATA_REQUEST, JsonUtils.json2Map(decryptData));
    	
		return true;
	}
	
	private MessageEncryptUtil getAesKey(String org_code) throws Exception {
		// 根据org_code从数据库获取配置
		QueryItem queryItem = new QueryItem(Where.eq("app_id", org_code));
		Map<String, Object> aesConfig = getBussModule().getOneByMap(queryItem, SCModule.TRUST, SCFunction.AES_CONFIG);
		String aesKey = (String) aesConfig.get("app_key");
		String appId = (String) aesConfig.get("app_id");
		return new MessageEncryptUtil(aesKey, aesKey, appId);
	}
	
	/**
	 * 保存调用日志
	 * @param request
	 * @param resultMsg
	 * @param paramMap
	 * @return 
	 */
	private TrustRequestLog addTrustRequestLog(HttpServletRequest request, String body, String resultMsg) {
		TrustRequestLog requestLog = new TrustRequestLog();
		Map<String, Object> paramMap = RequestUtil.getRequestMap(request);
		if(logger.isDebugEnabled())logger.debug(paramMap);
		try {
			requestLog.setReqContents(JsonUtils.object2JsonString(paramMap));
			requestLog.setReqUrl(request.getServletPath());
			requestLog.setBodyContents(body);
			requestLog.setResultCode(resultMsg);
			requestLog.setRemoteIp(IpUtil.ipStrToLong(RequestUtil.getRemoteIp()));
			getBussModule().insert(SCModule.TRUST, SCFunction.REQUEST_LOG,requestLog);
			if(logger.isInfoEnabled()){
				logger.info(JsonUtils.object2JsonString(requestLog));
			}
		} catch (Exception e) {
			logger.error("保存调用日志异常："+paramMap,e);
		}
		return requestLog;
	}

	private void sendResult(HttpServletRequest request, HttpServletResponse response,String message) throws IOException {
		if(isAjax(request)){
			DyResponse dyResponse = new DyResponse();
			dyResponse.setStatus(DyResponse.LOGINERR);
			if(StringUtils.isNotBlank(message)){
			    dyResponse.setDescription(message);
			}
			PrintWriter printWriter = response.getWriter();
			printWriter.print(JsonUtils.object2JsonString(dyResponse));
			printWriter.close();
		}else{
			response.sendRedirect(request.getContextPath() + "/badRequest");
		}
	}
	
	private boolean isAjax(HttpServletRequest request){
		return "application/x-www-form-urlencoded".equals(request.getHeader("Content-Type")) 
				&& request.getMethod().equals("POST");
	}
	
}