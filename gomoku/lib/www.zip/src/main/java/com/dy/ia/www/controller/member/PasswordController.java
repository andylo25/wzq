package com.dy.ia.www.controller.member;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.Constant;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.SecurityUtil;
import com.dy.sc.entity.org.OrgFrontUser;

@Controller
@RequestMapping("member")
public class PasswordController extends FrontBaseController {
	
	/**
	 * 界面结构：修改登录密码
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="member/passwdPage")
	public ModelAndView salerManager(Integer page,Integer limit,String search) throws Exception {
		
		ModelAndView view = new ModelAndView();
		try {

			SystemInfo system = new SystemInfo("backup/member/changePwd.html");
			system.setSiteName("安全设置");
			view = this.initMemberPageView(system);
			view.addObject("data", null);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	/**
	 * 修改登录密码
	 * @param raw
	 * @param newPwd
	 * @param confirmPwd
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/member/editpwd")
	public DyResponse editpwd(String raw,String newPwd,String confirmPwd) throws Exception {
		OrgFrontUser user = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		if( !SecurityUtil.md5(SecurityUtil.sha1(raw)).equals(user.getPassword())){
			return createErrorJsonResonse("原始密码错误");
		}
		//验证两次密码是否一致
		if(newPwd == null || confirmPwd == null)return createErrorJsonResonse("两次密码不能为空");
		if(!StringUtils.equals(newPwd, confirmPwd))return createErrorJsonResonse("两次密码不一致");
		
		//新密码与旧密码不能一致
		if(newPwd.equals(raw))return createErrorJsonResonse("新密码不能与旧密码一致");
		user.setPassword(SecurityUtil.md5(SecurityUtil.sha1(newPwd)));
		
		this.update(SCModule.SYSTEM, SCFunction.SYS_USER, user);
		return createSuccessJsonResonse("1","密码修改成功");
	}
	
	/**
	 * 修改支付密码
	 * @param raw
	 * @param newPwd
	 * @param confirmPwd
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/member/editpaypwd")
	public DyResponse editpaypwd(String raw,String newPwd,String confirmPwd) throws Exception {
		
		//验证两次密码是否一致
		if(!newPwd.equals(confirmPwd))return createErrorJsonResonse("两次密码不一致");
		
		//新密码与旧密码不能一致
		if(newPwd.equals(raw))return createErrorJsonResonse("新密码不能与旧密码一致");
				
		
		return createSuccessJsonResonse("1","支付密码修改成功");
	}
}
