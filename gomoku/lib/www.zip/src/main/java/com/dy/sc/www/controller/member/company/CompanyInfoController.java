package com.dy.sc.www.controller.member.company;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.ia.entity.enumeration.ReceiveBillStatusEnum;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.CheckStatus;
import com.dy.sc.entity.fund.FundLoanRepay;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * 核心企业总览
 * @ClassName: CompanyInfoController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年8月3日 上午11:23:21 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/member/core/companyInfo")
public class CompanyInfoController extends FrontBaseController{

    @RequestMapping(method=RequestMethod.GET)
    public ModelAndView get() throws Exception {
        Map<String,Object> formData = Maps.newHashMap();
        //年度申请通过的企业数量
        Calendar cal=Calendar.getInstance();
        Date today=new Date();
        String startTime=cal.get(Calendar.YEAR)+"-01-01";
		String endTime=DateUtil.dateFormat(DateUtil.addDay(today, 1));
		Where yearWhere=this.addAndWhereCondition(null,"create_time", startTime, endTime);
		QueryItem yearRelationItem = new QueryItem(Where.eq("core_company_id", getUser().getCompanyId()));		
		yearRelationItem.setFields("company_id,core_company_id");
		yearRelationItem.getWhere().add(yearWhere);
		yearRelationItem.getWhere().add(Where.eq("check_status", CheckStatus.CHECK_PASS.getIndex()));
		List<Map> yearRelation = this.getListByMap(yearRelationItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
		int yearRelationCount=0;
		List<Long> yearCompanyIds=Lists.newArrayList();
		if(yearRelation!=null){
			yearRelationCount=yearRelation.size();
			//取出通过的授信企业id,用于查询年度产业链融资金额
			for(Map item:yearRelation){
				Long companyId=item.get("company_id")==null?0:Long.parseLong(item.get("company_id").toString());
				yearCompanyIds.add(companyId);
			}
		}
		formData.put("year_relation_count", yearRelationCount);
		
		//全部申请通过的企业数量
		QueryItem relationItem = new QueryItem(Where.eq("core_company_id", getUser().getCompanyId()));		
		relationItem.setFields("company_id,core_company_id");
		relationItem.getWhere().add(Where.eq("check_status", CheckStatus.CHECK_PASS.getIndex()));
		List<Map> relations = this.getListByMap(relationItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
		int relationCount=0;
		List<Long> companyIds=Lists.newArrayList();
		if(relations!=null){
			relationCount=relations.size();
			//取出通过的授信企业id,用于查询全部产业链融资金额
			for(Map item:relations){
				Long companyId=item.get("company_id")==null?0:Long.parseLong(item.get("company_id").toString());
				companyIds.add(companyId);
			}
		}
		formData.put("relation_count", relationCount);
		
		//产业链融资金额
		QueryItem yearAmountItem = new QueryItem(Where.in("company_id", yearCompanyIds));
		yearAmountItem.setFields("sum(loan_amount) as total_amount");
		yearAmountItem.getWhere().add(Where.eq("status", 6));
		yearAmountItem.getWhere().add(yearWhere);
		Map yearAmount = this.getOneByMap(yearAmountItem, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
		if(yearAmount!=null){
			formData.put("year_amount", yearAmount.get("total_amount"));
		}else{
			formData.put("year_amount", 0);
		}
		
		//产业链融资金额
		QueryItem totalAmountItem = new QueryItem(Where.in("company_id", companyIds));
		totalAmountItem.setFields("sum(loan_amount) as total_amount");
		totalAmountItem.getWhere().add(Where.eq("status", 6));
		Map totalAmount = this.getOneByMap(totalAmountItem, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
		if(totalAmount!=null){
			formData.put("total_amount", totalAmount.get("total_amount"));
		}else{
			formData.put("total_amount", 0);
		}
		//待核实数量
		relationItem = new QueryItem(Where.eq("core_company_id", getUser().getCompanyId()));
		relationItem.setFields("count(id) as todo_count");
		relationItem.getWhere().add(Where.eq("check_status", CheckStatus.CHECK_TODO.getIndex()));
		Map todoCount = this.getOneByMap(relationItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
		formData.put("todo_count", todoCount.get("todo_count"));
		
		//待确认数量
		QueryItem recordedItem = new QueryItem(Where.eq("buyer_id", getUser().getCompanyId()));
		recordedItem.setFields("count(id) as recorded_count");
		recordedItem.getWhere().add(Where.eq("receive_bill_status", ReceiveBillStatusEnum.RECORDED.getIndex()));
		Map recordedCount = this.getOneByMap(recordedItem, SCModule.LOAN, SCFunction.LOAN_RECEIVE_BILL);
		formData.put("recorded_count", recordedCount.get("recorded_count"));
		
		//一个月内待付款数据
        recordedItem=new QueryItem();
        String startDate=DateUtil.dateFormat(DateUtil.addMonth(today, -1));
		String endDate=DateUtil.dateFormat(DateUtil.addDay(today, 1));
		Where dateWhere=this.addAndWhereCondition(null,"create_time", startDate, endDate);
        recordedItem.getWhere().add(Where.eq("buyer_id", getUser().getCompanyId()));
        recordedItem.getWhere().add(Where.eq("receive_bill_status", ReceiveBillStatusEnum.TRANSFERED.getIndex())); 
        recordedItem.getWhere().add(dateWhere); 
        recordedItem.setOrders("id desc");
        List<Map> receives=this.getListByMap(recordedItem, SCModule.LOAN, SCFunction.LOAN_RECEIVE_BILL);
        if(receives!=null&&receives.size()>0){
        	this.idToName(receives, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
        	for(Map receive:receives){
        		//电子协议及下载地址
                QueryItem docItem = new QueryItem(Where.eq("loan_id", receive.get("loan_id")));  
                docItem.setFields("id,loan_id,last_did,protocol_type,sign_time,create_time");
                List<Map> protocols = this.getListByMap(docItem, SCModule.LOAN, SCFunction.LOAN_PROTOCOL);        
                if(protocols!=null&&protocols.size()>0){
                	this.idToName(protocols, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, "last_did:file_path,file_name,type");
                	for(Map item:protocols){
//                		Integer type=item.get("protocol_type")==null?null:Integer.parseInt(item.get("protocol_type").toString());
//                		if(ScConstants.PROTO_TYPE_ZRTZS==type.intValue()){
//                			receive.put("file_path", item.get("file_path"));//转让通知书
//                			receive.put("file_name", item.get("file_name"));
//                		}
                	}       	
                }
        	}
        	dataConvert(receives,"credit_type:credit_type");
        }
        
        formData.put("receives", receives);
        return createSuccessModelAndView("member/core/companyInfo", JsonUtils.object2JsonString(formData));
    }
}
