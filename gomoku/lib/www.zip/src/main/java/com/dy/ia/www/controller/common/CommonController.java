package com.dy.ia.www.controller.common;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.Constant;
import com.dy.core.utils.Converter;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DyHttpClient;
import com.dy.core.utils.PropertiesUtil;
import com.dy.core.utils.RequestUtil;
import com.dy.ia.entity.common.SysDocument;
import com.dy.ia.entity.enumeration.UploadValidation;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/common")
public class CommonController extends FrontBaseController {
	@RequestMapping("/member/login")
	public ModelAndView loninIndex(Model model) {
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo();
			//判断用户是否已经登陆过
			if(this.getSessionAttribute(Constant.SESSION_USER) == null)  {
//				model.addAttribute("type", "login");
//				system.setSiteName("用户登录");
//				system.setContentPage("backup/member/login.jsp");
			    view.setViewName("member/login");
			    return view;
			} else {
				//system.setContentPage("backup/member/main.jsp");
				return new ModelAndView("redirect:/member/member/center");
			}
			//view = this.initSystemPageView(system);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}

	@RequestMapping("/member/reg")
	public ModelAndView regiserIndex(Model model,String invite) {
		if (this.getSessionAttribute(Constant.SESSION_USER) != null) {
			return new ModelAndView("redirect:/member/member/center");
		}
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo();
			system.setContentPage("backup/member/reg.jsp");
			system.setSiteName("用户注册");
			view = this.initSystemPageView(system);
			model.addAttribute("type", "reg");
			model.addAttribute("invite", invite);
//			model.addAttribute("is_email_open", isEmailAuthOpen());
			//除非客户有需要，否则一律不分个人开户和企业开户
//			if(TrustManager.MONEYMOREMORE.equals(trustType))
//				model.addAttribute("show_group","1");
//			else 
				model.addAttribute("show_group", "-1");
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 文件上传
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="fileupload/{module}/{function}", method=RequestMethod.POST)
	public DyResponse fileUpload(MultipartFile upload, @PathVariable("module")String module, @PathVariable("function")String function) throws Exception {
		DyResponse response = new DyResponse();
		String fileName = upload.getOriginalFilename();
		InputStream stream = upload.getInputStream();
		try {
			
			//上传内容校验
			String errorMsg = validateUploadContent(module, function, fileName, upload.getSize());;
			if(StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
			
			response = DyHttpClient.doImageUpload(module, function, fileName, stream);
			if(response != null && response.getStatus() == DyResponse.OK) {
				Map<String, Object> map = (Map<String, Object>) response.getData();
				String fileUrl = map.get("fileurl").toString();
				Map<String, Object> fileData=Maps.newHashMap();
				fileData.put("file_url", fileUrl);
				fileData.put("url", PropertiesUtil.getImageHost() + fileUrl);
				fileData.put("code", response.getStatus());
				fileData.put("size", upload.getSize());
				fileData.put("time", DateUtil.dateFormat(new Date()));
				String x=fileName.substring(0, fileName.lastIndexOf("."));
				fileData.put("name", fileName.substring(0, fileName.lastIndexOf(".")));
				fileData.put("format", fileName.substring(fileName.lastIndexOf("."), fileName.length()));
				map.put("Filedata", fileData);
				response.setData(map);
				
				// 保存文档表
				SysDocument document = new SysDocument();
				document.setFileName(fileName);
				document.setFilePath((String) fileData.get("url"));
				int ind = fileName.indexOf('.');
				if(ind > 0){
					document.setType(fileName.substring(ind));
				}
				document.setFileSize(upload.getSize());
				document.setRemarks(module + "_" + function);
				UploadValidation uploadValidation = UploadValidation.valueOf(module + "_" + function);
				document.setDocType(uploadValidation.getDocType());
				document.setCreateUname(getUser().getRealName());
				document.setClientType(Converter.boolToInt(RequestUtil.isAdmin()));
				this.insert(SCModule.SYSTEM,SCFunction.SYS_DOCUMENT, document);
				map.put("did",document.getId());
			}
		} catch (Exception e) {
			logger.error("File upload error:", e);
			response.setStatus(DyResponse.ERROR);
			response.setDescription(e.getMessage());
		}
		
		return response;
	}


	/**
	 * 上传内容校验
	 * @param module 模块名
	 * @param function 功能点
	 * @param fileName 上传文件名
	 * @param fileSize 上传文件大小
	 * @return
	 */
	private String validateUploadContent(String module, String function, String fileName, long fileSize) {
		if(StringUtils.isEmpty(fileName) || fileSize <= 0) return null;
		
		//根据moudle_function获取验证规则
		UploadValidation uploadValidation = null;
		try {
			uploadValidation = UploadValidation.valueOf(module + "_" + function);
			
			//文件类型验证
			String fileType = fileName.substring(fileName.lastIndexOf("."));
			if(!uploadValidation.getFileType().contains(fileType)) {
				return getMessage("validate.upload.wrongtype", new String[]{uploadValidation.getFileType().replace(".", "")});
			}
			
			//文件大小验证
			if(uploadValidation.getFileSize() < fileSize) {
				return getMessage("validate.upload.wrongsize", new Long[]{(uploadValidation.getFileSize()/1024/1024)});
			}
		} catch (Exception e) {
		}
		
		return null;
	}
	
	/**
	 * 获取文件地址
	 * @return
	 * @throws Exception 
	 */
	@ResponseBody
	@RequestMapping(value="document")
	public DyResponse getDocUrl(String did) throws Exception {
		if(StringUtils.isNotBlank(did)){
			QueryItem queryItem = new QueryItem(Where.in("id", did));
			List<Map> list = this.getListByMap(queryItem, SCModule.SYSTEM,SCFunction.SYS_DOCUMENT);
			this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_USER, "create_uid:real_name");
			return createSuccessJsonResonse(list);
		}
		return createErrorJsonResonse("请求参数为空");
	}

}