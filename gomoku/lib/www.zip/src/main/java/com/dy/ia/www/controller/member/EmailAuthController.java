package com.dy.ia.www.controller.member;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Email;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.EmailUtil;
import com.dy.core.utils.GenNumUtil;
import com.dy.core.utils.PropertiesUtil;
import com.dy.ia.entity.common.SysEmailPort;
import com.dy.ia.entity.common.SysSystemConfig;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.www.entity.EmailVerifyCode;

/**
 * 邮箱认证
 */
@Controller
@RequestMapping("/member")
public class EmailAuthController extends FrontBaseController {
	@Autowired
	private EmailUtil emailUtil;
	
	/**
	 * 邮箱验证第一步
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/email/againapprove")
	public DyResponse approveEmail(String email,String code) throws Exception {
		OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
		//解绑原邮箱进行验证
		if(code !=null && !"".equals(code)){
			Map<String,Object> sessionMap = (Map<String, Object>) this.getSessionAttribute("sessionMap");
//			String sessionCode = (String) sessionMap.get("sessionCode");
//			if(!code.equals(sessionCode))return createErrorJsonResonse("验证码错误");
			
			user = getMember(user.getId());
			String errorMsg = EmailVerifyCode.validate(user.getEmail(), code, 5);
			if(errorMsg != null) return createErrorJsonResonse(errorMsg);
			if(email.equals(user.getEmail())) return createErrorJsonResonse("新旧邮箱不能一致");
			//更新member，删除Email认证
			user.setEmail(null);
			this.update(SCModule.SYSTEM, SCFunction.SYS_USER, user);
		}
		//验证邮箱
		if(email=="")return createErrorJsonResonse("邮箱不能为空");
//		if(!StringUtils.checkEmail(email))return createErrorJsonResonse("邮箱格式错误");
		user.setEmail("");
		this.setSessionAtrribute(Constant.SESSION_USER, user);
		this.update(SCModule.SYSTEM, SCFunction.SYS_USER, user);
		return this.send(user, email, "approve");
	}
	
	/**
	 * 发送邮件
	 * @param email
	 * @param type
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/email/sendemail")
	public DyResponse sendemail(String email,String type) throws Exception {
		//获取当前用户
		OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
		
		if(StringUtils.isNotBlank(email)){
			//判断邮箱是否被使用
			List<Where> whereList = new ArrayList<Where>();
//			whereList.add(Where.eq("status", 1));
			whereList.add(Where.eq("email", email));
			whereList.add(Where.notEq("id", user.getId()));
			String errorMsg = BaseInfoUtils.validateExist(email, "邮箱", SCModule.SYSTEM, SCFunction.SYS_USER, whereList);
			if(org.apache.commons.lang.StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
		}else{
			email = user.getEmail();
		}

		user = getMember(user.getId());

		return send(user,email,type);
	}
	
	private DyResponse send(OrgFrontUser user,String email,String type) throws Exception{
		//发送激活邮箱,将验证码和email存入session
		String verifyCode = GenNumUtil.random(6);
		EmailVerifyCode emailVerifyCode = EmailVerifyCode.getCode(email, verifyCode, 60);
		if(emailVerifyCode.getErrorMsg() != null) return createErrorJsonResonse(emailVerifyCode.getErrorMsg());
		
		//组装email
		Email newEmail = new Email();
		newEmail.setMemberId(user.getId());
		newEmail.setMemberName(user.getRealName());
		if(StringUtils.isNotBlank(type) && type.equals("reset")){
			newEmail.setType(1);//重设email或者设置
		}else{
			newEmail.setType(0);
		}
		String[] arr = {email};
		newEmail.setTo(arr);
		Map<String, String> map = new HashMap<String, String>();
		map.put("#email_account#", getEmailPort().getEmailAccount());
		map.put("#web_name#", getSysConfig("site_name"));
		map.put("#web_url#", "http://" + getSysConfig("site_domain"));
		map.put("#code#", verifyCode);
		map.put("#web_now_time#", DateUtil.dateTimeFormat(new Date()));
		map.put("#logo#", PropertiesUtil.getImageHost() + getSysConfig("site_logo"));
		map.put("#member_name#", user.getRealName());
		map.put("#email#", email);
		map.put("#web_time#", DateUtil.dateFormat(DateUtil.getCurrentTime()));
		map.put("#member_url#", "http://" + getSysConfig("site_domain") + "/member/member/center");
		map.put("#service_qq_name#", getSysConfig("service_qq"));
		map.put("#service_tel#", getSysConfig("service_tel"));
		map.put("#service_hours#", getSysConfig("service_hours"));
		map.put("#site_copyright#", getSysConfig("site_copyright"));
		newEmail.setTemplateParam(map);
		if(StringUtils.isNotBlank(type) && type.equals("reset")){
			newEmail.setTemplateType(4);
		}else{
			newEmail.setTemplateType(1);
		}
		//测试要求发送失败验证码也可以用
		Map<String, Object> sessionMap = new HashMap<String, Object>();
		sessionMap.put("sessionCode", verifyCode);
		sessionMap.put("sessionEmail", email);
		if (this.getSessionAttribute("sessionMap") != null) {
			this.removeSessionAttribute("sessionMap");
		}
		this.setSessionAtrribute("sessionMap", sessionMap);
		
		boolean sendStatus = emailUtil.send(newEmail, EmailUtil.SEND_IMMEDIATE);
		if (sendStatus == false) {
			return createErrorJsonResonse("邮箱发送失败");
		}
		return createSuccessJsonResonse(null, "邮箱发送成功!");
	}
	
	/**
	 * 验证验证码
	 * @param email
	 * @param type
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/email/verifyemail")
	public DyResponse verifyEmail(String email, String code) throws Exception {
		Map<String, Object> sessionMap = (Map<String, Object>) this.getSessionAttribute("sessionMap");
		if (sessionMap == null) {//session已过期
			return createErrorJsonResonse("验证码错误");
		} else {
			//session未过期
			String sessionCode = (String) sessionMap.get("sessionCode");
			String sessionEmail = (String) sessionMap.get("sessionEmail");
			if (!email.equals(sessionEmail)) {
				return createErrorJsonResonse("邮箱不正确");
			}
			String errorMsg = EmailVerifyCode.validate(email, code, 5);
			if(errorMsg != null) return createErrorJsonResonse(errorMsg);
			if (!sessionCode.equals(code)) {
				return createErrorJsonResonse("验证码错误");
			}
		}
		
		//获取当前用户
		OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
		
		//判断邮箱是否被使用
		List<Where> whereList = new ArrayList<Where>();
		whereList.add(Where.eq("status", 1));
		whereList.add(Where.eq("email", email));
		whereList.add(Where.notEq("id", user.getId()));
		String errorMsg = BaseInfoUtils.validateExist(email, "邮箱", SCModule.SYSTEM, SCFunction.SYS_USER, whereList);
		if(org.apache.commons.lang.StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
		
		//更新member表
		user = getMember(user.getId());
		user.setEmail(email);
//		user.setIsEmail(1);
		this.update(SCModule.SYSTEM, SCFunction.SYS_USER, user);

		//重新设置session
		this.removeSessionAttribute(Constant.SESSION_USER);
		this.setSessionAtrribute(Constant.SESSION_USER, user);
		if(email != null) email = email.split("@")[0].substring(0,1)+"**@"+email.split("@")[1];
		return createSuccessJsonResonse(email, "验证成功!");
	}
	
	/**
	 * 获取用户认证信息
	 * @throws Exception 
	 */
	@ResponseBody
	@RequestMapping("/member/getapprove")
	public Map<String,Object> getApprove() throws Exception {
		OrgFrontUser user = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		//手机
		String phone = "";
		if(user.getPhone() != null && user.getPhone() != 0L){
			phone =String.valueOf(user.getPhone());
			phone = phone.substring(0,phone.length()-(phone.substring(3)).length())+"****"+phone.substring(7);
		}

		//邮箱
		String email = "";
		if(StringUtils.isNotBlank(user.getEmail())){
			email =String.valueOf(user.getEmail());
			email = email.split("@")[0].substring(0,1)+"**@"+email.split("@")[1];
		}
		
		//上次登录时间
		String lastlogin_time = DateUtil.dateTimeFormat(DateUtil.getCurrentTime());
		if(user.getLastloginTime() !=null){
			lastlogin_time = String.valueOf(user.getLastloginTime());
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("email", email);
		map.put("lastlogin_time", user.getCount() > 1 ? lastlogin_time : "");
		map.put("phone", phone);
		map.put("pwd", "1");
				
		return map;
	}
	
	/**
	 * 根据id获取用户
	 * @throws Exception 
	 */
	public OrgFrontUser getMember(Long memberId) throws Exception{
		QueryItem userItem = new QueryItem();
		userItem.getWhere().add(Where.eq("id", memberId));
		OrgFrontUser user = this.getOneByEntity(userItem, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
		return user;
	}
	
	/**
	 * 获取系统配置
	 * @throws Exception 
	 */
	private String getSysConfig(String type) throws Exception{
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("nid", type));
		SysSystemConfig config = this.getOneByEntity(item, SCModule.SYSTEM, SCFunction.SYS_CONFIG, SysSystemConfig.class);
		return config.getValue();
	} 
	
	/**
	 * 获取邮件发送配置
	 * @throws Exception 
	 */
	private SysEmailPort getEmailPort() throws Exception{
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("status", 1));
		item.setOrders("sort_index desc");
		List<SysEmailPort> emailPortList = this.getListByEntity(item, SCModule.SYSTEM, SCFunction.SYS_EMAILPORT, SysEmailPort.class);
		return (emailPortList != null && emailPortList.size() > 0) ? emailPortList.get(0) : null;
	}
}