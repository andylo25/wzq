package com.dy.sc.www.controller.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.utils.JsonUtils;
import com.dy.sc.entity.account.AccBankCard;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;

/**
 * 
 * 提现界面
 * @ClassName: CompanyTransferController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年8月24日 下午2:01:33 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/public/test")
public class TestController extends FrontBaseController {
	
	/**
	 * 
	 * 测试页面
	 * @return
	 * @throws Exception
	 * @author likf
	 */
	@RequestMapping(value="/{type}",method=RequestMethod.GET)
    public ModelAndView view(@PathVariable("type")String type) throws Exception {
	    
		return createSuccessModelAndView("test/"+type, null);
    }
	
}