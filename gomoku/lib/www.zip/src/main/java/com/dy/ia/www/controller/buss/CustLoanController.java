package com.dy.ia.www.controller.buss;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.utils.DateUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;

@Controller
@RequestMapping("/customer/loan")
public class CustLoanController extends FrontBaseController {
	
	/**
	 * 借贷记录界面
	 * @param model
	 * @return
	 */
    // @RequestMapping("log")
    // public ModelAndView loninIndex(Model model) {
    // ModelAndView view = new ModelAndView();
    // try {
    // SystemInfo system = new SystemInfo("backup/finance/loan_rec.html");
    // system.setSiteName("借贷记录");
    // view = this.initMemberPageView(system);
    //
    // TableHeader tableHeader = new TableHeader();
    // tableHeader.setNames(new
    // String[]{"loan_contract_no_link_","loan_amount","contract_time","real_name","status","create_time"});
    // tableHeader.setTexts(new String[]{"信贷信息",
    // "申贷金额(万元)","周期","业务员","状态","创建时间"});
    // tableHeader.setTypes(new String[]{"html","","", "","",""});
    // PageStructure data =
    // PageUtil.createTablePageStructure("customer/loan/logData","member/customer/viewCreditRecord",
    // "id", tableHeader,null,null);
    //
    // view.addObject("data", JsonUtils.object2JsonString(data));
    //
    // } catch (Exception e) {
    // logger.error(e.getMessage(), e);
    // }
    // return view;
    // }

	/**
	 * 获取借贷记录数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("logData")
	public DyResponse deptDetailData(Integer page,Integer limit,String company_name,String status) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setFields("id,loan_contract_no,loan_amount/10000 as loan_amount,loan_apr,sales_uid,loan_repay_type,contract_start_time,contract_end_time,status,create_time");
		if(StringUtils.isNotBlank(company_name)){
			queryItem.setWhere(Where.like("company_name", "%"+company_name+"%"));
		}
		queryItem.setWhere(Where.eq("user_id", getUserId()));
		queryItem.setOrders("id desc");
		Page recordPage=this.getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
		 List<Map> data=recordPage.getItems();
		 if(data!=null&& data.size()>0){
	    	 for (Map map : data) {
    			String start_time=DateUtil.dateFormatSlash(Long.valueOf(map.get("contract_start_time").toString()));
    			String end_time=DateUtil.dateFormatSlash(Long.valueOf(map.get("contract_end_time").toString()));
    			map.put("contract_time", start_time+"-"+end_time);	
	 		}
	    }
	    recordPage=(Page) dataConvert(recordPage,"status:credit_record_status,loan_repay_type:repay_type","create_time");
	    this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_USER, "sales_uid:real_name");
		return createSuccessJsonResonse(recordPage);
	}

}