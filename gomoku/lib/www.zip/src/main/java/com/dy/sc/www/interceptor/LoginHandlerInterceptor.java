package com.dy.sc.www.interceptor;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.dy.core.bussmodule.IBaseBussModule;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.service.BaseService;
import com.dy.core.utils.Constant;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PropertiesUtil;
import com.dy.ia.entity.common.SysSystemSitepage;
import com.dy.ia.entity.custom.SitepageTree;
import com.dy.sc.bussmodule.agpur.AgpurSpaModule;
import com.dy.sc.bussmodule.utils.SysSitepageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;


public class LoginHandlerInterceptor extends HandlerInterceptorAdapter{
	//IP黑名单
	private String blackListIp = "";
	
	private static final String FRONT_INTERCEPTOR_PATH = ".*/((content)|(public)|(common)).*";
	
    private IBaseBussModule bussModule;
	
	public LoginHandlerInterceptor(IBaseBussModule bussModule) {
		this.bussModule = bussModule;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		String path = request.getServletPath();
		if("/common/noaccess".equals(path)) return true;
		
		if(StringUtils.isNotBlank(blackListIp) && blackListIp.contains(getRequestIp(request))) {
			response.sendRedirect(request.getContextPath() + "/common/noaccess");
			return false;
		}
		
		//判断请求是否需要拦截
		if (path.matches(Constant.NO_INTERCEPTOR_PATH) || (path.matches(FRONT_INTERCEPTOR_PATH) && !"/trust/public/reg".equals(path))) return true;
		//第三方托管回调、通知
		if(path.startsWith("/trust/") 
				|| path.matches("/payment/.*/((return)|(notify))")
				|| path.startsWith("/ast/gateway/")) return true;
		
		for (String newPath : list) {
			if (path.matches(newPath)) {
				return true;
			}
		}
		//判断用户是否登陆，未登陆就返回到登录页面
		if (request.getSession().getAttribute(Constant.SESSION_USER) == null) {
			sendResult(request, response);
			return false;
		}
		return true;
	}
	
	private void sendResult(HttpServletRequest request, HttpServletResponse response) throws IOException {
		if(isAjax(request)){
			DyResponse dyResponse = new DyResponse();
			dyResponse.setStatus(DyResponse.LOGINERR);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(JsonUtils.object2JsonString(dyResponse));
			printWriter.close();
		}else{
			response.sendRedirect(request.getContextPath() + "/member/login");
		}
	}
	
	private boolean isAjax(HttpServletRequest request){
		return "application/x-www-form-urlencoded".equals(request.getHeader("Content-Type")) 
				&& request.getMethod().equals("POST");
	}
	
	/**
	 * 免拦截的url
	 */
	public static List<String> list = new ArrayList<String>();
	static {
		list.add("/member/login");
		list.add("/member/approve/isApprove");
		list.add("/member/trust/checkApprove");
		
		list.add("/robots.txt");
	}
	
	private String getRequestIp(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if(ip != null)
            ip = ip.split("\\,")[0];
        else
	        if(request.getRemoteAddr() != null)
	            ip = request.getRemoteAddr().split("\\,")[0];
	        if("0:0:0:0:0:0:0:1".equals(ip))
	            ip = "127.0.0.1";
        return ip;
	}
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		if(modelAndView == null)return;
		QueryItem queryItem = new QueryItem(Where.eq("status", 1));
		queryItem.setFields("id,pid,name,router,type,description");
		queryItem.getWhere().add(Where.eq("is_main_nav", 1));
		queryItem.setOrders("sort_index asc");
		List<SysSystemSitepage> systemSitepageList = bussModule.getListByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_SITEPAGE,SysSystemSitepage.class);
		List<SitepageTree> navSitepage = SysSitepageUtil.generateSitepageList(systemSitepageList);
		modelAndView.addObject("navSitepage", navSitepage);
		
		String js_type_ = PropertiesUtil.getProperty("dy.js.type");
		modelAndView.addObject("js_type_", StringUtils.isNotBlank(js_type_)?js_type_:"dist");
		super.postHandle(request, response, handler, modelAndView);
	}
	
	
}