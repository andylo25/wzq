package com.dy.ia.www.controller.member;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.SysDict;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.ia.entity.common.BussCreditRecord;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.common.FlowProcInst;
import com.dy.ia.entity.enumeration.AccountTypeEnum;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 用户管理
 * @author Administrator
 * 
 */
@Controller
@RequestMapping("/member")
public class CustomerController extends FrontBaseController {
	
	/**
	 * 授信记录 详情页
	 * @param id
	 * @return
	 * @throws Exception
	 */
    // @SuppressWarnings("unchecked")
    // @RequestMapping(value="customer/viewCreditRecord")
    // public ModelAndView viewCreditRecord(String id) throws Exception {
    //
    // ModelAndView view = new ModelAndView();
    // Map<String,Object> formData = Maps.newHashMap();
    // try {
    // Map<String,Object> record=null;
    // Map<String,Object> company=null;
    // Map<String,Object> saler=null;
    // Map<String,Object> loanRequest=null;
    // Map<String,Object> loanRepay=null;
    // List<Map> loanRepayPeriods=null;
    // if( StringUtils.isNotBlank(id) ){
    // QueryItem query = new QueryItem();
    // //this.filterUserId(query);
    // this.filterUserId(query);
    // query.setWhere(Where.eq("id", id));
    // record= this.getOneByMap(query, SCModule.LOAN,
    // SCFunction.LOAN_DEBIT_RECORD);
    // if(record!=null){
    // //借贷手续费
    // //计算费用
    // record.put("loan_fee_value_total", RepayUtil.calcShowFeeAmount(record));
    // dataConvert(record,
    // "status:credit_record_status,loan_type,loan_fee_type,loan_repay_type:repay_type");
    //
    // query = new QueryItem();
    // query.setWhere(Where.eq("id", record.get("company_id")));
    // company= this.getOneByMap(query, SCModule.SYSTEM,
    // SCFunction.SYS_COMPANY);
    // //业务员
    // query = new QueryItem();
    // query.setFields("real_name,superior_depart_name");
    // query.setWhere(Where.eq("id", record.get("sales_uid")));
    // saler= this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_USER);
    //
    // //请款时间
    // query = new QueryItem();
    // query.setFields("amount,create_time");
    // query.setWhere(Where.eq("loan_id", record.get("id")));
    // loanRequest= this.getOneByMap(query, SCModule.LOAN,
    // SCFunction.FUND_LOAN_REQUEST);
    // //放款情况
    // query = new QueryItem();
    // query.setFields("create_time");
    // query.setWhere(Where.eq("loan_id", record.get("id")));
    // loanRepay= this.getOneByMap(query, SCModule.LOAN,
    // SCFunction.FUND_LOAN_REPAY);
    // //还款情况
    // query = new QueryItem();
    // query.setFields(
    // "repay_time,principal,interest,repay_time_yes,amount_yes,overdue_fee,repay_type,principal_yes");
    // query.setWhere(Where.eq("loan_id", record.get("id")));
    // loanRepayPeriods= this.getListByMap(query, SCModule.LOAN,
    // SCFunction.FUND_LOAN_REPAYPERIOD);
    // if(loanRepayPeriods!=null&&loanRepayPeriods.size()>0){
    // for(Map item:loanRepayPeriods){
    // Date now=null;
    // if(item.get("repay_time_yes")!=null){
    // now=new Date(Long.parseLong(item.get("repay_time_yes").toString())*1000);
    // }else{
    // now=DateUtil.getCurrentDate();
    // }
    // //实际还款日/当前日期 -应还日期
    // Long repayTime=Long.parseLong(item.get("repay_time").toString());
    // int days=DateUtil.daysBetween(new Date(repayTime*1000),now);
    // if(days<=0){
    // days=0;
    // item.put("overdue_days", days+"天");
    // }else{
    // BigDecimal overdueFee=(BigDecimal)item.get("overdue_fee");
    // if(overdueFee.compareTo(BigDecimal.ZERO)<=0){
    // overdueFee = RepayUtil.calOverdueFeeAnyTime(
    // MapUtils.getString(record, "overdue_rate_value"),
    // (BigDecimal) item.get("principal"), (BigDecimal)
    // item.get("principal_yes"),
    // days);
    // }
    // item.put("overdue_days",
    // days+"天(逾期费:"+NumberUtils.format(overdueFee)+"元)");
    // }
    //
    // item.put("repay_time", DateUtil.dateFormat(item.get("repay_time")));
    // dataConvert(item, "repay_type:repay_period_status");
    // }
    // formData.put("loanRepayPeriods", loanRepayPeriods);
    // }
    // }
    // }
    // SystemInfo system = new
    // SystemInfo("backup/member/viewCreditRecord.html");
    // system.setSiteName("信贷详情");
    // view = this.initMemberPageView(system);
    // //催收记录
    // TableHeader tableHeader = new TableHeader();
    // tableHeader.setNames(new String[]{"id", "a","b","c"});
    // tableHeader.setTexts(new String[]{"ID", "催收时间","催收人","请款说明"});
    // tableHeader.setTypes(new String[]{"int","","", ""});
    // PageStructure data =
    // PageUtil.createTablePageStructure("member/customer/urgeData?creditRecordId="+record.get("id"),"id",
    // tableHeader,null,null);
    // view.addObject("data", JsonUtils.object2JsonString(data));
    //
    // formData.put("record", record);
    // formData.put("company", company);
    // formData.put("saler", saler);
    // formData.put("docs", new HashMap<>());
    // formData.put("loanRequest", loanRequest);
    // formData.put("loanRepay", loanRepay);
    //
    // view.addObject("formData", JsonUtils.object2JsonString(formData ));
    // } catch (Exception e) {
    // logger.error(e.getMessage(), e);
    // }
    // return view;
    //
    // }
	
	/**
	 * 催收记录 数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("customer/urgeData")
	public DyResponse deptDetailData(Integer page,Integer limit,Long creditRecordId) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setWhere(Where.in("status",creditRecordId));
		queryItem.setFields("id,create_time");
		
//		this.filterUserId(queryItem);
//		queryItem.setOrders("id desc");
//		this.getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
		Page recordPage=null;
		
		return createSuccessJsonResonse(recordPage);
	}
	
	/**
	 * 界面结构：授信用户
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="customer/add")
	public ModelAndView addCust() throws Exception {
		
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"id", "username", "company_name"});
			tableHeader.setTexts(new String[]{"ID", "业务员","企业名称"});
			tableHeader.setTypes(new String[]{"int","", ""});
			
			Map<String,Object> formData = Maps.newHashMap();
			formData.put("customerNum", 12);
			formData.put("checkingNum", 13);
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	/**
	 * 界面结构：选择新增授信类型
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="customer/jumpCustomerPage")
	public ModelAndView jumpCustomerNew(String custId) throws Exception {
		OrgFrontUser saler = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		ModelAndView view = new ModelAndView();
		try {
			QueryItem query = new QueryItem();
			query.setWhere(Where.eq("saler_id", saler.getId()));
			List<OrgFrontUser> custs = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
			
			SystemInfo system = new SystemInfo("backup/member/addCustTypeSelect.html");
			system.setSiteName("业务员列表");
			view = this.initMemberPageView(system);
			
			List<FormOption> opts = new ArrayList<FormOption>();
			for(OrgFrontUser u : custs){
				opts.add(new FormOption(u.getUsername(),u.getId()));
			}
			Map<String,Object> formData = Maps.newHashMap();
			formData.put("custList", opts);
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 界面结构：选择新增授信类型
	 * @param trust_customer 授信客户id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="customer/jumpOldCustomer")
	public ModelAndView jumpOldCustomer(String trust_customer) throws Exception {
		OrgFrontUser saler = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		ModelAndView view = new ModelAndView();
		try {
			QueryItem query = new QueryItem();
			query.setWhere(Where.eq("saler_id", saler.getId()));
			List<OrgFrontUser> custs = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
			
			SystemInfo system = new SystemInfo("backup/member/addCustTypeSelect.html");
			system.setSiteName("业务员列表");
			view = this.initMemberPageView(system);
			
			List<FormOption> opts = new ArrayList<FormOption>();
			for(OrgFrontUser u : custs){
				opts.add(new FormOption(u.getUsername(),u.getId()));
			}
			Map<String,Object> formData = Maps.newHashMap();
			formData.put("custList", opts);
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 获取授信用户列表
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="customer/customers")
	@ResponseBody
	public Map<String,Object> customerList(String keywords,Integer page,Integer limit) throws Exception {
		OrgFrontUser saler = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		try {
			QueryItem query = new QueryItem();
			query.setPage(page == null ? 1 : page);
			query.setLimit(limit == null ? 20 : limit);
//			query.setFields("id,username,real_name");
			
			List<Where> where = new ArrayList<Where>();
			addWhereCondition(where, "type", LIKE_ALL, AccountTypeEnum.CUSTUMER.getIndex());
			addWhereCondition(where, "saler_id", saler.getId());
			addWhereCondition(where, "status", GT, 0);
			addWhereCondition(where, "del_flag", 0);
			query.setWhere(where);
			List<OrgFrontUser> allusers = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
			if( StringUtils.isNotBlank(keywords)){
				addWhereCondition(where, "real_name", LIKE_ALL, keywords);
			}
			List<OrgFrontUser> custs = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
			
			Map<Long,String> opts = new HashMap<Long,String>();
			for(OrgFrontUser u : custs){
				opts.put(u.getId(),u.getRealName());
			}
			Map<String,Object> formData = Maps.newHashMap();
			formData.put("page", page == null ? 1 : page);
			formData.put("status", 200);
			formData.put("items", opts);
			formData.put("totalitems", allusers.size());
			return formData;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}
	
	/**
	 * 界面结构：增加授信客户界面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="customer/addCustomerPage")
	public ModelAndView addCustomerNew(String custId) throws Exception {
		
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo("backup/member/addNewCustomer.html");
			system.setSiteName("增加授信客户");
			system.setTitle("新增授信");
			view = this.initMemberPageView(system);
			
			
			Map<String,Object> formData = Maps.newHashMap();
			formData.put("repayTypeList", DictUtils.getOptions("repay_type"));
			formData.put("credTypeList", DictUtils.getOptions("cred_type"));
			List<SysDict> loanTypeList= DictUtils.getDictList("loan_type_");//先取表数据
			List<Option> loanTypeOptions=Lists.newArrayList();
			Map<String,String[]> loanTypeRelation=Maps.newHashMap();
			for(SysDict dict:loanTypeList){
				Option option=new Option(dict.getValue(), dict.getLabel());
				loanTypeOptions.add(option);
				String desc=dict.getDescription();
				if(StringUtils.isNoneBlank(desc)){
					loanTypeRelation.put(dict.getValue(),desc.split(","));
				}else{
					loanTypeRelation.put(dict.getValue(), new String[]{});
				}
			}
			formData.put("loanTypeRelation", loanTypeRelation);
			formData.put("loanTypeList", loanTypeOptions);
			List<Option> loanFeeTypeList=DictUtils.getOptions("loan_fee_type_");
			formData.put("loanFeeTypeList", loanFeeTypeList);//先取表数据
			if(loanFeeTypeList!=null&&loanFeeTypeList.size()>0){
				formData.put("loanFeeTypeListStatus", "1");//开启
			}else{
				formData.put("loanFeeTypeListStatus", "0");//关闭
			}
			
			List<Option> overdueFeeValueList=DictUtils.getOptions("overdue_fee_value");
			if(overdueFeeValueList!=null&&overdueFeeValueList.size()>0){
				formData.put("overdueFeeValue", overdueFeeValueList.get(0).getValue());
				formData.put("overdueFeeValueStatus", "1");//开启
			}else {
				formData.put("overdueFeeValueStatus", "0");//关闭
			}
			
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	private OrgFrontUser userIsExists(String param,String val) throws Exception{
		QueryItem query = new QueryItem();
		List<Where> where = new ArrayList<Where>();
		this.addWhereCondition(where, "username", val);
		this.addWhereCondition(where, "del_flag", 0);
		query.setWhere(where);
		
		OrgFrontUser u = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
		return u;
	}
	
	/**
	 * 获取数据：增加授信客户
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="customer/addCust")
	public DyResponse addCustomer(@RequestParam(value="contractStartTime1",required=false) String contractStartTime1,
			@RequestParam(value="contractEndTime1",required=false) String contractEndTime1,
			@RequestParam("imgs") String imgs,Company company,BussCreditRecord credictRecord) throws Exception {
//		OrgFrontUser saler = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
//		String docs = null;
//		if(StringUtils.isNotBlank(imgs)){
//			docs = this.checkDoc(imgs,UploadValidation.member_approve.getDocType());// 上传文档，返回文档关联id
//		}
//		if( credictRecord.getLoanAmount().compareTo(new BigDecimal(0)) <= 0 ){
//			return createErrorJsonResonse("借款金额必须大于0");	
//		}
//		company.setSalerId(saler.getId());
//		company.setSalerName(saler.getRealName());
//		company.setCompanyName(company.getCompanyName());
//		company.setSalerDepartment(saler.getSuperiorDepartName());
//		
//		//前台显示单位万元
//		credictRecord.setLoanAmount(credictRecord.getLoanAmount().multiply(new BigDecimal(10000)));
//	    credictRecord.setContractStartTime(DateUtil.convert(contractStartTime1));
//	    credictRecord.setContractEndTime(DateUtil.convert(contractEndTime1));
//	    credictRecord.setStatus(AccConstants.CREDIT_RECORD_STATUS_INIT_NEW);
//	    credictRecord.setDocId(docs);
//		if( StringUtils.isNotBlank(company.getCompanyLicense()) ){//新用户
//			OrgFrontUser u = this.userIsExists("username", company.getCompanyLicense());
//			if( u != null && u.getDelFlag() == 0 ){
//				return createErrorJsonResonse("统一社会信用号码已存在，不能新增，请重新输入");	
//			}
//			
//			OrgFrontUser customer = new OrgFrontUser();
//			customer.setUsername(company.getCompanyLicense());
//			customer.setPassword(SecurityUtil.md5(SecurityUtil.sha1("123")));
//			customer.setType(AccountTypeEnum.CUSTUMER.getIndex());
//			customer.setRealName(company.getCompanyName());
//			customer.setSalerId(saler.getId());
//			customer.setSalerName(saler.getRealName());
//			customer.setStatus(UserStatusEnum.DELETED.getIndex());//默认审核未通过
//			DyResponse resp = this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);
//			credictRecord.setCompanyId(resp.getId());
//			
//			customer.setCompanyId(resp.getId());
//			customer.setSuperiorDepart(saler.get);
//			customer.setSuperiorDepartName(saler.getSuperiorDepartName());
//			DyResponse res = this.insert(SCModule.SYSTEM, SCFunction.SYS_USER, customer);
//			credictRecord.setUserId(res.getId());
//		}
//		credictRecord.setSalesUid(saler.getId());
//		
//		// 发起流程
//		Map<String, Object> cond = Maps.newHashMap();
//		cond.put("cond1", String.valueOf(AccConstants.CREDIT_RECORD_STATUS_INIT_NEW));
//		cond.put("cond2", credictRecord.getCompanyName());
//		FlowProcInst procInst = this.startFlow(AccConstants.FLOW_DEF_XZSZ,credictRecord.getLoanContractNo(), credictRecord.getLoanDetail(),this.getRemoteIp(), cond );
//		
//		credictRecord.setProcInstId(procInst.getId());
//		credictRecord.setUpdateTime(DateUtil.getCurrentTime());
//		this.insert(SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, credictRecord);
//		
//		return createSuccessJsonResonse(null,"提交成功");
	    return null;
	}
	
	/**
	 * 界面结构：增加授信客户界面(已有)
	 * @param id 授信客户id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="customer/addOldCustomerPage")
	public ModelAndView addOldCustomerPage(String id) throws Exception {
		if( StringUtils.isBlank(id)){
			return this.createSuccessModelAndView(null, "错误");
		}
		ModelAndView view = new ModelAndView();
		try {
			QueryItem query1 = new QueryItem();
			query1.setWhere(Where.eq("id", id));
			OrgFrontUser cust = this.getOneByEntity(query1, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
			
			Company record = null;
			QueryItem query = new QueryItem();
			query.setWhere(Where.eq("id", cust.getCompanyId()));
			record = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
			
			SystemInfo system = new SystemInfo("backup/member/addOldCustomer.html");
			system.setSiteName("新增授信");
			system.setTitle("新增授信");
			view = this.initMemberPageView(system);
			
			
			List<SysDict> loanTypeList= DictUtils.getDictList("loan_type_");
			List<Option> loanTypeOptions=Lists.newArrayList();
			Map<String,String[]> loanTypeRelation=Maps.newHashMap();
			for(SysDict dict:loanTypeList){
				Option option=new Option(dict.getValue(), dict.getLabel());
				loanTypeOptions.add(option);
				String desc=dict.getDescription();
				if(StringUtils.isNoneBlank(desc)){
					loanTypeRelation.put(dict.getValue(),desc.split(","));
				}else{
					loanTypeRelation.put(dict.getValue(), new String[]{});
				}
			}
			Map<String,Object> formData = Maps.newHashMap();
			formData.put("loanTypeRelation", loanTypeRelation);
			formData.put("loanTypeList", loanTypeOptions);
			//借款手续费
			List<Option> loanFeeTypeList=DictUtils.getOptions("loan_fee_type_");
			formData.put("loanFeeTypeList", loanFeeTypeList);//先取表数据
			if(loanFeeTypeList!=null&&loanFeeTypeList.size()>0){
				formData.put("loanFeeTypeListStatus", "1");//开启
			}else{
				formData.put("loanFeeTypeListStatus", "0");//关闭
			}
			
			//逾期手续费
			List<Option> overdueFeeValueList=DictUtils.getOptions("overdue_fee_value");
			if(overdueFeeValueList!=null&&overdueFeeValueList.size()>0){
				formData.put("overdueFeeValue", overdueFeeValueList.get(0).getValue());
				formData.put("overdueFeeValueStatus", "1");//开启
			}else {
				formData.put("overdueFeeValueStatus", "0");//关闭
			}
			formData.put("repayTypeList", DictUtils.getOptions("repay_type"));
			List<Option> opts = DictUtils.getOptions("cred_type");
			Map<String,String> map = new HashMap<String,String>();
			for(Option opt : opts){
				map.put(opt.getValue().toString(), opt.getText());
			}
			record.setContactCardType(map.get(record.getContactCardType()));
			record.setLegalCardType(map.get(record.getLegalCardType()));
			record.setFinancialCardType(map.get(record.getFinancialCardType()));
			formData.put("record", record);
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	/**
	 * 界面结构：增加授信客户界面(已有)
	 * @param id 授信客户id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="customer/customerPage")
	public ModelAndView customerPage(String id) throws Exception {
		
		ModelAndView view = new ModelAndView();
		try {
			QueryItem query1 = new QueryItem();
			query1.setWhere(Where.eq("id", id));
			OrgFrontUser cust = this.getOneByEntity(query1, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
			
			Company record = null;
			QueryItem query = new QueryItem();
			query.setWhere(Where.eq("id", cust.getCompanyId()));
			record = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
			
			SystemInfo system = new SystemInfo("backup/member/customerInfo.html");
			system.setSiteName("新增授信");
			view = this.initMemberPageView(system);
			
			Map<String,Object> formData = Maps.newHashMap();
			formData.put("repayTypeList", DictUtils.getOptions("repay_type"));
			formData.put("loanTypeList", DictUtils.getOptions("loan_type"));
			formData.put("loanFeeTypeList", DictUtils.getOptions("loan_fee_type"));
			List<Option> opts = DictUtils.getOptions("cred_type");
			Map<String,String> map = new HashMap<String,String>();
			for(Option opt : opts){
				map.put(opt.getValue().toString(), opt.getText());
			}
			record.setContactCardType(map.get(record.getContactCardType()));
			record.setLegalCardType(map.get(record.getLegalCardType()));
			record.setFinancialCardType(map.get(record.getFinancialCardType()));
			formData.put("record", record);
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	/**
	 * 获取数据：增加授信客户(已有)
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="customer/addOldCust")
	public DyResponse addOldCustomer(@RequestParam(value="contractStartTime1",required=false) String contractStartTime1,
			@RequestParam(value="contractEndTime1",required=false) String contractEndTime1,String id,BussCreditRecord credictRecord) throws Exception {
		OrgFrontUser saler = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		
		QueryItem q = new QueryItem();
		q.setWhere(Where.eq("id", id));
		OrgFrontUser cus = this.getOneByEntity(q, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
		
		QueryItem query = new QueryItem();
		query.setWhere(Where.eq("id", cus.getCompanyId()));
		Company comp = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
		
		if( credictRecord.getLoanAmount().compareTo(new BigDecimal(0)) <= 0 ){
			return createErrorJsonResonse("借款金额必须大于0");	
		}
		
		//前台显示单位万元
		credictRecord.setLoanAmount(credictRecord.getLoanAmount().multiply(new BigDecimal(10000)));
		credictRecord.setCompanyId(comp.getId());
		credictRecord.setUserId(cus.getId());
		credictRecord.setCompanyName(comp.getCompanyName());
		credictRecord.setSalesUid(saler.getId());
		
		credictRecord.setContractStartTime(DateUtil.convert(contractStartTime1));
	    credictRecord.setContractEndTime(DateUtil.convert(contractEndTime1));
	    credictRecord.setStatus(AccConstants.CREDIT_RECORD_STATUS_INIT_OLD);
		
		Map<String, Object> cond = Maps.newHashMap();
		cond.put("cond1", String.valueOf(AccConstants.CREDIT_RECORD_STATUS_INIT_OLD));
		cond.put("cond2", credictRecord.getCompanyName());
		FlowProcInst procInst = workFlowUtil.startFlowPub(AccConstants.FLOW_DEF_LKHSX,credictRecord.getLoanContractNo(), credictRecord.getLoanDetail(),credictRecord.getCompanyId(), cond );
		
		credictRecord.setProcInstId(procInst.getId());
		credictRecord.setUpdateTime(DateUtil.getCurrentTime());
		this.insert(SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, credictRecord);
		
		return createSuccessJsonResonse(null,"提交成功");
	}
}