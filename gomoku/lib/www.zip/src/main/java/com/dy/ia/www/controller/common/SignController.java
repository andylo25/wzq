package com.dy.ia.www.controller.common;

import com.dy.core.adapter.AdapterManager;
import com.dy.core.adapter.FrontLoanAdapter;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.FDDUtils;
import com.dy.core.utils.JsonUtils;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

@Controller
@RequestMapping("/member/loan")
public class SignController extends FrontBaseController {
    @Autowired
    private FDDUtils utils;

    @RequestMapping("tmp/{businessType}")
    public ModelAndView tmpPage(Long id, Integer protocolType, String result_code, String download_url, String viewpdf_url,
                                @PathVariable("businessType") Integer businessType, Long protocolId, Long templateId) throws Exception {
        FrontLoanAdapter frontLoanAdapter = AdapterManager.getFrontLoanAdapter(businessType);
        if (frontLoanAdapter != null) {
            frontLoanAdapter.createPdfLink(id, protocolType, utils.fadadaOpen(), templateId);
        }
        DyResponse response = new DyResponse();
        response.setStatus(200);
        utils.notifySync(id, result_code, download_url, viewpdf_url, businessType, protocolId);
        return new ModelAndView("member/loan/tmp");
    }

    /**
     * 阅读并签署
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "readAndSign/{type}/{businessType}")
    public ModelAndView readAndSign(Long id, @PathVariable("type") Integer protocolType, @PathVariable("businessType") Integer businessType) throws Exception {
        if (!utils.fadadaOpen()) {
            Map<String, Object> formData = Maps.newHashMap();
            formData.put("id", id);
            formData.put("protocolType", protocolType);
            FrontLoanAdapter frontLoanAdapter = AdapterManager.getFrontLoanAdapter(businessType);
            String viewName = frontLoanAdapter.getSignView();
            return createSuccessModelAndView(viewName, JsonUtils.object2JsonString(formData));
        } else {
            DyResponse response = new DyResponse();
            response.setStatus(200);
            return new ModelAndView("member/loan/tmp");
        }
    }
}
