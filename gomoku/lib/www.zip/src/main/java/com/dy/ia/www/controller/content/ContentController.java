package com.dy.ia.www.controller.content;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PropertiesUtil;
import com.dy.ia.entity.common.SysSystemSitepage;
import com.dy.ia.entity.custom.Recommend;
import com.dy.sc.bussmodule.utils.SysSitepageUtil;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.content.CtArticles;
import com.dy.sc.entity.content.CtLinks;
import com.dy.sc.entity.content.CtNotice;

/**
 * 内容管理 
 * @author Administrator
 */

@Controller
@RequestMapping("/content")
public class ContentController extends FrontBaseController {
	
	protected Logger logger = Logger.getLogger(this.getClass());
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/page/getList")
	public ModelAndView getPageList(HttpServletRequest request) {
		ModelAndView view = new ModelAndView("content/page/page_list");
		try {
			Map<String,Object> param = (Map<String,Object>) request.getAttribute("page_param");
			if (param != null) {
				Long pid = (Long) param.get("pid");
				SysSystemSitepage pageContent = null;
				if (pid == 0) {
					pid = (Long) param.get("id");

					QueryItem queryItem = new QueryItem();
					queryItem.setFields("id,pid,name,router,title,description,contents,create_time");
					queryItem.getWhere().add(Where.eq("status", 1));
					queryItem.getWhere().add(Where.eq("pid", pid));
					queryItem.setOrders("sort_index asc");
					List<SysSystemSitepage> sitepageList = (List<SysSystemSitepage>) this.getListByEntity(queryItem,SCModule.SYSTEM, SCFunction.SYS_SITEPAGE, SysSystemSitepage.class);
					pageContent = (sitepageList != null && sitepageList.size() > 0) ? sitepageList.get(0) : null;
				} else {
					pageContent = this.getById((Serializable) param.get("id"), SCModule.SYSTEM, SCFunction.SYS_SITEPAGE,SysSystemSitepage.class);
				}

				SysSystemSitepage parentNav = this.getById(pid, SCModule.SYSTEM, SCFunction.SYS_SITEPAGE,SysSystemSitepage.class);
				List<SysSystemSitepage> subNavList = (List<SysSystemSitepage>) SysSitepageUtil.getSubNavList(pid);
				view.addObject("cur_nav", parentNav.getName());
				view.addObject("parent_nav", parentNav);
				view.addObject("sub_nav_list", subNavList);
				view.addObject("page_content", pageContent);
				initSystem(view, pageContent);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}

	private void initSystem(ModelAndView view, SysSystemSitepage pageContent) {
////		SystemInfo system = new SystemInfo();
////		system.setTitle(pageContent.getName());
////		system.setKeywords(pageContent.getKeywords());
////		system.setDescription(pageContent.getDescription());
////		system.setSiteName(PropertiesUtil.getProperty("diyou.siteName"));
////		view.addObject("system", system);
	}
	
	@ResponseBody
	@RequestMapping("/articles/index")
	public ModelAndView articleIndex(HttpServletRequest request) {
		Map<String,Object> param = (Map<String,Object>) request.getAttribute("page_param");
		Map<String, Object> data = getJumpPage(param);
		data.put("listUrl", "content/articles/listArticle");
		ModelAndView view = createSuccessModelAndView("content/article/article_list", JsonUtils.object2JsonString(data));
		view.addObject("cur_nav", data.remove("cur_nav"));
		initSystem(view, (SysSystemSitepage) data.remove("current"));
		return view;
	}
	
	public Map<String, Object> getJumpPage(Map<String, Object> param){
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			String site = (String) param.get("site");
			if (StringUtils.isNotBlank(site) && site.indexOf("/") >= 0) {
				SysSystemSitepage jumpPage = SysSitepageUtil.getSitePageByRouter(site);
				if (jumpPage != null) {
					Long pid = jumpPage.getPid();
					if (jumpPage.getPid() == 0) {
						pid = jumpPage.getId();
					}
					SysSystemSitepage parentNav =  this.getById(pid, SCModule.SYSTEM, SCFunction.SYS_SITEPAGE,SysSystemSitepage.class);
					
					List<SysSystemSitepage> subNavList = SysSitepageUtil.getSubNavList(pid);
					SysSystemSitepage currentMenu = null;
					if (jumpPage.getPid() == 0 && subNavList != null && subNavList.size() > 0) {
						currentMenu = subNavList.get(0);
					} else {
						currentMenu = this.getById(jumpPage.getId(), SCModule.SYSTEM, SCFunction.SYS_SITEPAGE,SysSystemSitepage.class);
					}
					
					result.put("cur_nav", parentNav.getName());
					result.put("menu_list", subNavList);
					result.put("current", currentMenu);
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return result;
	}
	
	/**
	 * 获取列表数据:文章列表
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("articles/listArticle")
	public DyResponse getListData(Integer page,Integer limit,String categoryId) throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("id,category_id,title,summary,create_time,author");
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 5 : limit);
		queryItem.getWhere().add(Where.eq("category_id", categoryId));
		queryItem.getWhere().add(Where.eq("status", 1));
		queryItem.setOrders("sort_index asc,create_time desc");
		Page data = (Page) this.getPageByEntity(queryItem, SCModule.CONTENT, SCFunction.ARTICLES, CtArticles.class);
		
		return createSuccessJsonResonse(data);
		
	}
	
	@RequestMapping("/articles/getDetail")
	public ModelAndView getArticleDetail(String id){
		ModelAndView view = createSuccessModelAndView("content/article/article_detail",null);
		try {
			if(StringUtils.isNotBlank(id)){
				//this.contentService.getCtArticle(Long.valueOf(id));
//				this.contentService.hitsArticles(Long.valueOf(id));
				QueryItem queryItem = new QueryItem(SCModule.CONTENT, SCFunction.ARTICLES);
				queryItem.setFields("id,category_id,title,summary,contents,create_time,author,hits");
				queryItem.getWhere().add(Where.eq("id", id));
				CtArticles articles = (CtArticles)super.getOne(queryItem, CtArticles.class);
				articles.setHits(articles.getHits()+1);
				this.update(SCModule.CONTENT, SCFunction.ARTICLES, articles);
				
				Long categoryId = articles.getCategoryId();
				SysSystemSitepage currentMenu = SysSitepageUtil.getSitePage(categoryId);
				SysSystemSitepage parentNav = SysSitepageUtil.getSitePage(currentMenu.getPid());
				List subNavList = SysSitepageUtil.getSubNavList(currentMenu.getPid());
				
				view.addObject("cur_nav", parentNav.getName());
				view.addObject("parent", parentNav);
				view.addObject("menu_list", subNavList);
				view.addObject("current", currentMenu);
				view.addObject("article_detail", articles);
				//返回url
				view.addObject("back_url",currentMenu.getRouter());
				view.addObject("createTime",DateUtil.dateTimeFormat(articles.getCreateTime()));
				
				initSystem(view, currentMenu);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		
		return view;
		
	}
	
	
	@ResponseBody
	@RequestMapping("/notice/index")
	public ModelAndView noticeIndex(HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo();
			system.setContentPage("content/notice/list.jsp");
			view = this.initPublicPageView(system);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	@ResponseBody
	@RequestMapping(value="/notice/list", method=RequestMethod.POST)
	public Page getNoticeList(HttpServletRequest request) {
		Page page = new Page();
		try {
			int pageNum = 1;
			String pageNumStr = request.getParameter("page");
			if (StringUtils.isNotBlank(pageNumStr)) {
				pageNum = Integer.valueOf(pageNumStr);
			}
			/*page.setPage(pageNum);
			page.setEpage(5);
			page.setParams(new CtNotice());*/
			
			QueryItem queryItem = new QueryItem();
			queryItem.setFields("id,title,summary,contents,create_time,sort_index,status");
			queryItem.setPage(pageNum);
			queryItem.setLimit(5);
			queryItem.setOrders("sort_index asc,create_time desc");
			queryItem.setWhere(Where.eq("status", 1));
			page = (Page) super.getPageByMap(queryItem, SCModule.CONTENT, SCFunction.CT_NOTICE);
			//page = this.contentService.getCtNoticeList(page);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return page;
	}
	@ResponseBody
	@RequestMapping("/notice/show")
	public ModelAndView getNoticeDetail(HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo();
			system.setContentPage("content/notice/show.jsp");
			view = this.initPublicPageView(system);
			view.addObject("system", system);

			String id = request.getParameter("id");
			if (StringUtils.isNotBlank(id)) {
				QueryItem queryItem = new QueryItem(SCModule.CONTENT, SCFunction.CT_NOTICE);
				queryItem.getWhere().add(Where.eq("id", Long.valueOf(id)));
				CtNotice notice = (CtNotice)super.getOne(queryItem, CtNotice.class);
				view.addObject("notice_content", notice);

			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	
	/**
	 * 常见问题
	 */
	@ResponseBody
	@RequestMapping(value="/articles/indexarticles", method=RequestMethod.POST)
	public DyResponse getIndexArticles() {
		List<Recommend> recommendList = new ArrayList<Recommend>();
		try {
			QueryItem queryItem = new QueryItem();
			queryItem.setFields("id,pid,name,router,type,description");
			queryItem.getWhere().add(Where.eq("status", 1));
			queryItem.getWhere().add(Where.eq("recommend", 1));
			queryItem.setOrders("sort_index asc");
			List<SysSystemSitepage> list = (List<SysSystemSitepage>) this.getListByEntity(queryItem,SCModule.CONTENT, SCFunction.SYS_SITEPAGE, SysSystemSitepage.class);
			if (list != null && list.size() > 0) {
				Recommend recommend = null;
				for (SysSystemSitepage sitepage : list) {
					recommend = new Recommend();
					recommend.setId(sitepage.getId());
					recommend.setName(sitepage.getName());
					recommend.setRouter(sitepage.getRouter());
					recommend.setAddTime(sitepage.getCreateTime());
					
					QueryItem pageQueryItem = new QueryItem("content", "articles");
					pageQueryItem.setLimit(5);
					pageQueryItem.setFields("id,category_id,title,summary,add_time,author,concat('" + PropertiesUtil.getImageHost()+ "'[c]thumbs) thumbs,contents");
					pageQueryItem.getWhere().add(Where.eq("status", 1));
					pageQueryItem.getWhere().add(Where.eq("category_id", sitepage.getId()));
					pageQueryItem.setOrders("sort_index asc,add_time desc");
					List<CtArticles> arList = (List<CtArticles>) super.getListByEntity(pageQueryItem,SCModule.CONTENT, SCFunction.ARTICLES, CtArticles.class);
					recommend.setArticleList(arList);
					//recommend.setArticleList(this.contentService.getArticlesByCategoryId(sitepage.getId()));

					recommendList.add(recommend);
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return createSuccessJsonResonse(recommendList);
	}
	
	/**
	 * 网站公告
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="/notice/noticeindex", method=RequestMethod.POST)
	public DyResponse getNotice() throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("id,title,summary,add_time");
		queryItem.getWhere().add(Where.eq("status", 1));
		queryItem.setOrders("sort_index asc,add_time desc");
		queryItem.setLimit(5);
		//List<CtNotice> list = (List<CtNotice>) super.getList(queryItem, CtNotice.class);
		//return createSuccessJsonResonse(this.contentService.getUserNoticeList());
		List<Map> list = this.getListByMap(queryItem, SCModule.CONTENT, SCFunction.CT_NOTICE);
		for(Map map : list){
			map.put("add_time", DateUtil.dateFormat(Long.valueOf(map.get("add_time").toString())));
		}
		try {
			return createSuccessJsonResonse(list);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return this.createErrorJsonResonse(e.getMessage());
		}
	}
	
	
	/**
	 * 友情链接
	 */
	@ResponseBody
	@RequestMapping(value="/friendslink", method=RequestMethod.POST)
	public DyResponse getFriendsLink() {
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("id,category_id,name,summary,jumpurl,logo");
		queryItem.getWhere().add(Where.eq("status", 1));
		queryItem.getWhere().add(Where.eq("category_id", 1));
		queryItem.setOrders("sort_index asc");
		try {
			List<CtLinks> ctLinkList = this.getListByEntity(queryItem, SCModule.CONTENT, SCFunction.CT_LINKS, CtLinks.class);
			return createSuccessJsonResonse(ctLinkList);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return this.createErrorJsonResonse(e.getMessage());
		}
	}
	
	/**
	 * 合作伙伴
	 */
	@ResponseBody
	@RequestMapping(value="/partners", method=RequestMethod.POST)
	public DyResponse getPartners() {
		QueryItem pQueryItem = new QueryItem();
		pQueryItem.setFields("id,category_id,name,summary,jumpurl,logo");
		pQueryItem.getWhere().add(Where.eq("status", 1));
		pQueryItem.getWhere().add(Where.eq("category_id", 2));
		pQueryItem.setOrders("sort_index asc");
		try {
			List<CtLinks> ctLinkList = this.getListByEntity(pQueryItem, SCModule.CONTENT, SCFunction.CT_LINKS, CtLinks.class);
			return createSuccessJsonResonse(ctLinkList);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return this.createErrorJsonResonse(e.getMessage());
		}
	}
	
}