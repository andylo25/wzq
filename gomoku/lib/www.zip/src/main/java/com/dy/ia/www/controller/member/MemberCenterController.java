package com.dy.ia.www.controller.member;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DyStringUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.BussLoanRepay;
import com.dy.ia.entity.common.CreLimitInfo;
import com.dy.ia.entity.enumeration.AccountTypeEnum;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Maps;
/**
 * 会员中心
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/member")
public class MemberCenterController extends FrontBaseController {
	
	/**
	 * 设置日期转换格式
	 */
	@Override
	protected DateFormatType getDateFormatType() {
		return DateFormatType.DATE;
	}
	
	/**
	 * 用户中心
	 * @return
	 */
	@RequestMapping("/member/center")
	public ModelAndView toMemberCenter(Model model,Integer user_role) throws Exception{
		ModelAndView view = new ModelAndView();
		String page = "backup/member/center/center_tender_cust.html";
		OrgFrontUser user = this.getUser();
		int accountType = user.getType();//用户角色;
		Map<String,Object> formData = Maps.newHashMap();
		buildFormData(formData,accountType);
		if( AccountTypeEnum.DEPARTMENT.getIndex() == accountType){
			page = "backup/member/center/center_tender_dept.html";
		}else if(AccountTypeEnum.SALER.getIndex() == accountType){
			page = "backup/member/center/center_tender_saler.html";
		}
		SystemInfo system = new SystemInfo(page);
		system.setSiteName("账户中心");
		view = this.initMemberPageView(system);
		view.addObject("formData",JsonUtils.object2JsonString(formData));
		return view;
	}
	
	private void buildFormData(Map<String, Object> formData, int accountType) throws Exception {
		if( AccountTypeEnum.DEPARTMENT.getIndex() == accountType){
			QueryItem queryItem = new QueryItem(Where.eq("user_id", getUserId()));
			queryItem.setFields("temp_limit as tempLimit,avail_limit as availLimit,pay_limit as payLimit");
			CreLimitInfo creLimitInfo = this.getOneByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
			formData.put("availLimit", creLimitInfo.getAvailLimit());
			formData.put("tempLimit", creLimitInfo.getTempLimit());
			
			// 本月已放
			queryItem = new QueryItem(Where.in("sales_uid", getSalesId()));
			queryItem.setWhere(this.addAndWhereCondition(null, "pass_time", DateUtil.getMonthFirstDay(DateUtil.getTxnDate()), DateUtil.getCurrentDate()));
			queryItem.setFields("sum(loan_amount) as monthPayLimit");
			Map<String, Object> monthPayLimit = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
			if(monthPayLimit != null){
				formData.put("monthPayLimit", monthPayLimit.get("monthPayLimit"));
			}else{
				formData.put("monthPayLimit", 0);
			}
			
			// 授信客户
			queryItem = new QueryItem(Where.eq("superior_depart", getUserId()));
			queryItem.setWhere(Where.eq("del_flag", 0));
			queryItem.setWhere(Where.eq("type", AccountTypeEnum.CUSTUMER.getIndex()));
			queryItem.setFields("count(id) as custCount");
			Map<String, Object> custCount = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER);
			formData.put("custCount", custCount.get("custCount"));
			
			List<String> salesId = getSalesId();
			// 最近待回款<=7
			queryItem = new QueryItem(Where.eq("status", AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT));
			queryItem.setWhere(Where.in("sales_uid", StringUtils.join(salesId,",")));
			queryItem.setWhere(this.addAndWhereCondition(null, "contract_end_time", DateUtil.getCurrentDate(), DateUtil.addDay(new Date(), 7)));
			queryItem.setFields("count(id) as repayCount");
			Map<String, Object> repayCount = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
			formData.put("repayCount", repayCount.get("repayCount"));
			
			// 逾期未回款
			queryItem = new QueryItem(Where.eq("status", AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT));
			queryItem.setWhere(Where.in("sales_uid", StringUtils.join(salesId,",")));
			queryItem.setWhere(Where.lt("contract_end_time",DateUtil.convert(DateUtil.getCurrentDate())));
			queryItem.setFields("count(id) as overdueCount");
			Map<String, Object> overdueCount = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
			formData.put("overdueCount", overdueCount.get("overdueCount"));
			
		}else if(AccountTypeEnum.SALER.getIndex() == accountType){
			// 本月已放
			QueryItem queryItem = new QueryItem(Where.eq("sales_uid", getUserId()));
			queryItem.setWhere(this.addAndWhereCondition(null, "pass_time", DateUtil.getMonthFirstDay(DateUtil.getTxnDate()), DateUtil.getCurrentDate()));
			queryItem.setFields("sum(loan_amount) as monthAmount");
			Map<String, Object> monthAmount = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
			if(monthAmount != null){
				formData.put("monthAmount", monthAmount.get("monthAmount"));
			}else{
				formData.put("monthAmount", 0);
			}
			
			// 授信客户
			queryItem = new QueryItem(Where.eq("saler_id", getUserId()));
			queryItem.setWhere(Where.eq("del_flag", 0));
			queryItem.setFields("count(id) as custCount");
			Map<String, Object> custCount = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER);
			formData.put("custCount", custCount.get("custCount"));
			
			// 请款中
			queryItem = new QueryItem(Where.eq("status", AccConstants.CREDIT_RECORD_STATUS_REQUEST_PAY));
			queryItem.setWhere(Where.eq("sales_uid", getUserId()));
			queryItem.setFields("count(id) as loanCount");
			Map<String, Object> loanCount = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
			formData.put("loanCount", loanCount.get("loanCount"));
			
			// 待回款
			queryItem = new QueryItem(Where.eq("status", AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT));
			queryItem.setWhere(this.addAndWhereCondition(null, "contract_end_time", DateUtil.getCurrentDate(), DateUtil.addDay(new Date(), 7)));
			queryItem.setWhere(Where.eq("sales_uid", getUserId()));
			queryItem.setFields("count(id) as repayCount");
			Map<String, Object> repayCount = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
			formData.put("repayCount", repayCount.get("repayCount"));
			
			// 逾期未回款
			queryItem = new QueryItem(Where.eq("status", AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT));
			queryItem.setWhere(Where.eq("sales_uid", getUserId()));
			queryItem.setWhere(Where.lt("contract_end_time",DateUtil.convert(DateUtil.getCurrentDate())));
			queryItem.setFields("count(id) as overdueCount");
			Map<String, Object> overdueCount = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
			formData.put("overdueCount", overdueCount.get("overdueCount"));
			
		}else if(AccountTypeEnum.CUSTUMER.getIndex() == accountType){
			AccAccount accAccount = BaseInfoUtils.getCompAccountEntity(getUser().getCompanyId());
			if(accAccount != null && accAccount.getAccount() != null){
				accAccount.setAccount(DyStringUtils.desensitiz(accAccount.getAccount()));
			}
			formData.put("acc", accAccount);
			
			QueryItem queryItem = new QueryItem(Where.eq("user_id", getUserId()));
			queryItem.setWhere(Where.eq("status", "-1"));//未还完的数据
			queryItem.setFields("sum(principal_total) as principalTotal,sum(amount_total-amount_yes) as amountTotal,sum(interest_total-interest_yes) as interestTotal");
			BussLoanRepay loanRepay = this.getOneByEntity(queryItem, SCModule.LOAN, SCFunction.FUND_LOAN_REPAY, BussLoanRepay.class);
			if(loanRepay == null){
				loanRepay = new BussLoanRepay();
				loanRepay.setPrincipalTotal(BigDecimal.ZERO);
				loanRepay.setAmountTotal(BigDecimal.ZERO);
				loanRepay.setInterestTotal(BigDecimal.ZERO);
			}
			formData.put("loan", loanRepay);
		}
		OrgFrontUser userInfo = getUser();
		formData.put("user", userInfo );
	}
	
	/**
	 * 首页待跟踪授信跟踪界面渲染
	 * @param type 0部门，1业务员
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/buss/toTrace")
	public DyResponse getBussToTrace() throws Exception {
		TableHeader tableHeader = new TableHeader();
		OrgFrontUser user = this.getUser();
		int accountType = user.getType();//用户角色;
		if( AccountTypeEnum.DEPARTMENT.getIndex() == accountType){
			tableHeader.setNames(new String[]{"loan_contract_no_link_","company_name_ren_", "loan_amount","contract_time","saler","status"});
			tableHeader.setTexts(new String[]{"信贷信息", "授信企业", "申贷金额(万元)", "周期", "业务员", "状态"});
			tableHeader.setTypes(new String[]{"html", "html", "", "","", "", ""});
		}else if(AccountTypeEnum.SALER.getIndex() == accountType){
			tableHeader.setNames(new String[]{"loan_contract_no_link_","company_name_ren_", "loan_amount","contract_time","status","action"});
			tableHeader.setTexts(new String[]{"信贷信息", "授信企业", "申贷金额(万元)", "周期", "状态","操作"});
			tableHeader.setTypes(new String[]{"html", "html", "", "","","confirm1"});
		}
		
		PageStructure structure = PageUtil.createTablePageStructure("member/buss/toTraceData", "member/customer/viewCreditRecord","id", tableHeader, null, null);
		structure.setRightUrl1("saler/creditRequest/submit");
		return createSuccessJsonResonse(structure);

	}
	/**
	 * 首页待跟踪授信跟踪列表
	 * @param current_page
	 * @param member_name
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/buss/toTraceData")
	public DyResponse getBussToTraceData() throws Exception {
		//复核中
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(1);
		queryItem.setLimit(10);
		queryItem.setWhere(Where.in("status","0,2,3,4,8"));
		OrgFrontUser user = this.getUser();
		int accountType = user.getType();//用户角色;
		if( AccountTypeEnum.DEPARTMENT.getIndex() == accountType){
			queryItem.setFields("id,loan_contract_no,company_id,loan_amount/10000 as loan_amount,loan_apr,loan_repay_type,contract_start_time,contract_end_time,sales_uid,status");
			List<String> salesId = getSalesId();
			queryItem.setWhere(Where.in("sales_uid", StringUtils.join(salesId,",")));
		}else if( AccountTypeEnum.SALER.getIndex() == accountType){
			queryItem.setFields("id,loan_contract_no,company_id,loan_amount/10000 as loan_amount,loan_apr,loan_repay_type,contract_start_time,contract_end_time,status");
			queryItem.setWhere(Where.eq("sales_uid", getUserId()));
		}
		queryItem.setOrders("status");
		Page recordPage=this.getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
		List<Map> data=recordPage.getItems();
		if(data!=null&& data.size()>0){
	    	for (Map map : data) {
	    		String start_time=DateUtil.dateFormatSlash(Long.valueOf(map.get("contract_start_time").toString()));
	    		String end_time=DateUtil.dateFormatSlash(Long.valueOf(map.get("contract_end_time").toString()));
	    		map.put("contract_time", start_time+"-"+end_time);
	    		if(AccConstants.CREDIT_RECORD_STATUS_CUSTOMER_CHECKED == (Integer)map.get("status")){
    				map.put("action","请款");
    			}
	 		}
	    }
		if( AccountTypeEnum.DEPARTMENT.getIndex() == accountType){
			this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_USER, "sales_uid:real_name as saler");
		}
		this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name,company_license");
		List<Map> data1 = new ArrayList<Map>();
		for(Map tmp : data){
			if( (int)tmp.get("status") != 2 &&  (int)tmp.get("status") != 0){
				data1.add(tmp);
			}
		}
		for(Map tmp : data){
			if( (int)tmp.get("status") == 2 ){
				data1.add(tmp);
			}
		}
		recordPage.setItems(data1);
		return createSuccessJsonResonse(dataConvert(recordPage,"status:credit_record_status,loan_repay_type:repay_type"));
	}
	
	/**
	 * 首页最近待回款界面渲染
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/buss/toRecover")
	public DyResponse getBussToRecover() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"company_name_link_", "loan_amount", "loan_amount","contract_end_time","last_days","status"});
		tableHeader.setTexts(new String[]{"授信企业", "授信金额", "应还总额", "应还日期", "剩余时间", "状态"});
		tableHeader.setTypes(new String[]{"html", "", "","", "", ""});
		
		PageStructure structure = PageUtil.createTablePageStructure("member/buss/toRecoverData","member/customer/viewCreditRecord", "id", tableHeader, null, null);
		return createSuccessJsonResonse(structure);
		
	}
	/**
	 * 首页最近待回款列表
	 * @param current_page
	 * @param member_name
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/buss/toRecoverData")
	public DyResponse getBussToRecoverData() throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(1);
		queryItem.setLimit(7);
		queryItem.setWhere(Where.in("status",AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT));
		queryItem.setFields("id,loan_contract_no,company_name,loan_amount,contract_start_time,contract_end_time,status");
		queryItem.setWhere(this.addAndWhereCondition(null, "contract_end_time", DateUtil.getCurrentDate(), DateUtil.addDay(new Date(), 7)));
		
		Integer type = getUser().getType();
		if(AccountTypeEnum.DEPARTMENT.getIndex() == type){
			queryItem.setWhere(Where.in("sales_uid", StringUtils.join(getSalesId(),",")));
		}else if(AccountTypeEnum.SALER.getIndex() == type){
			queryItem.setWhere(Where.eq("sales_uid", getUserId()));
		}else {
			return createSuccessJsonResonse(null);
		}
		queryItem.setOrders("id desc");
		Page recordPage=this.getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
		List<Map> data=recordPage.getItems();
		if(data!=null&& data.size()>0){
	    	for (Map map : data) {
	    		Date end_time=new Date((Integer) map.get("contract_end_time")*1000L);
	    		map.put("last_days", DateUtil.daysBetween(new Date(),end_time )+"天");
	 		}
	    }
		return createSuccessJsonResonse(dataConvert(recordPage,"status:credit_record_status","contract_end_time"));
	}
	
	/**
	 * 首页逾期待回款界面渲染
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/buss/overdueToRecover")
	public DyResponse getBussOverdueToRecover() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"company_name_link_", "loan_amount", "loan_amount","contract_end_time","overdue_days","status"});
		tableHeader.setTexts(new String[]{"授信企业", "授信金额", "应还总额", "应还日期", "逾期天数", "状态"});
		tableHeader.setTypes(new String[]{"html", "", "","", "",""});
		
		PageStructure structure = PageUtil.createTablePageStructure("member/buss/overdueToRecoverData","member/customer/viewCreditRecord", "id", tableHeader, null, null);
		return createSuccessJsonResonse(structure);
		
	}
	/**
	 * 首页逾期待回款列表
	 * @param current_page
	 * @param member_name
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/buss/overdueToRecoverData")
	public DyResponse getBussOverdueToRecoverData() throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(1);
		queryItem.setLimit(7);
		queryItem.setWhere(Where.in("status",AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT));
		queryItem.setWhere(Where.lt("contract_end_time",DateUtil.convert(DateUtil.getCurrentDate())));
		queryItem.setFields("id,loan_contract_no,company_name,loan_amount,contract_end_time,status");
		
		Integer type = getUser().getType();
		if(AccountTypeEnum.DEPARTMENT.getIndex() == type){
			queryItem.setWhere(Where.in("sales_uid", StringUtils.join(getSalesId(),",")));
		}else if(AccountTypeEnum.SALER.getIndex() == type){
			queryItem.setWhere(Where.eq("sales_uid", getUserId()));
		}else {
			return createSuccessJsonResonse(null);
		}
		queryItem.setOrders("id desc");
		Page recordPage=this.getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
		List<Map> data=recordPage.getItems();
		if(data!=null&& data.size()>0){
	    	for (Map map : data) {
	    		Date end_time=new Date((Integer) map.get("contract_end_time")*1000L);
	    		map.put("overdue_days", DateUtil.daysBetween(end_time,new Date() )+"天");
	    		map.put("status", "逾期回款中");
	 		}
	    }
		return createSuccessJsonResonse(dataConvert(recordPage,null,"contract_end_time"));
	}
	
	/**
	 * 首页最近还款界面渲染
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/buss/lastrepay")
	public DyResponse getBussLastRepay() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"loan_contract_no", "principal", "repay_time","interest","amount","overdue_days","action"});
		tableHeader.setTexts(new String[]{"借款合同号", "授信金额", "应还款日期", "应还利息", "应还本息","逾期天数","操作"});
		tableHeader.setTypes(new String[]{"", "", "date","", "","", "openwin"});
		
		PageStructure structure = PageUtil.createTablePageStructure("member/buss/lastrepayData", "id", tableHeader, null, null);
		structure.setRightUrl("customer/loan/repayInfoView");
		return createSuccessJsonResonse(structure);
		
	}
	/**
	 * 首页最近还款列表
	 * @param current_page
	 * @param member_name
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="/buss/lastrepayData")
	public DyResponse getBussLastRepayData() throws Exception {
		
		QueryItem item = new QueryItem();
		item.setPage(1);
		item.setLimit(10);
		List<Where> whereList = new ArrayList<Where>();
		addWhereCondition(whereList, "user_id",getUserId());
		addWhereCondition(whereList, "repay_type","5");
		this.addAndWhereCondition(whereList, "repay_time", DateUtil.getCurrentDate(), DateUtil.addDay(new Date(), 7));
		item.setOrders("repay_time desc");
		item.setWhere(whereList);
		Page pageObj = (Page) this.dataConvert(this.getPageByMap(item,SCModule.LOAN,SCFunction.FUND_LOAN_REPAYPERIOD));
		List<Map<String,Object>> periodLogList = pageObj.getItems();	
		for(Map map:periodLogList){
			int overdue_days=DateUtil.daysBetween(DateUtil.dateParse(DateUtil.getCurrentTime()), DateUtil.dateParse(Long.valueOf(map.get("repay_time").toString())));		
			if(overdue_days<0){
				map.put("overdue_days",Math.abs(overdue_days));
			}
			else{
				map.put("overdue_days", 0);
			}
			map.put("action", "还款");
		}
		pageObj.setItems(periodLogList);
		return createSuccessJsonResonse(pageObj);
	}

	/**
	 * 上传头像页面
	 */
	@RequestMapping("/member/avatar")
	public ModelAndView avatar() {
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo("backup/member/center/avatar.jsp");
			view = this.initDialogPageView(system);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	
}
