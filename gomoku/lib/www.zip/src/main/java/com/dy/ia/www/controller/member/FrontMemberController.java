package com.dy.ia.www.controller.member;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.enumeration.AccountTypeEnum;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.CompanyRoleType;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.www.entity.Menu;
import com.dy.sc.www.entity.SubMenu;
import com.google.common.collect.Maps;

/**
 * 用户管理
 * @author Administrator
 * 
 */
@Controller
@RequestMapping("/member")
public class FrontMemberController extends FrontBaseController {
	
	@RequestMapping("/login")
	public ModelAndView loninIndex() {
		ModelAndView view = new ModelAndView();
		try {
			if(this.getSessionAttribute(Constant.SESSION_USER) == null)  {
			    view.setViewName("login/login");
			    return view;
			} else {
				if(CompanyRoleType.COMPANY_CORE.getIndex()==getUser().getType()){
					return new ModelAndView("redirect:/member/core/companyInfo");
				}else{
					return new ModelAndView("redirect:/member/manager/companyDetail");
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}

	@RequestMapping("/reg")
	public ModelAndView regiserIndex() {
		ModelAndView view = new ModelAndView();
		try {
			SystemInfo system = new SystemInfo();
			system.setContentPage("backup/member/reg.jsp");
			system.setSiteName("用户注册");
			view = this.initSystemPageView(system);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 退出
	 * @return
	 */
	@RequestMapping("/member/logout")
	public ModelAndView logout() {
		//销毁session
		this.removeSessionAttribute(Constant.SESSION_USER);
		this.removeSessionAttribute("member_info");
		
		//Shiro销毁
		Subject subject = SecurityUtils.getSubject(); 
		subject.logout();
		
		return new ModelAndView("redirect:/member/login");
	}

	
	/**
	 * 左侧菜单
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/member/leftMenu", method=RequestMethod.POST)
	public DyResponse getMemberLeftMenu() throws Exception {
		OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
		int accountType = user.getType();//用户角色
		return createSuccessJsonResonse(generateMemberMenu(accountType));
	}
	
	/**
	 * 业务管理
	 * @return
	 * @throws Exception
	 */
//	@ResponseBody
//	@RequestMapping(value="/member/salerManager")
//	public ModelAndView getSalerManager() throws Exception {
//		return createSuccessModelAndView("member/salerManager",null);
//	}
	
	/**
	 * 界面结构：业务员记录
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="saler/salerManager")
	public ModelAndView salerManager(Integer page,Integer limit,String search) throws Exception {
		
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"id", "real_name", "create_time"});
			tableHeader.setTexts(new String[]{"ID", "业务员","通过时间"});
			tableHeader.setTypes(new String[]{"int","", ""});
			
			PageStructure data = PageUtil.createTablePageStructure("member/saler/salerData", "id", tableHeader,null,null);
			
			SystemInfo system = new SystemInfo("backup/member/salerManager.html");
			system.setSiteName("业务员列表");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	/**
	 * 获取数据：业务员列表
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="saler/salerData")
	public DyResponse salerData(Integer page,Integer limit,String customerName,@RequestParam(value="start_time",required=false) String startDate,@RequestParam(value="end_time",required=false) String endDate) throws Exception {
		OrgFrontUser user = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setFields("id,real_name,create_time");
		List<Where> w = new ArrayList<Where>();
		addWhereCondition( w, "type", AccountTypeEnum.SALER.getIndex());
		addWhereCondition( w, "superior_depart", user.getId());
		if( StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate) ){ 
		    Date date = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
			addAndWhereCondition( w, "create_time", startDate, date);
		}
		if(StringUtils.isNotBlank(customerName)){
			addWhereCondition( w, "real_name",LIKE_ALL, "%"+StringUtils.trim(customerName)+"%");
		}
		queryItem.setOrders("id desc");
		queryItem.setWhere(w);
		
		Object data = dataConvert(getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER),"action_type:cus_cre_action_type","create_time");
		return createSuccessJsonResonse(data);
	}
	
	/**
	 * 界面结构：授信用户
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="customer/customerManager")
	public ModelAndView customerManager(Integer page,Integer limit,String search) throws Exception {
		OrgFrontUser user = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			SystemInfo system = null;
			if( user.getType() == AccountTypeEnum.SALER.getIndex() ){
				tableHeader.setNames(new String[]{"username", "company_name", "create_time", "pass_time", "action"});
				tableHeader.setTexts(new String[]{"用户名","企业名称", "申请时间", "通过时间", "操作"});
				tableHeader.setTypes(new String[]{"link1", "", "int", "int", "link"});
			}else{
				tableHeader.setNames(new String[]{"username", "company_name", "real_name", "create_time", "pass_time"});
				tableHeader.setTexts(new String[]{"用户名","企业名称", "所属业务员", "申请时间", "通过时间"});
				tableHeader.setTypes(new String[]{"link", "", "", "int", "int"});
			}
			
			PageStructure data = PageUtil.createTablePageStructure("member/customer/customerData", "id", tableHeader,null,null);
			if( user.getType() == AccountTypeEnum.SALER.getIndex() ){
				data.setRightUrl1("member/customer/customerPage");
				data.setRightUrl("member/customer/addOldCustomerPage");
				system = new SystemInfo("backup/member/customerManager.html");
			}else{
				data.setRightUrl("member/customer/customerPage");
				system = new SystemInfo("backup/member/departmentCustomerManager.html");
			}
			
			system.setSiteName("授信客户列表");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			
			Map<String,Object> formData = Maps.newHashMap();
			QueryItem query = new QueryItem();
			List<Where> where = new ArrayList<Where>();
			this.addWhereCondition(where, "type", AccountTypeEnum.CUSTUMER.getIndex());
			this.addWhereCondition(where, "del_flag", 0);
			if( user.getType() == AccountTypeEnum.SALER.getIndex() ){//业务员登录
				this.addWhereCondition(where, "saler_id", user.getId());
				query.setWhere(where);
			}else{//部门登录
				this.addWhereCondition(where, "superior_depart", user.getId());
//				this.addWhereCondition(where, "saler_id", user.getId());
				query.setWhere(where);
				
				//查询该部门下的所有业务员
				QueryItem q = new QueryItem();
				List<Where> w = new ArrayList<Where>();
				this.addWhereCondition(w, "type", AccountTypeEnum.SALER.getIndex());
				this.addWhereCondition(w, "superior_depart", user.getId());
				q.setWhere(w);
				List<OrgFrontUser> users = this.getListByEntity(q, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
				List<Option> opts = new ArrayList<Option>();
				for( OrgFrontUser u : users ){
					Option opt = new Option();
					opt.setText(u.getRealName());
					opt.setValue(u.getId());
					opts.add(opt);
				}
				formData.put("salerList", opts);
			}
			List<OrgFrontUser> list = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
//			if( user.getType() == AccountTypeEnum.DEPARTMENT.getIndex() ){
//				List<User> tmp = new ArrayList<User>();
//				for(User c : list){
//					QueryItem q = new QueryItem();
//					List<Where> w = new ArrayList<Where>();
//					this.addWhereCondition(w, "id", c.getSalerId());
//					this.addWhereCondition(w, "del_flag", 0);
//					this.addWhereCondition(w, "type", AccountTypeEnum.SALER.getIndex());
//					q.setWhere(w);
//					User saler = this.getOneByEntity(q, SCModule.SYSTEM, SCFunction.SYS_USER, User.class);
//					
//					if( saler.getSuperiorDepart().equals(user.getId()) ){
//						tmp.add(c);
//					}
//				}
//				list = tmp;
//			}
			
			int checkingNum = 0;
			List<Long> comList = list.stream().map(OrgFrontUser::getCompanyId).collect(Collectors.toList());
			QueryItem q = new QueryItem();
			q.setWhere(Where.in("id", comList));
			q.setWhere(Where.eq("status", -1));
			q.setFields("count(id) as checkingNum");
			Map<String, Object> company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
			checkingNum = ((Long) company.get("checkingNum")).intValue();
			
			formData.put("customerNum", list.size() - checkingNum);
			formData.put("checkingNum", checkingNum);
			view.addObject("formData", JsonUtils.object2JsonString(formData ));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
		
	}
	
	/**
	 * 获取数据：授信用户列表
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="customer/customerData")
	public DyResponse customerData(Integer page,Integer limit,String salerId,String customerName,@RequestParam(value="start_time",required=false) String startDate,@RequestParam(value="end_time",required=false) String endDate) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		limit = (limit == null ? 10 : limit);
		queryItem.setLimit(limit == null ? 10 : limit);
		queryItem.setFields("id,username,company_id,create_time,saler_id");
		List<Where> w = new ArrayList<Where>();
		
		OrgFrontUser user = (OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		if( user.getType() == AccountTypeEnum.SALER.getIndex() ){//业务员用户
			this.addWhereCondition(w, "saler_id", user.getId());
		}else{//部门
			this.addWhereCondition(w, "superior_depart", user.getId());
		}
		
		if( StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate) ){ 
		    Date date = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
		    Calendar cal = Calendar.getInstance();
		    cal.setTime(date);
		    cal.add(Calendar.DATE, 1);
		    if( AccountTypeEnum.DEPARTMENT.getIndex() == user.getType() ){
//		    	addAndWhereCondition( w, "pass_time", startDate, cal.getTime());
		    }else{//业务员
		    	addAndWhereCondition( w, "create_time", startDate, cal.getTime());
		    }
		}
		if(StringUtils.isNotBlank(salerId)){
			addWhereCondition( w, "saler_id",LIKE_ALL, "%"+StringUtils.trim(salerId)+"%");
		}
		if(StringUtils.isNotBlank(customerName)){
			addWhereCondition( w, "username",LIKE_ALL, "%"+StringUtils.trim(customerName)+"%");
		}
		addWhereCondition( w, "type", AccountTypeEnum.CUSTUMER.getIndex());
		this.addWhereCondition(w, "del_flag", 0);
		queryItem.setOrders("id desc");
		queryItem.setWhere(w);
		Page<Map> rlt = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER);
		List<Map> items = rlt.getItems();
		List<Map> r = new ArrayList<Map>();
		
		this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name,create_time,status,pass_time");
		if( user.getType() == AccountTypeEnum.DEPARTMENT.getIndex() ){
			this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_USER, "saler_id:real_name");
		}
		
		List<Map> bmsCustomer = new ArrayList<Map>();
		for( Map<String,Object> item : items ){
			if( Integer.parseInt(item.get("status").toString()) != -1 && user.getType() == AccountTypeEnum.SALER.getIndex() ){
				item.put("action", "申请授信");
			}
		}
		
		if( StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			this.filterCrossTable(rlt, "pass_time", startDate, endDate, page, limit);
		}
		
		Object data = dataConvert(rlt,"action_type:cus_cre_action_type","create_time,pass_time");
		return createSuccessJsonResonse(data);
	}
	
	private void filterCrossTable(Page<Map> data,String col,String startDate,String endDate,Integer page,Integer limit){
		List<Map> tmpItems = new ArrayList();
		Integer totalItems = 0;
		for(Map item : data.getItems()){
			if( item.get(col) == null ){
				continue;
			}
			Long pas = Long.parseLong(item.get(col).toString());
			Date tmp = DateUtil.dateParse(pas);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			String passTime = df.format(tmp);
			int x = compare_date(startDate,passTime);
			int y = compare_date(endDate,passTime);
			if( ((compare_date(startDate,passTime) <= 0) && (compare_date(endDate,passTime) >= 0)) ){
				tmpItems.add(item);
				totalItems ++;
			}
		}
		
		Integer totalPage = (totalItems  +  limit  - 1) / limit;
		
		List<Map> rltItems = new ArrayList();
		Integer startIndex = limit * (page - 1);
		Integer endIndex = limit * page > totalItems ? totalItems : (limit * page - 1);
		for(Integer index = 0;index < tmpItems.size();index ++){
			Map item = tmpItems.get(index);
			if( index >= startIndex && index <= endIndex ){
				rltItems.add(item);
			}
		}
		
		data.setEpage(limit);
		data.setPage(page);
		data.setItems(rltItems);
		data.setTotal_items(totalItems);
		data.setTotal_pages(totalPage);
	}
	
	public int compare_date(String DATE1, String DATE2) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date dt1 = df.parse(DATE1);
            Date dt2 = df.parse(DATE2);
            if (dt1.getTime() > dt2.getTime()) {
                return 1;
            } else if (dt1.getTime() < dt2.getTime()) {
                return -1;
            } else {
                return 0;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0;
    }
	
	/**
	 * 获取菜单树数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/member/listSaler")
	public DyResponse getAdminListData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.like("role_name", "%"+search+"%"));
		}
		queryItem.setOrders("id");
		
		return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER)));
	}
	
	/**
	 * 生成用户中心菜单
	 * @param isLoanAccount 是否借款账户
	 * @param isGroup 是否企业用户
	 * @return
	 */
	private List<Menu> generateMemberMenu(int accountType){
		List<Menu> menuList = new ArrayList<Menu>();
		Menu menu = new Menu();
		List<SubMenu> subMenuList = new ArrayList<SubMenu>();
		SubMenu subMenu = new SubMenu();
		try {
			if( AccountTypeEnum.DEPARTMENT.getIndex() == accountType ){
				//客户管理 
				menu.setId(1);
				menu.setName("客户管理");
				menu.setIcon("&#xe639;");
				menu.setSubMenu(subMenuList);
				
				subMenu.setPid(1);
				subMenu.setName("授信客户");
				subMenu.setRouter("/member/customer/customerManager");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("业务员");
				subMenu.setRouter("/member/saler/salerManager");
				subMenuList.add(subMenu);
				
				menuList.add(menu);
				
				//授信管理 
				menu = new Menu();
				menu.setId(1);
				menu.setName("授信管理");
				menu.setIcon("&#xe639;");
				subMenuList = new ArrayList<SubMenu>();
				menu.setSubMenu(subMenuList);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("授信记录");
				subMenu.setRouter("/saler/credit/log#?type=check");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("逾期待催收");
				subMenu.setRouter("/loan/outdate/collection");
//				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("催收记录");
				subMenu.setRouter("/loan/collection/log");
//				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("授信统计");
				subMenu.setRouter("/credit/statistics/all");
				subMenuList.add(subMenu);
				
				menuList.add(menu);
				
				//额度管理 
				menu = new Menu();
				menu.setId(1);
				menu.setName("额度管理");
				menu.setIcon("&#xe639;");
				subMenuList = new ArrayList<SubMenu>();
				menu.setSubMenu(subMenuList);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("内部额度记录");
				subMenu.setRouter("/limit/inside/log");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("外部额度记录");
				subMenu.setRouter("/limit/external/log");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("临时额度申请记录");
				subMenu.setRouter("/limit/tempLimitApplyLog");
				subMenuList.add(subMenu);
				
				menuList.add(menu);
			}else if( AccountTypeEnum.SALER.getIndex() == accountType ){
				//客户管理 
				menu.setId(1);
				menu.setName("客户管理");
				menu.setIcon("&#xe639;");
				menu.setSubMenu(subMenuList);
				
				subMenu.setPid(1);
				subMenu.setName("授信客户");
				subMenu.setRouter("/member/customer/customerManager");
				subMenuList.add(subMenu);
				
				menuList.add(menu);
				
				//授信管理 
				menu = new Menu();
				menu.setId(1);
				menu.setName("授信管理");
				menu.setIcon("&#xe639;");
				subMenuList = new ArrayList<SubMenu>();
				menu.setSubMenu(subMenuList);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("新增授信");
				subMenu.setRouter("/member/customer/jumpCustomerPage");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("授信记录");
				subMenu.setRouter("/saler/credit/log#?type=check");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("逾期待催收");
				subMenu.setRouter("/saler/outdate/collection");
//				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("催收记录");
				subMenu.setRouter("/saler/collectin/log");
//				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("授信统计");
				subMenu.setRouter("/credit/statistics/all");
				subMenuList.add(subMenu);
				
				menuList.add(menu);
			}else{
				//借贷管理 
				menu.setId(1);
				menu.setName("借贷管理");
				menu.setIcon("&#xe639;");
				menu.setSubMenu(subMenuList);
				
				subMenu.setPid(1);
				subMenu.setName("借贷记录");
				subMenu.setRouter("/member/loan/selectCoreCompany");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("还款计划");
				subMenu.setRouter("/customer/loan/repayment");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("额度记录");
				subMenu.setRouter("/limit/custLimitLog");
				subMenuList.add(subMenu);
				
//				subMenu = new SubMenu();
//				subMenu.setPid(1);
//				subMenu.setName("设置自动还款");
//				subMenu.setRouter("/customer/loan/setautorepayment");
//				subMenuList.add(subMenu);
//				
				menuList.add(menu);
				
				//资金管理 
				menu = new Menu();
				menu.setId(1);
				menu.setName("资金管理");
				menu.setIcon("&#xe639;");
				subMenuList = new ArrayList<SubMenu>();
				menu.setSubMenu(subMenuList);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("交易记录");
				subMenu.setRouter("/finance/trade/log");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("转入记录");
				subMenu.setRouter("/finance/tradeIn/log");
				subMenuList.add(subMenu);
				
				subMenu = new SubMenu();
				subMenu.setPid(1);
				subMenu.setName("转出记录");
				subMenu.setRouter("/finance/tradeOut/log");
				subMenuList.add(subMenu);
				
				menuList.add(menu);
			}
			
			//账户管理
			menu = new Menu();
			menu.setId(1);
			menu.setName("账户管理");
			menu.setIcon("&#xe639;");
			subMenuList = new ArrayList<SubMenu>();
			menu.setSubMenu(subMenuList);
			
			subMenu = new SubMenu();
			subMenu.setPid(1);
			subMenu.setName("安全设置");
			subMenu.setRouter("/member/member/passwdPage");
			subMenuList.add(subMenu);
			
			subMenu = new SubMenu();
			subMenu.setPid(1);
			subMenu.setName("站内消息");
			subMenu.setRouter("/system/msg/list");
			subMenuList.add(subMenu);
			
			menuList.add(menu);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return menuList;
	}
	

	/**
	 * 系统是否启用自动投标
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean isBorrowAutoSwitchOpen() {
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("value");
		queryItem.setWhere(new Where("nid", "borrow_auto_switch"));
		
		Map result = null;
		try {
			result = getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_CONFIG);
		} catch (Exception e) {
		}
		
		return result != null && "1".equals(result.get("value"));
	}
}