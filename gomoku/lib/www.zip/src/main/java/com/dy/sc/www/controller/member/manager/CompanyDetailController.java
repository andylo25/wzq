package com.dy.sc.www.controller.member.manager;

import com.dy.core.cache.SysCacheUtil;
import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.utils.*;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.Company;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.credit.CreCompanyLimit;
import com.dy.sc.entity.enumeration.CheckStatus;
import com.dy.sc.entity.enumeration.CompanyApproveStatus;
import com.dy.sc.entity.fund.FundLoanRepay;
import com.dy.sc.entity.loan.LoanDebitRecord;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Maps;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 公司明细信息
 *
 * @author Administrator
 */
@Controller
@RequestMapping("/member/manager")
public class CompanyDetailController extends FrontBaseController {

    @Autowired
    CommonBussUtil commonBussUtil;

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/companyDetail")
    public ModelAndView companyDetail() throws Exception {

        ModelAndView view = new ModelAndView("member/manager/companyDetail");
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Map<String, Object> viewData = Maps.newHashMap();
        Company company = this.getById(user.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        viewData.put("company", company);
        QueryItem repayItem = new QueryItem(Where.eq("company_id", user.getCompanyId()));
        repayItem.setWhere(Where.eq("status", -1));//未还完的数据
        repayItem.setFields("sum(amount_total-amount_yes) as amountTotal");
        FundLoanRepay loanRepay = this.getOneByEntity(repayItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAY, FundLoanRepay.class);
        if (loanRepay != null) {
            viewData.put("amountTotal", loanRepay.getAmountTotal());
        } else {
            viewData.put("amountTotal", 0);
        }

        QueryItem queryItem = new QueryItem(Where.eq("company_id", company.getId()));
        queryItem.setWhere(Where.eq("check_status", CheckStatus.CHECK_PASS.getIndex()));
        List<CreCompanyLimit> limits = this.getListByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        viewData.put("limitReceive", 0);
        viewData.put("limitB2B", 0);
        viewData.put("limitCD", 0);
        viewData.put("limitAG", 0);
        for (CreCompanyLimit limit : limits) {
            if (limit.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_RECEIVE) {
                viewData.put("limitReceive", limit.getUnusedLimit());
            } else if (limit.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_B2B) {
                viewData.put("limitB2B", limit.getUnusedLimit());
            } else if (limit.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
                viewData.put("limitCD", limit.getUnusedLimit());
            } else if (limit.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_AGPUR) {
                viewData.put("limitAG", limit.getUnusedLimit());
            }
        }

        QueryItem loanInfoQuery = new QueryItem();
        loanInfoQuery.setFields("sum(loan_amount) as loan_amount,count(id) as loan_count");
        loanInfoQuery.getWhere().add(Where.eq("company_id", getUser().getCompanyId()));
        loanInfoQuery.getWhere().add(Where.in("status", "1,2,3,4,8"));
        viewData.put("loan_amount", 0);
        viewData.put("loan_count", 0);
        Map loanAmount = this.getOneByMap(loanInfoQuery, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
        if (loanAmount != null) {
            if (loanAmount.get("loan_amount") != null) {
                viewData.put("loan_amount", loanAmount.get("loan_amount"));
            }
            if (loanAmount.get("loan_count") != null) {
                viewData.put("loan_count", loanAmount.get("loan_count"));
            }
        }

        loanInfoQuery = new QueryItem();
        loanInfoQuery.setFields("sum(loan_amount) as total_amount,count(id) as total_count");
        loanInfoQuery.getWhere().add(Where.eq("company_id", getUser().getCompanyId()));
        loanInfoQuery.getWhere().add(Where.in("status", "5,6"));
        Map totalAmount = this.getOneByMap(loanInfoQuery, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
        viewData.put("total_amount", 0);
        viewData.put("total_count", 0);
        if (totalAmount != null) {
            if (totalAmount.get("total_amount") != null) {
                viewData.put("total_amount", totalAmount.get("total_amount"));
            }
            if (totalAmount.get("total_count") != null) {
                viewData.put("total_count", totalAmount.get("total_count"));
            }
        }

        QueryItem periodItem = new QueryItem();
        periodItem.getWhere().add(Where.eq("company_id", user.getCompanyId()));
        periodItem.getWhere().add(Where.eq("status", -1));
        //取7天内的数据
        Date today = new Date();
        String startTime = DateUtil.dateFormat(today);
        Where timeWhere = this.addAndWhereCondition(null, "repay_time", startTime, DateUtil.dateFormat(DateUtil.addDay(today, 7)));
        periodItem.getWhere().add(timeWhere);
        periodItem.setOrders("repay_time desc");
        List<Map> periods = this.getListByMap(periodItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
        if (periods != null && periods.size() > 0) {
            for (Map period : periods) {
                if (period != null) {
                    LoanDebitRecord record = this.getById(period.get("debit_id").toString(), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, LoanDebitRecord.class);
                    period.put("business_type", record.getBusinessType());
                    period.put("repayAhead", commonBussUtil.repayAhead(period.get("id").toString()) == ScConstants.REPAY_AHEAD_YES ? "提前还款" : "还款");
                    int overdue_days = DateUtil.daysBetween(DateUtil.dateParse(DateUtil.getCurrentTime()), DateUtil.dateParse(Long.valueOf(period.get("repay_time").toString())));
                    if (overdue_days < 0) {
                        period.put("overdue_days", Math.abs(overdue_days));
                    } else {
                        period.put("overdue_days", 0);
                    }
                }
            }
        }
        viewData.put("period", periods);
        QueryItem moneyItem = new QueryItem();
        moneyItem.setPage(1);
        moneyItem.setLimit(7);
        moneyItem.setFields("id,txn_type,company_id,loan_id as rid,deal_amount,amount_in,amount_out,balance,remark,create_time");
        moneyItem.setWhere(Where.eq("company_id", user.getCompanyId()));
        moneyItem.setOrders("id desc");
        Page moneysData = (Page) dataConvert(getPageByMap(moneyItem, SCModule.MONEY, SCFunction.MONEY_DETAIL), "txn_type:cap_detail_type", "create_time");
        this.idToName(moneysData.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
        viewData.put("moneys", moneysData.getItems());

        moneyItem = new QueryItem();
        moneyItem.setPage(1);
        moneyItem.setLimit(7);
        moneyItem.setFields("id,txn_type,company_id,loan_id as rid,deal_amount,amount_in,amount_out,balance,remark,create_time");
        moneyItem.setWhere(Where.eq("company_id", user.getCompanyId()));
        moneyItem.getWhere().add(Where.eq("txn_dir", AccConstants.TXN_DIR_IN));
        moneyItem.setOrders("create_time desc");
        Page tradeInData = (Page) dataConvert(getPageByMap(moneyItem, SCModule.MONEY, SCFunction.MONEY_DETAIL), "txn_type:cap_detail_type", "create_time");
        this.idToName(tradeInData.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
        viewData.put("tradeIns", tradeInData.getItems());

        moneyItem = new QueryItem();
        moneyItem.setPage(1);
        moneyItem.setLimit(7);
        moneyItem.setFields("id,bank_name_type,account,deal_amount,real_amount,counter_fee,status,create_time");
        moneyItem.setWhere(Where.eq("uid", user.getId()));
        moneyItem.setOrders("create_time desc");
        Page tradeOutData = (Page) dataConvert(getPageByMap(moneyItem, SCModule.MONEY, SCFunction.MONEY_WITHDRAWALS_RECORD), "status:send_status,bank_name_type:bank_code", "create_time");
        viewData.put("tradeOuts", tradeOutData.getItems());

        AccAccount account = BaseInfoUtils.getCompAccountEntity(company.getId());
        if ((account != null && StringUtils.isNotBlank(account.getAccount())) || !SysCacheUtil.useTrust()) {
            viewData.put("account", account);
        }
        viewData.put("useTrust", SysCacheUtil.useTrust());
        if (CompanyApproveStatus.PASS.getIndex() != company.getApproveStatus()) {
            viewData.put("approveStatus", false);
        } else {
            viewData.put("approveStatus", true);
        }

        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;
    }

    /**
     * 查询余额
     *
     * @return
     * @throws Exception
     * @author likf
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/accBalance")
    @ResponseBody
    public DyResponse accBalance() throws Exception {
        OrgFrontUser user = this.getUser();
        Map<String, Object> account = BaseInfoUtils.getCompAccountMap(user.getCompanyId());
        String accountStr = MapUtils.getString(account, "account");
        if (StringUtils.isNoneBlank(accountStr))
            account.put("account", DyStringUtils.desensitiz(accountStr));
        return createSuccessJsonResonse(account, "查询成功");
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/companyInfo")
    public ModelAndView compnayInfo() throws Exception {
        ModelAndView view = new ModelAndView("member/manager/companyInfo");
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        Company company = this.getById(user.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        Map<String, Object> viewData = (Map<String, Object>) new DataConvertUtil(company, false).convert();

        QueryItem queryItem = new QueryItem(Where.eq("company_id", user.getCompanyId()));
        List<Map> documents = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT);
        this.idToName(documents, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, "premise_material_id:name as material_name");
        viewData.put("documents", dataConvert(documents, "never_expire:common_status", "create_time"));

        viewData = (Map<String, Object>) dataConvert(viewData, "companyType:company_type,businessLicType:business_lic_type," +
                "companyRoleType:company_role_type,companyCategory:company_category,companyScale:company_scale,isStock:is_stock," +
                "legalCardType:cred_type,financialCardType:cred_type,contactCardType:cred_type,isStock:common_status");
        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;
    }
}