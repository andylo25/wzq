package com.dy.sc.www.controller.member.manager;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.*;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 交易记录
 *
 * @author Administrator
 */
@Controller
@RequestMapping("/member/manager/companyFunds")
public class CompanyFundsController extends FrontBaseController {
    private static final int SELECT_DATE_ONE = 1;
    private static final int SELECT_DATE_TWO = 2;
    private static final int SELECT_DATE_THREE = 3;

    /**
     * 界面结构：交易记录
     *
     * @return
     */
    @SuppressWarnings("unchecked")
    @RequestMapping("/list")
    public ModelAndView list() {
        Map<String, Object> formData = Maps.newHashMap();
        ;
        try {
            TableHeader tableHeader = new TableHeader();
            tableHeader.setNames(new String[]{"create_time", "txn_type", "deal_amount", "amount_in", "amount_out", "remark"});
            tableHeader.setTexts(new String[]{"交易时间", "交易类型", "操作金额(元)", "收入(元)", "支出(元)", "备注"});
            PageStructure data = PageUtil.createTablePageStructure("member/manager/companyFunds/listData/99", null, "id", tableHeader, null, null);
            formData.put("list", data);
            formData.put("capDetailTypes", DictUtils.getOptions("cap_detail_type", "3,4,5,9,12,13,15,16"));
            formData.put("currentStatus", 1);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return createSuccessModelAndView("member/manager/companyFunds", JsonUtils.object2JsonString(formData));
    }

    /**
     * 获取数据：交易记录
     */
    @ResponseBody
    @RequestMapping("/listData/{type}")
    public DyResponse listData(Integer page, @PathVariable("type") Integer type, Integer selectDate, Integer tradeType,
                               @RequestParam(value = "startDate", required = false) String startDate, @RequestParam(value = "endDate", required = false) String endDate) throws Exception {
        OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(10);
        queryItem.setFields("id,txn_type,company_id,loan_id as rid,deal_amount,amount_in,amount_out,balance,remark,create_time");
        if (type == AccConstants.TXN_DIR_IN || type == AccConstants.TXN_DIR_OUT) {
            queryItem.getWhere().add(Where.eq("txn_dir", type));
        }
        if (type == AccConstants.TXN_DIR_OUT) {
            tradeType = AccConstants.CAP_DETAIL_TYPE_TX;
        }
        if (StringUtils.isNotBlank(startDate)) {
            String end = null;
            if (StringUtils.isNotBlank(endDate)) {
                end = DateUtil.dateFormat(DateUtil.addDay(DateUtil.dateParse(endDate), 1));
            }
            Where where = this.addAndWhereCondition(null, "create_time", startDate, end);

            if (where != null) {
                queryItem.getWhere().add(where);
            }
        }
        if (tradeType != null) {
            queryItem.getWhere().add(Where.eq("txn_type", tradeType));
        }

        if (selectDate != null) {
            Where timeWhere = null;
            Date today = new Date();
            String startTime = DateUtil.dateFormat(DateUtil.addDay(today, 1));//当前日期+1天
            if (selectDate == SELECT_DATE_ONE) {
                //一个月
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -1)), startTime);
            } else if (selectDate == SELECT_DATE_TWO) {
                //三个月
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -3)), startTime);
            } else if (selectDate == SELECT_DATE_THREE) {
                //一年
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -12)), startTime);
            }

            if (timeWhere != null) {
                queryItem.getWhere().add(timeWhere);
            }
        }
        queryItem.setWhere(Where.eq("company_id", user.getCompanyId()));
        queryItem.setOrders("id desc");
        Page pageData = (Page) dataConvert(getPageByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_DETAIL), "txn_type:cap_detail_type", "create_time");
        List<Map<String, Object>> dataList = pageData.getItems();
        this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
        return createSuccessJsonResonse(pageData);
    }


    /**
     * 界面结构：转入记录
     *
     * @return
     */
    @RequestMapping("/tradeIn")
    public ModelAndView tradeIn() {
        Map<String, Object> formData = Maps.newHashMap();
        try {
            TableHeader tableHeader = new TableHeader();
            tableHeader.setNames(new String[]{"create_time", "txn_type", "deal_amount", "remark"});
            tableHeader.setTexts(new String[]{"交易时间", "交易类型", "操作金额(元)", "备注"});
            tableHeader.setTypes(new String[]{"date", "", "number", ""});
            PageStructure data = PageUtil.createTablePageStructure("member/manager/companyFunds/listData/" + AccConstants.TXN_DIR_IN, null, "id", tableHeader, null, null);
            formData.put("list", data);
            formData.put("capDetailTypes", DictUtils.getOptions("cap_detail_type", "4,8"));
            formData.put("currentStatus", 2);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return createSuccessModelAndView("member/manager/companyFunds", JsonUtils.object2JsonString(formData));
    }

    /**
     * 界面结构：转出记录
     *
     * @return
     */
    @RequestMapping("/tradeOut")
    public ModelAndView tradeOut() {
        Map<String, Object> formData = Maps.newHashMap();
        try {
            TableHeader tableHeader = new TableHeader();
            tableHeader.setNames(new String[]{"create_time", "bank_name_type", "deal_amount", "real_amount", "counter_fee", "status"});
            tableHeader.setTexts(new String[]{"交易时间", "提现银行", "提现总额(元)", "到账金额(元)", "手续费", "状态"});
            tableHeader.setTypes(new String[]{"", "customize", "number", "number", "number", ""});
            PageStructure data = PageUtil.createTablePageStructure("member/manager/companyFunds/tradeOutData", "id", tableHeader, null, null);

            formData.put("list", data);
            formData.put("capDetailTypes", DictUtils.getOptions("cap_detail_type", "3,4,5,9,12,13"));
            formData.put("currentStatus", 3);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return createSuccessModelAndView("member/manager/companyFunds", JsonUtils.object2JsonString(formData));
    }

    /**
     * 获取数据：交易记录
     */
    @ResponseBody
    @RequestMapping("/tradeOutData")
    public DyResponse tradeOutData(Integer page, Integer selectDate,
                                   @RequestParam(value = "startDate", required = false) String startDate, @RequestParam(value = "endDate", required = false) String endDate) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(10);
        queryItem.setFields("id,bank_name_type,account,deal_amount,real_amount,counter_fee,status,create_time");
        if (StringUtils.isNotBlank(startDate)) {
            String end = null;
            if (StringUtils.isNotBlank(endDate)) {
                end = DateUtil.dateFormat(DateUtil.addDay(DateUtil.dateParse(endDate), 1));
            }
            Where where = this.addAndWhereCondition(null, "create_time", startDate, end);

            if (where != null) {
                queryItem.getWhere().add(where);
            }
        }

        if (selectDate != null) {
            Where timeWhere = null;
            Date today = new Date();
            String startTime = DateUtil.dateFormat(DateUtil.addDay(today, 1));//当前日期+1天
            if (selectDate == SELECT_DATE_ONE) {
                //一个月
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -1)), startTime);
            } else if (selectDate == SELECT_DATE_TWO) {
                //三个月
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -3)), startTime);
            } else if (selectDate == SELECT_DATE_THREE) {
                //一年
                timeWhere = this.addAndWhereCondition(null, "create_time", DateUtil.dateFormat(DateUtil.addMonth(today, -12)), startTime);
            }

            if (timeWhere != null) {
                queryItem.getWhere().add(timeWhere);
            }
        }
        queryItem.setWhere(Where.eq("uid", getUserId()));
        queryItem.setOrders("id desc");
        Page pageData = (Page) dataConvert(getPageByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_WITHDRAWALS_RECORD), "status:send_status,bank_name_type:bank_code", "create_time");
        return createSuccessJsonResonse(pageData);
    }

}