package com.dy.sc.www.controller.member.company;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.SecurityUtil;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.enumeration.UserStatusEnum;
import com.dy.ia.www.controller.common.VerifyCodeController;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.AccountUseType;
import com.dy.sc.entity.enumeration.CompanyApproveStatus;
import com.dy.sc.entity.enumeration.CompanyRoleType;
import com.dy.sc.entity.enumeration.PwdVerifyTypeEnum;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.service.money.MoneyService;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 用户管理
 * @author Administrator
 * 
 */
@Controller
@RequestMapping("/public/")
public class CompanyRegisterController extends FrontBaseController {
	
	private static final int STEP_ONE=1;
	private static final int STEP_TWO=2;
	private static final int STEP_THREE=3;
	private static final int STEP_FOUR=4;
	
	@Autowired
	private MoneyService moneyService;
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/register")
	public ModelAndView register() throws Exception {

		ModelAndView view = new ModelAndView("login/register");
		Map<String,Object> viewData = Maps.newHashMap();
		viewData.put("types", DictUtils.getOptionsInt("company_type"));
		//省市区
        List workList=Lists.newArrayList();
        Map item=Maps.newHashMap();
        item.put("name", "workProvinceId");
        workList.add(item);
        item=Maps.newHashMap();
        item.put("name", "workCityId");
        workList.add(item);
        item=Maps.newHashMap();
        item.put("name", "workAreaId");
        workList.add(item);
              
        viewData.put("workList", workList);
		view.addObject("data", JsonUtils.object2JsonString(viewData));
		return view;
		
	}
	
    /**
     * 保存用户
     * 
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/register/save")
    public DyResponse save(Company company, OrgFrontUser user, String valicode,String phoneCode,String mailCode,String password) throws Exception {
		//验证码校验
    	this.checkVerifyCode(valicode);
    	
		if(StringUtils.isBlank(password)){
            return createErrorJsonResonse(this.getMessage("validate.null",new String[]{"密码"}));
        }
		//短信验证码
		String sessionPhoneCode = (String) VerifyCodeController.getPhoneCode(company.getContactPhoneNumber());
		if(StringUtils.isBlank(phoneCode)||StringUtils.isBlank(sessionPhoneCode)||!phoneCode.equalsIgnoreCase(sessionPhoneCode)){
            return createErrorJsonResonse(this.getMessage("validate.phoneCodeError"));
        }
		
		//邮箱验证码
//		Map<String, Object> sessionMap = (Map<String, Object>) this.getSessionAttribute("sessionMap");
//		if (sessionMap == null) {//session已过期
//			return createErrorJsonResonse("邮箱验证码错误！");
//		} else {
//			//session未过期
//			String sessionCode = (String) sessionMap.get("sessionCode");
//			String errorMsg = EmailVerifyCode.validate(user.getEmail(), mailCode, 5);
//			if(errorMsg != null) return createErrorJsonResonse(errorMsg);
//			if (!sessionCode.equals(mailCode)) {
//				return createErrorJsonResonse("邮箱验证码错误！");
//			}
//		}
        if (isUserExists(user.getUsername())) {
            return createErrorJsonResonse("用户名已存在，不能注册，请重新输入！");
        }
        if(isUserExists(company.getContactPhoneNumber())){
        	return createErrorJsonResonse("联系人手机已在系统中绑定其他企业，不能注册，请重新输入！");
        }
        if(StringUtils.isNotBlank(company.getContactEmail())&&isUserExists(company.getContactEmail())){
        	return createErrorJsonResonse("联系人邮箱已在系统中绑定其他企业，不能注册，请重新输入！");
        }
        if (isCompanyExists(company.getCompanyName())) {
            return createErrorJsonResonse("企业名称已存在，不能注册，请重新输入！");
        }
        Long now = System.currentTimeMillis() / 1000;
        user.setRegisterTime(now);
        user.setRegisterIp(this.getRemoteIp());
        user.setLastloginTime(now);

        company.setApproveStatus(CompanyApproveStatus.UNSUBMITTED.getIndex());//未认证
        //普通用户
        company.setCompanyRoleType(CompanyRoleType.COMPANY_NORMAL.getIndex());
        user.setType(company.getCompanyRoleType());
        //创建账号
        user.setStatus(UserStatusEnum.ACTIVE.getIndex());
        //OrgFrontUser.setDelFlag(DelFlag.DELETED.getIndex());        
        user.setRealName(company.getCompanyName());
        user.setPassword(SecurityUtil.md5(SecurityUtil.sha1(password)));
        //联系人邮箱、手机
        user.setPhone(Long.parseLong(company.getContactPhoneNumber()));
        user.setEmail(company.getContactEmail());
        
        company.setStatus(1);// 默认审核通过
        company.setPassTime(System.currentTimeMillis() / 1000);
        //处理地区字段
        String ids=null;
        if(company.getWorkAreaId()!=null){
            ids=company.getWorkAreaId().toString();
        }
        if(company.getCompanyAreaId()!=null){
            if(ids!=null){
                ids+=","+company.getCompanyAreaId();
            }else{
                ids=company.getCompanyAreaId().toString();
            }
        }
        
        if(ids!=null){
            QueryItem queryItem=new QueryItem();
            queryItem.setFields("id,province,city");
            queryItem.setWhere(Where.in("id", ids));
            List<Map> areaList= this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS);
            ids="";
            String[] workAreaIds = null;
            String[] companyAreaIds=null;
            for(Map item:areaList){
                //获取省市
                if(ids!=null&&!"".equals(ids))
                    ids+=",";
                ids+=item.get("province")+","+item.get("city")+","+item.get("id");
                Long areaId=Long.parseLong(item.get("id").toString());
                if(areaId.equals(company.getWorkAreaId())){
                    workAreaIds=new String[3];
                    workAreaIds[0]=item.get("province").toString();
                    workAreaIds[1]=item.get("city").toString();
                    workAreaIds[2]=item.get("id").toString();
                }else if(areaId.equals(company.getCompanyAreaId())){
                    companyAreaIds=new String[3];
                    companyAreaIds[0]=item.get("province").toString();
                    companyAreaIds[1]=item.get("city").toString();
                    companyAreaIds[2]=item.get("id").toString();
                }
            }
            queryItem=new QueryItem();
            queryItem.setFields("id,name");
            queryItem.setWhere(Where.in("id", ids));
            areaList= this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS);
            Map<String,String> areaResult=Maps.newHashMap();
            for(Map item:areaList){
                //获取省市中文
                areaResult.put(item.get("id").toString(), item.get("name").toString());
            }
            if(workAreaIds!=null){
                String tempStr0=areaResult.get(workAreaIds[0]);
                String tempStr1=areaResult.get(workAreaIds[1]);
                company.setWorkArea((tempStr1.startsWith(tempStr0)?tempStr1:tempStr0+tempStr1)+areaResult.get(workAreaIds[2]));
            }
            if(companyAreaIds!=null){
                String tempStr0=areaResult.get(companyAreaIds[0]);
                String tempStr1=areaResult.get(companyAreaIds[1]);
                company.setCompanyArea((tempStr1.startsWith(tempStr0)?tempStr1:tempStr0+tempStr1)+areaResult.get(companyAreaIds[2]));
            }
        }
        //Long id = companyService.addCompany(company);
        DyResponse companyResp=this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);           
        user.setCompanyId(companyResp.getId());
        DyResponse res = this.insert(SCModule.SYSTEM, SCFunction.SYS_USER, user);            
        user.setId(res.getId());
		//加入Shiro身份验证
		Subject subject = SecurityUtils.getSubject(); 
		UsernamePasswordToken token = new UsernamePasswordToken(user.getUsername(), user.getPassword()); 
		subject.login(token); 
		
        // 企业创建成功，创建额度账户
//        if(companyResp.getStatus() == 200){
//        	// 默认值
//        	QueryItem queryBusi = new QueryItem(Where.eq("del_flag", 0));
//        	List<ProdBusinessType> businesses = this.getListByEntity(queryBusi, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class);
//        	for(ProdBusinessType business : businesses){
//            	CreCompanyLimit limit = new CreCompanyLimit();
//            	limit.setCompanyId(companyResp.getId());
//            	limit.setBusinessTypeId(business.getId());
//            	this.insert(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);
//        	}
//        }
        
        //账号 授信额度
        moneyService.createBankAccount(companyResp.getId(),null, AccConstants.PLAT_ACCOUNT_ID,AccountUseType.SETTLE_ACCOUNT.getIndex());
		//登录成功
		//插入登录log信息
		//更新最后登录时间和ip
//		user.setLastloginTime(System.currentTimeMillis() / 1000);
//		user.setLastloginIp(this.getRemoteIp());
//		user.setCount(1);
//		this.update(SCModule.SYSTEM, SCFunction.SYS_USER, user);		
		//把用户信息加入session
		this.setSessionAtrribute(Constant.SESSION_USER, user);
		
        return createSuccessJsonResonse(null, "注册成功");
    }
    
	@RequestMapping(value="/register/result")
	public ModelAndView result() throws Exception {
		ModelAndView view = new ModelAndView("login/registerResult");		
		return view;
		
	}
    
    private boolean isCompanyExists(String companyName) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields("count(1) as count");
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "company_name", companyName);
        this.addWhereCondition(where, "del_flag", 0);
        query.setWhere(where);
        Map<String, Object> result = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
            return true;
        }
        return false;
    }
    
    private boolean isUserExists(String userName) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields("count(1) as count");
        List<Where> where = new ArrayList<Where>();
        //用户名
        this.addWhereCondition(where, "username", userName);
        this.addWhereCondition(where, "del_flag", 0);
        query.setWhere(where);
        boolean exist=false;
        Map<String, Object> result = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_USER);
        if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
        	exist = true;
        }else{
        	//邮箱
          	QueryItem email = new QueryItem();
        	email.setFields("count(1) as count");
        	email.getWhere().add(Where.eq("email", userName));
        	email.getWhere().add(Where.eq("del_flag", 0));
        	result = this.getOneByMap(email, SCModule.SYSTEM, SCFunction.SYS_USER);
        	if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
        		exist = true;
            }else{
            	//手机
            	QueryItem phone = new QueryItem();
              	phone.setFields("count(1) as count");
              	phone.getWhere().add(Where.eq("phone", userName));
              	phone.getWhere().add(Where.eq("del_flag", 0));
              	result = this.getOneByMap(phone, SCModule.SYSTEM, SCFunction.SYS_USER);
              	if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
            		exist = true;
                }
        	}
        }
        return exist;
    }
    
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/getpasswd")
	public ModelAndView getpasswd() throws Exception {
		ModelAndView view = new ModelAndView("login/getpasswd");
		Map<String,Object> viewData = Maps.newHashMap();
		viewData.put("step", STEP_ONE);		
		view.addObject("data", JsonUtils.object2JsonString(viewData));
		return view;		
	}
	
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="/getpasswd/submit")
	public DyResponse changePassword(int step, String vcode,
			String username, String phoneCode, String emailCode, Long userId, Integer accountType, String newPasswd) throws Exception {
		Map<String,Object> data=Maps.newHashMap();
		if(step==STEP_ONE){
			//验证码校验
			this.checkVerifyCode(vcode);
			OrgFrontUser user=getUserByName(username);
			if(user==null){
				return createErrorJsonResonse("账号不存在！");
			}else{
				data.put("userId", user.getId());
				data.put("email", user.getEmail());
				data.put("phone", user.getPhone());
				data.put("step", STEP_TWO);
			}
		}else if(step==STEP_TWO){
			if(accountType==PwdVerifyTypeEnum.EMAIL.getIndex()){				
				//邮箱验证码
				Map<String, Object> sessionMap = (Map<String, Object>) this.getSessionAttribute("sessionMap");
				if (sessionMap == null) {//session已过期
					return createErrorJsonResonse("邮箱验证码错误！");
				} else {
					//session未过期
					String sessionCode = (String) sessionMap.get("sessionCode");
					if (!sessionCode.equals(emailCode)) {
						return createErrorJsonResonse("邮箱验证码错误！");
					}
				}
			}else if(accountType==PwdVerifyTypeEnum.PHONE.getIndex()){
				//短信验证码
				String sessionPhoneCode = (String) VerifyCodeController.getPhoneCode(String.valueOf(getUser().getPhone()));
				if(StringUtils.isBlank(phoneCode)||StringUtils.isBlank(sessionPhoneCode)||!phoneCode.equalsIgnoreCase(sessionPhoneCode)){
		            return createErrorJsonResonse(this.getMessage("validate.phoneCodeError"));
		        }
			}
			data.put("userId", userId);
			data.put("step", STEP_THREE);
		}else if(step==STEP_THREE){
			if(StringUtils.isBlank(newPasswd)){
	            return createErrorJsonResonse(this.getMessage("validate.null",new String[]{"新密码"}));
	        }
			Map<String,Object> map=Maps.newHashMap();
			map.put("id", userId);
			map.put("password", SecurityUtil.md5(SecurityUtil.sha1(newPasswd)));
			this.update(SCModule.SYSTEM, SCFunction.SYS_USER, map);
			data.put("step", STEP_FOUR);
		}
		return createSuccessJsonResonse(data);		
	}
	
    private OrgFrontUser getUserByName(String userName) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields("id,username,email,phone");
        query.getWhere().add(Where.eq("username", userName));
        query.getWhere().add(Where.eq("del_flag", 0));
        OrgFrontUser user = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER,OrgFrontUser.class);
        if(user==null){
        	QueryItem email = new QueryItem();
        	email.getWhere().add(Where.eq("email", userName));
        	email.getWhere().add(Where.eq("del_flag", 0));
        	user = this.getOneByEntity(email, SCModule.SYSTEM, SCFunction.SYS_USER,OrgFrontUser.class);
        	if(user==null){
              	QueryItem phone = new QueryItem();
              	phone.getWhere().add(Where.eq("phone", userName));
              	phone.getWhere().add(Where.eq("del_flag", 0));
            	user = this.getOneByEntity(phone, SCModule.SYSTEM, SCFunction.SYS_USER,OrgFrontUser.class);
        	}
        }
        return user;
    }
}