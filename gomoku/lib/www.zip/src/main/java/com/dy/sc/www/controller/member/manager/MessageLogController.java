package com.dy.sc.www.controller.member.manager;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.SecurityUtil;
import com.dy.ia.entity.common.Areas;
import com.dy.ia.entity.common.Company;
import com.dy.ia.www.controller.common.VerifyCodeController;
import com.dy.sc.entity.account.AccBankCard;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.MessageType;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.www.entity.EmailVerifyCode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;


/**
 * 站内消息
 * @ClassName: MessageLogController.java 
 * @Description: TODO 
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author diyou@diyou.cn
 * @date 2017年9月8日上午9:17:50 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * diyou 
 * </pre>
 */	
@Controller
@RequestMapping("/member/manager/messageLog/")
public class MessageLogController extends FrontBaseController {
	
	@Override
	protected DateFormatType getDateFormatType() {
		return DateFormatType.DATETIME;
	}
	
	/**
     * 构建列表结构:站内信记录
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
    	Map<String,Object> viewData = Maps.newHashMap();
    	QueryItem queryItem = new QueryItem();
    	queryItem.setFields("id,title,contents,read_status,create_time");
		queryItem.getWhere().add(Where.eq("message_type", MessageType.INFORMATION.getIndex()));
		queryItem.getWhere().add(Where.eq("company_id", getUser().getCompanyId()));
		queryItem.setOrders("id desc");
		List<Map> data=this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.MESSAGE_LOG);
		if(data!=null&&data.size()>0){
			dataConvert(data,null,"create_time");
		}
		viewData.put("list",data);
		return createSuccessModelAndView("member/manager/messageLog", JsonUtils.object2JsonString(viewData));
    }
    
	/**
	 * 已经读取
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="reader")
	public DyResponse reader(Long id) throws Exception {
		Map<String,Object> read=Maps.newHashMap();
		read.put("id", id);
		read.put("read_status",1);
		DyResponse dr=this.update(SCModule.SYSTEM, SCFunction.MESSAGE_LOG, read);
		return dr;
	}
	
	/**
	 * 删除
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete")
	public DyResponse delete(String ids) throws Exception {
		if(StringUtils.isNotBlank(ids)){				
			for(String id:ids.split(",")){
				this.deleteById(Long.parseLong(id),SCModule.SYSTEM, SCFunction.MESSAGE_LOG);
			}
		}
		Map<String,Object> viewData = Maps.newHashMap();
		return createSuccessJsonResonse(viewData,"删除成功！");
	}
	
}