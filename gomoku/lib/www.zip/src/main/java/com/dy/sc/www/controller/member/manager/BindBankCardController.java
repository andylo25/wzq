package com.dy.sc.www.controller.member.manager;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.SysDict;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.DyStringUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.ia.entity.common.Areas;
import com.dy.sc.entity.account.AccBankCard;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * 绑定银行卡
 * @ClassName: BindBankCardController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年8月18日 下午5:57:56 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/member/manager/bindBankCard/")
public class BindBankCardController extends FrontBaseController {
	
    /**
     * 
     * 银行卡列表
     * @return
     * @throws Exception
     * @author likf
     */
	@RequestMapping(value="list")
	public ModelAndView list() throws Exception {
		ModelAndView view = new ModelAndView("member/bankCard/list");
		OrgFrontUser user=getUser();
		
		QueryItem queryItem=new QueryItem();
		queryItem.setFields("id,account,bank_name_type");
		queryItem.setWhere(Where.eq("company_id", user.getCompanyId()));
		queryItem.setWhere(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
		List<Map> bankCardList=this.getListByMap(queryItem, SCModule.ACCOUNT, SCFunction.ACC_BANK_CARD);
		
		Map<String,Object> data = Maps.newHashMap();
		if(bankCardList!=null&&bankCardList.size()>0){
		    for(Map card:bankCardList){
		        String bank_name_type=MapUtils.getString(card, "bank_name_type");
		        SysDict dict=DictUtils.getDict(bank_name_type, "bank_code");
		        if(dict!=null){
		            card.put("bank_id", dict.getId());
	                card.put("bank_name", dict.getValue());
		        }
		        card.put("account", DyStringUtils.desensitiz(MapUtils.getString(card, "account")));
		    }
		}
		data.put("list", bankCardList);
		view.addObject("data", JsonUtils.object2JsonString(data));
		return view;
	}
	
	@RequestMapping(value="countCard",method=RequestMethod.POST)
	@ResponseBody
    public DyResponse countCard() throws Exception {
        OrgFrontUser user=getUser();
        
        QueryItem queryItem=new QueryItem();
        queryItem.setFields("count(1) as cnt");
        queryItem.setWhere(Where.eq("company_id", user.getCompanyId()));
        Map<String, Object> countMap=this.getOneByMap(queryItem, SCModule.ACCOUNT, SCFunction.ACC_BANK_CARD);
        
        Map<String,Object> data=Maps.newHashMap();
        data.put("result", MapUtils.getLong(countMap,"cnt")>0);
        return createSuccessJsonResonse(data);
    }
	
	private Areas getArea(Object id) throws Exception{
        if(id!=null){
            QueryItem queryItem=new QueryItem();
            queryItem.setFields("id,province,city");
            queryItem.setWhere(Where.eq("id", id));
            return this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS, Areas.class);
        }
        return null;
    }
	
	@SuppressWarnings("unchecked")
    @RequestMapping(value="add")
    public ModelAndView add(AccBankCard bankCard) throws Exception {
	    ModelAndView view = new ModelAndView("member/bankCard/add");
	    Map<String,Object> data=Maps.newHashMap();
	    List<Map> linklist=Lists.newArrayList();
        Map<String,Object> item=Maps.newHashMap();
        item.put("name", "pid_province");
        linklist.add(item);
        item=Maps.newHashMap();
        item.put("name", "pid_city");
        linklist.add(item);
        item=Maps.newHashMap();
        item.put("name", "areaId");
        linklist.add(item);
        data.put("linklist", linklist);
        data.put("bankCodes", DictUtils.getOptions("bank_code"));
	    if(bankCard.getId()!=null){
	        QueryItem queryItem=new QueryItem();
	        queryItem.setWhere(Where.eq("id", bankCard.getId()));
	        AccBankCard card=this.getOneByEntity(queryItem,SCModule.ACCOUNT, SCFunction.ACC_BANK_CARD,AccBankCard.class);
	        Map cardMap=new DataConvertUtil(card).convert(Map.class);
	        Areas area=getArea(card.getAreaId());
	        
            if(area!=null){
                cardMap.put("pid_province", area.getProvince());
                cardMap.put("pid_city", area.getCity());
                cardMap.put("areaId", area.getId());
                
                List<Map> pids=Lists.newArrayList();
                Map<String,Object> pid=Maps.newHashMap();
                pid.put("pid", area.getProvince());
                pid.put("index", 0);
                pids.add(pid);
                pid=Maps.newHashMap();
                pid.put("pid", area.getCity());
                pid.put("index", 1);
                pids.add(pid);
                pid=Maps.newHashMap();
                pid.put("pid", area.getId());
                pid.put("index", 2);
                pids.add(pid);
                data.put("dataparams", pids);
            }
            data.put("card", cardMap);
            
	    }else{
	        OrgFrontUser user=getUser();
	        QueryItem queryItem=new QueryItem();
	        queryItem.setFields("company_name as accountName");
	        queryItem.setWhere(Where.eq("id", user.getCompanyId()));
	        Map company=this.getOneByMap(queryItem, SCModule.SYSTEM,SCFunction.SYS_COMPANY);
	        data.put("card", company);
	    }
	    view.addObject("data",JsonUtils.object2JsonString(data));
        return view;
    }

    @RequestMapping(value="save",method=RequestMethod.POST)
	@ResponseBody
	public DyResponse save(AccBankCard card) throws Exception{
	    if(card.getId()==null){
	        OrgFrontUser user=getUser();
	        card.setCompanyId(user.getCompanyId());
	        this.insert(SCModule.ACCOUNT, SCFunction.ACC_BANK_CARD, card);
	    }else{
	        this.update(SCModule.ACCOUNT, SCFunction.ACC_BANK_CARD,card);
	    }
	    return createSuccessJsonResonse(null,"保存成功");
	}
    
    @RequestMapping(value="delete",method=RequestMethod.POST)
    @ResponseBody
    public DyResponse delete(Long id) throws Exception{
        
        if(id!=null){
            OrgFrontUser user=getUser();
            AccBankCard bankCard = this.getById(id, SCModule.ACCOUNT, SCFunction.ACC_BANK_CARD,AccBankCard.class);
            if(bankCard!=null&&bankCard.getCompanyId().equals(user.getCompanyId())){
                this.deleteById(id, SCModule.ACCOUNT, SCFunction.ACC_BANK_CARD);
            }
        }
        return createSuccessJsonResonse(null,"删除成功");
    }
	
}