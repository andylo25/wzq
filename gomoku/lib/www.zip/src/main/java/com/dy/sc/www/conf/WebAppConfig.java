package com.dy.sc.www.conf;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.velocity.VelocityProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.view.velocity.EmbeddedVelocityViewResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.dy.core.bussmodule.IBaseBussModule;
import com.dy.core.view.velocity.DyVelocityViewResolver;
import com.dy.sc.www.interceptor.LoginHandlerInterceptor;

@Configuration
@EnableConfigurationProperties(VelocityProperties.class)
public class WebAppConfig extends WebMvcConfigurerAdapter{
	
	@Autowired
	private IBaseBussModule bussModule;
	/**
     * 配置拦截器
     * @author cuiwm
     * @param registry
     */
    public void addInterceptors(InterceptorRegistry registry) {
    	registry.addInterceptor(new LoginHandlerInterceptor(bussModule)).addPathPatterns("/**");
//    		.excludePathPatterns("/**/*.js","/**/*.css","/**/*.png","/**/*.gif","/**/*.jpg","/**/*.jpeg");
    	super.addInterceptors(registry); 
	}
    
    @Autowired
    protected VelocityProperties velocityProperties;
    
    @Bean
    //@ConditionalOnMissingBean(name = "velocityViewResolver")
    @ConditionalOnProperty(name = "spring.velocity.enabled", matchIfMissing = true)
    public EmbeddedVelocityViewResolver velocityViewResolver() {
        DyVelocityViewResolver resolver= new DyVelocityViewResolver();
        this.velocityProperties.applyToViewResolver(resolver);
        return resolver;
    }
    
    /**
     * 使用velocity
     * @return
     */
    @Bean
	public EmbeddedVelocityViewResolver viewResolver(EmbeddedVelocityViewResolver velocityViewResolver) {
        return velocityViewResolver;
	}
    
}
