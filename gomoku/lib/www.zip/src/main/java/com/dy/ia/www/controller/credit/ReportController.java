package com.dy.ia.www.controller.credit;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.RepMonthLimit;
import com.dy.ia.entity.enumeration.AccountTypeEnum;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/credit/statistics")
public class ReportController extends FrontBaseController {
	
	@RequestMapping("all")
	public ModelAndView statistics() throws Exception  {
		ModelAndView view = new ModelAndView();
		try {
			OrgFrontUser user = getUser();
			TableHeader tableHeader = new TableHeader();
			if(AccountTypeEnum.DEPARTMENT.getIndex() == user.getType()){
				tableHeader.setNames(new String[]{"rep_date","pay_limit","total_back_limit","new_customer_count","action"});
				tableHeader.setTexts(new String[]{"月份","已放授信","已回授信","新增客户","操作"});
				tableHeader.setTypes(new String[]{"", "","","number","link"});
			}else if(AccountTypeEnum.SALER.getIndex() == user.getType()){
				tableHeader.setNames(new String[]{"rep_date","pay_limit","total_back_limit","new_customer_count"});
				tableHeader.setTexts(new String[]{"月份","已放授信","已回授信","新增客户"});
				tableHeader.setTypes(new String[]{"", "","","number"});
			}
			PageStructure data = PageUtil.createTablePageStructure("credit/statistics/logData", "id", tableHeader,null,null);
			if(AccountTypeEnum.DEPARTMENT.getIndex() == user.getType()){
				data.setRightUrl("credit/statistics/salerDetail");
			}
			String contentPage = "";
			if(AccountTypeEnum.DEPARTMENT.getIndex() == user.getType()){
				contentPage = "report/dept.html";
			}else if(AccountTypeEnum.SALER.getIndex() == user.getType()){
				contentPage = "report/saler.html";
			}
			SystemInfo system = new SystemInfo(contentPage);
			system.setSiteName("授信统计");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}
	
	/**
	 * 月度统计
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("logData")
	public DyResponse logData(Integer page,Integer limit,String search) throws Exception {
		OrgFrontUser user = getUser();
		Calendar now = Calendar.getInstance();  
		List<Where> where = new ArrayList<Where>();
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("id,rep_date,sum(pay_limit) as pay_limit,sum(total_back_limit) as total_back_limit,sum(new_customer_count) as new_customer_count");
		queryItem.setGroup("rep_date");
		String ym = now.get(Calendar.YEAR) + "";  
		this.addWhereCondition(where, "rep_date", LIKE_ALL, ym);
		int type = 3;
		if(AccountTypeEnum.DEPARTMENT.getIndex() == user.getType()){
			type = 1;
		}else if(AccountTypeEnum.SALER.getIndex() == user.getType()){
			type = 3;
		}
		this.addWhereCondition(where, "rec_category", type);
		if(AccountTypeEnum.DEPARTMENT.getIndex() == user.getType()){
			this.addWhereCondition(where, "uid", user.getId());//部门id
		}
		if(AccountTypeEnum.SALER.getIndex() == user.getType()){
			this.addWhereCondition(where, "uid", user.getId());
		}
		queryItem.setWhere(where);
		Page<Map> rlt = getPageByMap(queryItem, SCModule.REPORT, SCFunction.REP_MONTH_LIMIT);
		
		if(AccountTypeEnum.DEPARTMENT.getIndex() == user.getType()){
			List<Map> items = rlt.getItems();
			for( Map<String,Object> item : items ){
				String x= item.get("rep_date").toString();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy年M月");
				item.put("rep_date", sdf1.format(sdf.parse(x)));
				item.put("action", "查看业务员详情");
			}
		}
		return createSuccessJsonResonse(dataConvert(rlt));
	}
	
	/**
	 * 获取年度授信统计
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("year")
	public Map<String,Object> yearStatis(String type) throws Exception  {
		try {
			OrgFrontUser user = getUser();
			Map<String,Object> formData = Maps.newHashMap();
			Calendar now = Calendar.getInstance();  
			List<Where> where = new ArrayList<Where>();
			QueryItem queryItem = new QueryItem();
			String ym = now.get(Calendar.YEAR) + "";  
			this.addWhereCondition(where, "rep_date", LIKE_ALL, ym);
			int type1 = 3;
			if(AccountTypeEnum.DEPARTMENT.getIndex() == user.getType()){
				type1 = 1;
			}else if(AccountTypeEnum.SALER.getIndex() == user.getType()){
				type1 = 3;
			}
			this.addWhereCondition(where, "rec_category", type1);
			if(AccountTypeEnum.DEPARTMENT.getIndex() == user.getType()){
				this.addWhereCondition(where, "uid", user.getId());//部门id
			}
			if(AccountTypeEnum.SALER.getIndex() == user.getType()){
				this.addWhereCondition(where, "uid", user.getId());//业务员id
			}
			queryItem.setWhere(where);
			queryItem.setFields("id,rep_date as repDate,sum(pay_limit/10000) as payLimit,sum(total_back_limit/10000) as totalBackLimit,sum(new_customer_count) as newCustomerCount");
			queryItem.setGroup("rep_date");
			List<RepMonthLimit> creLimitInfos = this.getListByEntity(queryItem, SCModule.REPORT, SCFunction.REP_MONTH_LIMIT, RepMonthLimit.class);
			Map<String,Object> creditYear = new HashMap<String,Object>();
			Map<String,Object> data = new HashMap<String,Object>();
			data.put("data", formData);
			formData.put("credit_year", creditYear);
			
			String[] mon = new String[]{"一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"};
			BigDecimal de = new BigDecimal(0);
			BigDecimal[] pays = new BigDecimal[]{de,de,de,de,de,de,de,de,de,de,de,de};
			for(int i = 0;i < creLimitInfos.size();i ++){
				RepMonthLimit rep = creLimitInfos.get(i);
				BigDecimal tmp = new BigDecimal(0);
				if("put".equals(type)){
					creditYear.put("yName", "已放授信(万元)");
					creditYear.put("tipName", "已放授信");
					tmp = rep.getPayLimit();
				}else if("back".equals(type)){
					creditYear.put("yName", "已回授信(万元)");
					creditYear.put("tipName", "已回授信");
					tmp = rep.getTotalBackLimit();
				}else if("add".equals(type)){
					creditYear.put("yName", "新增客户(个)");
					creditYear.put("tipName", "新增客户");
					tmp = new BigDecimal(rep.getNewCustomerCount());
				}			
				changeMonthShowType(rep.getRepDate(), tmp, mon, pays);
			}
			creditYear.put("info", pays);
			creditYear.put("x_axis", mon);
			return data;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}
	
	private void changeMonthShowType(String month, BigDecimal pay, String[] mon,BigDecimal[] pays){
		if(StringUtils.isBlank(month) || month.length() < 5){
			return;
		}
		month = month.substring(4);
		switch(month){
		case "01":
			mon[0] = "一月";
			pays[0] = pay;
			break;
		case "02":
			mon[1] = "二月";
			pays[1] = pay;
			break;
		case "03":
			mon[2] = "三月";
			pays[2] = pay;
			break;
		case "04":
			mon[3] = "四月";
			pays[3] = pay;
			break;
		case "05":
			mon[4] = "五月";
			pays[4] = pay;
			break;
		case "06":
			mon[5] = "六月";
			pays[5] = pay;
			break;
		case "07":
			mon[6] = "七月";
			pays[6] = pay;
			break;
		case "08":
			mon[7] = "八月";
			pays[7] = pay;
			break;
		case "09":
			mon[8] = "九月";
			pays[8] = pay;
			break;
		case "10":
			mon[9] = "十月";
			pays[9] = pay;
			break;
		case "11":
			mon[10] = "十一月";
			pays[10] = pay;
			break;
		case "12":
			mon[11] = "十二月";
			pays[11] = pay;
			break;
		default:
			return;
		}
	}
	
	private OrgFrontUser getSaler(Long id) throws Exception{
		return this.getById(id, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
	}
	
	@ResponseBody
	@RequestMapping("depart/month")
	public Map<String,Object> departStatis(Long id) throws Exception  {
		try {
			if(id == null){
				return null;
			}
			OrgFrontUser user = getUser();
			QueryItem qitem = new QueryItem();
			List<Where> w1 = new ArrayList<Where>();
			this.addWhereCondition(w1, "id", id);
			qitem.setWhere(w1);
			RepMonthLimit monthLimit = this.getOneByEntity(qitem, SCModule.REPORT, SCFunction.REP_MONTH_LIMIT, RepMonthLimit.class);
			
			
			Map<String,Object> formData = Maps.newHashMap();
			QueryItem queryItem = new QueryItem();
			List<Where> w = new ArrayList<Where>();
			this.addWhereCondition(w, "rec_category", 3);// 业务员
			this.addWhereCondition(w, "dept_id", user.getId());
			this.addWhereCondition(w, "rep_date", LIKE_ALL, monthLimit.getRepDate());
			queryItem.setWhere(w);
			queryItem.setFields("id,uid,pay_limit as payLimit,new_customer_count as newCustomerCount");
			List<RepMonthLimit> limitInfos = this.getListByEntity(queryItem, SCModule.REPORT, 
					SCFunction.REP_MONTH_LIMIT, RepMonthLimit.class);
			
			Map<String,Object> sx = Maps.newHashMap();
			
			Map[] tmp = new Map[limitInfos.size()];
			Map[] tmp1 = new Map[limitInfos.size()];
			for(int i = 0;i < limitInfos.size();i ++){
				RepMonthLimit info = limitInfos.get(i);
				Map<String,Object> number = Maps.newHashMap();
				String name = getSaler(info.getUid()).getRealName();
				number.put("name", name);
				number.put("value", info.getPayLimit());
				tmp[i] = number;
				
				Map<String,Object> number1 = Maps.newHashMap();
				number1.put("name", name);
				number1.put("value", info.getNewCustomerCount());
				tmp1[i] = number1;
			}
			
			sx.put("number", tmp);
			sx.put("income", tmp1);
			formData.put("data", sx);
			return formData;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}
	
	@RequestMapping("salerDetail")
	public ModelAndView salerDetail(Long id) {
		ModelAndView view = new ModelAndView();
		try {
			TableHeader tableHeader = new TableHeader();
			tableHeader.setNames(new String[]{"real_name","pay_limit","total_back_limit","new_customer_count"});
			tableHeader.setTexts(new String[]{"业务员","已放授信","已回授信","新增客户"});
			tableHeader.setTypes(new String[]{"int", "","",""});
			PageStructure data = PageUtil.createTablePageStructure("credit/statistics/salerLogData/" + id, "id", tableHeader,null,null);
			SystemInfo system = new SystemInfo("backup/report/salerDetail.html");
			system.setSiteName("授信统计");
			view = this.initMemberPageView(system);
			view.addObject("data", JsonUtils.object2JsonString(data));
			Map<String,Object> tmp = new HashMap<String,Object>();
			tmp.put("id", id);
			
			QueryItem qitem = new QueryItem();
			List<Where> w = new ArrayList<Where>();
			this.addWhereCondition(w, "id", id);
			qitem.setWhere(w);
			RepMonthLimit monthLimit = this.getOneByEntity(qitem, SCModule.REPORT, SCFunction.REP_MONTH_LIMIT, RepMonthLimit.class);
			String month = monthLimit.getRepDate();
			OrgFrontUser user = getUser();
			List<Where> where = new ArrayList<Where>();
			QueryItem queryItem = new QueryItem();
			queryItem.setFields("id,rep_date as repDate,sum(pay_limit) as payLimit,sum(total_back_limit) as totalBackLimit,sum(new_customer_count) as newCustomerCount");
			this.addWhereCondition(where, "rep_date", LIKE_ALL, month);
			this.addWhereCondition(where, "rec_category", 3);//业务员
			this.addWhereCondition(where, "dept_id", user.getId());
			queryItem.setWhere(where);
			queryItem.setGroup("rep_date");
			RepMonthLimit rlt = this.getOneByEntity(queryItem, SCModule.REPORT, SCFunction.REP_MONTH_LIMIT, RepMonthLimit.class);
			
			tmp.put("id", id);
			tmp.put("putCredit", rlt == null ? 0 : rlt.getPayLimit());
			tmp.put("backCredit", rlt == null ? 0 : rlt.getTotalBackLimit());
			tmp.put("addCredit", rlt == null ? 0 : rlt.getNewCustomerCount());
			tmp.put("nowYearMonth", month.substring(0, 4) + "年" + month.substring(4) + "月");
			view.addObject("formData", JsonUtils.object2JsonString(tmp));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return view;
	}

	/**
	 * 获取数据:内部额度变动记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("salerLogData/{id}")
	public DyResponse salerLogData(Integer page,Integer limit,String search,@PathVariable("id")Long id) throws Exception {
		OrgFrontUser user = getUser();
		
		QueryItem qitem = new QueryItem();
		List<Where> w = new ArrayList<Where>();
		this.addWhereCondition(w, "id", id);
		qitem.setWhere(w);
		RepMonthLimit monthLimit = this.getOneByEntity(qitem, SCModule.REPORT, SCFunction.REP_MONTH_LIMIT, RepMonthLimit.class);
		
		List<Where> where = new ArrayList<Where>();
		QueryItem queryItem = new QueryItem();
		this.addWhereCondition(where, "rep_date", LIKE_ALL, monthLimit.getRepDate());
		this.addWhereCondition(where, "rec_category", 3);//业务员
		this.addWhereCondition(where, "dept_id", user.getId());
		queryItem.setWhere(where);
		queryItem.setOrders("pay_limit desc");
		Page<Map> rlt = getPageByMap(queryItem, SCModule.REPORT, SCFunction.REP_MONTH_LIMIT);
		this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_USER, "uid:real_name");
		return createSuccessJsonResonse(dataConvert(rlt));
	}
}