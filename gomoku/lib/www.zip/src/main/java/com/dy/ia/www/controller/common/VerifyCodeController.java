package com.dy.ia.www.controller.common;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.manager.util.SessionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dy.core.controller.FrontBaseController;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Email;
import com.dy.core.enumeration.SmsType;
import com.dy.core.utils.Constant;
import com.dy.core.utils.EmailUtil;
import com.dy.core.utils.GeetestUtil;
import com.dy.core.utils.GenNumUtil;
import com.dy.core.utils.sms.SmsUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.EmailType;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.www.entity.EmailVerifyCode;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Maps;


@Controller
public class VerifyCodeController extends FrontBaseController {
	@Autowired
	private EmailUtil emailUtil;
    private static Logger logger=LoggerFactory.getLogger(VerifyCodeController.class);
    
	public static final String VERIFY_CODES = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
	public static final String PHONE_VERIFY_CODES = "0123456789";
	private static Random random = new Random();

//	@RequestMapping("/common/public/{verifyType}/{r}")
//	public void getVerifyCode(HttpServletResponse response, @PathVariable("verifyType")String verifyType, @PathVariable("r")double r) {
//		if(!("verifycode".equals(verifyType) || "verifycode1".equals(verifyType))) return;
//		
//		Subject currentUser = SecurityUtils.getSubject();
//		Session session = currentUser.getSession();
//		if("verifycode1".equals(verifyType)) session.removeAttribute(Constant.SESSION_PHONE_CODE);
//		
//		ByteArrayOutputStream output = new ByteArrayOutputStream();
//		String code = drawImg(100, 36, output);
//		
//		session.setAttribute(Constant.SESSION_VERIFY_CODE, code);
//		Object obj = session.getAttribute(Constant.SESSION_PHONE_CODE);
//		if(obj != null && obj instanceof PhoneVerifyCode) {
//			PhoneVerifyCode phonVerifyCode = (PhoneVerifyCode)obj;
//			phonVerifyCode.setImgVerifyCode(code);
//			session.setAttribute(Constant.SESSION_PHONE_CODE, phonVerifyCode);
//		}
//
//		try {
//			ServletOutputStream out = response.getOutputStream();
//			output.writeTo(out);
//		} catch (IOException e) {
//			logger.error(e.getMessage(), e);
//		}
//	}

	@ResponseBody
	@RequestMapping(value = "/common/public/checkVerifyCode", method = RequestMethod.POST)
	public DyResponse checkVerifyCodeCtrl(String verifycode) {
		// 验证码校验
		this.checkVerifyCode(verifycode);
		
		return createSuccessJsonResonse("success");
	}

	@ResponseBody
	@RequestMapping(value = "/common/public/checkPhoneCode", method = RequestMethod.POST)
	public DyResponse checkPhoneCode(String phone_code) {
		// 验证码校验
		if ("".equals(phone_code))
			return createErrorJsonResonse("验证码不能为空!");
		String sessionVerifyCode = (String) this
				.getSessionAttribute(Constant.SESSION_PHONE_CODE);
		if (!phone_code.equalsIgnoreCase(sessionVerifyCode)) {
			return createErrorJsonResonse("fail");
		}
		return createSuccessJsonResonse("success");
	}

	/**
	 * 给定范围获得随机颜色
	 * 
	 * @param fc
	 * @param bc
	 * @return
	 */
	private static Color getRandColor(int fc, int bc) {
		Random random = new Random();
		if (fc > 255)
			fc = 255;
		if (bc > 255)
			bc = 255;
		int r = fc + random.nextInt(bc - fc);
		int g = fc + random.nextInt(bc - fc);
		int b = fc + random.nextInt(bc - fc);
		return new Color(r, g, b);
	}

	public static String drawImg(int w, int h, OutputStream os) {
		String code = generateVerifyCode(4);
		int verifySize = code.length();
		BufferedImage image = new BufferedImage(w, h,
				BufferedImage.TYPE_INT_RGB);
		Random rand = new Random();
		Graphics2D g2 = image.createGraphics();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		Color[] colors = new Color[5];
		Color[] colorSpaces = new Color[] { Color.WHITE, Color.CYAN,
				Color.GRAY, Color.LIGHT_GRAY, Color.MAGENTA, Color.ORANGE,
				Color.PINK, Color.YELLOW };
		float[] fractions = new float[colors.length];
		for (int i = 0; i < colors.length; i++) {
			colors[i] = colorSpaces[rand.nextInt(colorSpaces.length)];
			fractions[i] = rand.nextFloat();
		}
		Arrays.sort(fractions);

		g2.setColor(Color.GRAY);// 设置边框色
		g2.fillRect(0, 0, w, h);

		Color c = getRandColor(200, 250);
		g2.setColor(c);// 设置背景色
		g2.fillRect(0, 2, w, h - 4);

		// 绘制干扰线
		Random random = new Random();
		g2.setColor(getRandColor(160, 200));// 设置线条的颜色
		for (int i = 0; i < 20; i++) {
			int x = random.nextInt(w - 1);
			int y = random.nextInt(h - 1);
			int xl = random.nextInt(6) + 1;
			int yl = random.nextInt(12) + 1;
			g2.drawLine(x, y, x + xl + 40, y + yl + 20);
		}

		// 添加噪点
		float yawpRate = 0.05f;// 噪声率
		int area = (int) (yawpRate * w * h);
		for (int i = 0; i < area; i++) {
			int x = random.nextInt(w);
			int y = random.nextInt(h);
			int rgb = getRandomIntColor();
			image.setRGB(x, y, rgb);
		}

		shear(g2, w, h, c);// 使图片扭曲

		g2.setColor(getRandColor(100, 160));
		int fontSize = h - 4;
		Font font = new Font("Algerian", Font.ITALIC, fontSize);
		g2.setFont(font);
		char[] chars = code.toCharArray();
		for (int i = 0; i < verifySize; i++) {
			AffineTransform affine = new AffineTransform();
			affine.setToRotation(
					Math.PI / 4 * rand.nextDouble()
							* (rand.nextBoolean() ? 1 : -1), (w / verifySize)
							* i + fontSize / 2, h / 2);
			g2.setTransform(affine);
			g2.drawChars(chars, i, 1, ((w - 10) / verifySize) * i + 5, h / 2
					+ fontSize / 2 - 10);
		}
		g2.dispose();
		try {
			ImageIO.write(image, "jpg", os);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return code;
	}

	private static int getRandomIntColor() {
		int[] rgb = getRandomRgb();
		int color = 0;
		for (int c : rgb) {
			color = color << 8;
			color = color | c;
		}
		return color;
	}

	private static int[] getRandomRgb() {
		int[] rgb = new int[3];
		for (int i = 0; i < 3; i++) {
			rgb[i] = random.nextInt(255);
		}
		return rgb;
	}

	private static void shear(Graphics g, int w1, int h1, Color color) {
		shearX(g, w1, h1, color);
		shearY(g, w1, h1, color);
	}

	private static void shearY(Graphics g, int w1, int h1, Color color) {
		int period = random.nextInt(40) + 10; // 50;
		boolean borderGap = true;
		int frames = 20;
		int phase = 7;
		for (int i = 0; i < w1; i++) {
			double d = (double) (period >> 1)
					* Math.sin((double) i / (double) period
							+ (6.2831853071795862D * (double) phase)
							/ (double) frames);
			g.copyArea(i, 0, 1, h1, 0, (int) d);
			if (borderGap) {
				g.setColor(color);
				g.drawLine(i, (int) d, i, 0);
				g.drawLine(i, (int) d + h1, i, h1);
			}
		}
	}

	private static void shearX(Graphics g, int w1, int h1, Color color) {
		int period = random.nextInt(2);
		boolean borderGap = true;
		int frames = 1;
		int phase = random.nextInt(2);

		for (int i = 0; i < h1; i++) {
			double d = (double) (period >> 1)
					* Math.sin((double) i / (double) period
							+ (6.2831853071795862D * (double) phase)
							/ (double) frames);
			g.copyArea(0, i, w1, 1, (int) d, 0);
			if (borderGap) {
				g.setColor(color);
				g.drawLine((int) d, i, 0, i);
				g.drawLine((int) d + w1, i, w1, i);
			}
		}

	}

	public static String generateVerifyCode(int verifySize) {
		return generateVerifyCode(verifySize, VERIFY_CODES);
	}

	/**
	 * 使用指定源生成验证码
	 * 
	 * @param verifySize
	 *            验证码长度
	 * @param sources
	 *            验证码字符源
	 * @return
	 */
	public static String generateVerifyCode(int verifySize, String sources) {
		if (sources == null || sources.length() == 0) {
			sources = VERIFY_CODES;
		}
		int codesLen = sources.length();
		Random rand = new Random(System.currentTimeMillis());
		StringBuilder verifyCode = new StringBuilder(verifySize);
		for (int i = 0; i < verifySize; i++) {
			verifyCode.append(sources.charAt(rand.nextInt(codesLen - 1)));
		}
		return verifyCode.toString();
	}
	
	@RequestMapping("/common/public/getImageCode/{r}")
	public void getVerifyCode(HttpServletResponse response, @PathVariable("r")Long r) {
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		String code = drawImg(100, 36, output);
		Subject currentUser = SecurityUtils.getSubject();
		Session session = currentUser.getSession();
		session.setAttribute(Constant.SESSION_VERIFY_CODE, code);

		try {
			ServletOutputStream out = response.getOutputStream();
			output.writeTo(out);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				output.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	@ResponseBody
	@RequestMapping("/common/public/geetest")
	public String geetest() {
		String resStr = GeetestUtil.init();
		return resStr;
	}
	
	static LoadingCache<String, Integer> smsSendCount = CacheBuilder.newBuilder()
            .expireAfterWrite(24, TimeUnit.SECONDS)
            .maximumSize(100000).// 设置缓存个数
            build(new CacheLoader<String, Integer>() {
                @Override
                public Integer load(String key) throws Exception {
                    return 1;
                }
            });
	
	static LoadingCache<String, String> phoneCodeCache = CacheBuilder.newBuilder()
            .expireAfterWrite(5, TimeUnit.MINUTES)
            .maximumSize(100000).// 设置缓存个数
            build(new CacheLoader<String, String>() {
                @Override
                public String load(String key) throws Exception {
                    return null;
                }
            });
	
	/**
	 * 
	 * 获取手机验证码 
	 * @param key smsType=1 key为ip ,其他为userId
	 * @return
	 * @throws ExecutionException
	 * @author likf
	 */
	public static String getPhoneCode(String phone) throws ExecutionException{
	    return phoneCodeCache.getIfPresent(phone);
	}
	
	public static String getPhoneCode(String phone,Long r) throws ExecutionException{
	    return phoneCodeCache.getIfPresent(phone+"_"+r);
	}
	
	@Autowired
	private SmsUtil smsUtil;
	
	@RequestMapping("/common/public/getPhoneCode/{smsType}/{r}")
	@ResponseBody
    public DyResponse getPhoneCode(HttpServletResponse response,String phone,@PathVariable("smsType")int smsType, @PathVariable("r")Long r) throws Exception {
        
        if(smsType>=1&&smsType<=6){
            //TODO 验证码,短信验证码没过期
            //类型1 注册时匿名用户  
            
            String key=null;
            Long userId=null;
            String userRealName=null;
            if(smsType==SmsType.REALNAME.getIndex()){
                key=phone+"_"+r;
            }else{
                key=phone;
            }
            OrgFrontUser user=this.getUser();
            if(user == null){
            	userId=0L;
            }else{
            	userId=user.getId();
            	userRealName=user.getRealName();
            }
            
            //校验不能超过10次数
            String sendCountKey=key+"_"+smsType;
            Integer count=smsSendCount.get(sendCountKey);
            logger.debug("key:{} ,count:{}",sendCountKey,count);
            if(count>10){
                return createErrorJsonResonse("短信验证码输入错误超过10次,请明天在试.");
            }
            smsSendCount.put(sendCountKey, ++count);
            String code = generateVerifyCode(6, PHONE_VERIFY_CODES);
            
            int smsTemplateId = smsType;
            Map<String, String> templateParam = Maps.newHashMap();
            if(smsType==SmsType.REGISTER.getIndex()){
                templateParam.put("#code#", code);
                //TODO service_tel
                templateParam.put("#service_tel#", "");
            }else if(smsType==SmsType.RESET_PASSWORD.getIndex()){
                templateParam.put("#code#", code);
                templateParam.put("#service_tel#", "");
            }else if(smsType==SmsType.RESET_EMAIL.getIndex()){
                templateParam.put("#code#", code);
                templateParam.put("#service_tel#", "");
            }else if(smsType==SmsType.MOBILE_AUTH.getIndex()){
                templateParam.put("#code#", code);
                templateParam.put("#service_tel#", "");
            }else if(smsType==SmsType.REALNAME.getIndex()){
                templateParam.put("#code#", code);
                templateParam.put("#service_tel#", "");
            }
            smsUtil.send(phone, new Long(smsTemplateId), templateParam, smsType, SmsUtil.SEND_IMMEDIATE, userId, userRealName,ScConstants.APP_TYPE_FRONT);
           
//            Subject currentUser = SecurityUtils.getSubject();
//            Session session = currentUser.getSession();
//            session.setAttribute(Constant.SESSION_PHONE_CODE, code);
			phoneCodeCache.put(key, code);
        }

        return createSuccessJsonResonse(null,"发送成功,5分钟内有效");
    }
	/**
	 * 发送邮件
	 * @param email
	 * @param type
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/common/public/email/sendemail")
	public DyResponse sendemail(String email,Integer type,Long userId) throws Exception {
		//获取当前用户
		OrgFrontUser user = (OrgFrontUser) this.getSessionAttribute(Constant.SESSION_USER);
		if(user==null&&userId!=null){
			user=this.getById(userId, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
		}
		if(StringUtils.isBlank(email)&&user!=null){
			//判断邮箱是否被使用
//			List<Where> whereList = new ArrayList<Where>();
////			whereList.add(Where.eq("status", 1));
//			whereList.add(Where.eq("email", email));
//			if(!type.equals("register")){
//				whereList.add(Where.notEq("id", user.getId()));
//			}
//			String errorMsg = validateExist(email, "邮箱", SCModule.SYSTEM, SCFunction.SYS_USER, whereList);
//			if(org.apache.commons.lang.StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
//		}else{
			email = user.getEmail();
		}

//		user = getMember(user.getId());

		return send(user,email,type);
	}
	
	private DyResponse send(OrgFrontUser user,String email,Integer type) throws Exception{
		//发送激活邮箱,将验证码和email存入session
		String verifyCode = GenNumUtil.random(6);
		EmailVerifyCode emailVerifyCode = EmailVerifyCode.getCode(email, verifyCode, 60);
		if(emailVerifyCode.getErrorMsg() != null) return createErrorJsonResonse(emailVerifyCode.getErrorMsg());
		
		//组装email
		Email newEmail = new Email();
		if(user!=null){
			newEmail.setMemberId(user.getId());
			newEmail.setMemberName(user.getRealName());
		}else{
			if(EmailType.REGISTER.getIndex()==type){
				newEmail.setMemberName(EmailType.REGISTER.getName());
			}else if(EmailType.RESET_PASSWORD.getIndex()==type){
				newEmail.setMemberName(EmailType.RESET_PASSWORD.getName());
			}else if(EmailType.RESET_EMAIL.getIndex()==type){
				newEmail.setMemberName(EmailType.RESET_EMAIL.getName());
			}
		}
//		if(StringUtils.isNotBlank(type) && (type.equals("reset")||type.equals("register"))){
//			newEmail.setType(1);//重设email或者设置
//		}else{
//			newEmail.setType(0);
//		}
		newEmail.setType(type);
		String[] arr = {email};
		newEmail.setTo(arr);
		Map<String, String> map = new HashMap<String, String>();
//		map.put("#email_account#", getEmailPort().getEmailAccount());
//		map.put("#web_name#", getSysConfig("site_name"));
//		map.put("#web_url#", "http://" + getSysConfig("site_domain"));
		map.put("#code#", verifyCode);
//		map.put("#web_now_time#", DateUtil.dateTimeFormat(new Date()));
//		map.put("#logo#", PropertiesUtil.getImageHost() + getSysConfig("site_logo"));
//		map.put("#member_name#", user.getRealName());
//		map.put("#email#", email);
//		map.put("#web_time#", DateUtil.dateFormat(DateUtil.getCurrentTime()));
//		map.put("#member_url#", "http://" + getSysConfig("site_domain") + "/member/member/center");
//		map.put("#service_qq_name#", getSysConfig("service_qq"));
//		map.put("#service_tel#", getSysConfig("service_tel"));
//		map.put("#service_hours#", getSysConfig("service_hours"));
//		map.put("#site_copyright#", getSysConfig("site_copyright"));
		newEmail.setTemplateParam(map);
//		if(StringUtils.isNotBlank(type) && type.equals("reset")){
//			newEmail.setTemplateType(4);
//		}else{
//			newEmail.setTemplateType(1);
//		}
		newEmail.setTemplateType(3);
		//测试要求发送失败验证码也可以用
		Map<String, Object> sessionMap = new HashMap<String, Object>();
		sessionMap.put("sessionCode", verifyCode);
		sessionMap.put("sessionEmail", email);
		if (this.getSessionAttribute("sessionMap") != null) {
			this.removeSessionAttribute("sessionMap");
		}
		this.setSessionAtrribute("sessionMap", sessionMap);
		
		boolean sendStatus = emailUtil.send(newEmail, EmailUtil.SEND_IMMEDIATE);
		if (sendStatus == false) {
			return createErrorJsonResonse("邮箱发送失败！");
		}
		return createSuccessJsonResonse(null, "邮箱发送成功！");
	}
}