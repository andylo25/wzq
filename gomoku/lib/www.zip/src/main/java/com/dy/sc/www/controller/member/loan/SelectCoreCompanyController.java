package com.dy.sc.www.controller.member.loan;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.adapter.AdapterManager;
import com.dy.core.adapter.FrontLoanAdapter;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.ia.entity.enumeration.ReceiveBillStatusEnum;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.credit.CreCompanyLimit;
import com.dy.sc.entity.enumeration.CheckStatus;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.enumeration.MortgageType;
import com.dy.sc.entity.loan.LoanRequest;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.entity.product.ProdFeeValue;
import com.dy.sc.entity.product.ProdProductInfo;
import com.dy.sc.entity.system.CompanyRelation;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * @ClassName: SelectCoreCompanyController.java 
 * @Description:
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author diyou@diyou.cn
 * @date 2017年8月16日上午9:44:32 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * diyou 
 * </pre>
 */	
@Controller
@RequestMapping("/member/loan")
public class SelectCoreCompanyController extends FrontBaseController {
    
    @RequestMapping("selectCoreCompany")
	public ModelAndView selectCoreCompany(Long productId,String productName, Integer businessId) throws Exception {
    	
		Map<String,Object> formData = Maps.newHashMap();		
		formData.put("productName", productName);
		formData.put("productId", productId);
		ProdProductInfo product = null;
		if (productId != null) {
			product = this.getById(productId, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
			businessId = product.getBusinessTypeId(); 
		}
		
		FrontLoanAdapter loanAdapter = AdapterManager.getFrontLoanAdapter(businessId);
		if(loanAdapter != null){
			return loanAdapter.toFirstStep(formData, product);
		}
		return null;
	}

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @RequestMapping("requestLoan")
	public ModelAndView requestLoan(Long productId) throws Exception {
		OrgFrontUser user=(OrgFrontUser)this.getSessionAttribute(Constant.SESSION_USER);
		
		ProdProductInfo prod=this.getById(productId, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
		QueryItem relationItem = new QueryItem();
		relationItem.setFields("core_company_id as id,check_status");	
		relationItem.getWhere().add(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));		
		relationItem.getWhere().add(Where.eq("company_id", user.getCompanyId()));
		if(StringUtils.isNoneBlank(prod.getCoreCompanyIds())){
		    relationItem.setWhere(Where.in("core_company_id", prod.getCoreCompanyIds()));
		}
		relationItem.getWhere().add(Where.eq("check_status", CheckStatus.CHECK_PASS.getIndex()));
		List<Map> relations=this.getListByMap(relationItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
		this.idToName(relations, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "id:company_name");

		ProdProductInfo productInfo = this.getById(productId,SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO,ProdProductInfo.class);
        QueryItem feeValueQuery = new QueryItem();
        feeValueQuery.getWhere().add(Where.eq("product_id", productId));
        feeValueQuery.getWhere().add(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
        feeValueQuery.setOrders(" product_id desc");
        List<ProdFeeValue> feeValues = this.getListByEntity(feeValueQuery, SCModule.PRODUCT, SCFunction.PROD_FEE_VALUE,ProdFeeValue.class);
        List<Map> feeList=Lists.newArrayList();
        String unit = "个月";
        //质押类型
        if(MortgageType.DAY.getIndex() == productInfo.getMortgageType()){//按天
            unit="天";
        }
        for(ProdFeeValue feeValue:feeValues){
            Map<String,Object> item=(Map<String,Object>)new DataConvertUtil(feeValue, false).convert();
            item.put("loanTime", feeValue.getLoanDay()+unit);
            BigDecimal loanDayRate=BigDecimal.ZERO;
            if(feeValue.getLoanApr()!=null){
                //除以360天 *100
                loanDayRate=NumberUtils.round(NumberUtils.div(feeValue.getLoanApr(), new BigDecimal(360.0/100)),3);
            }
            item.put("loanDayRate", loanDayRate);
            feeList.add(item);
        }
		
		Map<String,Object> formData = Maps.newHashMap();
		formData.put("companies", relations);
		formData.put("productId", productId);
		formData.put("product", productInfo);
		formData.put("feeList", feeList);
		formData.put("companyId", user.getCompanyId());
		
		// 可用额度
		ProdProductInfo product=this.getById(productId, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO,ProdProductInfo.class);
		QueryItem queryLimit = new QueryItem(Where.eq("company_id", user.getCompanyId()));
		queryLimit.setWhere(Where.eq("check_status", ScConstants.LIMIT_PASS));
        queryLimit.setWhere(Where.eq("business_type_id", ScConstants.CONTRACT_TYPE_RECEIVE));// 应收账款
        CreCompanyLimit limit = this.getOneByEntity(queryLimit, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        if(product.getUseCreditLimit() == 1){// 开启了额度
        	formData.put("limit", limit == null ? 0 : limit.getUnusedLimit());
        }
		formData.put("creditTypeList", DictUtils.getOptions("credit_type"));
		
		return createSuccessModelAndView("member/loan/requestLoan", JsonUtils.object2JsonString(formData));
	}
	
	@RequestMapping("submitRelation")
	@ResponseBody
	public DyResponse submitRelation(Long coreId,Long productId, Integer businessId) throws Exception{
		if(coreId!=null){
			CompanyRelation relation=new CompanyRelation();
			relation.setCheckStatus(CheckStatus.CHECK_TODO.getIndex());
			relation.setCompanyId(getUser().getCompanyId());
			relation.setCoreCompanyId(coreId);
			this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION, relation);
		}
		Map<String,Object> formData = Maps.newHashMap();
		FrontLoanAdapter loanAdapter = AdapterManager.getFrontLoanAdapter(businessId);
		if(loanAdapter != null){
			loanAdapter.toFirstStep(formData, null);
			return createSuccessJsonResonse(formData);
		}
		
		return null;
	}
	
	@RequestMapping("reSubmitRelation")
	@ResponseBody
	public DyResponse reSubmitRelation(Long coreId, Long productId, Integer businessId) throws Exception{
		if(coreId!=null){
			QueryItem relationItem = new QueryItem(Where.eq("company_id", getUser().getCompanyId()));
			relationItem.getWhere().add(Where.eq("core_company_id", coreId));
			relationItem.getWhere().add(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
			CompanyRelation relation=this.getOneByEntity(relationItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION, CompanyRelation.class);
			relation.setCheckStatus(CheckStatus.CHECK_TODO.getIndex());
			this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION, relation);
		}
		Map<String,Object> formData = Maps.newHashMap();
		FrontLoanAdapter loanAdapter = AdapterManager.getFrontLoanAdapter(businessId);
		if(loanAdapter != null){
			loanAdapter.toFirstStep(formData, null);
			return createSuccessJsonResonse(formData);
		}
		
		return null;
	}
	
	/**
	 * 三份协议签属完成，将融资数据置保存
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("submitResult")
	public ModelAndView submitResult(Long id) throws Exception {
		Map<String,Object> formData = Maps.newHashMap();
		LoanRequest request = this.getById(id, SCModule.LOAN, SCFunction.LOAN_REQUEST, LoanRequest.class);
    	formData.put("productId", request.getProductId());
		return createSuccessModelAndView("member/loan/submitResult", JsonUtils.object2JsonString(formData));
	}

	@RequestMapping("submitResultMoney")
	public ModelAndView submitResultMoney(Long id) throws Exception {
		Map<String,Object> formData = Maps.newHashMap();
		LoanRequest request = this.getById(id, SCModule.LOAN, SCFunction.LOAN_REQUEST, LoanRequest.class);
		formData.put("productId", request.getProductId());
		return createSuccessModelAndView("member/loan/submitResultMoney", JsonUtils.object2JsonString(formData));
	}

    /**
     * 校验凭证编号和商务合同号是否存在
     * @param
     * @return
     * @throws Exception
     */
    private boolean isNumberExists(String number) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields("count(1) as count");
        List<Where> where = new ArrayList<Where>();
        //凭证编号
        this.addWhereCondition(where, "credit_no", number);
        this.addWhereCondition(where, "del_flag", 0);
        query.setWhere(where);
        query.getWhere().add(Where.notEq("receive_bill_status", ReceiveBillStatusEnum.REJECT.getIndex()));
        boolean exist=false;
        Map<String, Object> result = this.getOneByMap(query, SCModule.LOAN, SCFunction.LOAN_RECEIVE_BILL);
        if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
        	exist = true;
        }else{
        	//商务合同号
          	QueryItem numberQuery = new QueryItem();
          	numberQuery.setFields("count(1) as count");
          	numberQuery.getWhere().add(Where.eq("buss_contract_no", number));
          	numberQuery.getWhere().add(Where.notEq("receive_bill_status", ReceiveBillStatusEnum.REJECT.getIndex()));
          	numberQuery.getWhere().add(Where.eq("del_flag", 0));
        	result = this.getOneByMap(numberQuery, SCModule.LOAN, SCFunction.LOAN_RECEIVE_BILL);
        	if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
        		exist = true;
            }
        }
        return exist;
    }
    
    @RequestMapping("checkNumber")
	@ResponseBody
	public DyResponse checkNumber(String creditNo,String bussContractNo) throws Exception {
    	Map<String,Object> data = Maps.newHashMap(); 
        if (StringUtils.isNotBlank(creditNo)&&isNumberExists(creditNo)) {
            return createErrorJsonResonse("凭证编号已存在，请确认凭证编号没有错误后，重新输入！");
        }
        if(StringUtils.isNotBlank(bussContractNo)&&isNumberExists(bussContractNo)){
        	return createErrorJsonResonse("商务合同号已存在，请确认商务合同号没有错误后，重新输入！");
        }
        return createSuccessJsonResonse(data);
    }
}