package com.dy.sc.www.controller.member.manager;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.FrontBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.RepayUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.loan.RepMonthB2BDebit;
import com.dy.sc.entity.org.OrgFrontUser;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 对账管理
 *
 * @author lpp
 */
@Controller
@RequestMapping("/member/manager/companyCheck")
public class CompanyCheckController extends FrontBaseController {
    private static final int TYPE_ONE = 1;

    @RequestMapping(value = "/check/{type}")
    public ModelAndView list(@PathVariable("type") int type) throws Exception {
        ModelAndView view = new ModelAndView("member/manager/companyCheck");
        Map<String, Object> viewData = Maps.newHashMap();
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"rep_date", "debit_count", "total_amount", "payment", "detail"});
        tableHeader.setTexts(new String[]{"对账时间", "贷款笔数", "贷款总额", "应还总额", "详情$详情"});
        tableHeader.setTypes(new String[]{"", "", "number", "number", "link"});

        PageStructure data = PageUtil.createTablePageStructure("member/manager/companyCheck/listData/" + type, "member/manager/companyCheck/view", "id", tableHeader, null, null);
        viewData.put("list", data);
        viewData.put("currentStatus", type);
        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;
    }

    /**
     * 还款页面
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "/checkInfo")
    public ModelAndView repayInfo(Long id) throws Exception {
        ModelAndView view = new ModelAndView("member/manager/repayInfo");
        Map<String, Object> viewData = Maps.newHashMap();
        //还款期数表数据
        QueryItem item = new QueryItem();
        item.setWhere(Where.eq("id", id));
        Map<String, Object> period = this.getOneByMap(item, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
        //信贷记录表
        item = new QueryItem();
        item.setWhere(Where.eq("id", period.get("debit_id")));
        Map<String, Object> record = this.getOneByMap(item, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);

        //逾期费用
        int days = DateUtil.daysBetween(DateUtil.dateParse(Long.parseLong(record.get("contract_end_time").toString())), DateUtil.getCurrentDate());
        BigDecimal feeAmount = RepayUtil.calOverdueFeeAnyTime(record.get("overdue_rate_value").toString(),
                (BigDecimal) period.get("principal"), (BigDecimal) period.get("principal_yes"),
                days);
        //还款总额
        BigDecimal allAmount = NumberUtils.add(feeAmount, new BigDecimal(period.get("principal").toString()), new BigDecimal(period.get("interest").toString()));
        viewData.put("period_id", period.get("id"));
        viewData.put("loan_contract_no", period.get("loan_contract_no"));//借款合同
        viewData.put("principal", period.get("principal"));//授信金额
        viewData.put("repay_time", DateUtil.dateFormat(Long.parseLong(period.get("repay_time").toString())));//应还款日期
        viewData.put("interest", period.get("interest"));//应还利息
        viewData.put("amount", period.get("amount"));//应还本金
        viewData.put("feeAmount", feeAmount);//逾期手续费
        viewData.put("allAmount", allAmount);//还款总额
        view.addObject("data", JsonUtils.object2JsonString(viewData));
        return view;

    }

    /**
     * 待对账列表
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("/listData/{type}")
    public DyResponse listData(Integer page, Integer limit, @PathVariable("type") int type) throws Exception {
        OrgFrontUser user = getUser();
        //还款记录
        QueryItem qitem = new QueryItem();
        qitem.setPage(page == null ? 1 : page);
        qitem.setLimit(limit == null ? 10 : limit);
        qitem.getWhere().add(Where.eq("company_id", user.getCompanyId()));
        if (type == TYPE_ONE) {
            qitem.getWhere().add(Where.eq("status", ScConstants.CHECK_CONFIRM_WILL));
        } else {
            qitem.getWhere().add(Where.ge("status", ScConstants.CHECK_CONFIRMED));
        }
        qitem.setOrders("id desc");
        Page pageObj = this.getPageByMap(qitem, SCModule.REPORT, SCFunction.MONTH_B2B_DEBIT);
        List<Map> data = pageObj.getItems();
        if (data != null && data.size() > 0) {
            for (Map item : data) {
                item.put("detail", "/member/manager/companyCheck/view?id=" + item.get("id").toString());
            }
        }

        return createSuccessJsonResonse(pageObj);
    }

    @SuppressWarnings("unchecked")
    @RequestMapping("/view")
    public ModelAndView view(Long id) throws Exception {
        RepMonthB2BDebit debit = this.getById(id, SCModule.REPORT, SCFunction.MONTH_B2B_DEBIT, RepMonthB2BDebit.class);

        QueryItem queryItem = new QueryItem();
        queryItem.setFields("*");
        String month = debit.getRepDate();
        Date start = DateUtil.dateParse(month + "01");
        Date end = DateUtil.addMonth(start, 1);
        queryItem.setWhere(Where.between("create_time", DateUtil.convert(start), DateUtil.convert(end)));
        queryItem.setOrders("id desc");
        queryItem.setWhere(Where.eq("company_id", debit.getCompanyId()));
        queryItem.setWhere(Where.eq("business_type", ScConstants.CONTRACT_TYPE_B2B));
        List<Integer> ls = Lists.newArrayList();
        ls.add(AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT);
        ls.add(AccConstants.CREDIT_RECORD_STATUS_REPAY);
        ls.add(AccConstants.CREDIT_RECORD_ADVANCE_REPAY);
        queryItem.setWhere(Where.in("status", ls));
        List<Map> pagem = this.getListByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
        this.idToName(pagem, SCModule.FUND, SCFunction.FUND_LOAN_REPAY, "id#debit_id:success_time,expire_time,amount_total,amount_yes,interest_total,principal_total,next_repay_time");
        for (Map map : pagem) {
            map.put("success_time", DateUtil.dateFormat(map.get("success_time")));
            map.put("expire_time", DateUtil.dateFormat(map.get("expire_time")));
            map.put("next_repay_time", DateUtil.dateFormat(map.get("next_repay_time")));
            map.put("create_time", DateUtil.dateFormat(map.get("create_time")));
            map.put("status", DictUtils.getDictLabel(map.get("status").toString(), "credit_record_status"));
        }

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("debits", pagem);
        result.put("id", id);
        result.put("status", debit.getStatus());
        result.put("debitsize", pagem.size());
        result.put("amount", debit.getTotalAmount());
        result.put("payamount", debit.getPayment());
        result.put("date", month.substring(0, 4) + "年" + month.substring(4, 6) + "月");
        return createSuccessModelAndView("member/manager/checkDetail", JsonUtils.object2JsonNoEscaping(result));
    }

    /**
     * 确认对账
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/confirmsettle")
    public DyResponse confirm(Long id) throws Exception {
        RepMonthB2BDebit debit = this.getById(id, SCModule.REPORT, SCFunction.MONTH_B2B_DEBIT, RepMonthB2BDebit.class);
        debit.setConfirmCheck(DateUtil.convert(new Date()));
        debit.setStatus(ScConstants.CHECK_CONFIRMED);
        this.update(SCModule.REPORT, SCFunction.MONTH_B2B_DEBIT, debit);

        return createSuccessJsonResonse(null, "确认对账成功");
    }

}