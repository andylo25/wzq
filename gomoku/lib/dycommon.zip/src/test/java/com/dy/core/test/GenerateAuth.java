package com.dy.core.test;

import java.util.HashMap;
import java.util.Map;

import com.dy.core.utils.SecurityUtil;
import com.dy.core.utils.rsa.RsaUtil;
import com.dy.core.utils.serializer.SerializerUtil;

public class GenerateAuth {

	private static String privateKey = "MIICXQIBAAKBgQC3//sR2tXw0wrC2DySx8vNGlqt3Y7ldU9+LBLI6e1KS5lfc5jlTGF7KBTSkCHBM3ouEHWqp1ZJ85iJe59aF5gIB2klBd6h4wrbbHA2XE1sq21ykja/Gqx7/IRia3zQfxGv/qEkyGOx+XALVoOlZqDwh76o2n1vP1D+tD3amHsK7QIDAQABAoGBAKH14bMitESqD4PYwODWmy7rrrvyFPEnJJTECLjvKB7IkrVxVDkp1XiJnGKH2h5syHQ5qslPSGYJ1M/XkDnGINwaLVHVD3BoKKgKg1bZn7ao5pXT+herqxaVwWs6ga63yVSIC8jcODxiuvxJnUMQRLaqoF6aUb/2VWc2T5MDmxLhAkEA3pwGpvXgLiWL3h7QLYZLrLrbFRuRN4CYl4UYaAKokkAvZly04Glle8ycgOc2DzL4eiL4l/+x/gaqdeJU/cHLRQJBANOZY0mEoVkwhU4bScSdnfM6usQowYBEwHYYh/OTv1a3SqcCE1f+qbAclCqeNiHajCcDmgYJ53LfIgyv0wCS54kCQAXaPkaHclRkQlAdqUV5IWYyJ25foiq+Y8SgCCs73qixrU1YpJy9yKA/meG9smsl4Oh9IOIGI+zUygh9YdSmEq0CQQC24G3IP2G3lNDRdZIm5NZ7PfnmyRabxk/UgVUWdk47IwTZHFkdhxKfC8QepUhBsAHLQjifGXY4eJKUBm3FpDGJAkAFwUxYssiJjvrHwnHFbg0rFkvvY63OSmnRxiL4X6EYyI9lblCsyfpl25l7l5zmJrAHn45zAiOoBrWqpM5edu7c";
	private static String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC3//sR2tXw0wrC2DySx8vNGlqt3Y7ldU9+LBLI6e1KS5lfc5jlTGF7KBTSkCHBM3ouEHWqp1ZJ85iJe59aF5gIB2klBd6h4wrbbHA2XE1sq21ykja/Gqx7/IRia3zQfxGv/qEkyGOx+XALVoOlZqDwh76o2n1vP1D+tD3amHsK7QIDAQAB";

	public static void main(String[] args) {
		String encrypt = generateData();
		checkData(encrypt);
	}

	private static String generateData() {
        String date = "2018-12-31";
        // String domain = "diyou.cc,beescf.com,showttem.com";
		String domain = "jiuxinxinxi.com,diyou.cc,beescf.com,566.sh";

		Map<String, String> map = new HashMap<String, String>();
		map.put("domain", domain);
		map.put("date", date);
		try {
			byte[] data2 = new SerializerUtil().serialize(map);
			byte[] data3 = RsaUtil.encryptByPrivateKey(data2, privateKey);
			String encrypt=SecurityUtil.encode(data3);
			System.out.println(encrypt);
			return encrypt;
		} catch (Exception ex) {
			System.out.print(ex.getStackTrace());
		}
		return null;
	}

	private static void checkData(String encrypt) {
		try {
			Map authMap = (Map) new SerializerUtil()
					.unserialize(RsaUtil.decryptByPublicKey(SecurityUtil.decode(encrypt), publicKey));
			System.out.println(authMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
