package com.dy.core.test;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import com.dy.core.utils.SecurityUtil;
import com.dy.core.utils.rsa.RsaUtil;
import com.dy.core.utils.serializer.SerializerUtil;


public class Auth {
	
	private static   String privateKey = "MIICXQIBAAKBgQCzW4qQuFMeGOyeazZuQ5ldB0s0QF2bNtAE6okj80ovg/3OeoT6izdlKUJ1gIydiGLLWjYwTo/leJHtHNoglHmHeY+G6VbebA3YugB3fNUmOZHjCbJoCv6HfESjum64MtVs6e2cpEOjNf31moYpxRxMEazmgM/e5gdVL696kdKUUQIDAQABAoGAaCsfhEP5yj4xlySvnUTXmsc0r2k+tHoWQPSyp9WSXZxsWXKhLx6SEsfu2G3LvWbL8k03scC/JEhtgGhEa62wErxYvH9gfKZ8PKdmA11XQYLE+nw+HtQglZKdiFR2IlY2tpXnOs0KtJscZTCFkztsMLr/+Eh9CyomYLB/f/3olZECQQDlLbqufTZN0bej0SoE2rPA96lwQNuXKo0LIoiLcoh8VrDU5NcHHROLBZmJ4Iu2h3GjXOq2sVi3qqnpPdsPcyVdAkEAyFkoA78p/cwxT70fRHt0IdZ1ZWHzh1tO1aXiDjicgVycIYgm29uJ2fL4Z39UZ2eiqQJyqASNRoDqNVNf1ZsnhQJBALN4PisKzw3d34uf7uHiSsYgrEXF5LDal51Sq89YH94PHWd61ZEyie1iszwv5flI1Ar0ZrIu66TZNzn6QKQ2rdkCQQC+gTBwZ5zZLQmSpeWOa8lgx5j3ny0+/w62TrbmCOSgiVwY8mro0heBe+zCFSw/6yabiK1XoIRpjvmlXTMaXR81AkBYAExx6auF5aGG3YxpI4WVrc9/gs/hmylfbm0WRlSVbKd+TSQXk6c38ZA5N+p6phNDF4JDnOHi3qxuP6/9tIYw";
	private  static String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC3//sR2tXw0wrC2DySx8vNGlqt3Y7ldU9+LBLI6e1KS5lfc5jlTGF7KBTSkCHBM3ouEHWqp1ZJ85iJe59aF5gIB2klBd6h4wrbbHA2XE1sq21ykja/Gqx7/IRia3zQfxGv/qEkyGOx+XALVoOlZqDwh76o2n1vP1D+tD3amHsK7QIDAQAB";
	 
	
	public static byte[] encrypt(byte[] data){
		try {
			byte[] bytes= RsaUtil.encryptByPrivateKey(data, privateKey);
			return bytes;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private static Map decrypt(String data){
		try {
			//base64
			//解密
			//反序列
			byte[] data1=SecurityUtil.decode(data);
			byte[] data2= RsaUtil.decryptByPublicKey(data1, publicKey);
			Map result=(Map) new SerializerUtil().unserialize(data2);
			System.out.println("result:"+result);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws UnsupportedEncodingException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		try {
//			Map keys=RsaUtil.genKeyPair();
			
//			publicKe
//			privateKey=RsaUtil.getPrivateKey(keys);
//			publicKey =map.get("RSAPublicKey").toString();
//			publicKey =RsaUtil.getPublicKey(keys);
			
			
			privateKey = "MIICXQIBAAKBgQC3//sR2tXw0wrC2DySx8vNGlqt3Y7ldU9+LBLI6e1KS5lfc5jlTGF7KBTSkCHBM3ouEHWqp1ZJ85iJe59aF5gIB2klBd6h4wrbbHA2XE1sq21ykja/Gqx7/IRia3zQfxGv/qEkyGOx+XALVoOlZqDwh76o2n1vP1D+tD3amHsK7QIDAQABAoGBAKH14bMitESqD4PYwODWmy7rrrvyFPEnJJTECLjvKB7IkrVxVDkp1XiJnGKH2h5syHQ5qslPSGYJ1M/XkDnGINwaLVHVD3BoKKgKg1bZn7ao5pXT+herqxaVwWs6ga63yVSIC8jcODxiuvxJnUMQRLaqoF6aUb/2VWc2T5MDmxLhAkEA3pwGpvXgLiWL3h7QLYZLrLrbFRuRN4CYl4UYaAKokkAvZly04Glle8ycgOc2DzL4eiL4l/+x/gaqdeJU/cHLRQJBANOZY0mEoVkwhU4bScSdnfM6usQowYBEwHYYh/OTv1a3SqcCE1f+qbAclCqeNiHajCcDmgYJ53LfIgyv0wCS54kCQAXaPkaHclRkQlAdqUV5IWYyJ25foiq+Y8SgCCs73qixrU1YpJy9yKA/meG9smsl4Oh9IOIGI+zUygh9YdSmEq0CQQC24G3IP2G3lNDRdZIm5NZ7PfnmyRabxk/UgVUWdk47IwTZHFkdhxKfC8QepUhBsAHLQjifGXY4eJKUBm3FpDGJAkAFwUxYssiJjvrHwnHFbg0rFkvvY63OSmnRxiL4X6EYyI9lblCsyfpl25l7l5zmJrAHn45zAiOoBrWqpM5edu7c";
			publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC3//sR2tXw0wrC2DySx8vNGlqt3Y7ldU9+LBLI6e1KS5lfc5jlTGF7KBTSkCHBM3ouEHWqp1ZJ85iJe59aF5gIB2klBd6h4wrbbHA2XE1sq21ykja/Gqx7/IRia3zQfxGv/qEkyGOx+XALVoOlZqDwh76o2n1vP1D+tD3amHsK7QIDAQAB";
			System.out.println("public:\n"+publicKey);
			System.out.println("privateKey:\n"+privateKey);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//序列
		//加密
		//base64
		
		//byte[] data="aa".getBytes("UTF-8");
		Map data1=new HashMap();
        data1.put("domain", "diyou.cc,beescf.com,jiuxinxinxi.com");
        data1.put("date", "2019-12-31");
		byte[] data2=new SerializerUtil().serialize(data1);
//		byte[] data = new byte[] { (byte) 0xbe, (byte) 0xef , (byte) 0xef};
		byte[] data3=Auth.encrypt(data2);
		
		String encrypt=SecurityUtil.encode(data3);
		System.out.println("authInfo");
		System.out.println(encrypt);
		Auth.decrypt(encrypt);
		Map authMap = null;
		try {
			String authKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC3//sR2tXw0wrC2DySx8vNGlqt3Y7ldU9+LBLI6e1KS5lfc5jlTGF7KBTSkCHBM3ouEHWqp1ZJ85iJe59aF5gIB2klBd6h4wrbbHA2XE1sq21ykja/Gqx7/IRia3zQfxGv/qEkyGOx+XALVoOlZqDwh76o2n1vP1D+tD3amHsK7QIDAQAB";
			//String authInfo = PropertiesUtil.getProperty(encrypt);
			//authMap = (Map)new SerializerUtil().unserialize(RsaUtil.decryptByPublicKey(SecurityUtil.decode(encrypt), authKey));
			String oldEncrypt = "faSReWzxK75S1j1XUmw82o00BsfvK1YUwT/CIcAH5nc5WRibjPKLxYEsfTTiAzkeksNIfrVXzbRO5CUEklNZGfbe+VkHqGF3g9E0fcIjphaxw5CEVUH63gI04FoDf3e9B+rd78eQrdbpnAVjyW+bo98FquVR+yB6pX9/u4juwfI=";
			byte[] de_data1 = SecurityUtil.decode(oldEncrypt);
			byte[] de_data2= RsaUtil.decryptByPublicKey(de_data1, authKey);
			Map result=(Map) new SerializerUtil().unserialize(de_data2);
			System.out.println("result:"+result);
			
			System.out.println((String)result.get("date"));
			System.out.println((String)result.get("domain"));
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main1(String[] args) throws Exception {
		String privateKey = "MIICXQIBAAKBgQCzW4qQuFMeGOyeazZuQ5ldB0s0QF2bNtAE6okj80ovg/3OeoT6izdlKUJ1gIydiGLLWjYwTo/leJHtHNoglHmHeY+G6VbebA3YugB3fNUmOZHjCbJoCv6HfESjum64MtVs6e2cpEOjNf31moYpxRxMEazmgM/e5gdVL696kdKUUQIDAQABAoGAaCsfhEP5yj4xlySvnUTXmsc0r2k+tHoWQPSyp9WSXZxsWXKhLx6SEsfu2G3LvWbL8k03scC/JEhtgGhEa62wErxYvH9gfKZ8PKdmA11XQYLE+nw+HtQglZKdiFR2IlY2tpXnOs0KtJscZTCFkztsMLr/+Eh9CyomYLB/f/3olZECQQDlLbqufTZN0bej0SoE2rPA96lwQNuXKo0LIoiLcoh8VrDU5NcHHROLBZmJ4Iu2h3GjXOq2sVi3qqnpPdsPcyVdAkEAyFkoA78p/cwxT70fRHt0IdZ1ZWHzh1tO1aXiDjicgVycIYgm29uJ2fL4Z39UZ2eiqQJyqASNRoDqNVNf1ZsnhQJBALN4PisKzw3d34uf7uHiSsYgrEXF5LDal51Sq89YH94PHWd61ZEyie1iszwv5flI1Ar0ZrIu66TZNzn6QKQ2rdkCQQC+gTBwZ5zZLQmSpeWOa8lgx5j3ny0+/w62TrbmCOSgiVwY8mro0heBe+zCFSw/6yabiK1XoIRpjvmlXTMaXR81AkBYAExx6auF5aGG3YxpI4WVrc9/gs/hmylfbm0WRlSVbKd+TSQXk6c38ZA5N+p6phNDF4JDnOHi3qxuP6/9tIYw";
		String date = "3091881600";
		String domain = "diyou.cc";
		
		Map<String, String> requestMap = new LinkedHashMap<String, String>();
		requestMap.put("date", date);
		requestMap.put("domain", domain);
		try {
			byte[] serialString = new SerializerUtil().serialize(requestMap);			
			System.out.println(new String(serialString,"UTF-8"));
			byte[] decryptData = Base64.encodeBase64(RsaUtil.encryptByPrivateKey(serialString, privateKey));
			System.out.print(new String(decryptData,"UTF-8"));
			
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		//byte[] serilalString = new SerializerUtil().serialize(requestMap);
		//byte[] decryptData = Base64.encodeBase64(RsaUtil.encryptByPrivateKey(serilalString, privateKey));
	}
}
