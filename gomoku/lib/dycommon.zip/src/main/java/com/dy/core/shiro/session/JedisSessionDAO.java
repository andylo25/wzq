package com.dy.core.shiro.session;

import java.io.Serializable;
import java.util.Collection;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.UnknownSessionException;
import org.apache.shiro.session.mgt.eis.AbstractSessionDAO;
import org.apache.shiro.session.mgt.eis.SessionDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.cache.RedisCacheManager;

import com.dy.core.utils.RequestUtil;
import com.google.common.collect.Sets;

/**
 * 自定义授权会话管理类
 * @author cuiwm
 * @version 2017-9-14
 */
public class JedisSessionDAO extends AbstractSessionDAO implements SessionDAO {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	public static final String sessionKeyPrefix = "shiro_session_";
	
	CacheManager cacheManager;

	public JedisSessionDAO(RedisCacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}

	@Override
	public void update(Session session) throws UnknownSessionException {
		if (session == null || session.getId() == null) {  
            return;
        }
		
		HttpServletRequest request = RequestUtil.getRequest();
		if (request != null){
			String uri = request.getServletPath();
			// 如果是静态文件，则不更新SESSION
			if (RequestUtil.isStaticFile(uri)){
				return;
			}
		}
		
		Cache sessions = cacheManager.getCache(sessionKeyPrefix);
		sessions.put(session.getId(),session);
		
		logger.info("update {} {}", session.getId(), request != null ? request.getRequestURI() : "");
	}

	@Override
	public void delete(Session session) {
		if (session == null || session.getId() == null) {
			return;
		}
		Cache sessions = cacheManager.getCache(sessionKeyPrefix);
		sessions.evict(session.getId());

		logger.info("delete {} ", session.getId());
	}
	
	@Override
	public Collection<Session> getActiveSessions() {
		return getActiveSessions(true);
	}
	
	/**
	 * 获取活动会话
	 * @param includeLeave 是否包括离线（最后访问时间大于3分钟为离线会话）
	 * @return
	 */
	public Collection<Session> getActiveSessions(boolean includeLeave) {
		return getActiveSessions(includeLeave, null, null);
	}
	
	/**
	 * 获取活动会话
	 * @param includeLeave 是否包括离线（最后访问时间大于3分钟为离线会话）
	 * @param principal 根据登录者对象获取活动会话
	 * @param filterSession 不为空，则过滤掉（不包含）这个会话。
	 * @return
	 */
	public Collection<Session> getActiveSessions(boolean includeLeave, Object principal, Session filterSession){
		Set<Session> sessions = Sets.newHashSet();
		
//		Cache sessionCache = cacheManager.getCache(sessionKeyPrefix);
//		Object nc = sessionCache.getNativeCache();
//		if(nc instanceof RedisOperations){
//			Set fd = ((RedisOperations) nc).keys("*");
//		}
		return sessions;
	}

	@Override
	protected Serializable doCreate(Session session) {
		Serializable sessionId = this.generateSessionId(session);
		this.assignSessionId(session, sessionId);
		this.update(session);
		return sessionId;
	}

	@Override
	protected Session doReadSession(Serializable sessionId) {

		Session s = null;
		HttpServletRequest request = RequestUtil.getRequest();
		if (request != null){
			s = (Session)request.getAttribute(sessionId.toString());
		}
		if (s != null){
			return s;
		}

		Cache sessionCache = cacheManager.getCache(sessionKeyPrefix);
		Session session = sessionCache.get(sessionId,Session.class);
		logger.info("doReadSession {} {}", sessionId, request != null ? request.getRequestURI() : "");
		
		if (request != null && session != null){
			request.setAttribute(sessionId.toString(), session);
		}
		
		return session;
	}
	
}
