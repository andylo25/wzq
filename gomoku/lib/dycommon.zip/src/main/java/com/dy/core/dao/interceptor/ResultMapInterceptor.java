package com.dy.core.dao.interceptor;

import java.sql.Statement;
import java.util.Map;
import java.util.Properties;

import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.executor.statement.RoutingStatementHandler;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Component;

import com.dy.core.utils.Reflections;

@Component
@Intercepts({@Signature(type=StatementHandler.class,method="query",args={Statement.class, ResultHandler.class})})
public class ResultMapInterceptor implements Interceptor {

	
	@Override
	public Object intercept(Invocation invocation) throws Throwable {
		if(!(invocation.getTarget() instanceof RoutingStatementHandler)) return invocation.proceed();
		
		RoutingStatementHandler statementHandler = (RoutingStatementHandler) invocation.getTarget();
		StatementHandler delegate = (StatementHandler) Reflections.getFieldValue(statementHandler, "delegate");
		
		Object pobject = delegate.getParameterHandler().getParameterObject();
		Class<?> getClazz = null;
    	if(pobject instanceof Map){
    		if(((Map) pobject).containsKey("getClazz")){
    			Object obj = ((Map)pobject).get("getClazz");
    			if(obj != null && obj instanceof Class) getClazz = (Class<?>) obj;
    		}
    	}
	    if(getClazz != null){
	    	Object handler = Reflections.getFieldValue(delegate, "resultSetHandler");
	    	if(!(handler instanceof DyResultSetHandler)){
	    		handler = new DyResultSetHandler((Executor)Reflections.getFieldValue(delegate, "executor"),
	    				(MappedStatement)Reflections.getFieldValue(delegate, "mappedStatement"),
	    				delegate.getParameterHandler(),
	    				(ResultHandler<?>) invocation.getArgs()[1],
	    				delegate.getBoundSql(),
	    				(RowBounds)Reflections.getFieldValue(delegate, "rowBounds"));
	    		
	    		Reflections.setFieldValue(delegate, "resultSetHandler", handler);
	    	}
	    }
		
		return invocation.proceed();
	}

	@Override
	public Object plugin(Object target) {
		return Plugin.wrap(target, this);
	}

	@Override
	public void setProperties(Properties properties) {
	}
}