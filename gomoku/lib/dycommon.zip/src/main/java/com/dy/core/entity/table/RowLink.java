package com.dy.core.entity.table;

import java.io.Serializable;
import java.util.List;

/**
 * 列表页 -- 链接按钮
 */
public class RowLink implements Serializable {
    
    /**
     * 提示框
     */
    public static final String ROW_LINK_TYPE_CONFIRM="confirm";
    /**
     * 弹出框
     */
    public static final String ROW_LINK_TYPE_OPENWIN="openwin";

	private static final long serialVersionUID = 552819295393268152L;
	
	private String text;

	private String url;
	/**
	 * 类型 提示框 或 弹出看
	 */
	private String type;
	/**
	 * 框标题
	 */
	private String winTitle;
	/**
	 * 框内容
	 */
	private String winContent;
	
	public RowLink(){
	}
	
	public RowLink(String text,String url){
		this.text=text;
		this.url=url;
	}
	
	public RowLink(String text,String url,String type){
		this.text=text;
		this.url=url;
		this.type = type;
	}
	
	public RowLink(String text,String url,String type,String winTitle){
		this.text=text;
		this.url=url;
		this.type=type;
		this.winTitle=winTitle;
	}
	
	public RowLink(String text,String url,String type,String winTitle,String winContent){
        this.text=text;
        this.url=url;
        this.type=type;
        this.winTitle=winTitle;
        this.winContent=winContent;
    }

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

    
    public String getType() {
        return type;
    }

    
    public void setType(String type) {
        this.type = type;
    }

    
    public String getWinTitle() {
        return winTitle;
    }

    
    public void setWinTitle(String winTitle) {
        this.winTitle = winTitle;
    }

    
    public String getWinContent() {
        return winContent;
    }

    
    public void setWinContent(String winContent) {
        this.winContent = winContent;
    }

}