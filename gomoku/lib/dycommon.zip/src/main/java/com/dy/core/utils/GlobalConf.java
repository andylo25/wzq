package com.dy.core.utils;

public class GlobalConf {

	public static final int APP_ID_DATA = 1;// data端
	public static final int APP_ID_ADMIN = 2;// 管理端
	public static final int APP_ID_WWW = 3;// 门户端
	public static final int APP_ID_BAT = 4;// 批处理
	
	private static int app_id = 0;
	/**
	 * 设置应用标志
	 */
	public static void setAppId(Integer appId){
		app_id = appId;
	}
	public static int getAppId(){
		return app_id;
	}
	
	/**
	 * 是否data端
	 * @return
	 */
	public static boolean isDataEnd(){
		return app_id == APP_ID_DATA;
	}
	/**
	 * 是否管理端
	 * @return
	 */
	public static boolean isAdminEnd(){
		return app_id == APP_ID_ADMIN;
	}
	/**
	 * 是否门户端
	 * @return
	 */
	public static boolean isWwwEnd(){
		return app_id == APP_ID_WWW;
	}
	
	/**
	 * 是否批处理
	 * @return
	 */
	public static boolean isBatEnd(){
		return app_id == APP_ID_BAT;
	}
	
	
	
}
