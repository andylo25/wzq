package com.dy.core.entity.form;

import java.util.HashMap;
import java.util.List;

public class DetailItem extends HashMap<String, Object>{

	private static final long serialVersionUID = 1L;

	public static DetailItem create(String title){
		return new DetailItem().title(title);
	}
	
	public DetailItem title(String title){
		put("title", title);
		return this;
	}

	public DetailItem items(List<FormField> items) {
		put("items", items);
		return this;
	}
	
	public DetailItem type(String type){
		put("type", type);
		return this;
	}

	public DetailItem name(String name) {
		put("name", name);
		return this;
	}
	
	

}