package com.dy.core.outbound.client;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

public class Endpoint implements Cloneable{
	
	private String id;
	
	private String uri;
	
	private String needPath;
	
	private String type;
	private Charset charset;
	
	private List<Host> hosts;
	private int hostsNumber;
	private ConnectPolicy connectPolicy;
	private Map<String, String> extAttrMap = new HashMap<String, String>();

	private int currIndex = -1;

	public Host getNextHost() {
//		currIndex = (currIndex + 1) % hostsNumber;
		return hosts.get(0);
	}

	@XmlAttribute
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@XmlAttribute
	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	@XmlAttribute
	public String getType() {
		return type == null?"http":type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Charset getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = Charset.forName(charset);
	}

	@XmlElementWrapper(name="hosts")
	@XmlElement(name="host")
	public List<Host> getHosts() {
		return hosts;
	}

	public void setHosts(List<Host> hosts) {
		this.hosts = hosts;
	}

	public int getHostsNumber() {
		return hostsNumber;
	}

	public void setHostsNumber(int hostsNumber) {
		this.hostsNumber = hostsNumber;
	}

	@XmlElement(name="connect-policy")
	public ConnectPolicy getConnectPolicy() {
		return connectPolicy;
	}

	public void setConnectPolicy(ConnectPolicy connectPolicy) {
		this.connectPolicy = connectPolicy;
	}

	public Map<String, String> getExtAttrMap() {
		return extAttrMap;
	}

	public void setExtAttrMap(Map<String, String> extAttrMap) {
		this.extAttrMap = extAttrMap;
	}

	public int getCurrIndex() {
		return currIndex;
	}
	
	public void init(){
		if(hosts != null){
			for(Host h:hosts){
				StringBuilder url = new StringBuilder(getType()).append("://")
						.append(h.getIp()).append(':').append(h.getPort());
				if(uri.charAt(0)!='/'){
					url.append("/");
				}
				h.setUrl(url.append(uri).toString());
			}
		}
	}

	@Override
	public Object clone() {		
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}

	@XmlAttribute(name="need-path")
	public String getNeedPath() {
		return needPath;
	}
	
	public void setNeedPath(String needPath) {
		this.needPath = needPath;
	}
	
	public boolean needPath(){
		return needPath == null?true:Boolean.getBoolean(needPath);
	}
	
	

}
