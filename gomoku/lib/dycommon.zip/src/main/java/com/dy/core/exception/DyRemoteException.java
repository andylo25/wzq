package com.dy.core.exception;

public class DyRemoteException extends DyUncheckedException {
	private static final long serialVersionUID = 5190291468401300592L;
	
	public DyRemoteException() {}
	
	/**
	 * @param message 提示信息
	 */
	public DyRemoteException(String message) {
		super(message);
	}
	
	/**
	 * @param message 提示信息
	 * @param params 国际化信息参数
	 */
	public DyRemoteException(String message, Object[] params) {
		super(message, params);
		
	}
	
	/**
	 * @param message 提示信息
	 * @param exception 异常信息
	 */
	public DyRemoteException(String message, Throwable exception) {
		super(message, exception);
	}
	
	/**
	 * @param message 提示信息
	 * @param exception 异常信息
	 */
	public DyRemoteException(String message, Object[] params, Throwable exception) {
		super(message,params, exception);
		
	}
}