/**
 * Copyright cuiwm
 */
package com.dy.core.entity;

import java.io.Serializable;

import com.dy.core.entity.BaseEntity;

/**
 * @author cuiwm
 */
public class SysAccessLog extends BaseEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String requParams;		// 访问参数
	private String requUrl;		// 访问url
	private Long requIp;		// 访问ip
	
	public SysAccessLog() {
		super();
	}

	public SysAccessLog(Long id){
		super(id);
	}

	public String getRequParams() {
		return requParams;
	}

	public void setRequParams(String requParams) {
		this.requParams = requParams;
	}
	
	public String getRequUrl() {
		return requUrl;
	}

	public void setRequUrl(String requUrl) {
		this.requUrl = requUrl;
	}
	
	public Long getRequIp() {
		return requIp;
	}

	public void setRequIp(Long requIp) {
		this.requIp = requIp;
	}
	
}