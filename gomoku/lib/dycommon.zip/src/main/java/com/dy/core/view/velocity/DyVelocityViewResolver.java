package com.dy.core.view.velocity;

import org.springframework.boot.web.servlet.view.velocity.EmbeddedVelocityViewResolver;

public class DyVelocityViewResolver extends EmbeddedVelocityViewResolver {

    @Override
    protected Class<?> requiredViewClass() {
        return DyVelocityView.class;
    }
}
