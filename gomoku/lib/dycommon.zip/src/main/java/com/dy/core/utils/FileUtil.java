package com.dy.core.utils;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.commons.io.FileUtils;
import org.springframework.util.FileCopyUtils;

import com.dy.core.utils.common.SpringContextHolder;

public class FileUtil extends FileUtils{
	
	/**
	 * 通过类路径解压创建文件路径
	 * @param classPath
	 * @return
	 */
	public static String toFilePath(String classPath){
		String creFile = null;
		creFile = Thread.currentThread().getContextClassLoader().getResource(classPath).getPath();
		if(creFile != null && creFile.indexOf("jar!/") > 0){
			// jar资源，需要解压处理
			try {
				String realPath = SpringContextHolder.getWebApplicationContext().getServletContext().getRealPath("/");
				String path = realPath + ".temp/";
				File cf = new File(path);
				if(!cf.exists()){
					cf.mkdirs();
				}
				creFile = path+SecurityUtil.md5(DateUtil.getCurrentTimeStr(),classPath)+".tmp";
				FileCopyUtils.copy(Thread.currentThread().getContextClassLoader().getResourceAsStream(classPath), new FileOutputStream(creFile));
			} catch (Exception e) {
				throw Exceptions.unchecked("创建文件异常", e);
			}
		}
		return creFile;
	}
	
}
