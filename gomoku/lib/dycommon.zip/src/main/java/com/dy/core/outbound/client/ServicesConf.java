package com.dy.core.outbound.client;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.dy.core.outbound.exception.OutboundException;

@XmlRootElement(name = "outbound-services") 
public class ServicesConf implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String charset;

	private List<Endpoint> endpoints;
	
	private List<ServiceMeta> services;
	
	private Map<String,ServiceMeta> serviceMaps;
	
	private boolean isInit = false;

	@XmlElementWrapper(name="endpoints")
	@XmlElement(name="endpoint")
	public List<Endpoint> getEndpoints() {
		return endpoints;
	}

	public void setEndpoints(List<Endpoint> endpoints) {
		this.endpoints = endpoints;
	}

	@XmlElementWrapper(name="services")
	@XmlElement(name="service")
	public List<ServiceMeta> getServices() {
		return services;
	}

	public void setServices(List<ServiceMeta> services) {
		this.services = services;
	}
	
	public void init(){
		if(!isInit){
			doInit();
			isInit = true;
		}
	}
	
	private void doInit(){
		
		if(endpoints != null){
			for(Endpoint end:endpoints){
				for(Endpoint end1:endpoints){
					if(end != end1 && end.getId().equals(end1.getId())){
						throw new OutboundException("EndpointId重复,ID为："+end.getId());
					}
				}
				end.init();
			}
		}
		if(services != null){
			for(ServiceMeta end:services){
				for(ServiceMeta end1:services){
					if(end != end1 && end.getTransactionId().equals(end1.getTransactionId())){
						throw new OutboundException("服务ID重复,ID为："+end.getTransactionId());
					}
				}
			}
		}
		
		serviceMaps = new HashMap<String,ServiceMeta>();
		if(services != null){
			for(ServiceMeta mt:services){
				if(mt.getEndpointId() == null){
					throw new OutboundException("EndpointId为空,服务编码为："+mt.getTransactionId());
				}else{
					for(Endpoint end:endpoints){
						if(end.getId().equals(mt.getEndpointId())){
							mt.setEndpoint(end);
							break;
						}
					}
				}
				
				// 转换map
				serviceMaps.put(mt.getTransactionId(), mt);
			}
		}
	}

	public ServiceMeta getService(String tranId) {
		return serviceMaps.get(tranId);
	}

	@XmlElement(name="charset")
	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}
	
	public ServicesConf add(ServicesConf servicesConf){
		if(servicesConf != null){
			if(this.endpoints == null){
				this.endpoints = new ArrayList<Endpoint>();
			}
			this.endpoints.addAll(servicesConf.getEndpoints());
			if(this.services == null){
				this.services = new ArrayList<ServiceMeta>();
			}
			this.services.addAll(servicesConf.getServices());
		}
		return this;
	}
	
}
