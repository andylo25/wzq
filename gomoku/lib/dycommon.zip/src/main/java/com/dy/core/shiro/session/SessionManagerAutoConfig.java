package com.dy.core.shiro.session;

import org.apache.shiro.session.mgt.SessionManager;
import org.apache.shiro.session.mgt.eis.SessionDAO;
import org.apache.shiro.web.servlet.Cookie;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SessionManagerAutoConfig{

	//配置session管理器
    @Bean(name="sessionManager")
    public SessionManager sessionManager(SessionDAO sessionDAO, Cookie sessionIdCookie) {
    	DySessionManager s = new DySessionManager();
    	s.setSessionDAO(sessionDAO);
    	s.setSessionValidationSchedulerEnabled(true);
    	s.setSessionIdCookieEnabled(true);
    	s.setSessionIdCookie(sessionIdCookie);
    	return s;
    }
    
    @Bean
    public Cookie sessionIdCookie(){
    	return new SimpleCookie("dy.session.id");
    }
    
    
}
