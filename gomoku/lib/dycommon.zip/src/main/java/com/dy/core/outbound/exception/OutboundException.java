package com.dy.core.outbound.exception;

public class OutboundException extends RuntimeException{
    
    private static final long serialVersionUID = 1L;
    
    public OutboundException(String message){
        super(message);
    }
    
    public OutboundException(Throwable e){
    	super(e);
    }
    
    public OutboundException(String message,Throwable e){
    	super(message,e);
    }
    
    public OutboundException() {
    }
}