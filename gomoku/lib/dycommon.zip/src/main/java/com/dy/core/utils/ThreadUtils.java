package com.dy.core.utils;

import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dy.core.event.DyEvent;
import com.dy.core.event.DyEventManager;
import com.dy.core.utils.common.SpringContextHolder;

/**
 * 线程相关工具方法
 * @author cuiwm
 *
 */
public class ThreadUtils {

	private static Logger log = LoggerFactory.getLogger(ThreadUtils.class);
	
	private static DyEventManager eventManager;
	
	private static DyEventManager getDyEventManager(){
		if(eventManager == null){
			eventManager = SpringContextHolder.getBean(DyEventManager.class);
		}
		return eventManager;
	}
	
	/**
	 * 异步执行
	 * @param action 执行的函数
	 */
	public static void doSync(Supplier<?> action){
		DyEvent event = new DyEvent();
		event.setType(DyEvent.SYNC_TYPE);
		event.setData(action);
		event.setSync(true);
		
		try {
			getDyEventManager().trigger(event);
		} catch (Exception e) {
			log.error("异步事件触发异常",e);
		}
		
		
	}
	
	
}
