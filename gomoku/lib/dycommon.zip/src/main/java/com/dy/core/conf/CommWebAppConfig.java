package com.dy.core.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.dy.core.interceptor.LogInterceptor;

@Configuration
public class CommWebAppConfig extends WebMvcConfigurerAdapter{
	
	/**
     * 配置拦截器
     * @author cuiwm
     * @param registry
     */
    public void addInterceptors(InterceptorRegistry registry) {
    	registry.addInterceptor(new LocaleChangeInterceptor()).addPathPatterns("/**");
    	registry.addInterceptor(new LogInterceptor()).addPathPatterns("/**");
	}
    
    @Bean
    public GsonHttpMessageConverter getGsonHttpMessageConverter(){
    	return new GsonHttpMessageConverter();
    }
    
    @Bean("localeResolver")
    public LocaleResolver getSessionLocaleResolver(){
    	return new SessionLocaleResolver();
    }
    
}
