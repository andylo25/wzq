package com.dy.core.outbound.client;

import javax.xml.bind.annotation.XmlAttribute;

import com.dy.core.outbound.exception.OutboundException;

/**
 * 外部服务配置
 * <p>
 */
public class ServiceMeta  implements Cloneable{


	/**
	 * 服务路径
	 */
	private String path;

	/**
	 * 交易id
	 */
	private String transactionId;

	/**
	 * 服务端点配置
	 */
	private Endpoint endpoint;
	
	private String endpointId;
	
	/**
	 * 服务连接策略
	 */
	private ConnectPolicy connectPolicy;
	
	//private boolean valid = true;	
	
	private String version;
	
	private String protocol;

	//预留信息
	private String reserveInfo;
	
	@XmlAttribute
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@XmlAttribute(name="transaction-id")
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public Endpoint getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(Endpoint endpoint) {
		this.endpoint = endpoint;
	}

	public ConnectPolicy getConnectPolicy() {
		return connectPolicy;
	}

	public void setConnectPolicy(ConnectPolicy connectPolicy) {
		this.connectPolicy = connectPolicy;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}	
	
	public String getUrl(){
		Endpoint endpoint = getEndpoint();
		if(endpoint.needPath()){
			return endpoint.getNextHost().getUrl()+"/"+(path == null?transactionId:path);
		}
		return endpoint.getNextHost().getUrl();
	}
	
	/**
	 * @return the reserveInfo
	 */
	public String getReserveInfo() {
		return reserveInfo;
	}

	/**
	 * @param reserveInfo the reserveInfo to set
	 */
	public void setReserveInfo(String reserveInfo) {
		this.reserveInfo = reserveInfo;
	}

	@Override
	public Object clone() {		
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			throw new OutboundException(e) ;
		}
	}

	@XmlAttribute(name="endpoint-id")
	public String getEndpointId() {
		return endpointId;
	}

	public void setEndpointId(String endpointId) {
		this.endpointId = endpointId;
	}
}