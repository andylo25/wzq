package com.dy.core.view.velocity;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.view.velocity.VelocityView;

import com.dy.core.utils.RequestUtil;

public class DyVelocityView extends VelocityView {

    private static Object systemInfo;
    
    @Override
    protected void exposeHelpers(Map<String, Object> model, HttpServletRequest request) throws Exception {
        model.put("systemUser", RequestUtil.getUser());
        if(model.get("system")==null)
            model.put("system", systemInfo);
    }
    
    public static void setSystemInfo(Object systemInfo){
        DyVelocityView.systemInfo=systemInfo;
    }
    
    public static Object getSystemInfo() {
        return DyVelocityView.systemInfo;
    }

}
