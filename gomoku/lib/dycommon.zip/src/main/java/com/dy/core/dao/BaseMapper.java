package com.dy.core.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.dy.core.dao.dml.DmlItem;
import com.dy.core.dao.query.QueryItem;

public interface BaseMapper {
    public Integer insert(@Param("dmlItem")DmlItem dmlItem);
    
    public Integer update(@Param("dmlItem")DmlItem dmlItem);
    
    public Integer delete(@Param("dmlItem")DmlItem dmlItem);
    
    public Integer getListCount(@Param("queryItem")QueryItem queryItem);
    
    public <T> T getOne(@Param("queryItem")QueryItem queryItem, @Param("getClazz")Class<T> clazz);
    
    public <T> List<T> getList(@Param("queryItem")QueryItem queryItem, @Param("getClazz")Class<T> clazz);
}