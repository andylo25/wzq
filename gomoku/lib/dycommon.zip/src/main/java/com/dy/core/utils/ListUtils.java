package com.dy.core.utils;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.formula.functions.T;

import com.dy.core.entity.BaseEntity;
import com.dy.core.entity.SysAccessLog;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ListUtils extends org.apache.commons.collections.ListUtils{

	public static <R> void sort(List<T> list,Function<T, R> fun){
		if(list != null){
			Collections.sort(list,new Comparator<T>() {
				@Override
				public int compare(T o1, T o2) {
					return 0;
//					return fun.apply(o1).compareTo(fun.apply(o2));
				}
			});
		}
	}
	
	/**
	 * 求list的和
	 * @param coll 待合并的list,item是map时key必须为String
	 * @param group 分组,可空
	 * @param cols 求和的字段,不可空
	 */
	public static List mathMerge(List<?> list,String group,String cols){
		if(list == null || StringUtils.isBlank(cols))return null;
		Map<String,Object> map = Maps.newHashMap();
		for(Object l:list){
			if(l instanceof Map){
				Map lis = (Map) l;
				String key = null;
				if(StringUtils.isBlank(group)){
					key = UUID.randomUUID().toString();
				}else{
					String[] groups = group.split(",");
					for(String g:groups){
						key = key+lis.get(g);
					}
				}
				Map mapItem = (Map) map.get(key);
				if(mapItem == null){
					mapItem = Maps.newHashMap(lis);
					map.put(key, mapItem);
				}else{
					String[] colss = cols.split(",");
					for(String col:colss){
						Object v = lis.get(col);
						if(v == null)continue;
						if(v instanceof Integer){
							Integer integer = MapUtils.getInteger(mapItem, col);
							mapItem.put(col,(Integer)v + (integer == null?0:integer));
						}else if(v instanceof Long){
							Long long1 = MapUtils.getLong(mapItem, col);
							mapItem.put(col,(Long)v + (long1 == null?0:long1));
						}else if(v instanceof Double){
							Double double1 = MapUtils.getDouble(mapItem, col);
							mapItem.put(col,(Double)v + (double1 == null?0:double1));
						}else if(v instanceof Float){
							Float f = MapUtils.getFloat(mapItem, col);
							mapItem.put(col,(Float)v + (f == null?0:f));
						}else if(v instanceof BigDecimal){
							BigDecimal bd = (BigDecimal) mapItem.get(col);
							mapItem.put(col,NumberUtils.add((BigDecimal)v,bd));
						}
					}
				}
				
			}else if(l instanceof BaseEntity){
				String key = null;
				if(StringUtils.isBlank(group)){
					key = UUID.randomUUID().toString();
				}else{
					String[] groups = group.split(",");
					for(String g:groups){
						key = key+ReflectUtil.getFieldValue(l, g);
					}
				}
				Map mapItem = (Map) map.get(key);
				if(mapItem == null){
					mapItem = EntityUtils.toMap((BaseEntity) l);
					map.put(key, mapItem);
				}else{
					String[] colss = cols.split(",");
					for(String col:colss){
						Object v = ReflectUtil.getFieldValue(l, col);
						if(v == null)continue;
						if(v instanceof Integer){
							Integer integer = MapUtils.getInteger(mapItem, col);
							mapItem.put(col,(Integer)v + (integer == null?0:integer));
						}else if(v instanceof Long){
							Long long1 = MapUtils.getLong(mapItem, col);
							mapItem.put(col,(Long)v + (long1 == null?0:long1));
						}else if(v instanceof Double){
							Double double1 = MapUtils.getDouble(mapItem, col);
							mapItem.put(col,(Double)v + (double1 == null?0:double1));
						}else if(v instanceof Float){
							Float f = MapUtils.getFloat(mapItem, col);
							mapItem.put(col,(Float)v + (f == null?0:f));
						}else if(v instanceof BigDecimal){
							BigDecimal bd = (BigDecimal) mapItem.get(col);
							mapItem.put(col,NumberUtils.add((BigDecimal)v,bd));
						}
					}
				}
			}
		}
		return Lists.newArrayList(map.values());
	}
	
	public static void putAll(List<Map> list,String key,Object value){
		if(list != null){
			for(Map map:list){
				map.put(key, value);
			}
		}
	}
	
	public static List<Object> getByKey(List<Map> list,String key){
		List result = Lists.newArrayList();
		if(list != null){
			for(Map map:list){
				result.add(map.get(key));
			}
		}
		return result;
	}
	
	public static Map<Object, Map> toMap(List<Map> list,String key){
		Map<Object, Map> result = Maps.newHashMap();
		if(list != null){
			for(Map map:list){
				result.put(map.get(key),map);
			}
		}
		return result;
	}
	
	public static void main(String[] args) {
		List<SysAccessLog> fds = Lists.newArrayList();
		fds.add(new SysAccessLog(1L));
		fds.add(new SysAccessLog(3L));
		fds.add(new SysAccessLog(4L));
		
		System.out.println(null+"fd");
//		sort(fds, SysAccessLog::getRequParams);
	}

}
