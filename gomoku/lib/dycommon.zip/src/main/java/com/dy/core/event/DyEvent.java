package com.dy.core.event;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

import com.dy.core.httpinvoker.HttpInvokerHeader;
import com.dy.core.httpinvoker.SwapContext;
import com.dy.core.utils.GlobalConf;
import com.dy.core.utils.RequestUtil;

/**
 * 事件
 * @author cuiwm
 *
 */
public class DyEvent implements Serializable{

	private static final long serialVersionUID = 1L;
	
	public static final int SYNC_TYPE = -11111111;
	
	private Object data; // 携带数据
	
	private Integer id; 
	private boolean isSync;// 是否异步
	
	private Integer type; // 事件类型
	private Integer subType; // 事件子类型
	
	private HttpInvokerHeader header;
	
	static AtomicInteger idgen = new AtomicInteger(1);
	
	public DyEvent() {
		this.id = idgen.getAndIncrement();
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getSubType() {
		return subType;
	}

	public void setSubType(Integer subType) {
		this.subType = subType;
	}

	public boolean isSync() {
		return isSync;
	}

	public void setSync(boolean isSync) {
		this.isSync = isSync;
		if(isSync){
			header = new HttpInvokerHeader();
			header.setFromApp(GlobalConf.getAppId());
			header.setUser(RequestUtil.getUser());
			header.setIp(RequestUtil.getRemoteIp());
		}
	}
	
	public void bindThread(){
		SwapContext.setRequHeader(header);
	}
	
	public void clearThread(){
		SwapContext.clear();
	}

}
