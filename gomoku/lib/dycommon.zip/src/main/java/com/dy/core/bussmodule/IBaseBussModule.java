package com.dy.core.bussmodule;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.dy.core.dao.query.Condition;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.NameValue;
import com.dy.core.entity.Page;
import com.dy.core.utils.DateUtil;

public interface IBaseBussModule {

	//查询条件
	public static final String EQ = Condition.EQ;
	public static final String GT = Condition.GT;
	public static final String GE = Condition.GE;
	public static final String LT = Condition.LT;
	public static final String LE = Condition.LE;
	public static final String IN = Condition.IN;
	public static final String NEQ = Condition.NEQ;
	public static final String LIKE = Condition.LIKE;
	public static final String NOT_IN = Condition.NOT_IN;
	public static final String LIKE_ALL = Condition.LIKE_ALL;
	public static final String NULL = Condition.NULL;
	public static final String NOT_NULL = Condition.NOT_NULL;
	
	/**
	 * 添加日期where条件到whereList
	 * @param whereList
	 * @param column 2017/06/02-2017/06/03
	 * @param value 值
	 */
	public static Where addDateWhereCondition(List<Where> whereList, String column,String value) throws Exception {
		if(value == null)return null;
		String[] cols = value.split("-");
		return addAndWhereCondition(whereList, column, DateUtil.dateParse(StringUtils.replace(cols[0], "/", "-")),DateUtil.dateParse(StringUtils.replace(cols[1], "/", "-")));
	}
	
	/**
	 * 添加where条件到whereList
	 * @param whereList
	 * @param column 数据库字段名
	 * @param value 值
	 */
	public static Where addWhereCondition(List<Where> whereList, String column, Object value) throws Exception {
		return addWhereCondition(whereList, column, EQ, value, true);
	}
	
	/**
	 * 添加where条件到whereList
	 * @param whereList
	 * @param column 数据库字段名
	 * @param condition 查询条件(=,>,<,>等)
	 * @param value 值
	 */
	public static Where addWhereCondition(List<Where> whereList, String column, String condtion, Object value) throws Exception {
		return addWhereCondition(whereList, column, condtion, value, true);
	}
	
	/**
	 * 添加where条件到whereList
	 * @param whereList
	 * @param column 数据库字段名
	 * @param condition 查询条件(=,>,<,>等)
	 * @param value 值
	 * @param isDateNeedCovert 时间是否需要转为long，默认为true
	 */
	public static Where addWhereCondition(List<Where> whereList, String column, String condtion, Object value, boolean isDateNeedCovert) throws Exception {
		if(StringUtils.isEmpty(column) || value == null) return null;
		if(value instanceof String && StringUtils.isEmpty(value.toString())) return null;
		
		if(whereList == null) whereList = new ArrayList<Where>();
		if(isDateNeedCovert && value instanceof Date) value = DateUtil.convert((Date) value);
		Where where = new Where(column, value, condtion);
		whereList.add(where);
		return where;
	}
	
	/**
	 * 添加and条件，如：add_time > startValue and add_time < endValue
	 * @param whereList
	 * @param column 数据库字段名
	 * @param startValue
	 * @param endValue
	 */
	public static Where addAndWhereCondition(List<Where> whereList, String column, Object startValue, Object endValue) throws Exception {
		return addAndWhereCondition(whereList, column, startValue, endValue, true);
	}
	
	/**
	 * 添加and条件，如：add_time > startValue and add_time < endValue
	 * @param whereList
	 * @param column 数据库字段名
	 * @param startValue
	 * @param endValue
	 * @param formatType 格式化类型(date/datetime),默认为date
	 */
	public static Where addAndWhereCondition(List<Where> whereList, String column, Object startValue, Object endValue, String formatType) throws Exception {
		return addAndWhereCondition(whereList, column, startValue, endValue, true);
	}
	
	/**
	 * 添加and条件，如：add_time > startValue and add_time < endValue
	 * @param whereList
	 * @param column 数据库字段名
	 * @param startValue
	 * @param endValue
	 * @param isDateNeedCovert 时间是否需要转为long，默认为true
	 */
	public static Where addAndWhereCondition(List<Where> whereList, String column, Object startValue, Object endValue, boolean isDateNeedCovert) throws Exception {
		return addAndWhereCondition(whereList, column, startValue, endValue, isDateNeedCovert, "date");
	}
	
	/**
	 * 添加and条件，如：add_time > startValue and add_time < endValue
	 * @param whereList
	 * @param column 数据库字段名
	 * @param startValue
	 * @param endValue
	 * @param isDateNeedCovert 时间是否需要转为long，默认为true
	 * @param formatType 格式化类型(date/datetime),默认为date
	 */
	public static Where addAndWhereCondition(List<Where> whereList, String column, Object startValue, Object endValue, boolean isDateNeedCovert, String formatType) throws Exception {
		if(StringUtils.isEmpty(column)) return null;
		
		if(whereList == null) whereList = new ArrayList<Where>();
		
		List<NameValue> ands = new ArrayList<NameValue>();
		if(startValue != null) {
			if(isDateNeedCovert && startValue instanceof Date) {
				if("date".equals(formatType)) {
					String startDate = DateUtil.dateFormat((Date) startValue) + " 00:00:00";
					startValue = DateUtil.convert(startDate);
				} else {
					startValue = DateUtil.convert((Date) startValue);
				}
			}else if(startValue instanceof String){
				startValue = DateUtil.convert((String)startValue);
			}
			if(startValue != null)ands.add(new NameValue(column, startValue, GE));
		}
		if(endValue != null) {
			if(isDateNeedCovert && endValue instanceof Date) {
				if("date".equals(formatType)) {
					String endDate = DateUtil.dateFormat((Date) endValue) + " 23:59:59";
					endValue = DateUtil.convert(endDate);
				} else {
					endValue = DateUtil.convert((Date) endValue);
				}
			}else if(endValue instanceof String){
				endValue = DateUtil.convert((String)endValue);
			}
			if(endValue != null)ands.add(new NameValue(column, endValue, LE));
		}
		if(ands.size() > 0) whereList.add(new Where(ands));
		return whereList.isEmpty()?null:whereList.get(0);
	}
	
	/**
	 * 转换id为名称
	 * @param data 待转换的列表
	 * @param module 关联表模块
	 * @param function 关联表名
	 * @param cols 格式：src_col#tar_col:tar_col1,tar_col2
	 * @return
	 * @throws Exception 
	 */
	public Object idToName(List<Map> data, String module,String function, String cols) throws Exception;
	public Object idToName(Map data, String module,String function, String cols) throws Exception;
	
	/**
	 * 插入一条数据
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @return
	 * @throws Exception
	 */
	public DyResponse insert(String module, String function, Object obj) throws Exception;
	
	/**
	 * 根据主键更新数据
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @param isUpdateEmpty 是否更新属性值为空的字段
	 * @return
	 * @throws Exception
	 */
	public DyResponse update(String module, String function, Object obj,boolean isUpdateEmpty) throws Exception;
	
	/**
	 * 根据主键更新数据
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @return
	 * @throws Exception
	 */
	public DyResponse update(String module, String function, Object obj) throws Exception;
	
	/**
	 * 根据主键删除数据(主键字段不是id，要另外指定如：menu_id)
	 * @param pkColumn 数据库字段名
	 * @param id 主键值
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public DyResponse deleteById(String pkColumn, Long id, String module, String function) throws Exception;
	
	/**
	 * 根据主键(id)删除数据
	 * @param id 要删除的记录ID
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public DyResponse deleteById(Long id, String module, String function) throws Exception;
	
	/**
	 * 查询单条记录，返回Map<String, Object>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getOneByMap(QueryItem queryItem, String module, String function) throws Exception;
	
	/**
	 * 根据id查询单条记录，返回Map<String, Object>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getById(Serializable id, String module, String function) throws Exception;
	public Map<String, Object> getById(Serializable id, String module, String function,String fields) throws Exception;
	
	/**
	 * 查询单条记录，返回BaseEntity
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getOneByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception;
	
	/**
	 * 根据id查询单条记录，返回BaseEntity
	 * @param id
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getById(Serializable id, String module, String function, Class<T> clazz) throws Exception;
	
	/**
	 * 根据id查询单条记录，返回BaseEntity,可指定返回的字段
	 * @param id
	 * @param module
	 * @param function
	 * @param clazz
	 * @param fields
	 * @return
	 * @throws Exception
	 */
	public <T> T getById(Serializable id, String module, String function, Class<T> clazz, String fields) throws Exception;
	
	/**
	 * 查询列表,返回List<Map<String, Object>>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public List<Map> getListByMap(QueryItem queryItem, String module, String function) throws Exception;
	
	/**
	 * 查询列表，返回Page<Map>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Page<Map> getPageByMap(QueryItem queryItem, String module, String function) throws Exception;
	
	/**
	 * 查询列表，返回List<BaseEntity>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public <T> List<T> getListByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception;
	
	/**
	 * 查询列表，返回Page<BaseEntity>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public <T> Page<T> getPageByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception;
	
	
}
