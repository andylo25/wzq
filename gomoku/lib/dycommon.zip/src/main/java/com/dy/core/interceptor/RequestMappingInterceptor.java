package com.dy.core.interceptor;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.dy.core.bussmodule.IBaseBussModule;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.SysAccessLog;
import com.dy.core.entity.User;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.IpUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PropertiesUtil;
import com.dy.core.utils.SecurityUtil;
import com.dy.core.utils.rsa.RsaUtil;
import com.dy.core.utils.serializer.SerializerUtil;

@Aspect
@Component
public class RequestMappingInterceptor implements InitializingBean{
	
	private static Logger log = LoggerFactory.getLogger(RequestMappingInterceptor.class);
	
	private Map<String, Object> authMap = null;
	
	@Autowired
	IBaseBussModule bussModule;
	
	String DOMAIN_PAGE = "common/domain";
	
	@Around(value="@annotation(org.springframework.web.bind.annotation.RequestMapping)", argNames="pjp")
    public Object aroundAdvice(final ProceedingJoinPoint pjp) throws Throwable {
		ServletRequestAttributes requestAttributes = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
		HttpServletRequest request = requestAttributes.getRequest();
//		try {
//			accessLog(request);// 记录访问日志
//		} catch (Exception e) {
//			log.warn("记录访问日志异常",e);
//		}
		
		try {
			if(request.getServletPath().contains(DOMAIN_PAGE)
					|| request.getServletPath().contains("common/public/getImageCode")
					|| request.getServletPath().contains("/error")) {
				return pjp.proceed();
			}
			Map<String, Object> authMap = getAuthDomain();
			if (authMap != null && isDomainValid(request, authMap))
				return pjp.proceed();
		} finally {
			postProceed();
		}
		
		if(!"XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
			HttpServletResponse response = requestAttributes.getResponse();
			response.sendRedirect(request.getContextPath() + "/"+DOMAIN_PAGE);
			return null;
		} else {
			String errorMsg = "域名授权过期或无效";
			Class<?> returnType = ((MethodSignature)pjp.getSignature()).getReturnType();
			if(returnType.isAssignableFrom(DyResponse.class)) {
				DyResponse response = new DyResponse();
				response.setData(errorMsg);
				response.setDescription(errorMsg);
				response.setStatus(DyResponse.ERROR);
				return response;
			} else if(returnType.isAssignableFrom(String.class)) {
				return errorMsg;
			} else {
				return null;
			}
		}
	}

	private void accessLog(HttpServletRequest request) throws Exception {
		SysAccessLog accessLog = new SysAccessLog();
		
		accessLog.setRequIp(IpUtil.ipStrToLong(getIpAddr(request)));
		accessLog.setRequUrl(getBasePath(request)+request.getContextPath()+request.getRequestURI());
		String params = JsonUtils.object2JsonString(request.getParameterMap());
		accessLog.setRequParams(params.length() > 4000?params.substring(0, 4000):params);
		accessLog.setCreateUid(0l);
		Session session = null;
		try {
			session = SecurityUtils.getSubject().getSession();
		} catch (Exception e) {
		}
		if(session != null){
			User user = (User) session.getAttribute(Constant.SESSION_USER);
			if(user != null){
				accessLog.setCreateUid(user.getId());
			}
		}
		
		bussModule.insert("system","access_log",accessLog);
	}
	
	public String getBasePath(HttpServletRequest request) {
		
		StringBuffer basePath = new StringBuffer();
		basePath.append(request.getScheme()).append("://").append(request.getServerName());
		if(request.getServerPort() != 80) 
		basePath.append(":").append(request.getServerPort());
		basePath.append(request.getContextPath());
		
		return basePath.toString();
	}
	
	public String getIpAddr(HttpServletRequest request) {
       String ip = request.getHeader("x-forwarded-for"); 
       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
           ip = request.getHeader("Proxy-Client-IP"); 
       } 
       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
           ip = request.getHeader("WL-Proxy-Client-IP"); 
       } 
       if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
           ip = request.getRemoteAddr(); 
       } 
       if("0:0:0:0:0:0:0:1".equals(ip)) ip = "127.0.0.1";
       return ip; 
   }

	private void postProceed() {
		DictUtils.clearCur();// 清理当前请求缓存
	}

	private Map<String, Object> getAuthDomain() {
		if(authMap != null && authMap.containsKey("domain") && authMap.containsKey("date")) {
			// Map<String, String> result = new HashMap<String, String>();
			// result.put("date", (String)authMap.get("date"));
			// result.put("domain", (String)authMap.get("domain"));
			// return result;
			return authMap;
		}
		return null;
	}

	private boolean isDomainValid(HttpServletRequest request, Map<String, Object> authMap) {
		boolean isAuthDomain = false;
		String[] authDomains = (String[]) authMap.get("domain");
		for (String domain : authDomains) {
			if (!request.getServerName().endsWith("." + domain) && !request.getServerName().equals(domain))
				continue;
			isAuthDomain = true;
			break;
		}
		if(!isAuthDomain) {
			// if(log.isInfoEnabled()){
			// log.info("授权失败=》authDomain:["+authDomain+"],servName:["+request.getServerName()+"]");
			// }
			System.out.println("授权失败=》servName:[" + request.getServerName() + "]");
			return false;
		}
		Date expireDate = (Date) authMap.get("date");
		
		if(expireDate == null || expireDate.compareTo(new Date()) < 0) return false;
		return true;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		try {
			String authKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC3//sR2tXw0wrC2DySx8vNGlqt3Y7ldU9+LBLI6e1KS5lfc5jlTGF7KBTSkCHBM3ouEHWqp1ZJ85iJe59aF5gIB2klBd6h4wrbbHA2XE1sq21ykja/Gqx7/IRia3zQfxGv/qEkyGOx+XALVoOlZqDwh76o2n1vP1D+tD3amHsK7QIDAQAB";
			String authInfo = PropertiesUtil.getProperty("AUTHORIZE_INFO");
			authMap = (Map)new SerializerUtil().unserialize(RsaUtil.decryptByPublicKey(SecurityUtil.decode(authInfo), authKey));
			authMap.put("domain", authMap.get("domain").toString().split(","));
			authMap.put("date", new SimpleDateFormat("yyyy-MM-dd").parse((String) authMap.get("date")));
		} catch(Exception e) {
			// System.out.println("授权码错误");
			// log.error("授权解析失败",e);
			// e.printStackTrace();
		}
	}
}