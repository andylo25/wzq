package com.dy.core.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.dy.core.utils.PropertiesUtil;

public class LogInterceptor extends HandlerInterceptorAdapter {

	private static Logger log = LoggerFactory.getLogger(LogInterceptor.class);
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		if(log.isInfoEnabled()){
			log.info("url:"+request.getRequestURI());
			log.info("    ==>方法:"+handler);
			if(modelAndView != null){
				log.info("    ==>模板:"+modelAndView.getViewName());
				if(PropertiesUtil.isTest()){
					modelAndView.addObject("tpl__",modelAndView.getViewName());
				}
			}
		}
		super.postHandle(request, response, handler, modelAndView);
	}
	
}
