package com.dy.core.utils;

import java.util.List;

import com.dy.core.entity.SysDict;

public interface IOptionInit {
	
	public List<SysDict> initType(String type);
	
}
