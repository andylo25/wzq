package com.dy.core.dao.dml;

import java.util.HashMap;

import com.dy.core.dao.query.Where;
import com.dy.core.entity.NameValue;

public class DmlItemBuilder {


	private DmlItem build = new DmlItem();

	public DmlItemBuilder(String module, String function) {
		build = new DmlItem(module, function);
	}

	public DmlItemBuilder param(NameValue nameValue) {
		build.getParams().add(nameValue);
		return this;
	}

	public DmlItemBuilder param(String name, Object value) {
		build.getParams().add(new NameValue(name, value));
		return this;
	}

	public DmlItemBuilder setNull(String... names) {
		for (String name : names) {
			build.getParams().add(new NameValue(name, null));
		}
		return this;
	}

	public DmlItemBuilder where(Where where) {
		build.getWhereList().add(where);
		return this;
	}

	public DmlItemBuilder where(String name, Object value) {
		build.getWhereList().add(Where.eq(name, value));
		return this;
	}

	public DmlItemBuilder paramMap(String name, Object value) {
		if (build.getParamMap() == null)
			build.setParamMap(new HashMap<String, Object>());
		build.getParamMap().put(name, value);
		return this;
	}

	public DmlItem builder() {
		return build;
	}
	}
