package com.dy.core.exception;

import com.dy.core.service.I18N;

public class DyCheckedException extends Exception{

	private static final long serialVersionUID = 1L;
	
	private Object[] params;
	
	@Override
	public String getMessage() {
		return I18N.getMessage(super.getMessage(),params,super.getMessage());
	}
	
	@Override
	public String getLocalizedMessage() {
		return getMessage();
	}
	
	public Object[] getParams() {
		return params;
	}

	public DyCheckedException() {}
	
	/**
	 * @param message 提示信息
	 */
	public DyCheckedException(String message) {
		super(message);
	}
	
	/**
	 * @param message 提示信息
	 * @param params 国际化信息参数
	 */
	public DyCheckedException(String message, Object[] params) {
		super(message);
		
		this.params = params;
	}
	
	/**
	 * @param message 提示信息
	 * @param exception 异常信息
	 */
	public DyCheckedException(String message, Throwable exception) {
		super(message, exception);
	}
	
	/**
	 * @param message 提示信息
	 * @param exception 异常信息
	 */
	public DyCheckedException(String message, Object[] params, Throwable exception) {
		super(message, exception);
		
		this.params = params;
	}

}
