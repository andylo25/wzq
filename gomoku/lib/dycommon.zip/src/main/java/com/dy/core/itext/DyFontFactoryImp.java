package com.dy.core.itext;

import com.itextpdf.text.FontFactoryImp;

public class DyFontFactoryImp extends FontFactoryImp{

	public int registerDirectories() {
        int count = 0;
        String windir = System.getenv("windir");
        String fileseparator = System.getProperty("file.separator");
        if (windir != null && fileseparator != null) {
//        	count += registerDirectory(windir + fileseparator + "fonts");
//        	count += registerDirectory(windir + fileseparator + "Fonts");
        }
        count += registerDirectory("/usr/share/X11/fonts", true);
        count += registerDirectory("/usr/X/lib/X11/fonts", true);
        count += registerDirectory("/usr/openwin/lib/X11/fonts", true);
        count += registerDirectory("/usr/share/fonts", true);
        count += registerDirectory("/usr/X11R6/lib/X11/fonts", true);
        count += registerDirectory("/Library/Fonts");
        count += registerDirectory("/System/Library/Fonts");
        return count;
    }
	
}
