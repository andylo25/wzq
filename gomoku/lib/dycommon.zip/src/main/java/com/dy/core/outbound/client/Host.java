package com.dy.core.outbound.client;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * 服务节点信息
 * <p>
 */
public class Host {
	private String id;
	private String ip;
	private int port;
	private String url;
	private int failAndSkipCount;

	private Map<String, String> extAttrMap = new HashMap<String, String>();

	public Host() {
	}
	
	public Host(String ip, int port) {
		this.ip = ip;
		this.port = port;
	}

	@XmlAttribute
	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	@XmlAttribute
	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public Map<String, String> getExtAttrMap() {
		return Collections.unmodifiableMap(extAttrMap);
	}

	public void setExtAttrMap(Map<String, String> extAttrMap) {
		this.extAttrMap.putAll(extAttrMap);
	}

	@XmlAttribute
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@XmlAttribute(name="fail-and-skip-count")
	public int getFailAndSkipCount() {
		return failAndSkipCount;
	}

	public void setFailAndSkipCount(int failAndSkipCount) {
		this.failAndSkipCount = failAndSkipCount;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		return new StringBuilder("id=").append(id).append(", ").append("ip=")
				.append(ip).append(", ").append("port=").append(port)
				.append(", ").append("url=").append(url).append(", ")
				.append("failAndSkipCount=").append(failAndSkipCount)
				.toString();
	}

}
