package com.dy.core.httpinvoker.server;

import java.lang.reflect.InvocationTargetException;

import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * 服务端调用实现方法
 * @author cuiwm
 *
 */
@Component
public class DyRemoteInvocationExecutor implements RemoteInvocationExecutor {

	@Override
	public Object invoke(RemoteInvocation invocation, Object targetObject)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException{

		Assert.notNull(invocation, "RemoteInvocation must not be null");
		Assert.notNull(targetObject, "Target object must not be null");
		return invocation.invoke(targetObject);
	}
	
}
