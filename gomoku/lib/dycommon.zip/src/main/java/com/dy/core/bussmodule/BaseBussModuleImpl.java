package com.dy.core.bussmodule;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.BaseEntity;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.service.I18N;
import com.dy.core.utils.HttpInvoker;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.RequestUtil;
import com.google.common.collect.Sets;

@Component
public class BaseBussModuleImpl implements IBaseBussModule{

	protected Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private HttpInvoker httpInvokerUtil;
	
	/**
	 * 转换id为名称
	 * @param data 待转换的数据
	 * @param module 关联表模块
	 * @param function 关联表名
	 * @param cols 格式：src_col#tar_col:tar_col1,tar_col2
	 * @return
	 * @throws Exception 
	 */
	public Object idToName(Map data, String module,String function, String cols) throws Exception{
		if(data != null){
			String[] column = cols.split(":");
			String[] cs = column[0].split("#");
			String[] cs1 = cs[0].split(",");
			String field = cs1[0];
			String field1 = null;
			if(cs1.length > 1){
				field1 = cs1[1];
			}
			String tarCol = "id";
			String tarCol1 = null;
			if(cs.length > 1){
				String[] tarCola = cs[1].split(",");
				tarCol = tarCola[0];
				if(tarCola.length > 1){
					tarCol1 = tarCola[1];
				}
			}
			String[] colss = column[1].split(",");
			String id = data.get(field).toString();
			
			QueryItem queryItem = new QueryItem(Where.eq(tarCol, id));
			if(field1 != null){
				queryItem.setWhere(Where.eq(tarCol1, field1));
			}
			queryItem.setFields(tarCol+","+column[1]);
			List<Map> maps = this.getListByMap(queryItem, module, function);
			if(maps != null && !maps.isEmpty()){
				Map ent = maps.get(0);
				for(String col:colss){
					// col_1 as col1
					String[] cola = col.split(" ");
					String colas = cola[cola.length-1];
					data.put(colas, ent.get(colas));
				}
			}
		}
		
		return data;
	}
	
	/**
	 * 转换id为名称
	 * @param data 待转换的列表
	 * @param module 关联表模块
	 * @param function 关联表名
	 * @param cols 格式：src_col#tar_col:tar_col1,tar_col2
	 * @return
	 * @throws Exception 
	 */
	public Object idToName(List<Map> data, String module,String function, String cols) throws Exception{
		if(data != null && !data.isEmpty()) {
			String[] column = cols.split(":");
			String[] cs = column[0].split("#");
			String[] cs1 = cs[0].split(",");
			String field = cs1[0];
			String field1 = null;
			if(cs1.length > 1){
				field1 = cs1[1];
			}
			String tarCol = "id";
			String tarCol1 = null;
			if(cs.length > 1){
				String[] tarCola = cs[1].split(",");
				tarCol = tarCola[0];
				if(tarCola.length > 1){
					tarCol1 = tarCola[1];
				}
			}
			String[] colss = column[1].split(",");
			Set<String> ids = Sets.newHashSet();
			for(int i=0;i<data.size();i++){
				Object f = data.get(i).get(field);
				if(f != null){
					ids.add(f.toString());
				}
			}
			QueryItem queryItem = new QueryItem(Where.in(tarCol, StringUtils.join(ids,",")));
			if(field1 != null){
				queryItem.setWhere(Where.eq(tarCol1, field1));
			}
			queryItem.setFields(tarCol+","+column[1]);
			List<Map> maps = this.getListByMap(queryItem, module, function);
			if(maps != null){
				for(Map map:data){
					Object v = map.get(field);
					if(v != null){
						Map ent = getEntityById(maps,tarCol,v.toString());
						if(ent != null){
							for(String col:colss){
								// col_1 as col1
								String[] cola = col.split(" ");
								String colas = cola[cola.length-1];
								map.put(colas, ent.get(colas));
							}
						}
					}
				}
			}
		}
		
		return data;
		
	}
	
	private Map getEntityById(List<Map> maps, String key, String id) {
		if(maps!= null && id != null){
			for(Map map:maps){
				Object v = map.get(key);
				if(v != null){
					if(v.toString().equals(id)){
						return map;
					}
				}
			}
		}
		return null;
	}
	
	/**
	 * 插入一条数据
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @return
	 * @throws Exception
	 */
	public DyResponse insert(String module, String function, Object obj) throws Exception {
		DyResponse response = new DyResponse();
		try {
			Long result = httpInvokerUtil.insert(module, function, obj);
			if(result > 0) {
				if(obj instanceof BaseEntity){
					((BaseEntity)obj).setId(result);
				}
				response.setId(result);
				response.setStatus(DyResponse.OK);
				response.setDescription(I18N.getMessage("insert.success"));
			} else {
				response.setStatus(DyResponse.ERROR);
				response.setDescription(I18N.getMessage("insert.error"));
				logger.error("insert.error:"+JsonUtils.object2JsonString(obj));
			}
		} catch(Exception e) {
			logger.error("insert.error:"+JsonUtils.object2JsonString(obj),e);
			response.setStatus(DyResponse.ERROR);
			response.setDescription(I18N.getMessage("insert.error"));
		}
		
		return response;
	}
	
	/**
	 * 根据主键更新数据,为空的属性不更新
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @return
	 * @throws Exception
	 */
	public DyResponse update(String module, String function, Object obj) throws Exception {
		return update(module, function, obj,false);
	}
	
	/**
	 * 根据主键更新数据
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @param isUpdateEmpty 是否更新属性值为空的字段
	 * @return
	 * @throws Exception
	 */
	public DyResponse update(String module, String function, Object obj,boolean isUpdateEmpty) throws Exception {
		DyResponse response = new DyResponse();
		try {
			if(obj instanceof BaseEntity&&((BaseEntity)obj).getUpdateUid()==null){
				((BaseEntity)obj).setUpdateUid(RequestUtil.getUserId());
			}
			Integer result = httpInvokerUtil.update(module, function, obj,isUpdateEmpty);
			if(result > 0) {
				response.setStatus(DyResponse.OK);
				response.setDescription(I18N.getMessage("update.success"));
			} else {
				response.setStatus(DyResponse.ERROR);
				response.setDescription(I18N.getMessage("update.error"));
				logger.error("update.error:"+JsonUtils.object2JsonString(obj));
			}
		} catch(Exception e) {
			logger.error("update.error:"+JsonUtils.object2JsonString(obj),e);
			response.setStatus(DyResponse.ERROR);
			response.setDescription(I18N.getMessage("update.error"));
		}
		
		return response;
	}
	
	/**
	 * 根据主键(id)删除数据
	 * @param id 要删除的记录ID
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public DyResponse deleteById(Long id, String module, String function) throws Exception {
		return deleteById("id", id, module, function);
	}
	
	/**
	 * 根据主键删除数据(主键字段不是id，要另外指定如：menu_id)
	 * @param pkColumn 数据库字段名
	 * @param id 主键值
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public DyResponse deleteById(String pkColumn, Long id, String module, String function) throws Exception {
		DyResponse response = new DyResponse();
		try {
			Integer result = httpInvokerUtil.deleteById(pkColumn, id, module, function);
			if(result > 0) {
				response.setStatus(DyResponse.OK);
				response.setDescription(I18N.getMessage("delete.success"));
			} else {
				response.setStatus(DyResponse.ERROR);
				response.setDescription(I18N.getMessage("delete.error"));
				logger.error("delete.error:["+module+"-"+function+"=>"+id);
			}
		} catch(Exception e) {
			logger.error("delete.error:["+module+"-"+function+"=>"+id,e);
			response.setStatus(DyResponse.ERROR);
			response.setDescription(I18N.getMessage("delete.error"));
		}
		
		return response;
	}
	
	/**
	 * 查询单条记录，返回Map<String, Object>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getOneByMap(QueryItem queryItem, String module, String function) throws Exception {
	    return httpInvokerUtil.getOne(queryItem, module, function);
	}
	
	/**
	 * 根据id查询单条记录，返回Map<String, Object>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getById(Serializable id, String module, String function) throws Exception {
		return this.getById(id,module,function,"");
	}
	public Map<String, Object> getById(Serializable id, String module, String function,String fields) throws Exception {
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		if(StringUtils.isNotBlank(fields)){
			if(fields.startsWith("id,") || fields.indexOf(",id,") > 0){
				queryItem.setFields(fields);
			}else{
				queryItem.setFields("id,"+fields);
			}
		}
		return getOneByMap(queryItem, module, function);
	}
	
	/**
	 * 查询单条记录，返回BaseEntity
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getOneByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		return httpInvokerUtil.getOne(queryItem, module, function, clazz);
	}
	
	/**
	 * 根据id查询单条记录，返回BaseEntity
	 * @param id
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getById(Serializable id, String module, String function, Class<T> clazz) throws Exception {
		return httpInvokerUtil.getOneById(id, module, function, clazz);
	}
	
	/**
	 * 查询列表,返回List<Map<String, Object>>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public List<Map> getListByMap(QueryItem queryItem, String module, String function) throws Exception {
		return httpInvokerUtil.getList(queryItem, module, function);
	}
	
	/**
	 * 查询列表，返回Page<Map>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Page<Map> getPageByMap(QueryItem queryItem, String module, String function) throws Exception {
		return httpInvokerUtil.getPage(queryItem, module, function);
	}
	
	/**
	 * 查询列表，返回List<BaseEntity>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public <T> List<T> getListByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		return httpInvokerUtil.getList(queryItem, module, function, clazz);
	}
	
	/**
	 * 查询列表，返回Page<BaseEntity>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public <T> Page<T> getPageByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		return httpInvokerUtil.getPage(queryItem, module, function, clazz);
	}

	@Override
	public <T> T getById(Serializable id, String module, String function, Class<T> clazz, String fields) throws Exception {
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		if(StringUtils.isNotBlank(fields)){
			queryItem.setFields(fields);
		}
		return httpInvokerUtil.getOne(queryItem, module, function, clazz);
	}
	
}
