package com.dy.core.entity;

public interface User {
	
	public Long getId();
	
	public String getUsername();
	
	public String getRealName();
	
	public String getPassword();
	
	public Long getPhone();
	
	public Integer getType();
}
