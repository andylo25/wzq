package com.dy.core.event;

public interface IEventManager {

	/**
	 * 订阅事件
	 * @param consumer
	 * @throws Exception
	 */
	public void subscribe(DyConsumer consumer) throws Exception;
	
	/**
	 * 触发事件
	 * @param event
	 * @throws Exception
	 */
	public void trigger(DyEvent event) throws Exception;
	
}
