package com.dy.core.utils;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * 使用注解的方式实现Contextlistener, 必须实现listener接口
 * @author cuiwm
 */
public class SpringInit implements ServletContextListener{

	static WebApplicationContext context;
	
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
    }

    @Override
    public void contextInitialized(ServletContextEvent sce) {
    	context = WebApplicationContextUtils.getWebApplicationContext(sce.getServletContext());
    }

    public static WebApplicationContext getWebApplicationContext(){
    	return context;
    }
}