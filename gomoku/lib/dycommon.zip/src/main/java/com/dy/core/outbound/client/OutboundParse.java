package com.dy.core.outbound.client;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.stereotype.Service;

import com.dy.core.outbound.XMLUtils;

@Service
@Lazy(false)
public class OutboundParse implements InitializingBean{
	
	
	private ServicesConf servicesConf;
	
	public String confPath = "classpath*:outbound*";
	
	@Override
	public void afterPropertiesSet() throws Exception {
		ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();  
	    //只加载一个绝对匹配Resource，且通过ResourceLoader.getResource进行加载  
	    Resource[] resources=resolver.getResources(confPath); 
	    if(resources != null){
	    	for(Resource res:resources){
	    		if(res.getFilename().endsWith(".xml")){
	    			ServicesConf servicesConfT = XMLUtils.xml2Obj(ServicesConf.class, res.getInputStream());
	    			if(servicesConf == null){
	    				servicesConf = servicesConfT;
	    			}else{
	    				servicesConf.add(servicesConfT);
	    			}
	    		}
	    	}
	    }
		if(servicesConf != null){
			servicesConf.init();
		}
	}
	
	/** 
	 * 根据服务id获取服务信息
	 * @param tranId
	 * @return
	 */
	public ServiceMeta getService(String tranId){
		return servicesConf.getService(tranId);
	}
	
}
