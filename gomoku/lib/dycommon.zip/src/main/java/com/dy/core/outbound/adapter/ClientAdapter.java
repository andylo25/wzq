package com.dy.core.outbound.adapter;

import java.util.Map;

public interface ClientAdapter {
	
	String post(String url,String reqBody, String charset);
	
	String post(String url,Map<String,?> params,String charset);
	
	/**
	 * 下载远程文件
	 * @param url
	 * @param params
	 * @param filePath
	 * @return 响应类型：Content-Type
	 */
	String downFile(String url,Map<String,String> params, String filePath);
	
	byte[] request(String url,String reqBody);
	
	
}
