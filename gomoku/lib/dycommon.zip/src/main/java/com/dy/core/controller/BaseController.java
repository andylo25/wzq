package com.dy.core.controller;

import java.beans.PropertyEditorSupport;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.bussmodule.IBaseBussModule;
import com.dy.core.dao.query.Condition;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.BaseEntity;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.exception.DyWebException;
import com.dy.core.service.I18N;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.EntityUtils;
import com.dy.core.utils.HttpInvoker;
import com.dy.core.utils.ReflectUtil;
import com.dy.core.utils.RequestUtil;
import com.dy.core.utils.SecurityUtil;
import com.google.common.collect.Lists;

public abstract class BaseController {
	protected Logger logger = Logger.getLogger(this.getClass());
	
	public static final String GET = "GET";
	public static final String POST = "POST";
	
	//查询条件
	public static final String EQ = Condition.EQ;
	public static final String GT = Condition.GT;
	public static final String GE = Condition.GE;
	public static final String LT = Condition.LT;
	public static final String LE = Condition.LE;
	public static final String IN = Condition.IN;
	public static final String NEQ = Condition.NEQ;
	public static final String LIKE = Condition.LIKE;
	public static final String NOT_IN = Condition.NOT_IN;
	public static final String LIKE_ALL = Condition.LIKE_ALL;
	public static final String NULL = Condition.NULL;
	public static final String NOT_NULL = Condition.NOT_NULL;
	
	@Autowired
	private HttpInvoker httpInvokerUtil;
	@Autowired
	private IBaseBussModule baseBussModule;
	
	/**
	 * 时间转换格式(Date/Long --> String)
	 */
	protected DateFormatType getDateFormatType(){
		return DateFormatType.DATETIME;
	}

	public DyResponse createSuccessJsonResonse(Object data) {
		return DyResponse.createSuccessJsonResonse(data);
	}
	
	public DyResponse createSuccessJsonResonse(Object data, Object description) {
		return DyResponse.createSuccessJsonResonse(data, description);
	}
	
	public DyResponse createErrorJsonResonse(Object errorMsg) {
		return DyResponse.createErrorJsonResonse(errorMsg);
	}
	
	public DyResponse createLoginJsonResonse(String errorMsg) {
		return DyResponse.createLoginJsonResonse(errorMsg);
	}
	
	public static ModelAndView createSuccessModelAndView(String viewName, Object data) {
		ModelAndView modelAndView = new ModelAndView(viewName);
		modelAndView.addObject("status", DyResponse.OK);
		modelAndView.addObject("description", "OK");
		modelAndView.addObject("data", data);
		return modelAndView;
	}
	
	public static ModelAndView createErrorModelAndView(String errorMsg) {
		ModelAndView modelAndView = new ModelAndView("error");
		modelAndView.addObject("description", errorMsg);
		modelAndView.addObject("error", errorMsg);
		return modelAndView;
	}
	
	/**
	 * 获取request
	 * @return
	 */
	public HttpServletRequest getRequest() {
		return RequestUtil.getRequest();
	}
	
	/**
	 * 获取session
	 * @return
	 */
	public HttpSession getSession() {
		return getRequest().getSession();
	}
	
	/**
	 * 获取session值
	 * @param attribueName
	 * @return
	 */
	public Object getSessionAttribute(String attribueName) {
		return this.getSession().getAttribute(attribueName);
	}
	
	/**
	 * 移除session
	 * @param attribueName
	 */
	public void removeSessionAttribute(String attribueName) {
		this.getSession().removeAttribute(attribueName);
	}
	
	/**
	 * Session属性赋值
	 * @param attributeName 属性名
	 * @param attributeValue 属性值
	 */
	public void setSessionAtrribute(String attributeName, Object attributeValue) {
		this.getSession().setAttribute(attributeName, attributeValue);
	}
	
	/**
	 * 获取国际化信息
	 * @param code properites文件的Key
	 * @return
	 */
	public String getMessage(String code) {
		return this.getMessage(code, null);
	}
	
	/**
	 * 获取国际化信息(带参数)
	 * @param code properites文件的Key
	 * @param args 参数类表，如new String[]{"0", "1"}
	 * @return
	 */
	public String getMessage(String code, Object[] args) {
		return I18N.getMessage(code, args);
	}
	
	/**
	 * 获取用户登陆IP
	 * @return
	 * @throws Exception
	 */
	public String getRemoteIp() throws Exception {  
	    return RequestUtil.getRemoteIp();
	}
	
	/**
	 * 添加日期where条件到whereList
	 * @param whereList
	 * @param column 
	 * @param value 值 2017/06/02-2017/06/03
	 */
	public Where addDateWhereCondition(List<Where> whereList, String column,String value) throws Exception {
		if(value == null)return null;
		String[] cols = value.split("-");
		return this.addAndWhereCondition(whereList, column, DateUtil.dateParse(StringUtils.replace(cols[0], "/", "-")),DateUtil.dateParse(StringUtils.replace(cols[1], "/", "-")));
	}
	
	/**
	 * 添加where条件到whereList
	 * @param whereList
	 * @param column 数据库字段名
	 * @param value 值
	 */
	public Where addWhereCondition(List<Where> whereList, String column, Object value) throws Exception {
		return this.addWhereCondition(whereList, column, EQ, value, true);
	}
	
	/**
	 * 添加where条件到whereList
	 * @param whereList
	 * @param column 数据库字段名
	 * @param condition 查询条件(=,>,<,>等)
	 * @param value 值
	 */
	public Where addWhereCondition(List<Where> whereList, String column, String condtion, Object value) throws Exception {
		return this.addWhereCondition(whereList, column, condtion, value, true);
	}
	
	/**
	 * 添加where条件到whereList
	 * @param whereList
	 * @param column 数据库字段名
	 * @param condition 查询条件(=,>,<,>等)
	 * @param value 值
	 * @param isDateNeedCovert 时间是否需要转为long，默认为true
	 */
	public Where addWhereCondition(List<Where> whereList, String column, String condtion, Object value, boolean isDateNeedCovert) throws Exception {
		return IBaseBussModule.addWhereCondition(whereList, column, condtion, value, isDateNeedCovert);
	}
	
	/**
	 * 添加and条件，如：add_time > startValue and add_time < endValue
	 * @param whereList
	 * @param column 数据库字段名
	 * @param startValue
	 * @param endValue
	 */
	public Where addAndWhereCondition(List<Where> whereList, String column, Object startValue, Object endValue) throws Exception {
		return this.addAndWhereCondition(whereList, column, startValue, endValue, true);
	}
	
	/**
	 * 添加and条件，如：add_time > startValue and add_time < endValue
	 * @param whereList
	 * @param column 数据库字段名
	 * @param startValue
	 * @param endValue
	 * @param formatType 格式化类型(date/datetime),默认为date
	 */
	public Where addAndWhereCondition(List<Where> whereList, String column, Object startValue, Object endValue, String formatType) throws Exception {
		return this.addAndWhereCondition(whereList, column, startValue, endValue, true);
	}
	
	/**
	 * 添加and条件，如：add_time > startValue and add_time < endValue
	 * @param whereList
	 * @param column 数据库字段名
	 * @param startValue
	 * @param endValue
	 * @param isDateNeedCovert 时间是否需要转为long，默认为true
	 */
	public Where addAndWhereCondition(List<Where> whereList, String column, Object startValue, Object endValue, boolean isDateNeedCovert) throws Exception {
		return this.addAndWhereCondition(whereList, column, startValue, endValue, isDateNeedCovert, "date");
	}
	
	/**
	 * 添加and条件，如：add_time > startValue and add_time < endValue
	 * @param whereList
	 * @param column 数据库字段名
	 * @param startValue
	 * @param endValue
	 * @param isDateNeedCovert 时间是否需要转为long，默认为true
	 * @param formatType 格式化类型(date/datetime),默认为date
	 */
	public Where addAndWhereCondition(List<Where> whereList, String column, Object startValue, Object endValue, boolean isDateNeedCovert, String formatType) throws Exception {
		return IBaseBussModule.addAndWhereCondition(whereList, column, startValue, endValue, isDateNeedCovert, formatType);
	}
	
	/**
	 * 数据转换(Number/Date -- String)
	 * @param data 要转换的数据(DyResponse/List/Map的子类)
	 * @return
	 */
	public static Object dataConvert(Object data) throws Exception {
		return dataConvert(data, null, null, null, null, null);
	}
	
	/**
	 * 数据转换
	 * @param data 要转换的数据(DyResponse/List/Map的子类)
	 * @param statusColumns 需要转换的状态字段 --> status:getApproveStatus,status1:getApproveStatus1
	 * @return
	 */
	public static Object dataConvert(Object data, String statusColumns) throws Exception {
		return dataConvert(data, statusColumns, null, null, null, null);
	}
	
	/**
	 * 数据转换
	 * @param data 要转换的数据(DyResponse/List/Map的子类)
	 * @param statusColumns 需要转换的状态字段 --> status:getApproveStatus,status1:getApproveStatus1
	 * @param dateColumns 需要转换的时间字段 --> add_time,verify_time
	 * @return
	 */
	public static Object dataConvert(Object data, String statusColumns, String dateColumns) throws Exception {
		return dataConvert(data, statusColumns, dateColumns, null, null, null);
	}
	
	/**
	 * 数据转换
	 * @param data 要转换的数据(DyResponse/List/Map的子类)
	 * @param statusColumns 需要转换的状态字段 --> status:getApproveStatus,status1:getApproveStatus1
	 * @param dateColumns 需要转换的时间字段 --> add_time,verify_time
	 * @param doubleColumns double类型的字段 --> column1,column2
	 * @return
	 */
	public static Object dataConvert(Object data, String statusColumns, String dateColumns, String doubleColumns) throws Exception {
		return dataConvert(data, statusColumns, dateColumns, doubleColumns, null, null);
	}
	
	/**
	 * 数据转换
	 * @param data 要转换的数据(DyResponse/List/Map的子类)
	 * @param statusColumns 需要转换的状态字段 --> status:getApproveStatus,status1:getApproveStatus1
	 * @param dateColumns 需要转换的时间字段 --> add_time,verify_time
	 * @param doubleColumns double类型的字段 --> column1,column2
	 * @param picColumns 图片字段
	 * @return
	 */
	public static Object dataConvert(Object data, String statusColumns, String dateColumns, String doubleColumns, String picColumns) throws Exception {
		return dataConvert(data, statusColumns, dateColumns, doubleColumns, picColumns, null);
	}
	
	/**
	 * 数据转换
	 * @param data 要转换的数据(DyResponse/List/Map的子类)
	 * @param statusColumns 需要转换的状态字段 --> status:getApproveStatus,status1:getApproveStatus1
	 * @param dateColumns 需要转换的时间字段 --> add_time,verify_time
	 * @param doubleColumns double类型的字段 --> column1,column2
	 * @param picColumns 图片字段
	 * @param ipColumns IP字段
	 * @return
	 */
	public static Object dataConvert(Object data, String statusColumns, String dateColumns, String doubleColumns, String picColumns, String ipColumns) throws Exception {
		return DataConvertUtil.dataConvert(data, statusColumns, dateColumns, doubleColumns, picColumns, ipColumns);
	}
	
	/**
	 * 转换id为名称
	 * @param data 待转换的列表
	 * @param module 关联表模块
	 * @param function 关联表名
	 * @param cols 格式：src_col#tar_col:tar_col1,tar_col2
	 * @return
	 * @throws Exception 
	 */
	public Object idToName(List<Map> data, String module,String function, String cols) throws Exception{
		return baseBussModule.idToName(data, module, function, cols);
	}
	public Object idToName(Map data, String module,String function, String cols) throws Exception{
		return baseBussModule.idToName(data, module, function, cols);
	}
	
	/**
	 * 插入一条数据
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @return
	 * @throws Exception
	 */
	public DyResponse insert(String module, String function, Object obj) throws Exception {
		return baseBussModule.insert(module, function, obj);
	}
	
	/**
	 * 根据主键更新数据,为空的属性不更新
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @return
	 * @throws Exception
	 */
	public DyResponse update(String module, String function, Object obj) throws Exception {
		return update(module, function, obj,false);
	}
	
	/**
	 * 根据主键更新数据
	 * @param module
	 * @param function
	 * @param obj DmlItem/Map/BaseEntity
	 * @param isUpdateEmpty 是否更新属性值为空的字段
	 * @return
	 * @throws Exception
	 */
	public DyResponse update(String module, String function, Object obj,boolean isUpdateEmpty) throws Exception {
		return baseBussModule.update(module, function, obj, isUpdateEmpty);
	}
	
	/**
	 * 根据主键(id)删除数据
	 * @param id 要删除的记录ID
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public DyResponse deleteById(Long id, String module, String function) throws Exception {
		return deleteById("id", id, module, function);
	}
	
	/**
	 * 根据主键删除数据(主键字段不是id，要另外指定如：menu_id)
	 * @param pkColumn 数据库字段名
	 * @param id 主键值
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public DyResponse deleteById(String pkColumn, Long id, String module, String function) throws Exception {
		return baseBussModule.deleteById(pkColumn, id, module, function);
	}
	
	/**
	 * 查询单条记录，返回Map<String, Object>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getOneByMap(QueryItem queryItem, String module, String function) throws Exception {
	    return httpInvokerUtil.getOne(queryItem, module, function);
	}
	
	/**
	 * 根据id查询单条记录，返回Map<String, Object>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getById(Serializable id, String module, String function) throws Exception {
		return getById(id, module, function,"");
	}
	public Map<String, Object> getById(Serializable id, String module, String function, String fields) throws Exception {
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		if(StringUtils.isNotBlank(fields)){
			if(fields.startsWith("id,") || fields.indexOf(",id,") > 0){
				queryItem.setFields(fields);
			}else{
				queryItem.setFields("id,"+fields);
			}
		}
		return getOneByMap(queryItem, module, function);
	}
	
	/**
	 * 查询单条记录，返回BaseEntity
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getOneByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		return httpInvokerUtil.getOne(queryItem, module, function, clazz);
	}
	
	/**
	 * 根据id查询单条记录，返回BaseEntity
	 * @param id
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getById(Serializable id, String module, String function, Class<T> clazz) throws Exception {
		return httpInvokerUtil.getOneById(id, module, function, clazz);
	}
	
	/**
	 * 根据id查询单条记录，返回BaseEntity
	 * @param id
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getById(Serializable id, String module, String function, Class<T> clazz,String cols) throws Exception {
		return httpInvokerUtil.getOneById(id, module, function, clazz,cols);
	}
	
	/**
	 * 查询列表,返回List<Map<String, Object>>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public List<Map> getListByMap(QueryItem queryItem, String module, String function) throws Exception {
		return httpInvokerUtil.getList(queryItem, module, function);
	}
	
	/**
	 * 
	 * 查询指定条件的数量 
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 * @author likf
	 */
	public Long getCount(QueryItem queryItem, String module, String function) throws Exception {
	    queryItem.setFields("count(1) cnt"); 
        List<Map> list=httpInvokerUtil.getList(queryItem, module, function);
        return MapUtils.getLong(list.get(0),"cnt");
    }
	
	/**
	 * 查询列表，返回Page<Map>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Page<Map> getPageByMap(QueryItem queryItem, String module, String function) throws Exception {
		return httpInvokerUtil.getPage(queryItem, module, function);
	}
	
	/**
	 * 查询列表，返回List<BaseEntity>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public <T> List<T> getListByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		return httpInvokerUtil.getList(queryItem, module, function, clazz);
	}
	
	/**
	 * 查询列表，返回Page<BaseEntity>
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public <T> Page<T> getPageByEntity(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		return httpInvokerUtil.getPage(queryItem, module, function, clazz);
	}
	
	/**
	 * 获取条件范围id
	 * @param module 关联模块
	 * @param function 关联模块的表
	 * @param col 关联表字段
	 * @param cond 过滤条件值
	 * @return
	 * @throws Exception
	 */
	public List<Object> getIdsLike(String module, String function,String col,Object cond) throws Exception {
		String[] cols = col.split(":");
		String field = "id";
		if(cols.length > 1){
			field = cols[1];
		}
		
		QueryItem queryItem = new QueryItem(Where.likeAll(cols[0], cond));
		return getIds(module, function, field, queryItem);
	}
	
	/**
	 * 获取条件范围字段
	 * @param module 关联模块
	 * @param function 关联模块的表
	 * @param field 取值
	 * @param where 过滤条件值
	 * @return
	 * @throws Exception
	 */
	public List<Object> getIds(String module, String function,Where... where) throws Exception {
		return getIds(module,function,"id",where);
	}
	/**
	 * 获取条件范围id
	 * @param module 关联模块
	 * @param function 关联模块的表
	 * @param where 过滤条件值
	 * @return
	 * @throws Exception
	 */
	public List<Object> getIds(String module, String function,String field,Where... where) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setWhere(Arrays.asList(where));
		return getIds(module, function, field, queryItem);
	}
	
	/**
	 * 获取条件范围id
	 * @param module 关联模块
	 * @param function 关联模块的表
	 * @param col 关联表字段
	 * @param cond 过滤条件值
	 * @return
	 * @throws Exception
	 */
	public List<Object> getIds(String module, String function,List<Where> where) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setWhere(where);
		return getIds(module, function, "id", queryItem);
	}
	
	/**
	 * 获取条件范围id
	 * @param module 关联模块
	 * @param function 关联模块的表
	 * @param col 关联表字段
	 * @param cond 过滤条件值
	 * @return
	 * @throws Exception
	 */
	public List<Object> getIdsEq(String module, String function,String col,Object cond) throws Exception {
		String[] cols = col.split(":");
		String field = "id";
		if(cols.length > 1){
			field = cols[1];
		}
		QueryItem queryItem = new QueryItem(Where.eq(cols[0], cond));
		return getIds(module, function, field, queryItem);
	}

	private List<Object> getIds(String module, String function, String field, QueryItem queryItem) throws Exception {
		queryItem.setPage(1);
		queryItem.setLimit(100); // 限定模糊条件100内
		queryItem.setFields(field);
		List<Map> ents = this.getListByMap(queryItem, module, function);
		
		List<Object> ids = Lists.newArrayList();
		if(ents != null){
			for(Map s:ents){
				ids.add(MapUtils.getString(s, field));
			}
		}
		return ids;
	}
	
	/**
	 * 获取条件范围id
	 * @param module 关联模块
	 * @param function 关联模块的表
	 * @param col 关联表字段
	 * @param cond 过滤条件值
	 * @return
	 * @throws Exception
	 */
	public List<Object> getIdsIn(String module, String function,String col, List<Object> conds) throws Exception {
		String[] cols = col.split(":");
		String field = "id";
		if(cols.length > 1){
			field = cols[1];
		}
		QueryItem queryItem = new QueryItem(Where.in(cols[0], conds));
		return getIds(module, function, field, queryItem);
	}
	
	/**
	 * List<Option>转Map
	 * @param optionList
	 * @return
	 */
	public Map<Object, String> optionListToMap(List<Option> optionList) {
		Map<Object, String> result = new HashMap<Object, String>();
		for(Option option : optionList) result.put(option.getValue(), option.getText());
		
		return result;
	}
	
	/**
	 * 实体转Map
	 * @param baseEntity
	 * @return
	 */
	public Map<String, Object> convertEntityToMap(BaseEntity baseEntity) {
		if(baseEntity == null) return null;
		return EntityUtils.toMap(baseEntity);
	}
	
	public String getBasePath() {
		return RequestUtil.getBasePath();
	}
	
	/**
	 * 非空校验
	 * @param obj(Map/BaseEntity) 要做校验的数据 
	 * @param columns 要做非空校验的字段
	 * @param texts 提示信息
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String validateNull(Object obj, String[] columns, String[] texts) {
		if(columns == null || texts == null	|| columns.length <= 0
				|| texts.length <= 0 || columns.length != texts.length)
			return null;
		
		String errorMsg = null;
		for(int i=0;i<columns.length;i++) {
			String column = columns[i];
			Object value = null;
			if (obj instanceof Map) { //Map
				if (columns[i] == null) {
					continue;
				}
				value = ((Map<String, Object>) obj).get(column);
			} else if (obj instanceof BaseEntity) { //BaseEntity
				if (columns[i] == null) {
					continue;
				}
				value = ReflectUtil.getFieldValue(obj, column);
			} else if (obj instanceof Object[]) { //Object[]
				value = ((Object[]) obj)[i];
			}
			
			boolean isNull = false;
			if(value instanceof String) {
				if(value == null || StringUtils.isEmpty(value.toString())) isNull = true;
			} else if(value instanceof Object[]) {
				Object[] arrayValue = (Object[])value;
				if(arrayValue.length <= 0 || arrayValue[0] == null) isNull = true;
				else if(arrayValue[0] instanceof String && StringUtils.isEmpty(arrayValue[0].toString())) isNull = true;
			} else {
				if(value == null) isNull = true;
			}
			
			if(isNull) {
				errorMsg = this.getMessage("validate.notnull", new String[]{texts[i]});
				break;
			}
		}
		
		return errorMsg;
	}
	
	public void validateNull(Object obj, String columnsStr) {
		String[] columns = columnsStr.split(",");
		for(int i=0;i<columns.length;i++) {
			String column = columns[i];
			Object value = null;
			if (obj instanceof Map) { //Map
				if (columns[i] == null) {
					continue;
				}
				value = ((Map<String, Object>) obj).get(column);
			} else if (obj instanceof BaseEntity) { //BaseEntity
				if (columns[i] == null) {
					continue;
				}
				value = ReflectUtil.getFieldValue(obj, column);
			} else if (obj instanceof Object[]) { //Object[]
				value = ((Object[]) obj)[i];
			}
			
			boolean isNull = false;
			if(value instanceof String) {
				if(StringUtils.isEmpty((String)value)) isNull = true;
			} else if(value instanceof Object[]) {
				Object[] arrayValue = (Object[])value;
				if(arrayValue.length <= 0 || arrayValue[0] == null) isNull = true;
				else if(arrayValue[0] instanceof String && StringUtils.isEmpty(arrayValue[0].toString())) isNull = true;
			} else {
				if(value == null) isNull = true;
			}
			
			if(isNull) {
				throw new DyWebException("validate.notnull",new String[]{column});
			}
		}
	}
	
	/**
	 * 初始化数据绑定
	 * 1. 将所有传递进来的String进行HTML编码，防止XSS攻击
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		// String类型转换，将所有传递进来的String进行HTML编码，防止XSS攻击
//		binder.registerCustomEditor(String.class, new PropertyEditorSupport() {
//			@Override
//			public void setAsText(String text) {
//			    setValue(text == null ? null : SecurityUtil.cleanXSS(text.trim()));
//			}
//		});
		// Date 类型转换
		binder.registerCustomEditor(Date.class, new PropertyEditorSupport() {
			@Override
			public void setAsText(String text) {
				Date d = DateUtil.timeParse(text);
				if(d == null){
					d = DateUtil.dateParse(text);
				}
				setValue(d);
			}
//			@Override
//			public String getAsText() {
//				Object value = getValue();
//				return value != null ? DateUtils.formatDateTime((Date)value) : "";
//			}
		});
		// Long 类型转换
		binder.registerCustomEditor(Long.class, new PropertyEditorSupport() {
			@Override
			public void setAsText(String text) {
				if(text.indexOf('-') > 0){
					// 日期格式
					setValue(DateUtil.convert(text));
				}else if(StringUtils.isNotEmpty(text)){
					try {
						setValue(Long.valueOf(text));
					} catch (Exception e) {
						setValue(0L);
						logger.warn("转换异常："+text);
					}
				}
			}
		});
		// Integer 类型转换
		binder.registerCustomEditor(Integer.class, new PropertyEditorSupport() {
			@Override
			public void setAsText(String text) {
				if(StringUtils.isNotEmpty(text)){
					try {
						setValue(Integer.valueOf(text));
					} catch (Exception e) {
						setValue(0);
						logger.warn("转换异常："+text);
					}
				}
			}
		});
		// BigDecimal 类型转换
		binder.registerCustomEditor(BigDecimal.class, new PropertyEditorSupport() {
			@Override
			public void setAsText(String text) {
				if(StringUtils.isNotEmpty(text)){
					try {
						setValue(new BigDecimal(text));
					} catch (Exception e) {
						logger.warn("转换异常："+text, e);
					}
				}
			}
		});
	}
	
	/**
	 * 是否登录
	 * @return
	 */
	public boolean isLogin(){
		return getSessionAttribute(Constant.SESSION_USER) != null;
	}
	
	/**
	 * 获取登录用户id
	 */
	public abstract Long getUserId();
}