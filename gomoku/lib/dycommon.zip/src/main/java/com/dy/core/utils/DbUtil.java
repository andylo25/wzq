package com.dy.core.utils;

import com.dy.core.entity.BaseEntity;
import com.dy.core.utils.common.SpringContextHolder;

/**
 * 并发数据操作cas
 * @author cuiwm
 *
 */
public class DbUtil {
	
	private static HttpInvoker httpInvoker;
	private static HttpInvoker getHttpInvoker(){
		if(httpInvoker == null){
			httpInvoker = SpringContextHolder.getBean(HttpInvoker.class);
		}
		return httpInvoker;
	}
	
	public static Object doInCas(IUpdateAction action){
		Object resu = null;
		int times = 3;
		while(resu == null && times-- > 0){
			// 查询
			BaseEntity entity = action.getOne();
			// 更新
			resu = action.update(entity);
		}
		return resu;
	}
	
	public static interface IUpdateAction<T extends BaseEntity> {
		T getOne();
		Object update(BaseEntity entity);
		
	}
}
