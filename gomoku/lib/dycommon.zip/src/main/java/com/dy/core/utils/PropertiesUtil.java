package com.dy.core.utils;

import java.io.InputStream;
import java.util.Properties;

public class PropertiesUtil {
	public static Properties properties = new Properties();
	
	static {
		try {
		    String profile=System.getProperty("spring.profiles.active");
		    String[] props = null;
		    if(profile!=null&&!"".equals(profile)){
		    	InputStream inputStream = PropertiesUtil.class.getClassLoader().getResourceAsStream("application-"+profile+".properties");
		    	if(inputStream != null){
		    		props = new String[]{"system.properties","application-"+profile+".properties"};
		    	}else{
		    		props = new String[]{"system.properties","application.properties"};
		    	}
		    } else{
                props = new String[]{"system.properties","application.properties"};
            }
			for(String prop:props){
				InputStream inputStream = PropertiesUtil.class.getClassLoader().getResourceAsStream(prop);
				if(inputStream != null){
					Properties propertiest = new Properties();
					propertiest.load(inputStream);
					properties.putAll(propertiest);
				}
			}
		} catch(Exception e) {}
	}
	
	/**
	 * 从system.properties中获取相应配置项的值
	 * @param key 相应配置项的key
	 * @return
	 */
	public static String getProperty(String key) {
		return properties.getProperty(key) == null ? "" : properties.get(key).toString();
	}
	
	/**
	 * 是否测试环境
	 * @return
	 */
	public static boolean isTest() {
		return "true".equals(properties.getProperty("test.on")) ? true : false;
	}
	
	public static String getDatabaseType() {
		return getProperty("dy.databaseType");
	}
	
	/**
	 * 获取AES加密密钥(system.properties -> AES_KEY)
	 * @return
	 */
	public static String getAesKey() {
		return properties.getProperty("AES_KEY") == null ? "#123we#$%^fdhg34" : properties.get("AES_KEY").toString();
	}
	
	/**
	 * 获取data端URL(system.properties -> SERVER_URL)
	 * @return
	 */
	public static String getHost() {
		return properties.getProperty("SERVER_URL") == null ? "http://localhost:8080/diyou_server" : properties.get("SERVER_URL").toString();
	}
	
	/**
	 * 获取图片服务器URL(system.properties -> IMAGE_VIEW_SERVER_URL)
	 * @return
	 */
	public static String getImageHost() {
		return properties.getProperty("IMAGE_VIEW_SERVER_URL") == null ? "http://localhost:8080/diyou_image" : properties.get("IMAGE_VIEW_SERVER_URL").toString();
	}
	/**
	 * 获取图片上传服务器URL(system.properties -> IMAGE_SERVER_URL)
	 * @return
	 */
	public static String getImageUploadHost() {
		return properties.getProperty("IMAGE_SERVER_URL") == null ? "http://localhost:8080/diyou_image" : properties.get("IMAGE_SERVER_URL").toString();
	}
}