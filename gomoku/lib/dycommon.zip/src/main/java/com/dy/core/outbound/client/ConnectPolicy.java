package com.dy.core.outbound.client;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * 客户端调用连接策略
 * <p>
 */
public class ConnectPolicy implements Cloneable {

	
	private int requestTimeout; // 请求超时时间，等待数据的超时时间
	
	private int connectTimeout; // 连接建立的超时时间
	
	private int retryTimes; // 对目标服务器的重试次数
	/*
	 * 是否采用失效备援调用方式（及群集调用中当前服务器处理失败，自动切换到下一台服务器， 直至尝试群集中所有服务器，才返回错误）
	 */
	private boolean failover;
	
	private int failThenSkipTimes; // 服务器失败后，需要跳过的请求次数

	public Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}

	@XmlAttribute(name="request-timeout")
	public int getRequestTimeout() {
		return requestTimeout;
	}

	public void setRequestTimeout(int requestTimeout) {
		this.requestTimeout = requestTimeout;
	}

	@XmlAttribute(name="connect-timeout")
	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	@XmlAttribute(name="retry-times")
	public int getRetryTimes() {
		return retryTimes;
	}

	public void setRetryTimes(int retryTimes) {
		this.retryTimes = retryTimes;
	}

	public boolean isFailover() {
		return failover;
	}

	@XmlAttribute(name="failover")
	public void setFailover(boolean failover) {
		this.failover = failover;
	}

	@XmlAttribute(name="fail-then-skip-times")
	public int getFailThenSkipTimes() {
		return failThenSkipTimes;
	}

	public void setFailThenSkipTimes(int failThenSkipTimes) {
		this.failThenSkipTimes = failThenSkipTimes;
	}
}
