package com.dy.core.utils.multiquery;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.Page;
import com.dy.core.exception.DyServiceException;
import com.dy.core.service.BaseService;

/**
 *	多表查询
 *	拆分关联查询,多次进行单表查询，并返回结果集
 */
@Repository
public class MultiQuery {
	
	@Autowired
	private BaseService baseService ;
	/**
	 * 多表查询
	 * @param queryItem 主表的原始查询条件
	 * @param multiConditions 关联表查询条件
	 * @return 查询结果
	 * @throws DyServiceException 
	 */
	public Page<Map> join(QueryItem queryItem ,List<MultiCondition> multiConditions) throws DyServiceException{
		QueryItem joinQuery = null ;
		//关联查询结果集
		List<Map<Object,Object>> joinResultList = null ;
		Map<String,Map> joinMap = null ;
		Map<String,Map> allJoinMap = new HashMap<String, Map>() ;
		StringBuilder inSql = null ;
		//为提升效率，如果需要关联的结果没有条件，则进行反向查询
		List<MultiCondition> reverseCondition = new ArrayList<MultiCondition>();
		for (MultiCondition multiCondition : multiConditions) {
			joinQuery = multiCondition.getQueryItem() ;
			//没有条件，添加到反向查询
			if(null == joinQuery.getWhere() || joinQuery.getWhere().isEmpty()){
				reverseCondition.add(multiCondition) ;
				continue ;
			}
			joinResultList = (List<Map<Object, Object>>) this.baseService.getList(joinQuery) ;
			
			//最终主表的in查询条件
			inSql = new StringBuilder() ;
			//将关联表的数据以关联条件为key存入Map
			joinMap = new HashMap<String, Map>() ;
			for (Map<Object, Object> map : joinResultList) {
				String key = MapUtils.getString(map, multiCondition.getMainJoinCondition()) ;
				inSql.append(key).append(",") ;
				joinMap.put(key, map) ;
			}
			//通过别名为key将关联查询结果存入map
			allJoinMap.put(multiCondition.getAlias(), joinMap) ;
			//在条件中加入子表的结果
			queryItem.getWhere().add(Where.in(multiCondition.getSubJoinCondition(), inSql.toString())) ;
		}
		//查出主表的结果
		Page<Map> page = this.baseService.getPage(queryItem,Map.class) ;
		List<Map> result = page.getItems() ;
		//反向查询
		if(!reverseCondition.isEmpty()){
			for (MultiCondition multiCondition : reverseCondition) {
				inSql = new StringBuilder() ;
				for (Map map : result) {
					inSql.append(MapUtils.getString(map, multiCondition.getSubJoinCondition()) + ",") ;
				}
				queryItem = multiCondition.getQueryItem() ;
				queryItem.getWhere().add(Where.in(multiCondition.getMainJoinCondition(), inSql.toString())) ;
				joinResultList = (List<Map<Object, Object>>) this.baseService.getList(queryItem) ;
				joinMap = new HashMap<String, Map>() ;
				//将关联表的数据以关联条件为key存入Map
				for (Map<Object, Object> map : joinResultList) {
					String key = MapUtils.getString(map, multiCondition.getMainJoinCondition()) ;
					joinMap.put(key, map) ;
				}
				//通过别名为key将关联查询结果存入map
				allJoinMap.put(multiCondition.getAlias(), joinMap) ;
			}
		}
		
		Set<String> keySet = null ;
		Map tableResult = null ;
		for (Map map : result) {
			for (MultiCondition multiCondition : multiConditions) {
				//从map中取出之前的关联结果
				joinMap = allJoinMap.get(multiCondition.getAlias()) ;
				//通过关联条件取得之前存入map的关联查询结果
				tableResult = joinMap.get(MapUtils.getString(map, multiCondition.getSubJoinCondition())) ;
				if(null == tableResult){
					tableResult = new HashMap() ;
				}
				keySet = tableResult.keySet() ;
				//关联表的数据以表的别名+"_"+原始名称存入主表的结果
				for (String key : keySet) {
					map.put(multiCondition.getAlias() + "_" + key, tableResult.get(key));
				}
			}
		}
		return page ;
	}
}
