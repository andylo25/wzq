package com.dy.core.dao.transaction;

import org.springframework.stereotype.Component;

import com.dy.core.exception.DyRemoteException;

@Component
public class DyTransactionManagerImpl implements DyTransactionManager{

	ThreadLocal<DyTransaction> trans = new ThreadLocal<>();
	
	@Override
	public void commit() throws DyRemoteException {
		DyTransaction transaction = trans.get();
		if(transaction != null){
			transaction.commit();
		}
		trans.remove();
	}

	@Override
	public void rollback() throws DyRemoteException {
		try {
			DyTransaction transaction = trans.get();
			if(transaction != null){
				transaction.rollback();
			}
		} catch (Exception e) {
			throw new DyRemoteException("回滚异常",e);
		} finally{
			trans.remove();
		}
	}

	@Override
	public void begin() throws DyRemoteException {
		trans.set(new DyTransaction());
	}

	@Override
	public DyTransaction curTransaction() {
		return trans.get();
	}

}
