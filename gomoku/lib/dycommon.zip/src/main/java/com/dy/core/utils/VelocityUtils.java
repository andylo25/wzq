package com.dy.core.utils;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;

import com.google.common.collect.Maps;

public class VelocityUtils {

	/**
	 * 根据字符串模板渲染
	 * @param content
	 * @param model
	 * @return
	 */
	public static String renderString(String content,Map<String,Object> model) {
		if(StringUtils.isBlank(content))return content;
	    // 初始化模板引擎
	    VelocityEngine ve = new VelocityEngine();
	    ve.init();
	    VelocityContext ctx = buildContext(model);
	    // 输出
	    StringWriter sw = new StringWriter();
	    ve.evaluate(ctx, sw, "", escape(content));
	    return sw.toString();
	}
	
	private static VelocityContext buildContext(Map<String, Object> model) {
		VelocityContext ctx = new VelocityContext(model);
		// 设置变量
		ctx.put("DICT", DictUtils.class); // 字典转换
		ctx.put("DU", DateUtil.class); // 日期转换
		ctx.put("NU", NumberUtils.class); // 金额转换
		
		return ctx;
	}

	/**
	 * 根据模板名称渲染
	 * @param tpl
	 * @param model
	 * @return
	 */
	public static String renderTpl(String tpl,Map<String,Object> model) {
		// 初始化模板引擎
	    VelocityEngine ve = new VelocityEngine();
	    ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
	    ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
	    ve.init();
	    // 获取模板文件
	    if(!tpl.endsWith(".vm")){
	    	tpl = tpl + ".vm";
	    }
	    Template t = ve.getTemplate(tpl);
	    
	    VelocityContext ctx = buildContext(model);
	    
	    // 输出
	    StringWriter sw = new StringWriter();
	    t.merge(ctx,sw);
	    return sw.toString();
	}

	/**
	 * 包装html片段
	 * @param content
	 */
	public static String buildHtml(String content) {
		String head = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /></head><body>";
		String foot = "</body></html>";
		
		return head+content+foot;
	}
	
	/**
	 * 反转义单引号
	 * @return
	 */
	private static String escape(String content){
		if(content == null)return "";
		return content.replace("&#39;", "'");
	}
	
	public static void main(String[] args) {
		HashMap<String, Object> model = Maps.newHashMap();
		model.put("a", new BigDecimal("-12456456.120012"));
		model.put("b", Collections.singletonMap("c",new BigDecimal("-12456456.120012")));
//		String fds = renderString("${NU.format($a)}", model);
		String fds = renderString("${NU.getTest($b.c,'dddd')}", model);
		System.out.println(fds);
	}
	
}
