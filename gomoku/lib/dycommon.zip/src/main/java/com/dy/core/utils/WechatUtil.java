package com.dy.core.utils;

import java.util.HashMap;
import java.util.Map;

public class WechatUtil {

	public static final Integer OK = 0;

	public static final Integer ERR = -1;

	public static final Integer ERR_ACCESS_TOKEN = 42001;

	/**
	 * 微信服务器返回的json字符串，或者中文错误信息
	 * 
	 * @param errCode
	 * @return
	 */
	public static String getErrMsgCn(String msg) {
		Map map = JsonUtils.fromJson(msg, HashMap.class);
		return getErrMsgCn(((Double) map.get("errcode")).intValue());
	}

	/**
	 * 微信错误码，获取错误消息
	 * 
	 * @param errCode
	 * @return
	 */
	public static String getErrMsgCn(Integer errCode) {
		if (1 == errCode) {
			return "系统繁忙，此时请开发者稍候再试";
		}
		if (0 == errCode) {
			return "更新成功";
		}
		if (40001 == errCode) {
			return "获取access_token时AppSecret错误，或者access_token无效。请开发者认真比对AppSecret的正确性，或查看是否正在为恰当的公众号调用接口";
		}
		if (40002 == errCode) {
			return "不合法的凭证类型";
		}
		if (40003 == errCode) {
			return "不合法的OpenID，请开发者确认OpenID（该用户）是否已关注公众号，或是否是其他公众号的OpenID";
		}
		if (40004 == errCode) {
			return "不合法的媒体文件类型";
		}
		if (40005 == errCode) {
			return "不合法的文件类型";
		}
		if (40006 == errCode) {
			return "不合法的文件大小";
		}
		if (40007 == errCode) {
			//return "不合法的媒体文件id";
			return "请先上传图文再操作";
		}
		if (40008 == errCode) {
			return "不合法的消息类型";
		}
		if (40009 == errCode) {
			return "不合法的图片文件大小";
		}
		if (40010 == errCode) {
			return "不合法的语音文件大小";
		}
		if (40011 == errCode) {
			return "不合法的视频文件大小";
		}
		if (40012 == errCode) {
			return "不合法的缩略图文件大小";
		}
		if (40013 == errCode) {
			return "不合法的AppID，请开发者检查AppID的正确性，避免异常字符，注意大小写";
		}
		if (40014 == errCode) {
			return "不合法的access_token，请开发者认真比对access_token的有效性（如是否过期），或查看是否正在为恰当的公众号调用接口";
		}
		if (40015 == errCode) {
			return "不合法的菜单类型";
		}
		if (40016 == errCode) {
			return "不合法的按钮个数";
		}
		if (40017 == errCode) {
			return "不合法的按钮个数";
		}
		if (40018 == errCode) {
			return "不合法的按钮名字长度";
		}
		if (40019 == errCode) {
			return "不合法的按钮KEY长度";
		}
		if (40020 == errCode) {
			return "不合法的按钮URL长度";
		}
		if (40021 == errCode) {
			return "不合法的菜单版本号";
		}
		if (40022 == errCode) {
			return "不合法的子菜单级数";
		}
		if (40023 == errCode) {
			return "不合法的子菜单按钮个数";
		}
		if (40024 == errCode) {
			return "不合法的子菜单按钮类型";
		}
		if (40025 == errCode) {
			return "不合法的子菜单按钮名字长度";
		}
		if (40026 == errCode) {
			return "不合法的子菜单按钮KEY长度";
		}
		if (40027 == errCode) {
			return "不合法的子菜单按钮URL长度";
		}
		if (40028 == errCode) {
			return "不合法的自定义菜单使用用户";
		}
		if (40029 == errCode) {
			return "不合法的oauth_code";
		}
		if (40030 == errCode) {
			return "不合法的refresh_token";
		}
		if (40031 == errCode) {
			return "不合法的openid列表";
		}
		if (40032 == errCode) {
			return "不合法的openid列表长度";
		}
		if (40033 == errCode) {
			return "不合法的请求字符，不能包含\\uxxxx格式的字符";
		}
		if (40035 == errCode) {
			return "不合法的参数";
		}
		if (40038 == errCode) {
			return "不合法的请求格式";
		}
		if (40039 == errCode) {
			return "不合法的URL长度";
		}
		if (40050 == errCode) {
			return "不合法的分组id";
		}
		if (40051 == errCode) {
			return "分组名字不合法";
		}
		if (40117 == errCode) {
			return "分组名字不合法";
		}
		if (40118 == errCode) {
			return "media_id大小不合法";
		}
		if (40119 == errCode) {
			return "button类型错误";
		}
		if (40120 == errCode) {
			return "button类型错误";
		}
		if (40121 == errCode) {
			return "不合法的media_id类型";
		}
		if (40132 == errCode) {
			return "微信号不合法";
		}
		if (40137 == errCode) {
			return "不支持的图片格式";
		}
		if (41001 == errCode) {
			return "缺少access_token参数";
		}
		if (41002 == errCode) {
			return "缺少appid参数";
		}
		if (41003 == errCode) {
			return "缺少refresh_token参数";
		}
		if (41004 == errCode) {
			return "缺少secret参数";
		}
		if (41005 == errCode) {
			return "缺少多媒体文件数据";
		}
		if (41006 == errCode) {
			return "缺少media_id参数";
		}
		if (41007 == errCode) {
			return "缺少子菜单数据";
		}
		if (41008 == errCode) {
			return "缺少oauth code";
		}
		if (41009 == errCode) {
			return "缺少openid";
		}
		if (42001 == errCode) {
			return "access_token超时，请检查access_token的有效期，请参考基础支持-获取access_token中，对access_token的详细机制说明";
		}
		if (42002 == errCode) {
			return "refresh_token超时";
		}
		if (42003 == errCode) {
			return "oauth_code超时";
		}
		if (43001 == errCode) {
			return "需要GET请求";
		}
		if (43002 == errCode) {
			return "需要POST请求";
		}
		if (43003 == errCode) {
			return "需要HTTPS请求";
		}
		if (43004 == errCode) {
			return "需要接收者关注";
		}
		if (43005 == errCode) {
			return "需要好友关系";
		}
		if (44001 == errCode) {
			return "多媒体文件为空";
		}
		if (44002 == errCode) {
			return "POST的数据包为空";
		}
		if (44003 == errCode) {
			return "图文消息内容为空";
		}
		if (44004 == errCode) {
			return "文本消息内容为空";
		}
		if (45001 == errCode) {
			return "多媒体文件大小超过限制";
		}
		if (45002 == errCode) {
			return "消息内容超过限制";
		}
		if (45003 == errCode) {
			return "标题字段超过限制";
		}
		if (45004 == errCode) {
			return "描述字段超过限制";
		}
		if (45005 == errCode) {
			return "链接字段超过限制";
		}
		if (45006 == errCode) {
			return "图片链接字段超过限制";
		}
		if (45007 == errCode) {
			return "语音播放时间超过限制";
		}
		if (45008 == errCode) {
			return "图文消息超过限制";
		}
		if (45009 == errCode) {
			return "接口调用超过限制";
		}
		if (45010 == errCode) {
			return "创建菜单个数超过限制";
		}
		if (45015 == errCode) {
			return "回复时间超过限制";
		}
		if (45016 == errCode) {
			return "系统分组，不允许修改";
		}
		if (45017 == errCode) {
			return "分组名字过长";
		}
		if (45018 == errCode) {
			return "分组数量超过上限";
		}
		if (46001 == errCode) {
			return "不存在媒体数据";
		}
		if (46002 == errCode) {
			return "不存在的菜单版本";
		}
		if (46003 == errCode) {
			return "不存在的菜单数据";
		}
		if (46004 == errCode) {
			return "不存在的用户";
		}
		if (47001 == errCode) {
			return "解析JSON/XML内容错误";
		}
		if (48001 == errCode) {
			return "api功能未授权，请确认公众号已获得该接口，可以在公众平台官网-开发者中心页中查看接口权限";
		}
		if (50001 == errCode) {
			return "用户未授权该api";
		}
		if (50002 == errCode) {
			return "用户受限，可能是违规后接口被封禁";
		}
		if (61451 == errCode) {
			return "参数错误(invalid parameter)";
		}
		if (61452 == errCode) {
			return "无效客服账号(invalid kf_account)";
		}
		if (61453 == errCode) {
			return "客服账号已存在(kf_account exsited)";
		}
		if (61454 == errCode) {
			return "客服账号名长度超过限制(仅允许10个英文字符，不包括@及@后的公众号的微信号)(invalid kf_acount length)";
		}
		if (61455 == errCode) {
			return "客服账号名包含非法字符(仅允许英文+数字)(illegal character in kf_account)";
		}
		if (61456 == errCode) {
			return "客服账号个数超过限制(10个客服账号)(kf_account count exceeded)";
		}
		if (61457 == errCode) {
			return "无效头像文件类型(invalid file type)";
		}
		if (61450 == errCode) {
			return "系统错误(system error)";
		}
		if (61500 == errCode) {
			return "日期格式错误";
		}
		if (61501 == errCode) {
			return "日期范围错误";
		}
		if (9001001 == errCode) {
			return "POST数据参数不合法";
		}
		if (9001002 == errCode) {
			return "远端服务不可用";
		}
		if (9001003 == errCode) {
			return "Ticket不合法";
		}
		if (9001004 == errCode) {
			return "获取摇周边用户信息失败";
		}
		if (9001005 == errCode) {
			return "获取商户信息失败";
		}
		if (9001006 == errCode) {
			return "获取OpenID失败";
		}
		if (9001007 == errCode) {
			return "上传文件缺失";
		}
		if (9001008 == errCode) {
			return "上传素材的文件类型不合法";
		}
		if (9001009 == errCode) {
			return "上传素材的文件尺寸不合法";
		}
		if (9001010 == errCode) {
			return "上传失败";
		}
		if (9001020 == errCode) {
			return "账号不合法";
		}
		if (9001021 == errCode) {
			return "已有设备激活率低于50%，不能新增设备";
		}
		if (9001022 == errCode) {
			return "设备申请数不合法，必须为大于0的数字";
		}
		if (9001023 == errCode) {
			return "已存在审核中的设备ID申请";
		}
		if (9001024 == errCode) {
			return "一次查询设备ID数量不能超过50";
		}
		if (9001025 == errCode) {
			return "设备ID不合法";
		}
		if (9001026 == errCode) {
			return "页面ID不合法";
		}
		if (9001027 == errCode) {
			return "页面参数不合法";
		}
		if (9001028 == errCode) {
			return "一次删除页面ID数量不能超过10";
		}
		if (9001029 == errCode) {
			return "页面已应用在设备中，请先解除应用关系再删除";
		}
		if (9001030 == errCode) {
			return "一次查询页面ID数量不能超过50";
		}
		if (9001031 == errCode) {
			return "时间区间不合法";
		}
		if (9001032 == errCode) {
			return "保存设备与页面的绑定关系参数错误";
		}
		if (9001033 == errCode) {
			return "门店ID不合法";
		}
		if (9001034 == errCode) {
			return "设备备注信息过长";
		}
		if (9001035 == errCode) {
			return "设备申请参数不合法";
		}
		if (9001036 == errCode) {
			return "查询起始值begin不合法";
		}
		return "未知错误";
	}

}
