package com.dy.core.httpinvoker.client;


import org.aopalliance.intercept.MethodInvocation;
import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;

import com.dy.core.exception.DyRemoteException;
import com.dy.core.exception.DyUncheckedException;
import com.dy.core.httpinvoker.HttpInvokerHeader;
import com.dy.core.httpinvoker.SwapContext;
import com.dy.core.utils.GlobalConf;
import com.dy.core.utils.RequestUtil;

/**
 * 客户端请求代理
 * @author cuiwm
 *
 */
public class DyHttpInvokerProxyFactoryBean extends HttpInvokerProxyFactoryBean {

	@Override
	public Object invoke(MethodInvocation methodInvocation) throws Throwable {
		
		try {
			Object result = super.invoke(methodInvocation);
			return result;
		} catch (DyUncheckedException ex) {
			throw ex;
		} catch (Throwable ex) {
			throw new DyRemoteException("data.submit.error",ex);
		}
	}
	
	/**
	 * 加入客户端信息头调用链传递context
	 */
	protected RemoteInvocationResult executeRequest(
			RemoteInvocation invocation, MethodInvocation originalInvocation) throws Exception{
		HttpInvokerHeader header = new HttpInvokerHeader();
		header.setFromApp(GlobalConf.getAppId());
		header.setUser(RequestUtil.getUser());
		header.setIp(RequestUtil.getRemoteIp());
		invocation.addAttribute(SwapContext.HttpInvokerHeader_key_, header);
		RemoteInvocationResult result = super.executeRequest(invocation, originalInvocation);
		
		// 检测是否有异常
		
		return result;
		
	}

}
