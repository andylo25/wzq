
package com.dy.core.httpinvoker.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.springframework.remoting.httpinvoker.HttpComponentsHttpInvokerRequestExecutor;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;

/**
 * 客户端编解码(httpclient方式)
 * @author cuiwm
 *
 */
public class KryoHttpComponentsInvokerRequestExecutor extends HttpComponentsHttpInvokerRequestExecutor {
	
	protected void writeRemoteInvocation(RemoteInvocation invocation, OutputStream os) throws IOException {
		super.writeRemoteInvocation(invocation, os);
		
//		Kryo kryo = new Kryo();
//		Output output = new Output(os);
//		try {
//			kryo.writeObject(output, invocation);
//		}
//		finally {
//			output.close();
//		}
	}
	
	protected RemoteInvocationResult readRemoteInvocationResult(InputStream is, String codebaseUrl)
			throws IOException, ClassNotFoundException {

		return super.readRemoteInvocationResult(is, codebaseUrl);
		
//		Kryo kryo = new Kryo();
//		Input input = new Input(is);
//		try {
//			return kryo.readObject(input, RemoteInvocationResult.class);
//		}
//		finally {
//			input.close();
//		}
	}

}
