package com.dy.core.entity;

import java.io.Serializable;

/**
 * 贷款变更事件
 * @author cuiwm
 *
 */
public class CreditEvent implements Serializable{

	private static final long serialVersionUID = 1L;
	
	

}
