package com.dy.core.httpinvoker.server;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;

import com.dy.core.httpinvoker.HttpInvokerHeader;
import com.dy.core.httpinvoker.SwapContext;

/**
 * 服务提供端编解码
 * @author cuiwm
 *
 */
public class KryoHttpInvokerServiceExporter extends HttpInvokerServiceExporter {


	protected RemoteInvocation readRemoteInvocation(HttpServletRequest request, InputStream is)
			throws IOException, ClassNotFoundException {
		return super.readRemoteInvocation(request, is);
		
//		Kryo kryo = new Kryo();
//		Input input = new Input(is);
//		try {
//			return kryo.readObject(input, RemoteInvocation.class);
//		}
//		finally {
//			input.close();
//		}
	}

	protected void writeRemoteInvocationResult(
			HttpServletRequest request, HttpServletResponse response, RemoteInvocationResult result, OutputStream os)
			throws IOException {
		super.writeRemoteInvocationResult(request, response, result, os);
		
//		Kryo kryo = new Kryo();
//		Output output = new Output(os);
//		try {
//			kryo.writeObject(output, result);
//		}
//		finally {
//			output.close();
//		}
	}
	
	protected RemoteInvocationResult invokeAndCreateResult(RemoteInvocation invocation, Object targetObject) {
		SwapContext.setRequHeader((HttpInvokerHeader) invocation.getAttribute(SwapContext.HttpInvokerHeader_key_));
		try {
			RemoteInvocationResult result = super.invokeAndCreateResult(invocation, targetObject);
	//		Throwable throwable = result.getException();
	//		if(throwable != null){
	//			result.setException(null);
	//			DyResponse response = new DyResponse();
	//			response.setStatus(DyResponse.ERROR);
	//			Throwable cause = throwable.getCause();
	//			if(cause != null){
	//				throwable = cause;
	//			}
	//			response.setDescription(throwable.getClass().getName());
	//			if(throwable instanceof DyServiceException){
	//				response.setData(throwable.getMessage());
	//			}else{
	//				response.setData("data.submit.error");
	//			}
	//			result.setValue(response);
	//		}
			return result;
			
		} finally {
			SwapContext.clear();
		}
	}


}
