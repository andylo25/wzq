package com.dy.core.dao.transaction;

import java.io.Serializable;
import java.util.Map;

import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.utils.HttpInvoker;
import com.dy.core.utils.common.SpringContextHolder;
import com.google.common.collect.Maps;

public class DyTransaction implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int status = 0; // 0开始，1提交完成，2回滚
	
	transient HttpInvoker httpInvoker;
	
	private Map<String,OperationWrap> operations = Maps.newHashMap();
	
	private String curOpId; // 当前的数据id
	private OperationWrap curOp; // 当前的数据操作
	
	public HttpInvoker getHttpInvoker() {
		if(httpInvoker == null){
			httpInvoker = SpringContextHolder.getBean(HttpInvoker.class);
		}
		return httpInvoker;
	}

	public void commit() {
		operations.clear();
		status = 1;
	}

	public void rollback() throws Exception {
		if(status != 0)return;
		status = 2;
		HttpInvoker httpInvoker = getHttpInvoker();
		for(OperationWrap op:operations.values()){
			if(op.getAction().equals(OperationWrap.insert)){
				// 插入的反操作->删除
				httpInvoker.deleteById((Long) op.obj, op.model, op.function);
			}else if(op.getAction().equals(OperationWrap.update)){
				// 更新的反操作->还原更新
				httpInvoker.update(op.model, op.function, op.obj,true);
			}else if(op.getAction().equals(OperationWrap.delete)){
				// 删除的反操作->插入
				httpInvoker.insert(op.model, op.function, op.obj);
			}
		}
	}
	
	public void tryTran(Object opId,OperationWrap op) throws Exception{
		if(status != 0)return;
		HttpInvoker httpInvoker = getHttpInvoker();
		if(op.getAction().equals(OperationWrap.update) || op.getAction().equals(OperationWrap.delete)){
			// 更新或删除:先预存原记录
			QueryItem queryItem = new QueryItem(Where.eq("id", opId));
			op.obj = httpInvoker.getOne(queryItem ,op.model, op.function);
		}else{
			op.obj = opId;
		}
		this.curOp = op;
		this.curOpId = opId.toString();
	}
	
	public void ready(Object opId) throws Exception{
		if(status != 0)return;
		if(curOp != null && curOpId.equals(opId.toString())){
			OperationWrap op = operations.get(curOpId);
			if(op != null){
				if(op.getAction().equals(OperationWrap.update) && curOp.getAction().equals(OperationWrap.delete)){
					// 前面已经更新过，后面如果删除，需要替换成插入的反操作
					curOp.action = OperationWrap.delete;
					operations.put(curOpId,curOp);
				}
			}else{
				operations.put(curOpId,curOp);
			}
			
		}
	}
	
	public static class OperationWrap {
		
		public static final String insert = "insert";
		public static final String update = "update";
		public static final String delete = "delete";

		private String action;
		private String model;
		private String function;
		private Object obj;
		
		public OperationWrap(String action) {
			this.action = action;
		}
		public OperationWrap(String action,String model,String function) {
			this(action);
			this.model = model;
			this.function = function;
		}
		
		public Object getObj(){
			return obj;
		}
		
		public void setObj(Object obj){
			this.obj = obj;
		}
		
		public String getAction() {
			return action;
		}
		
	}

}
