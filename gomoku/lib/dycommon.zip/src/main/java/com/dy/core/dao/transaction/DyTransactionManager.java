package com.dy.core.dao.transaction;

import com.dy.core.exception.DyRemoteException;

public interface DyTransactionManager {

	  void commit() throws DyRemoteException;

	  void rollback() throws DyRemoteException;
	  
	  void begin() throws DyRemoteException;

	  DyTransaction curTransaction();
}
