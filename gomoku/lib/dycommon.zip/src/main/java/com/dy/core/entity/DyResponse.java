package com.dy.core.entity;

import java.io.Serializable;

public class DyResponse implements Serializable {

	private static final long serialVersionUID = 4022828639456713673L;

	public static final int OK = 200;

	public static final int ERROR = 100;
	public static final int ERROR_AJAX = 500;
	public static final int ERROR_NET = 102; // 网络异常

	public static final int LOGINERR = 250;

	private int status;

	private Long id;

	private Object data;

	private Object description;
	
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Object getDescription() {
		return description;
	}

	public void setDescription(Object description) {
		this.description = description;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public boolean isOK(){
		return OK == status;
	}
	
	public boolean isNetError(){
		return ERROR_NET == status;
	}
	
	public static DyResponse createResp(int status){
		DyResponse dy = new DyResponse();
		dy.setStatus(status);
		return dy;
	}
	
	public static DyResponse createResp(int status,Object description){
		DyResponse dy = new DyResponse();
		dy.setStatus(status);
		dy.setDescription(description);
		return dy;
	}
	
	public static DyResponse createSuccResp(){
		DyResponse dy = new DyResponse();
		dy.setStatus(OK);
		return dy;
	}
	
	public static DyResponse createErrorResp(){
		DyResponse dy = new DyResponse();
		dy.setStatus(ERROR);
		return dy;
	}
	
	public static DyResponse createSuccessJsonResonse(Object data) {
		return createSuccessJsonResonse(data, "OK");
	}
	
	public static DyResponse createSuccessJsonResonse(Object data, Object description) {
		DyResponse response = new DyResponse();
		response.setStatus(DyResponse.OK);
		response.setDescription(description);
		response.setData(data);
		
		return response;
	}
	
	public static DyResponse createErrorJsonResonse(Object errorMsg) {
		DyResponse response = new DyResponse();
		response.setStatus(DyResponse.ERROR);
		response.setDescription(errorMsg);
		
		return response;
	}
	
	public static DyResponse createLoginJsonResonse(String errorMsg) {
		DyResponse response = new DyResponse();
		response.setStatus(DyResponse.LOGINERR);
		response.setDescription(errorMsg);
		
		return response;
	}

}