package com.dy.core.event;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import com.dy.core.utils.PropertiesUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Component
public class DyEventManager implements IEventManager,Runnable,InitializingBean {
	
	private static Logger log = LoggerFactory.getLogger(DyEventManager.class);

	private Map<Integer,List<DyConsumer>> coMap = Maps.newConcurrentMap(); // 事件消费者
	
	private BlockingQueue<DyEvent> blockingQueue = new ArrayBlockingQueue<>(1000);
	
	private List<Thread> threads = Lists.newArrayList();
	
	private boolean isRun;
	
	@Override
	public void subscribe(DyConsumer consumer){
		Integer key = consumer.apply();
		List<DyConsumer> list = coMap.get(key);
		if(list == null){
			list = Lists.newArrayList();
			coMap.put(key, list);
		}
		list.add(consumer);
		
	}
	
	@Override
	public void trigger(DyEvent event) throws Exception{
		if(event.isSync()){
			blockingQueue.offer(event, 10, TimeUnit.SECONDS);
		}else{
			dealEvent(event);
		}
	}
	
	public void run(){
		while (isRun) {
			DyEvent event = null;
			try {
				event = blockingQueue.take();
			} catch (InterruptedException e) {
				log.error("取事件异常",e);
			}
			event.bindThread();
			try {
				dealEvent(event);
			} catch (Throwable e) {
				log.error("事件处理异常",e);
			} finally {
				event.clearThread();
			}
		}
		
	}

	private void dealEvent(DyEvent event) {
		if(event != null){
			if(event.getType() == DyEvent.SYNC_TYPE){
				Supplier<?> supplier= (Supplier<?>) event.getData();
				try {
					supplier.get();
				} catch (Exception e) {
					log.error("异步处理异常",e);
				}
			}else{
				List<DyConsumer> consumers = coMap.get(event.getType());
				if(consumers != null){
					for(DyConsumer dyc:consumers){
						try {
							dyc.consume(event);
						} catch (Exception e) {
							log.error("事件处理异常",e);
						}
					}
				}
			}
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		isRun = true;
		int thsiz = 2;
		String siz = PropertiesUtil.getProperty("dy.event.thread");
		if(StringUtils.isNotBlank(siz)){
			try {
				thsiz = Integer.parseInt(siz);
			} catch (Exception e) { }
		}
		for(int i=0;i<thsiz;i++){
			Thread thread = new Thread(this);
			thread.setName("dy_event_"+i);
			thread.setDaemon(true);
			thread.start();
			threads.add(thread);
		}
	}
	
	
}
