package com.dy.core.entity;

/**
 * 日期转换格式 
 */
public enum DateFormatType {
	/**
	 * yyyy-MM-dd
	 */
	DATE,
	/**
	 * yyyy-MM-dd HH:mm:ss
	 */
	DATETIME
}