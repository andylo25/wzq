package com.dy.core.dao.query;


public class QueryItemBuilder {

    private QueryItem queryItem=new QueryItem();
    
    public QueryItem build(){
        return queryItem;
    }
    
    public QueryItemBuilder(){
    }
    
    public QueryItemBuilder(String module,String function){
        queryItem.setModule(module);
        queryItem.setFunction(function);
    }
    
    public QueryItemBuilder field(String fields){
        queryItem.setFields(fields);
        return this;
    }
    
    public QueryItemBuilder where(Where where){
        queryItem.setWhere(where);
        return this;
    }
    
    public QueryItemBuilder where(String name,Object value){
        queryItem.setWhere(Where.eq(name, value));
        return this;
    }
    
    public QueryItemBuilder group(String group){
        queryItem.setGroup(group);
        return this;
    }
    
    public QueryItemBuilder orders(String orders){
        queryItem.setOrders(orders);
        return this;
    }
    
    public QueryItemBuilder limit(Integer limit){
        queryItem.setLimit(limit);
        return this;
    }
    
    public QueryItemBuilder page(Integer page){
        queryItem.setPage(page);
        return this;
    }
    
}
