package com.dy.core.utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dy.core.dao.dml.DmlItem;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.transaction.DyTransaction;
import com.dy.core.dao.transaction.DyTransaction.OperationWrap;
import com.dy.core.dao.transaction.DyTransactionManager;
import com.dy.core.entity.BaseEntity;
import com.dy.core.entity.NameValue;
import com.dy.core.entity.Page;
import com.dy.core.exception.DyServiceException;
import com.dy.core.service.BaseService;

@Component
public class HttpInvokerUtil implements HttpInvoker{
	
	@Autowired
	BaseService baseService;
	
	@Autowired
	DyTransactionManager transactionManager;
	
	/**
	 * 插入一条数据
	 * @param module
	 * @param function
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Long insert(String module, String function, Object obj) throws Exception {
		if(obj == null) return 0L;
		Long id = 0L;
		if(obj instanceof BaseEntity){
			id = baseService.insert(module, function, (BaseEntity)obj);
			((BaseEntity)obj).setId(id);
		}else{
			DmlItem dmlItem = null;
			if(obj instanceof DmlItem) {
				dmlItem = (DmlItem) obj;
			} else if(obj instanceof Map) {
				dmlItem = new DmlItem();
				List<NameValue> params = new ArrayList<NameValue>();
				
				Map<String, Object> map = (Map<String, Object>) obj;
				if(map.get("create_time") == null){
					params.add(new NameValue("create_time",DateUtil.getCurrentTime()));
				}
				if(map.get("create_uid") == null){
					params.add(new NameValue("create_uid",RequestUtil.getUserId()));
				}
				for(String key : map.keySet()) {
					params.add(new NameValue(key, map.get(key)));
				}
				
				dmlItem.setParams(params);
			}
			dmlItem.setModule(module);
			dmlItem.setFunction(function);
			id = baseService.insert(dmlItem);
		}
		
		// 分布式事务相关
		DyTransaction dyTransaction = transactionManager.curTransaction();
		if(dyTransaction != null){
			dyTransaction.tryTran(id,new OperationWrap(OperationWrap.insert,module,function));
			dyTransaction.ready(id);
		}
		
		return id;
	}
	
	/**
	 * 根据主键更新数据,忽略为空值的字段
	 * @param module
	 * @param function
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public Integer update(String module, String function, Object obj) throws Exception {
		return update(module, function, obj,false);
	}
	@SuppressWarnings("unchecked")
	public Integer update(String module, String function, Object obj,boolean isUpdateEmpty) throws Exception {
		if(obj == null) return 0;
		Integer count = 0;
		Object idv = null;
		DyTransaction dyTransaction = transactionManager.curTransaction();
		if(obj instanceof BaseEntity) {
			idv = ((BaseEntity) obj).getId();
			// 分布式事务相关
			if(dyTransaction != null){
				dyTransaction.tryTran(idv,new OperationWrap(OperationWrap.update,module,function));
			}
			count = baseService.updateById(module, function, (BaseEntity) obj, isUpdateEmpty);
		}else{
			DmlItem dmlItem = null;
			if(obj instanceof DmlItem) {
				dmlItem = (DmlItem) obj;
				idv = dmlItem.getId();
			} else if(obj instanceof Map) {
				dmlItem = new DmlItem();
				List<NameValue> params = new ArrayList<NameValue>();
				
				Map<String, Object> map = (Map<String, Object>) obj;
				String id = map.get("pkColumn") == null ? "id" : map.get("pkColumn").toString(); 
				if(map.get("update_time") == null){
					params.add(new NameValue("update_time",DateUtil.getCurrentTime()));
				}
				if(map.get("update_uid") == null){
					params.add(new NameValue("update_uid",RequestUtil.getUserId()));
				}
				for(String key : map.keySet()) {
					if("editid".equals(key) || "pkColumn".equals(key) || id.equals(key)) continue;
					params.add(new NameValue(key, map.get(key)));
				}
				
				dmlItem.setPkColumn(id);
				idv = map.get(id);
				dmlItem.setId(idv);
				dmlItem.setParams(params);
			}
			dmlItem.setModule(module);
			dmlItem.setFunction(function);
			// 分布式事务相关
			if(dyTransaction != null){
				dyTransaction.tryTran(idv,new OperationWrap(OperationWrap.update,module,function));
			}
			count = baseService.update(dmlItem);
		}
		
		// 分布式事务相关
		if(dyTransaction != null){
			dyTransaction.ready(idv);
		}
		
		return count;
	}

	/**
	 * 根据主键(id)删除数据
	 * @param id 要删除的记录ID
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public Integer deleteById(Long id, String module, String function) throws Exception {
		return deleteById("id", id, module, function);
	}
	
	/**
	 * 根据主键删除数据(主键字段不是id，要另外指定如：menu_id)
	 * @param pkColumn 数据库字段名
	 * @param id 主键值
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public Integer deleteById(String pkColumn, Long id, String module, String function) throws Exception {
		
		// 分布式事务相关
		DyTransaction dyTransaction = transactionManager.curTransaction();
		if(dyTransaction != null){
			dyTransaction.tryTran(id,new OperationWrap(OperationWrap.delete,module,function));
		}
		
		Integer count = baseService.deleteById(pkColumn, id, module, function);
		
		if(dyTransaction != null){
			dyTransaction.ready(id);
		}
		
		return count;
	}
	
	/**
	 * 查询单条记录，返回Map
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getOne(QueryItem queryItem, String module, String function) throws Exception {
		return getOne(queryItem, module, function, Map.class);
	}
	
	/**
	 * 查询单条记录，返回BaseEntity
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getOne(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		if(clazz == null) throw new DyServiceException("clazz can not be null");
		
		queryItem.setModule(module);
		queryItem.setFunction(function);
		
		return baseService.getOne(queryItem, clazz);
	}
	public <T> T getOneById(Serializable id, String module, String function,Class<T> clazz) throws Exception {
		return baseService.getOneById(id, module, function, (Class<? extends BaseEntity>) clazz);
	}
	public <T> T getOneById(Serializable id, String module, String function,Class<T> clazz,String cols) throws Exception {
		return baseService.getOneById(id, module, function, (Class<? extends BaseEntity>) clazz,cols);
	}
	
	/**
	 * 查询列表，返回List
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public List<Map> getList(QueryItem queryItem, String module, String function) throws Exception {
		return getList(queryItem, module, function, Map.class);
	}
	
	/**
	 * 查询列表，返回Page
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Page<Map> getPage(QueryItem queryItem, String module, String function) throws Exception {
		return getPage(queryItem, module, function, Map.class);
	}
	
	/**
	 * 查询列表，返回List
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> List<T> getList(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		queryItem.setModule(module);
		queryItem.setFunction(function);
		
		return baseService.getList(queryItem, clazz);
	}
	
	/**
	 * 查询列表，返回Page
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> Page<T> getPage(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception {
		queryItem.setModule(module);
		queryItem.setFunction(function);
		
		return baseService.getPage(queryItem, clazz);
	}
}