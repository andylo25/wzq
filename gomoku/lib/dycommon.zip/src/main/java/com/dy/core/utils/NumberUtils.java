package com.dy.core.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class NumberUtils {
	
	public static final BigDecimal ONE_HUNDRED = new BigDecimal(100);
	public static final BigDecimal ONE_PERCENT = new BigDecimal(0.01);
	/**
	 * 格式化成保留两位小数,三位一逗号
	 */
	public static final DecimalFormat FORMATER = new DecimalFormat("#,##0.00");
	/**
	 * 格式化成保留两位小数,无逗号
	 */
	public static DecimalFormat FORMAT = new DecimalFormat("0.00"); 
	
	/**
	 * 比率小数位
	 */
	public static final int RATE_SCALE = 6; 
	
	/**
	 * 格式化两位小数加三位一逗号
	 * @param num
	 * @return
	 */
	public static String format(BigDecimal num) {
		return FORMATER.format(exNull(num));
	}

	/**
	 * 按指定format进行格式化
	 * @param num
	 * @param format
	 * @return
	 */
	public static String format(BigDecimal num, DecimalFormat format) {
		if(num == null){
			return "0.00";
		}
		return format.format(num);
	}
	
	/**
	 * 如果是空返回0
	 * @param num
	 * @return
	 */
	public static BigDecimal exNull(BigDecimal num) {
		return num != null ? num : BigDecimal.ZERO;
	}
	
	/**
	 * 加法
	 * @param nums
	 * @return
	 */
	public static BigDecimal add(BigDecimal... nums) {
		BigDecimal totalAmount = BigDecimal.ZERO;
		for (BigDecimal num : nums) {
			if (num != null) {
				totalAmount = totalAmount.add(num);
			}
		}
		return totalAmount;
	}
	
	/**
	 * 减法
	 * @param num1
	 * @param num2
	 * @return
	 */
	public static BigDecimal sub(BigDecimal num1, BigDecimal num2) {
		return (num1 != null ? num1 : BigDecimal.ZERO).subtract(num2 != null ? num2 : BigDecimal.ZERO);
	}
	
	/**
	 * 乘法
	 * @param nums
	 * @return
	 */
	public static BigDecimal mul(BigDecimal... nums) {
		BigDecimal totalAmount = BigDecimal.ZERO;
		int count = 0;
		for (BigDecimal num : nums) {
			if (num == null || BigDecimal.ZERO.compareTo(num) == 0) {
				return BigDecimal.ZERO;
			}
			if (count == 0) {
				totalAmount = num;
			} else {
				totalAmount = totalAmount.multiply(num);
			}
			count++;
		}
		return totalAmount;
	}
	
	/**
	 * 除法
	 * @param num1
	 * @param num2
	 * @return
	 */
	public static BigDecimal divHund(BigDecimal num1) {
		if (num1 == null) {
			return BigDecimal.ZERO;
		}
		return num1.divide(ONE_HUNDRED, RATE_SCALE, BigDecimal.ROUND_HALF_DOWN);
	}
	
	/**
	 * 除法
	 * @param num1
	 * @param num2
	 * @return
	 */
	public static BigDecimal div(BigDecimal num1, BigDecimal num2) {
		if (num1 == null || num2 == null) {
			return BigDecimal.ZERO;
		}
		return num1.divide(num2, RATE_SCALE, BigDecimal.ROUND_HALF_DOWN);
	}
	
	/**
	 * 除法
	 * @param num1
	 * @param num2
	 * @return
	 */
	public static BigDecimal div(BigDecimal num1, BigDecimal num2, int scale) {
		if (num1 == null || num2 == null || num1.compareTo(BigDecimal.ZERO) == 0 || num2.compareTo(BigDecimal.ZERO) == 0) {
			return BigDecimal.ZERO;
		}
		return num1.divide(num2, scale, BigDecimal.ROUND_HALF_DOWN);
	}

	/**
	 * 处理小数点位数，默认保留两位小数
	 * @param num
	 * @return
	 */
	public static BigDecimal round(BigDecimal num) {
		return round(num, 2);
	}
	
	/**
	 * 四舍五入
	 * @param value
	 *  @param scale 小数点后num位
	 * @return
	 */
	public static BigDecimal round(BigDecimal num, int scale) {
		return num == null ? BigDecimal.ZERO : num.setScale(scale, BigDecimal.ROUND_HALF_UP);
	}

	
	/**
	 * 处理小数点位数，默认为小数点后两位
	 * @param num
	 * @return
	 */
	public static Double round(Double num) {
		return round(num, 2);
	}
	
	/**
	 * 处理小数点位数
	 * @param num
	 * @param scale 小数点后num位
	 * @return
	 */
	public static Double round(Double num, int scale) {
		return num == null ? 0d : round(new BigDecimal(num), scale).doubleValue();
	}

	/**
	 * 向上取整
	 * @param value
	 * @return
	 */
	public static BigDecimal ceilNumber(BigDecimal num) {
		return num == null ? BigDecimal.ZERO : num.setScale(0, BigDecimal.ROUND_CEILING);
	}
	
	/**
	 * 判断是否大于0
	 * @param value
	 * @return
	 */
	public static boolean greaterThanZero(BigDecimal num) {
		return num == null ? false : num.setScale(RATE_SCALE).compareTo(BigDecimal.ZERO) > 0;
	}
	
	/**
	 * 判断是否大于等于0
	 * @param value
	 * @return
	 */
	public static boolean greaterEqualZero(BigDecimal num) {
		return num == null ? false : num.setScale(RATE_SCALE).compareTo(BigDecimal.ZERO) > 0;
	}
	
	/**
	 * 判断是否大于
	 * @param value
	 * @return
	 */
	public static boolean greaterThan(BigDecimal num1, BigDecimal num2) {
		if (num1 == null) {
			return false;
		}
		return num1.setScale(RATE_SCALE).compareTo(num2 != null ? num2 : BigDecimal.ZERO) > 0;
	}

	
	/**
	 * 判断是否大于等于
	 * @param value
	 * @return
	 */
	public static boolean greaterEqual(BigDecimal num1, BigDecimal num2) {
		if (num1 == null) {
			return false;
		}
		return num1.setScale(RATE_SCALE).compareTo(num2 != null ? num2 : BigDecimal.ZERO) >= 0;
	}

	
	/**
	 * 判断是否小于
	 * @param value
	 * @return
	 */
	public static boolean lessThan(BigDecimal num1, BigDecimal num2) {
		if (num1 == null) {
			return false;
		}
		return num1.setScale(RATE_SCALE).compareTo(num2 != null ? num2 : BigDecimal.ZERO) < 0;
	}
	/**
	 * 将double类型的数据格式化成字符串表示,保留两位小数
	 * @param d
	 * @return
	 */
	public static String format(Double d) {
		if(d==null) return null;
		return NumberUtils.format(new BigDecimal(d),NumberUtils.FORMAT);
	}
	
	/**
	 * 将object类型对象转换为double类型
	 * @param obj 要转换成double类型的对象
	 * @param decimal 保留的小数位数
	 * @return
	 */
	public static double toDouble(Object obj, int decimal) {
		if(decimal<0) {
			throw new IllegalArgumentException("illegal decimal value ["+decimal+"]");
		}
		String s = "0";
		if(obj!=null) {
			s = obj.toString().trim();
		}
		if(s.length()==0) {
			s = "0";
		}
		BigDecimal bg = new BigDecimal(s);
		return bg.setScale(decimal, BigDecimal.ROUND_HALF_UP).doubleValue();
	}
	
	public static Integer toInteger(Object obj){
		if(obj == null)return null;
		if(obj instanceof Long){
			return ((Long)obj).intValue();
		}
		if(obj instanceof Integer){
			return ((Integer)obj);
		}
		if(obj instanceof String){
			return Integer.valueOf((String)obj);
		}
		throw new IllegalArgumentException();
	}
	
	public static Long toLong(Object obj){
		if(obj == null)return null;
		if(obj instanceof Integer){
			return ((Integer)obj).longValue();
		}
		if(obj instanceof Long){
			return ((Long)obj);
		}
		if(obj instanceof String){
			return Long.valueOf((String)obj);
		}
		throw new IllegalArgumentException();
	}
	
	/**
	 * 将object类型对象转换为double类型,保留两位小数
	 * @param obj 要转换成double类型的对象
	 * @return
	 */
	public static double toDouble(Object obj) {
		return toDouble(obj, 2);
	}
	
	/** 
	 * 数字金额大写转换，思想先写个完整的然后将如零拾替换成零 要用到正则表达式 
	 */  
	public static String digitUppercase(Object num) {
		if(num == null)return "";
		double n = 0;
		if(num instanceof BigDecimal){
			n = ((BigDecimal) num).doubleValue();
		}else if(num instanceof Double){
			n = (Double) num;
		}else if(num instanceof String){
			n = Double.valueOf((String) num);
		}else {
			return "";
		}
	    String fraction[] = {"角", "分"};
	    String digit[] = {"零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"};
	    String unit[][] = {{"元", "万", "亿"}, {"", "拾", "佰", "仟"}};
	    String head = n < 0 ? "负" : "";  
	    n = Math.abs(n);  
	    String s = "";  
	    for (int i = 0; i < fraction.length; i++) {  
	        s += (digit[(int) (Math.floor(n * 10 * Math.pow(10, i)) % 10)] + fraction[i]).replaceAll("(零.)+", "");  
	    }  
	    if (s.length() < 1) {  
	        s = "整";  
	    }  
	    int integerPart = (int) Math.floor(n);  
	    for (int i = 0; i < unit[0].length && integerPart > 0; i++) {  
	        String p = "";  
	        for (int j = 0; j < unit[1].length && n > 0; j++) {  
	            p = digit[integerPart % 10] + unit[1][j] + p;  
	            integerPart = integerPart / 10;  
	        }  
	        s = p.replaceAll("(零.)*零$", "").replaceAll("^$", "零") + unit[0][i] + s;  
	    }  
	    return head + s.replaceAll("(零.)*零元", "元").replaceFirst("(零.)+", "").replaceAll("(零.)+", "零").replaceAll("^整$", "零元整");  
	} 
	
	public static void main(String[] args) {
		System.out.println(NumberUtils.mul(BigDecimal.ONE, new BigDecimal(1000),new BigDecimal(898)));
		System.out.println(NumberUtils.digitUppercase(100.43));
//		DictUtils.getDictLabel(value, type);
	}
}
