package com.dy.core.service.impl;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.dy.core.dao.BaseMapper;
import com.dy.core.dao.dml.DmlItem;
import com.dy.core.dao.query.Condition;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.BaseEntity;
import com.dy.core.entity.NameValue;
import com.dy.core.entity.Page;
import com.dy.core.exception.DyServiceException;
import com.dy.core.service.BaseService;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DyStringUtils;
import com.dy.core.utils.EntityUtils;
import com.dy.core.utils.PropertiesUtil;
import com.dy.core.utils.ReflectUtil;
import com.dy.core.utils.RequestUtil;
import com.dy.core.utils.common.SpringContextHolder;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class BaseServiceImpl implements BaseService {
	//查询条件
	public static final String EQ = Condition.EQ;
	public static final String GT = Condition.GT;
	public static final String GE = Condition.GE;
	public static final String LT = Condition.LT;
	public static final String LE = Condition.LE;
	public static final String IN = Condition.IN;
	public static final String NEQ = Condition.NEQ;
	public static final String LIKE = Condition.LIKE;
	public static final String LIKE_ALL = Condition.LIKE_ALL;
	public static final String NOT_IN = Condition.NOT_IN;
	public static final String NULL = Condition.NULL;
	public static final String NOT_NULL = Condition.NOT_NULL;
	
	private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
	
	@Override
	public Long insert(DmlItem dmlItem) throws DyServiceException {
		dmlItem.setMethod("insert");
		validateParam(dmlItem);
		
		//Service调用，需要先对dmlItem做预处理
		if(!dmlItem.isFromController()) {
			if(dmlItem.getParams() == null || dmlItem.getParams().size()<1) dmlItem.setParams(new ArrayList<NameValue>());
			
			StringBuffer param = new StringBuffer();
			StringBuffer fields = new StringBuffer();
			String keywordEscape = getDatabaseKeywordEscape();
			Map<String, Object> paramMap = new HashMap<String, Object>();
			for(NameValue nameValue : dmlItem.getParams()) {
				fields.append(",").append(keywordEscape).append(nameValue.getName()).append(keywordEscape);
				param.append(",").append("#{dmlItem.paramMap.").append(nameValue.getName()).append("}");
				
				paramMap.put(nameValue.getName(), nameValue.getValue());
			}
			
			dmlItem.setParamMap(paramMap);
			dmlItem.setParam(param.toString().substring(1));
			dmlItem.setFields(fields.toString().substring(1));
		}
		
		return (Long)executeDml(dmlItem);
	}
	
	@Override
	public Long insert(String module, String function, BaseEntity baseEntity) throws DyServiceException {
		return this.insert(module, function, null, baseEntity);
	}
	
	@Override
	public Long insert(String module, String function, String whereExp, BaseEntity baseEntity) throws DyServiceException {
		if(baseEntity == null) return 0L;
		
		addCreateTime(baseEntity);
		//entity转List<NameValue>
		List<NameValue> nameValueList = EntityUtils.getNameValues(baseEntity,false);
		
		DmlItem dmlItem = new DmlItem();
		dmlItem.setModule(module);
		dmlItem.setFunction(function);
		dmlItem.setParams(nameValueList);
		if(whereExp != null){
			List<Where> whereList = Lists.newArrayList();
			whereList.add(Where.expression(whereExp, false));
			dmlItem.setWhereList(whereList );
		}
		Long result = insert(dmlItem);
		//插入成功，更新主键值到entity
		if(result > 0) {
			baseEntity.setId(result);
		}
		
		return result;
	}

	private void addCreateTime(BaseEntity baseEntity) {
		if(baseEntity.getCreateUid()==null){
			baseEntity.setCreateUid(RequestUtil.getUserId());
		}
		if(baseEntity.getCreateTime()==null){
			baseEntity.setCreateTime(DateUtil.getCurrentTime());
		}
	}

	@Override
	public Integer update(DmlItem dmlItem) throws DyServiceException {
		dmlItem.setMethod("update");
		validateParam(dmlItem);
		
		//Service调用，需要先对dmlItem做预处理
		if(!dmlItem.isFromController()) {
			if(dmlItem.getParams() == null) dmlItem.setParams(new ArrayList<NameValue>());
			
			StringBuffer fields = new StringBuffer();
			String keywordEscape = getDatabaseKeywordEscape();
			Map<String, Object> paramMap = new HashMap<String, Object>();
			for(NameValue nameValue : dmlItem.getParams()) {
				fields.append(",").append(keywordEscape).append(nameValue.getName()).append(keywordEscape).append("=");
				if(StringUtils.isNotEmpty(nameValue.getExpression())) {
					fields.append(nameValue.getExpression());
				} else {
					fields.append("#{dmlItem.paramMap._").append(nameValue.getName()).append("}");
					paramMap.put("_" + nameValue.getName(), nameValue.getValue());
				}
			}
			if(dmlItem.getWhereList() != null && dmlItem.getWhereList().size() > 0) {
				StringBuffer whereCondition = new StringBuffer();
				for(Where where : dmlItem.getWhereList()) {
					if (where.getAnd() != null && where.getAnd().size() > 0) {
						StringBuffer andCondition = new StringBuffer(" and (");
						for(int i=0;i<where.getAnd().size();i++) {
							generateAndCondition(andCondition, paramMap, where.getAnd().get(i), i, true);
						}
						whereCondition.append(andCondition.toString()).append(")");
					} else {
						generateAndCondition(whereCondition, paramMap, where, null, true);
					}
				}
				dmlItem.setParam(whereCondition.toString());
			}
			dmlItem.setParamMap(paramMap);
			dmlItem.setFields(fields.toString().substring(1));
		}
		
		return (Integer)executeDml(dmlItem);
	}
	
	@Override
	public Integer updateById(String module, String function, BaseEntity baseEntity) throws DyServiceException {
		return this.updateById(module, function, "id", baseEntity, false);
	}
	
	@Override
	public Integer updateById(String module, String function, BaseEntity baseEntity, boolean updateEmpty) throws DyServiceException {
		return this.updateById(module, function, "id", baseEntity, updateEmpty);
	}
	
	@Override
	public Integer updateById(String module, String function, String pkColumn, BaseEntity baseEntity) throws DyServiceException {
		return this.updateById(module, function, pkColumn, baseEntity, false);
	}
	
	@Override
	public Integer updateById(String module, String function, String pkColumn, BaseEntity baseEntity, boolean updateEmpty) throws DyServiceException {
		if(baseEntity == null) return 0;
		
		addUpdateTime(baseEntity);
		//entity转List<NameValue>
		List<NameValue> nameValueList = EntityUtils.getNameValues(baseEntity,updateEmpty);
		//主键
		Object idValue = baseEntity.getId();
		if(!"id".equals(pkColumn)){
			idValue = ReflectUtil.getFieldValue(baseEntity, DyStringUtils.columnToProperty(pkColumn));
		}
		
		DmlItem dmlItem = new DmlItem();
		dmlItem.setModule(module);
		dmlItem.setFunction(function);
		dmlItem.setParams(nameValueList);
		
		dmlItem.setId(idValue);
		dmlItem.setPkColumn(pkColumn);
		
		return this.update(dmlItem);
	}
	
	private void addUpdateTime(BaseEntity baseEntity) {
		baseEntity.setUpdateTime(DateUtil.getCurrentTime());
		baseEntity.setUpdateUid(RequestUtil.getUserId());
	}

	@Override
	public Integer delete(DmlItem dmlItem) throws DyServiceException {
		dmlItem.setMethod("delete");
		validateParam(dmlItem);
		
		//Service调用，需要先对dmlItem做预处理
		if(!dmlItem.isFromController()) {
			if(dmlItem.getParams() == null) dmlItem.setParams(new ArrayList<NameValue>());
			
			StringBuffer param = new StringBuffer();
			String keywordEscape = getDatabaseKeywordEscape();
			Map<String, Object> paramMap = new HashMap<String, Object>();
			String condition = "";
			for(NameValue nameValue : dmlItem.getParams()) {
				condition = StringUtils.isEmpty(nameValue.getCondition())?"=":nameValue.getCondition();
				param.append(" and ").append(keywordEscape).append(nameValue.getName()).append(keywordEscape).append(condition);
				param.append("#{dmlItem.paramMap.").append(nameValue.getName()).append("}");
				
				paramMap.put(nameValue.getName(), nameValue.getValue());
			}
			
			dmlItem.setParamMap(paramMap);
			String paramStr=param.toString();
			if(StringUtils.isNoneBlank(paramStr))
			    dmlItem.setParam(paramStr.substring(1));
		}
		
		if(dmlItem.getId() == null && StringUtils.isEmpty(dmlItem.getParam())) throw new RuntimeException("参数错误，至少需要指定一个条件");
		
		return (Integer)executeDml(dmlItem);
	}
	
	@Override
	public Integer deleteById(Long id, String module, String function) throws DyServiceException {
		return this.deleteById("id", id, module, function);
	}

	@Override
	public Integer deleteById(String pkColumn, Long id, String module, String function) throws DyServiceException {
		DmlItem dmlItem = new DmlItem();
		dmlItem.setModule(module);
		dmlItem.setFunction(function);
		dmlItem.setId(id);
		dmlItem.setPkColumn(pkColumn);
		return delete(dmlItem);
	}
	
	/**
	 * 执行新增、修改、删除
	 * @param dmlItem
	 * @return
	 * @throws DyServiceException
	 */
	private Object executeDml(DmlItem dmlItem) throws DyServiceException {
		//获取要操作的表
		String tableName = PropertiesUtil.getProperty(dmlItem.getModule() + "_" + dmlItem.getFunction());
		if(StringUtils.isBlank(tableName)){
			throw new DyServiceException("根据module+function无法获取到要操作的table！:"+tableName);
		}
		//Oracle数据库设置主键生成为sequence
		if("insert".equals(dmlItem.getMethod()) && "oracle".equals(getDatabaseType())) {
			String id = (StringUtils.isEmpty(dmlItem.getPkColumn())) ? "id" : dmlItem.getPkColumn();
			dmlItem.setFields(id + "," + dmlItem.getFields());
			dmlItem.setParam("#{id}," + dmlItem.getParam());
			dmlItem.setSequenceName("sq_" + tableName.substring(tableName.indexOf("_") + 1));
		}
		
		dmlItem.setTableName(tableName);
		//根据module获取相应的dao
		Object mapper = getBaseMapper(dmlItem.getModule());
		
		Object result = null;
		try {
			//调用相应的方法执行dml
			Method method = mapper.getClass().getMethod(dmlItem.getMethod(), DmlItem.class);
			result = method.invoke(mapper, dmlItem);
		} catch (Exception e) {
			throw new DyServiceException("执行dml异常",e);
		}
		
		//新增返回插入的主键值
		if("insert".equals(dmlItem.getMethod())) result = dmlItem.getId();
		
		return result;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Map<String, Object> getOne(QueryItem queryItem) throws DyServiceException {
		return getOne(queryItem, Map.class);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public <T> T getOneById(Serializable id, String module, String function, Class<? extends BaseEntity> clazz,String fields) throws DyServiceException {
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		if(StringUtils.isNotBlank(fields)){
			if(fields.startsWith("id,") || fields.indexOf(",id,") > 0){
				queryItem.setFields(fields);
			}else{
				queryItem.setFields("id,"+fields);
			}
		}
//		queryItem.setFields(EntityUtils.getSelectFields(clazz));
		queryItem.setModule(module);
		queryItem.setFunction(function);
		return (T) getOne(queryItem, clazz);
	}
	
	@Override
	public <T> T getOneById(Serializable id, String module, String function, Class<? extends BaseEntity> clazz) throws DyServiceException {
		return getOneById(id, module, function, clazz,null);
	}
	
	@Override
	public <T> T getOne(QueryItem queryItem, Class<T> clazz) throws DyServiceException {
		
		if(StringUtils.isEmpty(queryItem.getFields()) && BaseEntity.class.isAssignableFrom(clazz)){
			queryItem.setFields(EntityUtils.getSelectFields((Class<? extends BaseEntity>) clazz));
		}
		
		validateParam(queryItem);
		
		//Pre process
		boolean isKeyNeedConvert = queryPreProcess(queryItem);
		
		//Do query
		T result = null;
		BaseMapper baseMapper = getBaseMapper(queryItem.getModule());
		try {
			result = baseMapper.getOne(queryItem, clazz);
		} catch(Exception e) {
			throw new DyServiceException("data.submit.error",e);
		}
		
		//Post process
		if(isKeyNeedConvert && "oracle".equals(getDatabaseType())) {
			queryPostProcess(queryItem, result);
		}
		
		return result;
	}
	
	@Override
	public Object getList(QueryItem queryItem) throws DyServiceException {
		return getList(queryItem, Map.class);
	}
	
	@Override
	public <T> List<T> getList(QueryItem queryItem, Class<T> clazz) throws DyServiceException {
		
		if(StringUtils.isEmpty(queryItem.getFields()) && BaseEntity.class.isAssignableFrom(clazz)){
			queryItem.setFields(EntityUtils.getSelectFields((Class<? extends BaseEntity>) clazz));
		}
		
		validateParam(queryItem);
		
		//Pre process
		boolean isKeyNeedConvert = queryPreProcess(queryItem);
		
		//Do query
		List<T> result = null;
		BaseMapper baseMapper = getBaseMapper(queryItem.getModule());
		try {
			result = baseMapper.getList(queryItem, clazz);
		} catch(Exception e) {
			throw new DyServiceException("data.submit.error",e);
		}
		
		//Post process
		if(isKeyNeedConvert && "oracle".equals(getDatabaseType())) {
			queryPostProcess(queryItem, result);
		}
		
		return result;
	}
	
	@Override
	public <T> Page<T> getPage(QueryItem queryItem, Class<T> clazz) throws DyServiceException {
		Integer pageNo = queryItem.getPage();
		Integer limit = queryItem.getLimit();
		queryItem.setPage(pageNo == null ? 1 : pageNo);
		queryItem.setLimit(limit == null ? 20 : limit);
		List<T> items = getList(queryItem, clazz);
		
		Page<T> page = new Page<T>();
		page.setItems(items);
		page.setPage(queryItem.getPage());
		page.setEpage(queryItem.getLimit());
		if(items != null && items.size() > 0) {
			page.setTotal_items(getListCount(queryItem));
		} else {
			page.setTotal_items(0);
		}
		
		return page;
	}
	
	@Override
	public Integer getListCount(QueryItem queryItem) throws DyServiceException {
		Integer count = null;
		BaseMapper baseMapper = getBaseMapper(queryItem.getModule());
		//Pre process
		queryPreProcess(queryItem);
		try {
			count = baseMapper.getListCount(queryItem);
		} catch(Exception e) {
			throw new DyServiceException("data.submit.error",e);
		}
		
		return count;
	}
	
	/**
	 * 获取数据库类型
	 * @return
	 */
	private String getDatabaseType() {
		return StringUtils.isEmpty(PropertiesUtil.getDatabaseType()) ? "mysql" : PropertiesUtil.getDatabaseType();
	}
	
	/**
	 * 数据库关键字转义字符
	 * @return
	 */
	public String getDatabaseKeywordEscape() {
		return "mysql".equalsIgnoreCase(getDatabaseType()) ? "`" : "";
	}
	
	/**
	 * 逗号替换符号
	 * @return
	 */
	public String getCommaReplacement() {
		return "[c]";
	}
	
	/**
	 * 根据module获取相应的mapper
	 * @param module
	 * @return
	 */
	private BaseMapper getBaseMapper(String module) {
		Object mapper = SpringContextHolder.getBean(PropertiesUtil.getProperty("mp_"+module) + "Mapper");
		return mapper == null ? null : (BaseMapper)mapper;
	}
	
	/**
	 * 查询预处理
	 * @param queryItem
	 * @return
	 * @throws DyServiceException 
	 */
	private boolean queryPreProcess(QueryItem queryItem) throws DyServiceException {
		if(queryItem.isPreProcess()){
			return false;
		}
		//Service调用，需要先对queryItem做预处理
		if(!queryItem.isFromController()) {
			StringBuffer whereCondition = new StringBuffer();
			Map<String, Object> params = new HashMap<String, Object>();
			for(Where where : queryItem.getWhere()) {
				if (where.getAnd() != null) {
					if(!where.getAnd().isEmpty()){
						StringBuffer andCondition = new StringBuffer(" and (");
						for(int i=0;i<where.getAnd().size();i++) {
							generateAndCondition(andCondition, params, where.getAnd().get(i), i, false);
						}
						whereCondition.append(andCondition.toString()).append(")");
					}
				} else {
					generateAndCondition(whereCondition, params, where, null, false);
				}
			}
			queryItem.setParams(params);
			if (StringUtils.isEmpty(queryItem.getFields())) {
				queryItem.setFields("*");
			}
			queryItem.setWhereCondition(whereCondition.toString());
		}
		
		//根据module+function获取要操作的table
		if(StringUtils.isBlank(queryItem.getTableName())){
			String tableName = PropertiesUtil.getProperty(queryItem.getModule() + "_" + queryItem.getFunction());
			if(StringUtils.isBlank(tableName)){
				throw new DyServiceException("根据module+function->"+queryItem.getModule() + "_" + queryItem.getFunction()+"无法获取到要操作的table:"+tableName);
			}
			queryItem.setTableName(tableName);
		}
		queryItem.setPreProcess(true);
		
		//查询字段处理(Oracle:转小写/mysql:添加关键字转义符)
		boolean isKeyNeedConvert = false;
		String keywordEscape = getDatabaseKeywordEscape();
		if(!"getListCount".equals(queryItem.getMethod())) {
			if("*".equals(queryItem.getFields())) {
				isKeyNeedConvert = true;
			} else {
				StringBuffer fields = new StringBuffer();
				for(String temp : queryItem.getFields().split(",")) {
					String alais = "";
					String column = temp.trim();
					int idx = column.lastIndexOf(" ");
					if(idx > 0) {
						alais = column.substring(idx + 1);
						column = column.substring(0, idx);
					} else {
						alais = column;
					}
					if(StringUtils.isNotEmpty(keywordEscape)) {
						if("1".equals(column))
							fields.append(",").append(temp);
						else
							fields.append(",").append(column.equals(alais) ? (keywordEscape + column + keywordEscape) : temp);
					} else {
						fields.append(",").append(column).append(" \"").append(alais.toLowerCase()).append("\"");
					}
				}
				queryItem.setFields(fields.toString().substring(1));
			}
		}
		String comma = this.getCommaReplacement();
		String fields = queryItem.getFields();
		if (fields.indexOf(comma) > 0) {
			fields = fields.replaceAll("\\[c\\]", ",");
			queryItem.setFields(fields);
		}
		
		//getList根据数据库类型添加分页语句
		Integer page = queryItem.getPage();
		Integer limit = queryItem.getLimit();
		
		if(limit != null) {
			page = page == null ? 1 : page;
			if("mysql".equalsIgnoreCase(getDatabaseType())) {
				queryItem.setPageFooter("limit " + (page - 1) * limit + ", " + limit);
			} else if("oracle".equalsIgnoreCase(getDatabaseType())) {
				queryItem.setPageHeader("select * from (select p.*, rownum r from (");
				queryItem.setPageFooter(") p where rownum < " + (page * limit - 1) + ") where r >= " + ((page - 1)*limit + 1));
			}
		}
		
		return isKeyNeedConvert;
	}
	
	@SuppressWarnings("unchecked")
	private Object queryPostProcess(QueryItem queryItem, Object result) {
		if(result instanceof Map) {
			return keyConvert(result == null ? null : (Map)result);
		} else if(result instanceof List) {
			List<Map<String, Object>> newData = new ArrayList<Map<String,Object>>();
			List<Map<String, Object>> oldData = result == null ? new ArrayList<Map<String,Object>>() : (List)result;
			for(Map<String, Object> temp : oldData) {
				newData.add(keyConvert(temp));
			}
			
			result = newData;
		}
		
		return result;
	}
	
	/**
	 * Oracle查询没指定查询字段，对=返回的map的Key转小写
	 * @param data
	 * @return
	 */
	private Map<String, Object> keyConvert(Map<String, Object> data) {
		if(data == null || data.size() <= 0) return null;
		
		Map<String, Object> newData = new HashMap<String, Object>();
		for(String key : data.keySet()) newData.put(key.toLowerCase(), data.get(key));
		
		return newData;
	}
	
	/**
	 * QueryItem/DmlItem参数检查
	 * @param obj
	 * @throws DyServiceException
	 */
	private void validateParam(Object obj) throws DyServiceException {
		if(obj instanceof QueryItem) {
			QueryItem queryItem = (QueryItem) obj;
			if(StringUtils.isEmpty(queryItem.getTableName()) && (StringUtils.isEmpty(queryItem.getModule())
					|| StringUtils.isEmpty(queryItem.getFunction()))) 
				throw new RuntimeException("QueryItem参数错误，module/function不能为空");
		} else if(obj instanceof DmlItem) {
			DmlItem dmlItem = (DmlItem) obj;
			if(StringUtils.isEmpty(dmlItem.getModule())
					|| StringUtils.isEmpty(dmlItem.getFunction())) 
				throw new RuntimeException("DmlItem参数错误，module/function不能为空");
			
			if("update".equals(dmlItem.getMethod())) {
				if(dmlItem.getId() == null && (dmlItem.getWhereList() == null || dmlItem.getWhereList().size() <= 0))
					throw new DyServiceException("DmlItem参数错误，缺少更新条件(id/whereList)");
				if(dmlItem.getWhereList() == null || dmlItem.getWhereList().size() <= 0) {
					if(dmlItem.getId() == null
							|| StringUtils.isEmpty(dmlItem.getPkColumn()))
						throw new RuntimeException("DmlItem参数错误，id/pkColumn不能为空");
				}
			}else if("delete".equals(dmlItem.getMethod())) {
				if(dmlItem.getId() == null && (dmlItem.getParams() == null || dmlItem.getParams().size() <= 0))
					throw new DyServiceException("DmlItem参数错误，缺少更新条件(id/whereList)");
				if(dmlItem.getParams() == null || dmlItem.getParams().size() <= 0) {
					if(dmlItem.getId() == null
							|| StringUtils.isEmpty(dmlItem.getPkColumn()))
						throw new RuntimeException("DmlItem参数错误，id/pkColumn不能为空");
				}
			}
		}
	}
	
	/**
	 * 生成and
	 * @param whereCondition
	 * @param params
	 * @param conditions
	 * @param key
	 * @param andIndex
	 * @param isDml
	 */
	private void generateAndCondition(StringBuffer whereCondition, Map<String, Object> params, NameValue nameValue, Integer andIndex, boolean isDml) {
		//Expression
		if(andIndex == null) andIndex = 1;
		String orAnd = nameValue.isOr() ? " or " : " and ";
		if(nameValue.getName() == null && nameValue.getValue() == null && nameValue.getExpression() != null) {
			whereCondition.append(andIndex == 0 ? " " : orAnd).append(nameValue.getExpression());
			return;
		}
		
		String key = nameValue.getName();
		if(nameValue.getName().indexOf('.') < 0){
			String keywordEscape = getDatabaseKeywordEscape();
			key = keywordEscape + nameValue.getName() + keywordEscape;
		}
		Object value = nameValue.getValue();
		String operation = nameValue.getCondition();
		
		String paramPrefix = isDml ? "#{dmlItem.paramMap." : "#{queryItem.params.";
		String paramKey = escapeDot(nameValue.getName()) + (andIndex == null ? "" : andIndex);
		if(IN.equals(operation) || NOT_IN.equals(operation)) {
			StringBuffer and = new StringBuffer();
			String inValue = value == null ? "" : value.toString();
			int index = 0;
			for(String temp : inValue.split(",")) {
				params.put(paramKey + index, temp);
				and.append(",").append(paramPrefix).append(paramKey + (index++)).append("}");
			}
			whereCondition.append(andIndex == 0 ? " " : orAnd).append(key).append(" ").append(operation).append(" ").append(" (").append(and.toString().substring(1)).append(")");
		} else if (NULL.equals(operation) || NOT_NULL.equals(operation)) {
			whereCondition.append(orAnd).append(key).append(" ").append(operation).append(" ");
		} else {
			if(LIKE.equals(operation) && value instanceof String) {
				value = value == null ? "" : value.toString() + "%";
			} else if(LIKE_ALL.equals(operation) && value instanceof String) {
				value = value == null ? "" : ("%" + value.toString() + "%");
			}
			params.put(paramKey, value);
			whereCondition.append(andIndex == 0 ? " " : orAnd).append(key).append(" ").append("likeall".equals(operation) ? "like" : operation).append(" ").append(paramPrefix).append(paramKey).append("}");
		}
	}
	
	private String escapeDot(String name) {
		return StringUtils.replaceChars(name, '.', '$');
	}

	/**
	 * 数据转换(List<Map> --> List<Entity>)
	 * @param dataList
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unused")
	private List<Object> dataConvert(List<Map<String, Object>> dataList, Class<?> clazz) {
		if(dataList == null || clazz == null) return null;
		try {
			if(!(clazz.newInstance() instanceof BaseEntity)) return null;
		} catch (Exception e) {
			return null;
		}
		
		Set<String> columnSet = new HashSet<String>();
		if(dataList.size() > 0) 
			columnSet = dataList.get(0).keySet();
		Map<String, String> cpMap = columnToProperty(columnSet);
		
		List<Object> resultList = new ArrayList<Object>();
		for(Map<String, Object> map : dataList) {
			resultList.add(dataConvert(map, clazz, cpMap));
		}
		
		return resultList;
	}
	
	/**
	 * 数据转换(Map --> Entity)
	 * @param dataMap
	 * @param clazz
	 * @return
	 */
	private Object dataConvert(Map<String, Object> dataMap, Class<?> clazz, Map<String, String> cpMap) {
		if(dataMap == null || clazz == null) return dataMap;
		try {
			if(!(clazz.newInstance() instanceof BaseEntity)) return null;
		} catch (Exception e) {
			return null;
		}
		
		if(cpMap == null) cpMap = new HashMap<String, String>();
		Map<String, Object> newData = new HashMap<String, Object>();
		for(String column : dataMap.keySet()) {
			String property = cpMap.get(column);
			if(StringUtils.isEmpty(property))
				property = DyStringUtils.columnToProperty(column);
			
			Object value = dataMap.get(column);
			if(value instanceof Date) value = DateUtil.dateTimeFormat((Date)value);
			newData.put(property, value);
		}
		
		return gson.fromJson(gson.toJson(newData), clazz);
	}
	
	private Map<String, String> columnToProperty(Set<String> columnSet) {
		Map<String, String> map = new HashMap<String, String>();
		for(String column : columnSet) {
			map.put(column, DyStringUtils.columnToProperty(column));
		}
		
		return map;
	}
	
}