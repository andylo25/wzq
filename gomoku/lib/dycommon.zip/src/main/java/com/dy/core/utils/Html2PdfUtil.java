package com.dy.core.utils;
import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.StreamUtils;

import com.dy.core.itext.DyFontFactoryImp;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.Pipeline;
import com.itextpdf.tool.xml.XMLWorker;
import com.itextpdf.tool.xml.XMLWorkerFontProvider;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.itextpdf.tool.xml.css.CssFilesImpl;
import com.itextpdf.tool.xml.css.StyleAttrCSSResolver;
import com.itextpdf.tool.xml.html.CssAppliersImpl;
import com.itextpdf.tool.xml.html.Tags;
import com.itextpdf.tool.xml.parser.XMLParser;
import com.itextpdf.tool.xml.pipeline.css.CssResolverPipeline;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import com.itextpdf.tool.xml.pipeline.html.AbstractImageProvider;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipelineContext;
 
/**
 * Html 转PDF工具类
 * <p/>
 * 支持简单的html格式,对css解析不够好
 * 
 * @author bangis.wangdf
 * @date 16/6/22.20:15
 */
public class Html2PdfUtil {
 
	static final Charset UTF8 = Charset.forName("UTF-8");
	
    /**
     * 静态css文件
     */
    public static String cssFile = "/static/assets/dist/css/itextpdf.css";
    /**
     * 图片路径
     */
    public static String imagePath;
    
 
    /**
     * html转PDF
     * 
     * @param htmlFle
     * @param pdfFile
     */
    public static void parse2Pdf(String htmlFle, String pdfFile) {
        try {
            parse2Pdf(new FileInputStream(htmlFle), new FileOutputStream(pdfFile));
        } catch (FileNotFoundException e) {
            throw Exceptions.unchecked("转换失败", e);
        }
    }
 
    /**
     * html转PDF
     * 
     * @param htmlFle
     * @param pdfFile
     */
    public static void parse2Pdf(InputStream input, OutputStream pdfFile) {
        try {
            // step 1
            Document document = new Document(PageSize.A4);
            // step 2
            PdfWriter writer = PdfWriter.getInstance(document, pdfFile);
            // step 3
            document.open();
            // step 4
            InputStream cssIn = MyFontsProvider.class.getResourceAsStream(cssFile);
			XMLWorkerHelper.getInstance().parseXHtml(writer, document,input,cssIn ,UTF8,new MyFontsProvider("fonts/simsun.ttc"));
            //step 5
            document.close();
        } catch (Exception e) {
        	throw Exceptions.unchecked("转换失败", e);
        }
    }
 
    /**
     * html转PDF
     *
     * @param htmlContext html 字符串
     * @param pdfFile
     */
    public static void parseHtml2Pdf(String htmlContext, OutputStream pdfFile) {
    	ByteArrayInputStream input = new ByteArrayInputStream(htmlContext.getBytes());
    	parse2Pdf(input, pdfFile);
    }
 
    /**
     * html转PDF
     *
     * @param htmlContext html 字符串
     * @param pdfFile
     */
    public static void parseHtml2Pdf(String htmlContext, File pdfFile) {
        try {
            parseHtml2Pdf(htmlContext, new FileOutputStream(pdfFile));
        } catch (Exception e) {
        	throw Exceptions.unchecked("转换失败", e);
        }
    }
    
    /**  
     * 重写 字符设置方法，解决中文乱码问题  
     *   
     */  
    public static class MyFontsProvider extends XMLWorkerFontProvider {  
  
        public MyFontsProvider(){  
            super(null, null);
        }  
        
        public MyFontsProvider(String ttc){  
        	super(null, null);
        	String ttcp = MyFontsProvider.class.getClassLoader().getResource(ttc).getPath();
        	if(StringUtils.indexOf(ttcp, "jar!/") > 0){
        		ttcp = "jar:" + ttcp;
        	}
        	this.register(ttcp);
        }  
  
        @Override  
        public Font getFont(final String fontname, String encoding, float size, final int style) {  
            String fntname = fontname;  
            if (fntname == null) {  
                fntname = "SimSun";
            }
            return super.getFont(fntname, encoding, size, style);  
        }  
    }  
 
    protected static class MyXMLParser {
        public static XMLParser getInstance(Document doc, PdfWriter pdfWriter) throws Exception {
 
            //固定css
            CssFilesImpl cssFiles = new CssFilesImpl();
            if (StringUtils.isNotBlank(cssFile)) {
                cssFiles.add(XMLWorkerHelper.getCSS(new FileInputStream(new File(cssFile))));
            } else {
 
                cssFiles.add(XMLWorkerHelper.getInstance().getDefaultCSS());
            }
            StyleAttrCSSResolver cssResolver = new StyleAttrCSSResolver(cssFiles);
 
            //宋体支持
            HtmlPipelineContext hpc = new HtmlPipelineContext(new CssAppliersImpl());
 
            //图片加载
            if (StringUtils.isNotBlank(imagePath)) {
                hpc.setImageProvider(new ImageProvider(imagePath));
            }
            hpc.setAcceptUnknown(true).autoBookmark(true)
                    .setTagFactory(Tags.getHtmlTagProcessorFactory());
            HtmlPipeline htmlPipeline = new HtmlPipeline(hpc, new PdfWriterPipeline(doc, pdfWriter));
            Pipeline<?> pipeline = new CssResolverPipeline(cssResolver, htmlPipeline);
            return new XMLParser(true, new XMLWorker(pipeline, true));
        }
    }
 
    protected static class ImageProvider extends AbstractImageProvider {
        private String imageRootPath;
 
        public ImageProvider(String imageRootPath) {
            this.imageRootPath = imageRootPath;
        }
 
        public String getImageRootPath() {
            return imageRootPath;
        }
    }
    
    public static void main(String[] args) {
		parse2Pdf("d:/html.html", "d:/html.pdf");
	}
    
    
}