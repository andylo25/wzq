package com.dy.core.conf;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.dy.core.event.DyConsumer;
import com.dy.core.event.DyEventManager;

@Component
public class CommonStartupListener implements ApplicationListener<ApplicationReadyEvent> {

	@Autowired
	DyEventManager eventManager;
	
    public void onApplicationEvent(ApplicationReadyEvent event) {
    	// spring启动完成后的一些后续工作
    	
    	// 注册消费者订阅信息
    	Map<String, DyConsumer> consumers = event.getApplicationContext().getBeansOfType(DyConsumer.class);
    	if(consumers != null){
    		for(DyConsumer con:consumers.values()){
    			eventManager.subscribe(con);
    		}
    	}
    	
    }

}
