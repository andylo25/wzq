package com.dy.core.outbound;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.dy.core.outbound.adapter.ClientAdapter;
import com.dy.core.outbound.client.OutboundParse;
import com.dy.core.outbound.client.ServiceMeta;
import com.dy.core.utils.common.SpringContextHolder;

/**
 * 外呼处理类
 * @author andy
 *
 */
public class OutboundUtil {
	
	private static Log logger = LogFactory.getLog(OutboundUtil.class) ;
	
	private static ClientAdapter adapter;
	private static OutboundParse outboundParse;
	
	private static ClientAdapter getAdapter(){
		if(adapter == null){
			adapter = SpringContextHolder.getBean(ClientAdapter.class);
		}
		return adapter;
	}
	private static OutboundParse getOutboundParse(){
		if(outboundParse == null){
			outboundParse = SpringContextHolder.getBean(OutboundParse.class);
		}
		return outboundParse;
	}
	
	/**
	 * 直接对外开放交易
	 * @param tranId
	 * @param reqBody
	 * @return
	 */
	public static String doCommonPost(String tranId,String reqBody){
		return doPost(tranId, reqBody) ;
	}
	
	private static String doPost(String tranId,String reqBody){
		String url = getUrl(tranId);
		logger.error("请求url："+url);
		logger.error("请求报文："+reqBody);
		String responseJson = getAdapter().post(url, reqBody,null);
		logger.error("响应报文："+responseJson);
		return responseJson;
	}
	
	private static String getUrl(String tranCod) {
		ServiceMeta serviceMeta = getOutboundParse().getService(tranCod);
		return serviceMeta.getUrl();
	}
	
}
