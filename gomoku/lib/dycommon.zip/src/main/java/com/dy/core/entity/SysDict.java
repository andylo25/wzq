package com.dy.core.entity;

import java.math.BigDecimal;

import com.dy.core.entity.BaseEntity;

public class SysDict extends BaseEntity{

	private static final long serialVersionUID = 1L;

	private String value;

    private String label;

    private String type;

    private String description;

    private BigDecimal sort;

    private String remarks;

    private Integer dictType;


    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value == null ? null : value.trim();
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label == null ? null : label.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public BigDecimal getSort() {
        return sort;
    }

    public void setSort(BigDecimal sort) {
        this.sort = sort;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    
    public Integer getDictType() {
        return dictType;
    }

    
    public void setDictType(Integer dictType) {
        this.dictType = dictType;
    }

}