package com.dy.core.event;

/**
 * 消费者
 * @author cuiwm
 *
 */
public interface DyConsumer {

	/**
	 * 
	 * @param dyEvent
	 */
	public Integer apply();
	
	public void consume(DyEvent event) throws Exception;
	
}
