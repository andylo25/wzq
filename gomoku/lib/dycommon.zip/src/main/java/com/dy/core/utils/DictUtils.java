package com.dy.core.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.dy.core.bussmodule.IBaseBussModule;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.Option;
import com.dy.core.entity.SysDict;
import com.dy.core.entity.constant.CommonConstant;
import com.dy.core.utils.common.SpringContextHolder;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 字典工具类
 * @author cuiwm
 */
public class DictUtils {
	protected static Logger logger = Logger.getLogger(DictUtils.class);
	
	private static IBaseBussModule baseBussModule;
    static IBaseBussModule getBaseBussModule() {
        if (baseBussModule == null) {
        	baseBussModule = SpringContextHolder.getBean(IBaseBussModule.class);
        }
        return baseBussModule;
    }
	
	private volatile static ConcurrentHashMap<String, List<SysDict>> cache = new ConcurrentHashMap<>();
	private static ThreadLocal<Map<String, List<SysDict>>> curRequest = new ThreadLocal<>();
	
	public static void clearCur(){
		curRequest.remove();
	}
	
	public static SysDict getDict(String value, String type){
	    if (StringUtils.isNotBlank(type) && StringUtils.isNotBlank(value)){
            for (SysDict dict : getDictList(type)){
                if (type.equals(dict.getType()) && value.equals(dict.getValue())){
                    return dict;
                }
            }
        }
	    return null;
	}
	
	public static String getDictLabel(String value, String type, String defaultValue){
		if (StringUtils.isNotBlank(type) && StringUtils.isNotBlank(value)){
			for (SysDict dict : getDictList(type)){
				if ((StringUtils.isBlank(dict.getType())||type.equals(dict.getType())) && value.equals(dict.getValue())){
					return dict.getLabel();
				}
			}
		}
		return defaultValue == null?value:defaultValue;
	}
	
	public static String getDictLabel(String value, String type){
		return getDictLabel(value, type, value);
	}
	
	public static String getDictLabel(Object value, String type){
		if(value == null)return "";
		return getDictLabel(value.toString(), type, value.toString());
	}
	
	public static String getDictLabels(String values, String type, String defaultValue){
		if (StringUtils.isNotBlank(type) && StringUtils.isNotBlank(values)){
			List<String> valueList = new ArrayList<>();
			for (String value : StringUtils.split(values, ",")){
				valueList.add(getDictLabel(value, type, defaultValue));
			}
			return StringUtils.join(valueList, ",");
		}
		return defaultValue;
	}

	public static String getDictValue(String label, String type, String defaultLabel){
		if (StringUtils.isNotBlank(type) && StringUtils.isNotBlank(label)){
			for (SysDict dict : getDictList(type)){
				if (type.equals(dict.getType()) && label.equals(dict.getLabel())){
					return dict.getValue();
				}
			}
		}
		return defaultLabel;
	}
	
	public static List<SysDict> getDictList(String type){
		List<SysDict> dicts = cache.get(type);
		if (dicts==null){
			QueryItem queryItem = new QueryItem(Where.eq("type", type));
			queryItem.setWhere(Where.eq("del_flag", 0));
			queryItem.setWhere(Where.eq("dict_type", 0));//0 子项 1父项
			queryItem.setOrders("sort");
			try {
				dicts = getBaseBussModule().getListByEntity(queryItem, CommonConstant.MODULE_SYSTEM, "dict", SysDict.class);
			} catch (Exception e) {
				logger.error("获取字典异常",e);
			}
			if (dicts == null){
				dicts = Lists.newArrayList();
			}
			cache.putIfAbsent(type, dicts);
		}
		if(dicts.isEmpty()){
			// 局部缓存
			Map<String, List<SysDict>> map = curRequest.get();
			if(map == null){
				map = Maps.newHashMap();
			}
			dicts = map.get(type);
			if(dicts == null){
				dicts = SpringContextHolder.getBean(IOptionInit.class).initType(type);
				map.put(type, dicts);
			}
		}
		return dicts;
	}
	
	public static List<Option> getOptions(String type){
		List<Option> result = new ArrayList<>();
		List<SysDict> dicts = getDictList(type);
		if(dicts != null){
			for(SysDict sd:dicts){
				result.add(new Option(sd.getValue(), sd.getLabel()));
			}
		}
		return result;
	}
	
	public static List<Option> toOption(List<SysDict> dicts){
		List<Option> result = new ArrayList<>();
		if(dicts != null){
			for(SysDict sd:dicts){
				result.add(new Option(sd.getValue(), sd.getLabel()));
			}
		}
		return result;
	}
	
	/**
	 * 返回value类型为int的option
	 * @param type
	 * @return
	 * @author likf
	 */
	public static List<Option> getOptionsInt(String type){
        List<Option> result = new ArrayList<>();
        List<SysDict> dicts = getDictList(type);
        if(dicts != null){
            for(SysDict sd:dicts){
                result.add(new Option(Integer.parseInt(sd.getValue()), sd.getLabel()));
            }
        }
        return result;
    }
	
	/**
	 * 获取选项，包含指定选项
	 * @param type
	 * @param include 1,2
	 * @return
	 */
	public static List<Option> getOptions(String type,String include){
		if(StringUtils.isBlank(include))return getOptions(type);
		List<Option> result = new ArrayList<>();
		List<SysDict> dicts = getDictList(type);
		if(dicts != null){
			String[] strings = include.split(",");
			for(SysDict sd:dicts){
				if(ArrayUtils.contains(strings,sd.getValue())){
					result.add(new Option(sd.getValue(), sd.getLabel()));
				}
			}
		}
		return result;
	}
	
	/**
	 * 获取选项，排除部分选项
	 * @param type
	 * @param exclude 1,2
	 * @return
	 */
	public static List<Option> getOptionsByExclude(String type,String exclude){
		if(StringUtils.isBlank(exclude))return getOptions(type);
		List<Option> result = new ArrayList<>();
		List<SysDict> dicts = getDictList(type);
		if(dicts != null){
			String[] strings = exclude.split(",");
			for(SysDict sd:dicts){
				if(!ArrayUtils.contains(strings,sd.getValue())){
					result.add(new Option(sd.getValue(), sd.getLabel()));
				}
			}
		}
		return result;
	}
	
	public static Map<String,String> getOptionsMap(String type){
		Map<String,String> result = Maps.newHashMap();
		List<SysDict> dicts = getDictList(type);
		if(dicts != null){
			for(SysDict sd:dicts){
				result.put(sd.getValue(), sd.getLabel());
			}
		}
		return result;
	}
	
	/**
	 * 清除缓存
	 * @param type
	 * @return
	 */
	public static List<SysDict> clearCache(String type){
		return cache.remove(type);
	}
	
}
