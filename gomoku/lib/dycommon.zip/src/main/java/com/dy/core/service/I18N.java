package com.dy.core.service;


import java.util.Locale;

import javax.annotation.Resource;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import com.dy.core.utils.common.SpringContextHolder;

/**
 * 国际化工具类
 */

public class I18N {

    private volatile static MessageSource messageSource;
    
    private static MessageSource getMessageSource(){
    	if(messageSource == null){
    		messageSource = SpringContextHolder.getBean(MessageSource.class);
    	}
    	return messageSource;
    }

    /**
     * @param code ：对应messages配置的key.
     * @return
     */
    public static String getMessage(String code){
       return getMessage(code,new Object[]{});
    }

    public static String getMessage(String code,String defaultMessage){
       return getMessage(code, null,defaultMessage);
    }

    public static String getMessage(String code,String defaultMessage,Locale locale){
       return getMessage(code, null,defaultMessage,locale);
    }

    public static String getMessage(String code,Locale locale){
       return getMessage(code,null,code,locale);
    }

    /**
     * @param code ：对应messages配置的key.
     * @param args : 数组参数.
     * @return
     */
    public static String getMessage(String code,Object[] args){
       return getMessage(code, args,code);
    }

    public static String getMessage(String code,Object[] args,Locale locale){
       return getMessage(code, args,code,locale);
    }
    /**
     *
     * @param code ：对应messages配置的key.
     * @param args : 数组参数.
     * @param defaultMessage : 没有设置key的时候的默认值.
     * @return
     */
    public static String getMessage(String code,Object[] args,String defaultMessage){
       //这里使用比较方便的方法，不依赖request.
       Locale locale =LocaleContextHolder.getLocale();
       return getMessage(code, args, defaultMessage, locale);
    }

    /**
     * 指定语言.
     * @param code
     * @param args
     * @param defaultMessage
     * @param locale
     * @return
     */
    public static String getMessage(String code,Object[]args,String defaultMessage,Locale locale){
       return getMessageSource().getMessage(code, args, defaultMessage,locale);

    }

}