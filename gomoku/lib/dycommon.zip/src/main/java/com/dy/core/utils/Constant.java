package com.dy.core.utils;


public class Constant {
	public static final String LOGIN_URL = "/";
	
	public static final String SESSION_USER	= "sessionUser";
	public static final String SESSION_NDS	= "session_no_double_submit";
	public static final String SESSION_COMPANY	= "sessionCompany";
	public static final String SESSION_VERIFY_CODE = "verifyCode";
	public static final String SESSION_MSG_CODE = "msgCode";
	public static final String SESSION_DATE_FORMAT_TYPE = "dateFormatType";
	public static final String SESSION_EMAIL_CODE = "emailCode";
	public static final String SESSION_PHONE_CODE = "phoneCode";
	
	public static final String NO_INTERCEPTOR_PATH = ".*/((toIndex)|(verifyLogin)|(checkLogin)|(login)|(getImageCode)|(error)|(logout)|(verifycode*)|(common/domain)|(api/trust/callback)).*";
	
}