package com.dy.core.exception;

public class DyWebException extends DyUncheckedException {
	private static final long serialVersionUID = 5190291468401300592L;
	
	public DyWebException() {}
	
	/**
	 * @param message 提示信息
	 */
	public DyWebException(String message) {
		super(message);
	}
	
	/**
	 * @param message 提示信息
	 * @param params 国际化信息参数
	 */
	public DyWebException(String message, Object[] params) {
		super(message, params);
	}
	
	/**
	 * @param message 提示信息
	 * @param exception 异常信息
	 */
	public DyWebException(String message, Throwable exception) {
		super(message, exception);
	}
	
	/**
	 * @param message 提示信息
	 * @param exception 异常信息
	 */
	public DyWebException(String message, Object[] params, Throwable exception) {
		super(message,params, exception);
	}
}