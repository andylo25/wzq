package com.dy.core.interceptor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dy.core.dao.transaction.DyTransactionManager;
import com.dy.core.dao.transaction.DyTransactional;

@Aspect
@Component
public class DyTransactionInterceptor {
	
	private static Logger log = LoggerFactory.getLogger(DyTransactionInterceptor.class);
	
	@Autowired
	private DyTransactionManager transactionManager;
	
	@Around(value="@annotation(dyTransactional)")
    public Object aroundAdvice(final ProceedingJoinPoint pjp,DyTransactional dyTransactional) throws Throwable {
		if(dyTransactional != null){
			if(dyTransactional.value()){
				// 开启分布式事务
				if(log.isDebugEnabled()){
					log.debug("开启分布式事务:"+pjp.getSignature());
				}
				transactionManager.begin();
			}
		}
		try {
			return pjp.proceed();
		}catch (Exception e) {
			transactionManager.rollback();
			throw e;
		} finally {
			transactionManager.commit();
		}
	    
	}


}