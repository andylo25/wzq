package com.dy.core.interceptor.doublesmt;

import javax.servlet.http.HttpSession;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.dy.core.exception.DyWebException;
import com.dy.core.utils.Constant;
import com.dy.core.utils.RequestUtil;

@Aspect
@Component
public class NoDoubleSubmInterceptor {
	
	@Around(value="@annotation(com.dy.core.interceptor.doublesmt.NoDoubleSubm)", argNames="pjpsb")
    public Object aroundAdvice(final ProceedingJoinPoint pjpsb) throws Throwable {
		HttpSession session = RequestUtil.getSession();
		String key = Constant.SESSION_NDS+pjpsb.getSignature();
		if(session != null){
				// 检测是否重复提交
				Object lock = session.getAttribute(key);
				if(lock != null){
					String errorMsg = "正在处理，请稍候片刻...";
					throw new DyWebException(errorMsg);
				}else{
					session.setAttribute(key, new Object());
				}
		}
		try {
			return pjpsb.proceed();
		} finally {
			session.removeAttribute(key);
		}
		
	}
}