package com.dy.core.dao.interceptor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.ibatis.executor.parameter.ParameterHandler;
import org.apache.ibatis.executor.statement.RoutingStatementHandler;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.scripting.defaults.DefaultParameterHandler;

import com.dy.core.entity.Page;
import com.dy.core.utils.ReflectUtil;

@Intercepts({@Signature(type=StatementHandler.class,method="prepare",args={Connection.class})})
public class PageInterceptor implements Interceptor {

	private String databaseType;
	
	public void setDatabaseType(String databaseType) {
		this.databaseType = databaseType;
	}

	@Override
	public Object intercept(Invocation invocation) throws Throwable {
		if(!(invocation.getTarget() instanceof RoutingStatementHandler)) return invocation.proceed();
		
		RoutingStatementHandler statementHandler = (RoutingStatementHandler) invocation.getTarget();
		StatementHandler delegate = (StatementHandler) ReflectUtil.getFieldValue(statementHandler, "delegate");
		
		BoundSql boundSql = delegate.getBoundSql();
		Object parameterObj = boundSql.getParameterObject();
		if(parameterObj instanceof Page<?>) {
			Page<?> page = (Page<?>) parameterObj;
			
			String sql = boundSql.getSql();
			Connection connection = (Connection)invocation.getArgs()[0];
			MappedStatement mappedStatement = (MappedStatement) ReflectUtil.getFieldValue(delegate, "mappedStatement");
			
			this.setTotalRecord(page, mappedStatement, connection);
			
			String pageSql = this.getPageSql(page, sql);
			ReflectUtil.setFieldValue(boundSql, "sql", pageSql);
		}
		
		return invocation.proceed();
	}

	@Override
	public Object plugin(Object target) {
		return Plugin.wrap(target, this);
	}

	@Override
	public void setProperties(Properties properties) {
		this.databaseType = properties.getProperty("databaseType");
	}
	
	public String getPageSql(Page<?> page, String sql) {
		StringBuffer sqlBuffer = new StringBuffer(sql);
		
		if("mysql".equalsIgnoreCase(databaseType)) 
			return getMysqlPageSql(page, sqlBuffer);
		else if("oracle".equalsIgnoreCase(databaseType))
			return getOraclePageSql(page, sqlBuffer);
		return sqlBuffer.toString();
	}

	private String getMysqlPageSql(Page<?> page, StringBuffer sqlBuffer) {
		int offset = (page.getPage() - 1) * page.getEpage();
		sqlBuffer.append(" limit ").append(offset).append(",").append(page.getEpage());
		return sqlBuffer.toString();
	}
	
	private String getOraclePageSql(Page<?> page, StringBuffer sqlBuffer) {
		int offset = (page.getPage() - 1) * page.getEpage() + 1;
		sqlBuffer.insert(0, "select u.*, rownum r from (");
		sqlBuffer.append(") u where rownum < ").append(offset + page.getEpage());
		sqlBuffer.insert(0, "select * from (");
		sqlBuffer.append(") where r >= ").append(offset);
		return sqlBuffer.toString();
	}

	private void setTotalRecord(Page<?> page, MappedStatement mappedStatement, Connection connection) {
		BoundSql boundSql = mappedStatement.getBoundSql(page);
		String sql = boundSql.getSql();

		String countSql = this.getCountSql(sql);
		List<ParameterMapping> parameterMappings = boundSql.getParameterMappings();
		BoundSql countBoundSql = new BoundSql(mappedStatement.getConfiguration(), countSql, parameterMappings, page);
		ParameterHandler parameterHandler = new DefaultParameterHandler(mappedStatement, page, countBoundSql);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = connection.prepareStatement(countSql);
			parameterHandler.setParameters(pstmt);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				int totalRecord = rs.getInt(1);
				page.setTotal_items(totalRecord);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private String getCountSql(String sql) {
		int subQueryIndex = sql.indexOf("(");
    	int fromIndex = sql.toLowerCase().indexOf("from");
		if(fromIndex > subQueryIndex) {
			String tmpSql = sql;
			Pattern pattern = Pattern.compile("\\([^(^)]*\\)");
			Matcher matcher = pattern.matcher(tmpSql);
			while(matcher.find()) {
				tmpSql = matcher.replaceFirst("");
				
				subQueryIndex = tmpSql.indexOf("(");
		    	fromIndex = tmpSql.toLowerCase().indexOf("from");
		    	if(subQueryIndex <= 0 || fromIndex < subQueryIndex) {
		    		sql = tmpSql;
		    		break;
		    	}
				matcher = pattern.matcher(tmpSql);
			} 
		}
		
		return "select count(1) " + sql.substring(fromIndex);
	}
}
