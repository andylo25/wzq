package com.dy.core.dao.query;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class QueryItem implements Serializable {

	private static final long serialVersionUID = -6879821231581293682L;

	private Integer page;

	private Integer limit;

	private String fields;

	private String group;

	private String orders;

	private String module;

	private String function;

	private String method;

	private String tableName;
	
	private String pageHeader;

	private String pageFooter;

	private String whereCondition;

	private List<Where> where;

	private Map<String, Object> params;

	private boolean isFromController;
	
	private boolean isPreProcess = false;
	
	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
	}

	public String getOrders() {
		return orders;
	}

	public void setOrders(String orders) {
		this.orders = orders;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getPageHeader() {
		return pageHeader;
	}

	public void setPageHeader(String pageHeader) {
		this.pageHeader = pageHeader;
	}

	public String getPageFooter() {
		return pageFooter;
	}

	public void setPageFooter(String pageFooter) {
		this.pageFooter = pageFooter;
	}

	public String getWhereCondition() {
		return whereCondition;
	}

	public void setWhereCondition(String whereCondition) {
		this.whereCondition = whereCondition;
	}

	public List<Where> getWhere() {
		return where;
	}

	public void setWhere(List<Where> where) {
		this.where = where;
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

	public boolean isFromController() {
		return isFromController;
	}

	public void setFromController(boolean isFromController) {
		this.isFromController = isFromController;
	}

	public void setWhere(Where where) {
		if (this.where == null)
			this.where = new ArrayList<Where>();
		if(where != null){
			this.where.add(where);
		}
	}
	
	public void addWhere(List<Where> where) {
		if (this.where == null)
			this.where = new ArrayList<Where>();
		if(where != null){
			this.where.addAll(where);
		}
	}

	public QueryItem() {
		if (this.where == null) {
			this.where = new ArrayList<Where>();
		}
	};

	public QueryItem(Where where) {
		if (this.where == null) {
			this.where = new ArrayList<Where>();
		}
		this.where.add(where);
	}
	
	public QueryItem(String module, String function) {
		if (this.where == null) {
			this.where = new ArrayList<Where>();
		}
		this.module = module;
		this.function = function;
	}

	public boolean isPreProcess() {
		return isPreProcess;
	}

	public void setPreProcess(boolean isPreProcess) {
		this.isPreProcess = isPreProcess;
	}
	
	public static QueryItemBuilder builder(String module,String function){
	    return new QueryItemBuilder(module, function);
	}
	public static QueryItemBuilder builder(){
        return new QueryItemBuilder();
    }

}