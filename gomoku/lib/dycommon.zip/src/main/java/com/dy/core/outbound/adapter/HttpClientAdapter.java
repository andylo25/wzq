package com.dy.core.outbound.adapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

import com.dy.core.outbound.exception.OutboundException;

@Service
public class HttpClientAdapter implements ClientAdapter {

	private static Logger logger = LoggerFactory.getLogger(HttpClientAdapter.class);
	
	private static SSLConnectionSocketFactory sslsf = null;
    private static PoolingHttpClientConnectionManager cm = null;
    private static SSLContextBuilder builder = null;
    static {
        try {
            builder = new SSLContextBuilder();
            // 全部信任 不做身份鉴定
            builder.loadTrustMaterial(null, new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                    return true;
                }
            });
            sslsf = new SSLConnectionSocketFactory(builder.build(), new String[]{"SSLv2Hello", "SSLv3", "TLSv1", "TLSv1.2"}, null, NoopHostnameVerifier.INSTANCE);
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", new PlainConnectionSocketFactory())
                    .register("https", sslsf)
                    .build();
            cm = new PoolingHttpClientConnectionManager(registry);
            cm.setMaxTotal(200);//max connection
        } catch (Exception e) {
        	logger.error("初始化ssl异常",e);
        }
    }
	
	@Override
	public String post(String url, String strBody,String charset) {
		RequestConfig requestConfig = getRequestConfig();
		if(charset == null)charset = "UTF-8";
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpPost request = null;
		try {
			// 根据地址获取请求
			request = new HttpPost(url);// 这里发送post请求

			// 创建默认的httpClient实例.
//			httpClient = HttpClients.createDefault();
			httpClient = getHttpClient();
			StringEntity stringEntity = new StringEntity(strBody, "UTF-8");
			request.setConfig(requestConfig);
			request.setEntity(stringEntity);
			// 重试策略
//			httpClient.setHttpRequestRetryHandler(getRetryHandler(connectPolicy
//					.getRetryTimes()));
			// 执行请求
			response = httpClient.execute(request);

			if(response != null && response.getEntity() != null){
				return EntityUtils.toString(response.getEntity(), charset);
			}
			return "";
		} catch (Exception e) {
			throw new OutboundException("发送请求异常",e);
		} finally {
			try {
				// 关闭连接,释放资源
				request.abort();
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				logger.error("发送请求关闭连接异常",e);
			}
		}
	}

	private RequestConfig getRequestConfig() {
		return RequestConfig.custom().setSocketTimeout(600000).setConnectTimeout(5000)
				.setConnectionRequestTimeout(2000).build();
	}
	
	protected HttpRequestRetryHandler getRetryHandler(int retryTimes) {
		return new DefaultHttpRequestRetryHandler(retryTimes, false);
	}

	@Override
	public byte[] request(String url, String reqBody) {
		RequestConfig requestConfig = getRequestConfig();

		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpPost request = null;
		try {
			// 根据地址获取请求
			request = new HttpPost(url);// 这里发送post请求

			// 创建默认的httpClient实例.
//			httpClient = HttpClients.createDefault();
			httpClient = getHttpClient();
			StringEntity stringEntity = new StringEntity(reqBody, "UTF-8");
			request.setConfig(requestConfig);
			request.setEntity(stringEntity);
			// 重试策略
//			httpClient.setHttpRequestRetryHandler(getRetryHandler(connectPolicy
//					.getRetryTimes()));
			// 执行请求
			response = httpClient.execute(request);

			if(response != null && response.getEntity() != null){
				return StreamUtils.copyToByteArray(response.getEntity().getContent());
			}
			return null;
		} catch (Exception e) {
			throw new OutboundException("发送请求异常",e);
		} finally {
			try {
				// 关闭连接,释放资源
				request.abort();
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				logger.error("发送请求关闭连接异常",e);
			}
		}
	}

	@Override
	public String post(String url, Map<String, ?> params,String charset) {
		RequestConfig requestConfig = getRequestConfig();
		if(charset == null)charset = "UTF-8";
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpPost request = null;
		try {
			// 根据地址获取请求
			request = new HttpPost(url);// 这里发送post请求
			request.setConfig(requestConfig);

			// 创建默认的httpClient实例.
//			httpClient = HttpClients.createDefault();
			httpClient = getHttpClient();
			
			//设置参数  
            List<NameValuePair> list = new ArrayList<NameValuePair>();  
            for(Entry<String, ?> elem:params.entrySet()){
            	if(elem.getValue() != null){
            		list.add(new BasicNameValuePair(elem.getKey(),elem.getValue().toString()));  
            	}
            }
            if(list.size() > 0){  
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list,"UTF-8");  
                request.setEntity(entity);  
            } 
			// 重试策略
//			httpClient.setHttpRequestRetryHandler(getRetryHandler(connectPolicy
//					.getRetryTimes()));
			// 执行请求
			response = httpClient.execute(request);

			if(response != null && response.getEntity() != null){
				return EntityUtils.toString(response.getEntity(), charset);
			}
			return "";
		} catch (Exception e) {
			throw new OutboundException("发送请求异常",e);
		} finally {
			try {
				// 关闭连接,释放资源
				request.abort();
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				logger.error("发送请求关闭连接异常",e);
			}
		}
	}
	
	public static CloseableHttpClient getHttpClient() throws Exception {
        CloseableHttpClient httpClient = HttpClients.custom()
                .setSSLSocketFactory(sslsf)
                .setConnectionManager(cm)
                .setConnectionManagerShared(true)
                .build();
        return httpClient;
    }

	@Override
	public String downFile(String url, Map<String, String> params,String filePath) {
		RequestConfig requestConfig = getRequestConfig();

		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpPost request = null;
		try {
			// 根据地址获取请求
			request = new HttpPost(url);// 这里发送post请求
			request.setConfig(requestConfig);

			// 创建默认的httpClient实例.
			httpClient = HttpClients.createDefault();
			
			//设置参数  
            List<NameValuePair> list = new ArrayList<NameValuePair>();  
            Iterator<Entry<String,String>> iterator = params.entrySet().iterator();  
            while(iterator.hasNext()){  
                Entry<String,String> elem = iterator.next();  
                list.add(new BasicNameValuePair(elem.getKey(),elem.getValue()));  
            }  
            if(list.size() > 0){  
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list,"UTF-8");  
                request.setEntity(entity);  
            } 
			// 重试策略
//			httpClient.setHttpRequestRetryHandler(getRetryHandler(connectPolicy
//					.getRetryTimes()));
			// 执行请求
			response = httpClient.execute(request);

			if(response.getStatusLine().getStatusCode() != HttpStatus.SC_OK){
		        return null;
		    }
		    HttpEntity entity = response.getEntity();
		    if(entity != null) {
		        InputStream is = entity.getContent();
		        if(filePath == null){
		        	filePath = System.getProperty("java.io.tmpdir")+"/"+System.currentTimeMillis();
		        }
		        File file = new File(filePath);
		        FileOutputStream fos = new FileOutputStream(file); 
		        byte[] buffer = new byte[4096];
		        int len = -1;
		        while((len = is.read(buffer) )!= -1){
		            fos.write(buffer, 0, len);
		        }
		        fos.close();
		        is.close();
		    }
		    return response.getFirstHeader("Content-Type").getValue();
		} catch (Exception e) {
			throw new OutboundException("发送请求异常",e);
		} finally {
			try {
				// 关闭连接,释放资源
				request.abort();
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				logger.error("发送请求关闭连接异常",e);
			}
		}
	}

}
