package com.dy.core.httpinvoker;

import java.io.Serializable;

import com.dy.core.entity.User;

/**
 * 客户端、服务端上下文，存储交互信息，可修改
 * @author cuiwm
 *
 */
public class SwapContext implements Serializable{

	private static final long serialVersionUID = 1L;
	
	public static final String HttpInvokerHeader_key_ = "HttpInvokerHeader_key_";

	static ThreadLocal<HttpInvokerHeader> header_ = new ThreadLocal<>();
	
	/**
	 * 设置请求user
	 */
	public static void setRequHeader(HttpInvokerHeader header){
		header_.set(header);
	}
	
	public static User getRequUser(){
		HttpInvokerHeader header = header_.get();
		if(header != null){
			return header.getUser();
		}
		return null;
	}
	
	public static String getRemoteIp(){
		HttpInvokerHeader header = header_.get();
		if(header != null){
			return header.getIp();
		}
		return null;
	}
	
	public static Integer getRemoteApp(){
		HttpInvokerHeader header = header_.get();
		if(header != null){
			return header.getFromApp();
		}
		return 0;
	}
	
	public static void clear(){
		header_.remove();
	}
}
