package com.dy.core.utils;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.dy.core.dao.query.QueryItem;
import com.dy.core.entity.Page;

public interface HttpInvoker {

	/**
	 * 插入一条数据
	 * @param module
	 * @param function
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public Long insert(String module, String function, Object obj) throws Exception ;
	
	/**
	 * 根据主键更新数据
	 * @param module
	 * @param function
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public Integer update(String module, String function, Object obj) throws Exception ;
	public Integer update(String module, String function, Object obj, boolean isUpdateEmpty) throws Exception ;
	
	/**
	 * 根据主键(id)删除数据
	 * @param id 要删除的记录ID
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public Integer deleteById(Long id, String module, String function) throws Exception ;
	
	/**
	 * 根据主键删除数据(主键字段不是id，要另外指定如：menu_id)
	 * @param pkColumn 数据库字段名
	 * @param id 主键值
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws Exception
	 */
	public Integer deleteById(String pkColumn, Long id, String module, String function) throws Exception ;
	
	/**
	 * 查询单条记录，返回Map
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getOne(QueryItem queryItem, String module, String function) throws Exception ;
	
	/**
	 * 查询单条记录，返回BaseEntity
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> T getOne(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception ;
	public <T> T getOneById(Serializable id, String module, String function, Class<T> clazz) throws Exception ;
	public <T> T getOneById(Serializable id, String module, String function, Class<T> clazz,String cols) throws Exception ;
	
	/**
	 * 查询列表，返回List
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public List<Map> getList(QueryItem queryItem, String module, String function) throws Exception;
	
	/**
	 * 查询列表，返回Page
	 * @param queryItem
	 * @param module
	 * @param function
	 * @return
	 * @throws Exception
	 */
	public Page<Map> getPage(QueryItem queryItem, String module, String function) throws Exception;
	
	/**
	 * 查询列表，返回List
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> List<T> getList(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception ;
	
	/**
	 * 查询列表，返回Page
	 * @param queryItem
	 * @param module
	 * @param function
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public <T> Page<T> getPage(QueryItem queryItem, String module, String function, Class<T> clazz) throws Exception ;

}
