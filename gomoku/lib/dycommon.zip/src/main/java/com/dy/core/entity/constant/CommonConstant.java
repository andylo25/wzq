package com.dy.core.entity.constant;

public class CommonConstant {
	
    /**
     * 模块:系统模块
     */
    public static String MODULE_SYSTEM = "system";
    public static String MODULE_BUSINESS= "business";
    
    //菜单状态
  	public static final int MENU_STATUS_NOR = 1;//正常
  	public static final int MENU_STATUS_FORB = -1;//禁用
}