package com.dy.core.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.dy.core.dao.dml.DmlItem;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.entity.BaseEntity;
import com.dy.core.entity.Page;
import com.dy.core.exception.DyServiceException;

public interface BaseService {
	
	/**
	 * 事务管理器
	 */
	public static final String TX_MASTER = "tx_master";
	public static final String TX_CLUSTER = "tx_cluster";
	
	/**
	 * 插入
	 * @param dmlItem
	 * @return 返回主键
	 * @throws Exception
	 */
	public Long insert(DmlItem dmlItem) throws DyServiceException;
	
	/**
	 * 插入(主键为id)
	 * @param module
	 * @param function
	 * @param baseEntity
	 * @return
	 * @throws Exception
	 */
	public Long insert(String module, String function, BaseEntity baseEntity) throws DyServiceException;
	
	/**
	 * 插入(主键不为id)
	 * @param module
	 * @param function
	 * @param baseEntity
	 * @return
	 * @throws DyServiceException
	 */
	public Long insert(String module, String function, String pkColumn, BaseEntity baseEntity) throws DyServiceException;
	
	/**
	 * 更新
	 * @param dmlItem
	 * @return 返回更新的记录数
	 * @throws DyServiceException
	 */
	public Integer update(DmlItem dmlItem) throws DyServiceException;
	
	/**
	 * 更新
	 * @param module
	 * @param function
	 * @param baseEntity
	 * @return
	 * @throws DyServiceException
	 */
	public Integer updateById(String module, String function, BaseEntity baseEntity) throws DyServiceException;
	
	/**
	 * 更新
	 * @param module
	 * @param function
	 * @param baseEntity
	 * @param updateEmpty 是否更新null
	 * @return
	 * @throws DyServiceException
	 */
	public Integer updateById(String module, String function, BaseEntity baseEntity, boolean updateEmpty) throws DyServiceException;
	
	/**
	 * 更新
	 * @param module
	 * @param function
	 * @param pkColumn
	 * @param baseEntity
	 * @return
	 * @throws DyServiceException
	 */
	public Integer updateById(String module, String function, String pkColumn, BaseEntity baseEntity) throws DyServiceException;
	
	/**
	 * 更新
	 * @param module
	 * @param function
	 * @param pkColumn
	 * @param baseEntity
	 * @param updateEmpty 是否更新null
	 * @return
	 * @throws DyServiceException
	 */
	public Integer updateById(String module, String function, String pkColumn, BaseEntity baseEntity, boolean updateEmpty) throws DyServiceException;
	
	/**
	 * 删除
	 * @param dmlItem
	 * @return 返回删除记录数
	 * @throws DyServiceException
	 */
	public Integer delete(DmlItem dmlItem) throws DyServiceException;
	
	/**
	 * 根据主键(id)删除数据
	 * @param id 要删除的记录ID
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws DyServiceException
	 */
	public Integer deleteById(Long id, String module, String function) throws DyServiceException;
	
	/**
	 * 根据主键删除数据(主键字段不是id，要另外指定如：menu_id)
	 * @param pkColumn 数据库字段名
	 * @param id 主键值
	 * @param module 模块名
	 * @param function 功能
	 * @return
	 * @throws DyServiceException
	 */
	public Integer deleteById(String pkColumn, Long id, String module, String function) throws DyServiceException;
	
	/**
	 * 查询单条记录(返回Map)
	 * @param queryItem
	 * @return 
	 * @throws DyServiceException
	 */
	public Map<String, Object> getOne(QueryItem queryItem) throws DyServiceException;
	
	/**
	 * 查询单条记录(返回Entity)
	 * @param baseEntity
	 * @return 
	 * @throws DyServiceException
	 */
	public <T> T getOneById(Serializable id, String module, String function, Class<? extends BaseEntity> clazz) throws DyServiceException ;
	public <T> T getOneById(Serializable id, String module, String function, Class<? extends BaseEntity> clazz,String fields) throws DyServiceException ;
	
	/**
	 * 查询单条记录(返回Entity)
	 * @param queryItem
	 * @param clazz
	 * @return
	 * @throws DyServiceException
	 */
	public <T> T getOne(QueryItem queryItem, Class<T> clazz) throws DyServiceException;
	
	/**
	 * 查询多条记录
	 *   1、如果queryItem.page和queryItem.limit都不为空，返回满足条件的第page页的记录(Page)
	 *   2、如果queryItem.limit为空，queryItem.page不为空，limit取默认值20，返回满足条件的第page页的记录(Page)
	 *   3、如果queryItem.page为空，queryItem.limit不为空，返回满足条件的前n条记录(List<Map<String, Object>>)
	 *   4、如果queryItem.page和queryItem.limit都为空，返回满足条件的所有记录(List<Map<String, Object>>)
	 * @param queryItem
	 * @return
	 * @throws DyServiceException
	 */
	public Object getList(QueryItem queryItem) throws DyServiceException;
	
	/**
	 * 查询多条记录(绑定entity)
	 * @param queryItem
	 * @param clazz
	 * @return
	 * @throws DyServiceException
	 */
	public <T> List<T> getList(QueryItem queryItem, Class<T> clazz) throws DyServiceException;
	
	/**
	 * 查询多条记录(绑定entity)
	 * @param queryItem
	 * @param clazz
	 * @return
	 * @throws DyServiceException
	 */
	public <T> Page<T> getPage(QueryItem queryItem, Class<T> clazz) throws DyServiceException;
	
	/**
	 * 统计满足条件的记录数
	 * @param queryItem
	 * @return
	 * @throws DyServiceException
	 */
	public Integer getListCount(QueryItem queryItem) throws DyServiceException;
}