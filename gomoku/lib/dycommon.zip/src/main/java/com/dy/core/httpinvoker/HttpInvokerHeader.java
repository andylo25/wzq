package com.dy.core.httpinvoker;

import java.io.Serializable;

import com.dy.core.entity.User;

public class HttpInvokerHeader implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private User user;
	
	private String ip;
	
	private Integer fromApp;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Integer getFromApp() {
		return fromApp;
	}

	public void setFromApp(Integer fromApp) {
		this.fromApp = fromApp;
	}

	

}
