package com.dy.core.utils.multiquery;

import com.dy.core.dao.query.QueryItem;

public class MultiCondition {
	/**
	 * 查询条件
	 */
	private QueryItem queryItem;
	/**
	 * 本表的关联条件
	 */
	private String mainJoinCondition ;
	/**
	 * 关联表的关联条件
	 */
	private String subJoinCondition ;
	/**
	 * 表的别名
	 */
	private String alias ;
	/**
	 * 获取查询条件
	 * @return
	 */
	public QueryItem getQueryItem() {
		return queryItem;
	}
	/**
	 * 设置查询条件
	 * @param queryItem
	 */
	public void setQueryItem(QueryItem queryItem) {
		this.queryItem = queryItem;
	}
	/**
	 * 获取本表的关联条件
	 * @return
	 */
	public String getMainJoinCondition() {
		return mainJoinCondition;
	}
	/**
	 * 设置本表的关联条件
	 * @param mainJoinCondition
	 */
	public void setMainJoinCondition(String mainJoinCondition) {
		this.mainJoinCondition = mainJoinCondition;
	}
	/**
	 * 获取关联表的关联条件
	 * @return
	 */
	public String getSubJoinCondition() {
		return subJoinCondition;
	}
	/**
	 * 设置关联表的关联条件
	 * @param subJoinCondition
	 */
	public void setSubJoinCondition(String subJoinCondition) {
		this.subJoinCondition = subJoinCondition;
	}
	/**
	 * 获取表的别名
	 * @return
	 */
	public String getAlias() {
		return alias;
	}
	/**
	 * 设置表的别名
	 * @param alias
	 */
	public void setAlias(String alias) {
		this.alias = alias;
	}

}
