package com.dy.core.dao.dml;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.dy.core.dao.query.Where;
import com.dy.core.entity.NameValue;

public class DmlItem implements Serializable {
	private static final long serialVersionUID = -3395878677233328236L;
	
	private Object id;
	
	private String fields;
	
	private String param;
	
	private String module;
	
	private String method;
	
	private String function;
	
	private String tableName;
	
	private String sequenceName;
	
	private String pkColumn;
	
	private List<Where> whereList;
	
	private List<NameValue> params;
	
	private Map<String, Object> paramMap;
	
	private Boolean isFromController;

	public Object getId() {
		return id;
	}

	public void setId(Object id) {
		this.id = id;
	}

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getSequenceName() {
		return sequenceName;
	}

	public void setSequenceName(String sequenceName) {
		this.sequenceName = sequenceName;
	}

	public String getPkColumn() {
		return StringUtils.isEmpty(pkColumn) ? "id" : pkColumn;
	}

	public void setPkColumn(String pkColumn) {
		this.pkColumn = pkColumn;
	}

	public List<Where> getWhereList() {
		if (whereList == null) {
			whereList = new ArrayList<Where>();
		}
		return whereList;
	}

	public void setWhereList(List<Where> whereList) {
		this.whereList = whereList;
	}

	public List<NameValue> getParams() {
		return params;
	}

	public void setParams(List<NameValue> params) {
		this.params = params;
	}
	
	public Map<String, Object> getParamMap() {
		return paramMap;
	}

	public void setParamMap(Map<String, Object> paramMap) {
		this.paramMap = paramMap;
	}
	
	public Boolean isFromController() {
		return isFromController == null ? false : isFromController;
	}

	public void setFromController(Boolean isFromController) {
		this.isFromController = isFromController;
	}

	public DmlItem() {
	}
	
	public DmlItem(String module, String function) {
		if (this.params == null) {
			this.params = new ArrayList<NameValue>();
		}
		this.module = module;
		this.function = function;
	}
	
	public DmlItem(Long id, String pkColumn) {
		this.id = id;
		this.pkColumn = pkColumn;
	}
	
	public DmlItem(NameValue param) {
		if(this.params == null) this.params = new ArrayList<NameValue>();
		this.params.add(param);
	}
	
	public DmlItem(List<NameValue> params) {
		this.params = params;
	}

	public static DmlItemBuilder build(String module, String function) {
		return new DmlItemBuilder(module, function);
	}

}