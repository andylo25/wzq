package com.dy.sc.admin.flow;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dy.core.utils.JsonUtils;
import com.dy.ia.entity.custom.flow.TaskNode;
import com.dy.sc.admin.AdminApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=AdminApplication.class)
public class FlowTests {
    
    private static TaskNode start(String name){
        TaskNode node=new TaskNode();
        node.setNode_id("-1");
        node.setNode_name(name);
        node.setRole("");
        node.setLevel("-1");
        node.setType("1");
        return node;
    }
    
    private static List<TaskNode> middle(String[] names,String role){
        return middle(names, role, null);
    }
    
    private static List<TaskNode> middle(String[] names,String role,Boolean open){
        List<TaskNode> list=new ArrayList<TaskNode>();
        for(int i=0;i<names.length;i++){
            TaskNode node=new TaskNode();
            node.setNode_id(String.valueOf(i));
            node.setNode_name(names[i]);
            node.setRole(role);
            node.setLevel(String.valueOf(i+1));
            node.setType("1");
            if(open!=null)
                node.setOpen(open);
            list.add(node);
        }
        return list;
    }
    
    private static TaskNode end(String name,String role){
        TaskNode node=new TaskNode();
        node.setNode_id("99");
        node.setNode_name(name);
        node.setRole(role);
        node.setLevel("99");
        node.setType("1");
        return node;
    }
    String role="126";

    /**
     * 
     * 实名认证
     * @author likf
     */
	@Test
	public void shiMing() {
	    String json=JsonUtils.object2JsonString(FlowTests.start("实名认证申请"));
	    System.out.println(json);
	    
	    String[] names=new String[]{"核心企业复核"};
	    json=JsonUtils.object2JsonString(FlowTests.middle(names, role));
        System.out.println(json);
        json=JsonUtils.object2JsonString(FlowTests.middle(names, role,true));
        System.out.println(json);
	    
	    json=JsonUtils.object2JsonString(FlowTests.end("实名认证审核",role));
        System.out.println(json);
	}
	
	/**
	 * 
	 * 质押合同
	 * @author likf
	 */
	@Test
    public void zhiYa() {
        String json=JsonUtils.object2JsonString(FlowTests.start("应收账款质押合同申请"));
        System.out.println(json);
        
        json=JsonUtils.object2JsonString(FlowTests.end("应收账款质押合同审核",role));
        System.out.println(json);
    }

	/**
	 * 
	 * 发起转让
	 * @author likf
	 */
	@Test
    public void chuZhi() {
        String json=JsonUtils.object2JsonString(FlowTests.start("发起转让"));
        System.out.println(json);
        
        String[] names=new String[]{"转让复核"};
        json=JsonUtils.object2JsonString(FlowTests.middle(names, role));
        System.out.println(json);
        
        json=JsonUtils.object2JsonString(FlowTests.end("回执确认",role));
        System.out.println(json);
    }
	
	/**
	 * 
	 * 借贷
	 * @author likf
	 */
	@Test
    public void jieDai() {
        String json=JsonUtils.object2JsonString(FlowTests.start("借贷合同申请"));
        System.out.println(json);
        
        json=JsonUtils.object2JsonString(FlowTests.end("借贷合同审核",role));
        System.out.println(json);
    }
	
	/**
	 * 
	 * 请款
	 * @author likf
	 */
	@Test
    public void qingKuan() {
        String json=JsonUtils.object2JsonString(FlowTests.start("发起请款"));
        System.out.println(json);
        
        String[] names={"请款复核"};
        json=JsonUtils.object2JsonString(FlowTests.middle(names,role));
        System.out.println(json);
        
        json=JsonUtils.object2JsonString(FlowTests.end("确认出款",role));
        System.out.println(json);
    }
	
	@Test
    public void zhuiZhang() {
        String json=JsonUtils.object2JsonString(FlowTests.start("应收账款转追账申请"));
        System.out.println(json);
        
        json=JsonUtils.object2JsonString(FlowTests.end("应收账款转追账审核",role));
        System.out.println(json);
    }
	
	@Test
    public void huaiZhang() {
        String json=JsonUtils.object2JsonString(FlowTests.start("应收账款转坏账申请"));
        System.out.println(json);
        
        json=JsonUtils.object2JsonString(FlowTests.end("应收账款转坏账审核",role));
        System.out.println(json);
    }
}
