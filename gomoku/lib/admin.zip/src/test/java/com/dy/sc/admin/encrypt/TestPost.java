package com.dy.sc.admin.encrypt;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

import org.junit.Test;

import com.dy.core.utils.HttpClientUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.encrypt.AesException;
import com.dy.core.utils.encrypt.MessageEncryptUtil;
import com.google.common.collect.Maps;

public class TestPost {

    public void post(String path,Map data){
        String aesKey="YbgnaegXuzyA5tIt";
        String appId="sc1";
        String org_code="sc1";
        String token=aesKey;
        try {
            
            MessageEncryptUtil encryptUtil=new MessageEncryptUtil(token, aesKey, appId);
            String nonce=encryptUtil.getRandomStr();
            String timeStamp=String.valueOf(new Date().getTime());
            Map<String, String> result=encryptUtil.encryptObject(data, timeStamp, nonce,org_code);
            
            try {
                String requestPath=path+"?";
                for(Map.Entry<String, String> entry:result.entrySet()){
                    requestPath+=entry.getKey()+"="+entry.getValue()+"&";
                }
                System.out.println("请求地址:"+requestPath);
                String returnStr=HttpClientUtils.doPost(path, result);
                System.out.println(returnStr);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (AesException e1) {
            e1.printStackTrace();
        }
    }
    
    @Test
    public void openbank(){
        String path="http://a.sc1.diyou.cc:2224/trust/register/dypay";

        Map<String,Object> data=Maps.newHashMap();
        data.put("trn_id", UUID.randomUUID().toString());
        data.put("action", "register");
        data.put("company", "和雅贸易有限公司");
        data.put("type", "3");
        data.put("business_no", "GS111111");
        data.put("card_type", "1");
        data.put("card_no", "23232382032");
        data.put("card_name", "张先生");
        data.put("mobile", "13812345678");
        data.put("notify_url", "http://a.sc1.diyou.cc:2225/api/trust/callback");
        post(path,data);
    }
    
    /**
     * 
     * 余额查询
     * @author likf
     */
    @Test
    public void qcard(){
        String path="http://a.sc1.diyou.cc:2224/trust/qcard/dypay";

        Map<String,Object> data=Maps.newHashMap();
        data.put("trn_id", UUID.randomUUID().toString());
        data.put("action", "qcard");
        data.put("account", "62222222202222");
        post(path,data);
    }
    
    @Test
    public void pay_detail(){
        String path="http://a.sc1.diyou.cc:2224/trust/pay_detail/dypay";

        Map<String,Object> data=Maps.newHashMap();
        data.put("trn_id", UUID.randomUUID().toString());
        data.put("action", "pay_detail");
        data.put("account", "62222222202222");
        data.put("time_start", System.currentTimeMillis());
        data.put("time_end", System.currentTimeMillis());
        //data.put("buss_type", "62222222202222");
        data.put("start_index", 0);
        data.put("page_size", 10);
        post(path,data);
    }
    
    /**
     * 
     * 虚转虚
     * @author likf
     */
    @Test
    public void transfer(){
        String path="http://a.sc1.diyou.cc:2224/trust/pay_detail/dypay";

        Map<String,Object> data=Maps.newHashMap();
        data.put("trn_id", UUID.randomUUID().toString());
        data.put("action", "transfer");
        data.put("payer_account", "62222222202222");
        data.put("payer", "厦门金融保险");
        data.put("payee_account", "622222989");
        data.put("payee", "福建网联信息");
        data.put("amount", 100.00);
        data.put("notify_url", "http://www.baidu.com");
        data.put("remark", "");
        post(path,data);
    }
    
    @Test
    public void transferOut(){
        String path="http://a.sc1.diyou.cc:2224/common/dypay/transfer_out";

        Map<String,Object> data=Maps.newHashMap();
        data.put("trn_id", UUID.randomUUID().toString());
        data.put("action", "transfer_out");
        data.put("payer_account", "62222222202222");
        data.put("payer", "厦门金融保险");
        data.put("payee_account", "622222989");
        data.put("payee", "福建网联信息");
        data.put("amount", 100.00);
        data.put("notify_url", "http://www.baidu.com");
        data.put("remark", "");
        post(path,data);
    }
    
    @Test
    public void login(){
    	String path="http://dev.www.ia.diyou.cc:2224/common/dypay/login";
    	
    	Map<String,Object> data=Maps.newHashMap();
    	data.put("trn_id", UUID.randomUUID().toString());
    	data.put("action", "login");
    	data.put("account", "01010141700270660000100");
    	System.out.println(JsonUtils.object2JsonString(data));
//    	post(path,data);
    }
}
