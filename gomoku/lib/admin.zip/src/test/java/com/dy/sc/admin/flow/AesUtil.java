package com.dy.sc.admin.flow;

import java.lang.reflect.Array;
import java.nio.charset.Charset;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.tomcat.util.descriptor.web.SecurityRoleRef;

public class AesUtil {

    /**
     * 注意key和加密用到的字符串是不一样的 加密还要指定填充的加密模式和填充模式 AES密钥可以是128或者256， 加密模式包括ECB, CBC等
     * ECB模式是分组的模式， CBC是分块加密后，每块与前一块的加密结果异或后再加密 第一块加密的明文是与IV变量进行异或
     */
    static Charset CHARSET = Charset.forName("utf-8");
    public static final String KEY_ALGORITHM        = "AES";
    public static final String ECB_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";
    public static final String CBC_CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";

    /**
     * IV(Initialization Value)是一个初始值，对于CBC模式来说，它必须是随机选取并且需要保密的
     * 而且它的长度和密码分组相同(比如：对于AES 128为128位，即长度为16的byte类型数组)
     */

    public static final String base = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    
    public static String getRandomStr(int len) {
        int baseStringLength = base.length();
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < len; i++) {
            int number = random.nextInt(baseStringLength);
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    public static void main(String[] arg) {
        String password = "12345633333333333333301234567891111";
        password=getRandomStr(16);
        String PLAIN_TEXT           = "MANUTD is the greatest club in the world";

//        SecretKey key = generateSecretKey(password);
//        System.out.println(key.getEncoded().length);
//        byte[] encodedText = AesEcbEncode(PLAIN_TEXT.getBytes(), key);
//        System.out.println("AES ECB encoded with Base64: " + Base64.encodeBase64String(encodedText));
//        System.out.println("AES ECB decoded: " + AesEcbDecode(encodedText, key));

        
        byte[] iv = Arrays.copyOfRange(password.getBytes(), 0, 16);
        byte[] encodedText = encrypt(PLAIN_TEXT.getBytes(), password, iv);
        
        System.out.println("AES CBC encoded with Base64: " + Base64.encodeBase64String(encodedText));
        byte[] data=decrypt(encodedText, password, iv);
        System.out.println("AES CBC decoded: " +new String(data));
    }

    /**
     * 使用ECB模式进行加密。 加密过程三步走： 1. 传入算法，实例化一个加解密器 2. 传入加密模式和密钥，初始化一个加密器 3.
     * 调用doFinal方法加密
     * 
     * @param plainText
     * @return
     */
    public static byte[] AesEcbEncode(byte[] plainText, SecretKey key) {
        try {
            Cipher cipher = Cipher.getInstance(ECB_CIPHER_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return cipher.doFinal(plainText);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException
                | BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 使用ECB解密
     * 
     * @param decodedText
     * @param key
     * @return
     */
    public static String AesEcbDecode(byte[] decodedText, SecretKey key) {
        try {
            Cipher cipher = Cipher.getInstance(ECB_CIPHER_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            return new String(cipher.doFinal(decodedText));
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException
                | BadPaddingException e) {
            e.printStackTrace();
        }
        return null;

    }

    /**
     * CBC加密
     * 
     * @param plainText
     * @param key
     * @param IVParameter
     * @return
     */
    public static byte[] encrypt(byte[] plainText, String aesKey, byte[] IVParameter) {
        try {
            Key key=generateSecretKey(aesKey);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(IVParameter);
            Cipher cipher = Cipher.getInstance(CBC_CIPHER_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key, ivParameterSpec);
            return cipher.doFinal(plainText);

        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException
                | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * CBC 解密
     * 
     * @param decodedText
     * @param key
     * @param IVParameter
     * @return
     */
    public static byte[] decrypt(byte[] data, String aesKey, byte[] ivParameter) {
        SecretKey key=generateSecretKey(aesKey);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(ivParameter);
//        IvParameterSpec ivParameterSpec = new IvParameterSpec(aesKey.getBytes(CHARSET),0,16);
        try {
            Cipher cipher = Cipher.getInstance(CBC_CIPHER_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key, ivParameterSpec);
            return cipher.doFinal(data);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException
                | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 1.创建一个KeyGenerator 2.调用KeyGenerator.generateKey方法
     * 由于某些原因，这里只能是128，如果设置为256会报异常，需修改java jce文件
     * 
     * @return
     */
//    public static SecretKey generateAESSecretKey(String password) {
//        KeyGenerator keyGenerator = null;
//        try {
//            keyGenerator = KeyGenerator.getInstance(KEY_ALGORITHM);
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        }
////        keyGenerator.init(256, new SecureRandom(password.getBytes()));
//        keyGenerator.init(256);
//        // keyGenerator.init(128, new SecureRandom(password.getBytes()));
//        return keyGenerator.generateKey();// .getEncoded();
//        // return new SecretKeySpec(password.getBytes(),"AES");
//    }
    
    public static SecretKey generateSecretKey(String aesKey) {
        return new SecretKeySpec(aesKey.getBytes(),"AES");
    }

    /**
     * 还原密钥
     * 
     * @param secretBytes
     * @return
     */
    public static SecretKey restoreSecretKey(byte[] secretBytes) {
        SecretKey secretKey = new SecretKeySpec(secretBytes, KEY_ALGORITHM);
        return secretKey;
    }
}
