package com.dy.sc.admin.flow;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dy.sc.admin.AdminApplication;
import com.dy.sc.bussmodule.utils.workflow.WorkflowUtil;
import com.dy.sc.entity.constant.SCFlow;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=AdminApplication.class)
public class FlowInstTest {
    
    @Autowired
    private WorkflowUtil util;

    /**
     * 
     * 实名认证
     * @author likf
     * @throws Exception 
     */
    @org.junit.Test
    public void test() throws Exception{
        
        String flowNum="002";
        String msg="实名审批";
        String companyId=String.valueOf(166);
//        util.startFlow(SCFlow.FLOW_SHIMING, flowNum, msg, "127.0.0.1", companyId,"测试003");
    }
}
