/*
* 首页
*/
require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
require("./plugins/ueditor/angular-ueditor.js");  //完整版的编辑器指令
var indexApp = angular.module("indexApp", ["validation", "validation.rule", "ng.ueditor", "dyDir", "dyService"]);

//系统首页-公告
indexApp.controller("systemIndexCtrl", function($scope, $http, postUrl, $timeout){

    $scope.formStruct = formStruct;

    $scope.parentEvents = function(pId, id){  //点击待办任务或者预警提醒触发左侧菜单的点击事件
        parent.$("dt[data-id='" + pId + "']", parent.doucment).trigger('click');
        parent.$("dd[data-id='" + id + "']", parent.doucment).trigger('click');
    }
    
    $scope.parentLink = function(pId, id, keyName){  //点击待办任务或者预警提醒触发左侧菜单的点击事件
        parent.$("dt[data-id='" + pId + "']", parent.doucment).trigger('click');
        parent.$("dd[data-id='" + id + "']", parent.doucment).trigger('click');
        /*parent.$("#rightcontent").load(function(){
	    	this.contentWindow.$('input[name=defKey]').val(keyName).trigger('change');
	        this.contentWindow.$("A.search-btn").trigger('click');
	        this.contentWindow.$('input[name=defKey]').val('').trigger('change');
	    });*/
	    parent.document.getElementById("rightcontent").src = "/workflow/todo/list/0?defKey="+keyName;
    }

});


//信贷数据看板-首页
indexApp.controller("secondIndexCtrl", function($scope, $http, postUrl, $timeout){
    $scope.formStruct = formStruct;
    $scope.formData = formStruct.form_data;

    function toArray(list,col){
        var re = [];
        for(var i in list){
            re.push(list[i][col]);
        }
        return re;
    }

    //我本月放贷/回款走势情况
    if($scope.formData.user_trend){
        $scope.user_Data = {
            tooltip: {
                trigger: "axis"
            },
            legend: {
                data: ["本月贷款总额","本月回款总额"],
                bottom: "bottom"
            },
            xAxis: {
                type: "category",
                axisLabel: {interval: 0,rotate:30},
                data: $scope.formData.x_axis
            },
            yAxis: {
                type: "value",
                name: "金额(元)"
            },
            series: [
                {
                    name: "本月贷款总额",
                    type: "line",
                    data: toArray($scope.formData.user_trend,'credit')
                },
                {
                    name: "本月回款总额",
                    type: "line",
                    data: toArray($scope.formData.user_trend,'back')
                }
            ]
        };
    }

    //我部门放贷/回款走势情况
    if($scope.formData.dept_trend){
        $scope.dept_Data = {
            tooltip: {
                trigger: "axis"
            },
            legend: {
                data: ["本月贷款总额","本月回款总额"],
                bottom: "bottom"
            },
            xAxis: {
                type: "category",
                axisLabel: {interval: 0,rotate:30},
                data: $scope.formData.x_axis
            },
            yAxis: {
                type: "value",
                name: "金额(元)"
            },
            series: [
                {
                    name: "本月贷款总额",
                    type: "line",
                    data: toArray($scope.formData.dept_trend,'credit')
                },
                {
                    name: "本月回款总额",
                    type: "line",
                    data: toArray($scope.formData.dept_trend,'back')
                }
            ]
        };
    }

    //公司本月放贷/回款走势情况
    if($scope.formData.company_trend){
        $scope.company_Data = {
            tooltip: {
                trigger: "axis"
            },
            legend: {
                data: ["本月贷款总额","本月回款总额"],
                bottom: "bottom"
            },
            xAxis: {
                type: "category",
                axisLabel: {interval: 0,rotate:30},
                data: $scope.formData.x_axis
            },
            yAxis: {
                type: "value",
                name: "金额(元)"
            },
            series: [
                {
                    name: "本月贷款总额",
                    type: "line",
                    data: toArray($scope.formData.company_trend,'credit')
                },
                {
                    name: "本月回款总额",
                    type: "line",
                    data: toArray($scope.formData.company_trend,'back')
                }
            ]
        };
    }

    //公司内业务员排名
    if($scope.formData.company_saler){
        $scope.company_saler_Data = {
            tooltip: {
                trigger: "axis"
            },
            legend: {
                data: ["本月贷款总额"],
                bottom: "bottom"
            },
            xAxis: {
                type: "category",
                axisLabel: {interval: 0,rotate:30},
                data: toArray($scope.formData.company_saler,'name')
            },
            yAxis: {
                type: "value",
                name: "金额(元)"
            },
            series: [
                {
                    name: "本月贷款总额",
                    type: "bar",
                    data: toArray($scope.formData.company_saler,'credit')
                },
            ]
        };
    }

    //部门内业务员排名
    if($scope.formData.depart_saler){
        $scope.depart_saler_Data = {
                tooltip: {
                    trigger: "axis"
                },
                legend: {
                    data: ["本月贷款总额"],
                    bottom: "bottom"
                },
                xAxis: {
                    type: "category",
                    axisLabel: {interval: 0,rotate:30},
                    data: toArray($scope.formData.depart_saler,'name')
                },
                yAxis: {
                    type: "value",
                    name: "金额(元)"
                },
                series: [
                    {
                        name: "本月贷款总额",
                        type: "bar",
                        data: toArray($scope.formData.depart_saler,'credit')
                    }
                ]
        };
    }

})


//ng-bind-html后台返回html数据格式的过滤器
indexApp.filter("to_trusted", ["$sce", function($sce){
    return function(text){
        return $sce.trustAsHtml(text || "");
    };
}]);

module.exports = indexApp;
