/*
* 系统管理
*/
require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var roleManagement = angular.module("roleManagement", ["validation", "validation.rule", "dyDir", "dyService"]);

//组织架构-角色管理-授权
roleManagement.controller("authManagement", function($scope, $http, postUrl){
    $scope.formData = {};
    $scope.zTreeData = zTreeData;  //权限管理渲染数据
    $scope.initial = eval("(" + $scope.zTreeData.initial + ")");  //zTree初始化数据
    // $scope.itemId = window.location.search.split("=")[1];   //页面id
    $scope.itemId = itemId;   //页面id
    var formDataStr = "";
    $scope.saveRole = function(){
        formDataStr = "";
        for(var i in $scope.formData){
        	if($scope.formData[i]){
        		formDataStr += $scope.formData[i] + ",";
        	}
        }
        $http({
            method: "post",
            url: "/org/auth/saveAuth",
            data: $.param({
                id: $scope.itemId,
                auth: formDataStr
            }),
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            }
        }).success(function(data, status, header, config){
            parent.layer.msg(data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                window.location.href = "/org/role/list";
            });
        }).error(function(data, status, header, config){
            parent.layer.msg(data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                window.location.reload();
            });
        })
    }
}).directive("zTree", function($timeout){
        return {
            require: "?ngModel",
            scope:{
                treeData: "@?"
            },
            restrict: "A",
            link: function(scope, element, attrs, ngModel){
                var setting = {
                    view: {
                        showIcon: false
                    },
                    check: {
                        enable: true,
                        chkboxType: {"Y": "p", "N": ""}
                    },
                    data: {
                        simpleData: {
                            enable: true
                        }
                    },
                    callback: {
                        onCheck: onCheck
                    }
                };
                function onCheck(e, treeId, treeNode){
                    var zTree = $.fn.zTree.getZTreeObj(treeId);
                    var nodes = zTree.getCheckedNodes(true);
                    var str = "";
                    for(var i=0, l=nodes.length; i<l; i++){
                        str += nodes[i].id + ",";
                    }
                    str = str.substring(0, str.length-1);
                    scope.$apply(function(){
                        ngModel.$setViewValue(str);
                    });
                }
                var zNodes = eval("(" + scope.treeData + ")");
                $timeout(function(){
                    $.fn.zTree.init(element, setting, zNodes);
                }, 0);
            }
        };
    });

//用户管理-添加用户
roleManagement.controller("addAdminCtrl", function($scope, $http, postUrl, getUrlParams, scopeService){
    $scope.formStruct = formStruct;  //初始数据
    $scope.departmentData = $scope.formStruct.department_list;  //部门数据

    var subUrl = $scope.formStruct.submit_url;  //获取提交地址

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.formData = {};

    //获取url的参数
    getUrlParams.events();


    //选择职位-显示
    $scope.toggleRoleBox = false;
    $scope.showRoleBox = function(){
        $scope.toggleRoleBox = !$scope.toggleRoleBox;
    }
    //选择职位-隐藏
    $scope.hideRoleBox = function(){
        $scope.toggleRoleBox = false;  //关闭下拉内容
    }

    //清空选择职位
    $scope.clearPositionBox = function(){
        $scope.formData["position"] = [];
        $scope.formData["positionNameStr"] = "";
        $scope.formData["positionNameArray"] = [];
        for(var i in $scope.departmentData){
        	$scope.departmentData[i].checked = false;
        }
    }


    //选择职位
    $scope.formData.positionNameArray = [];
    $scope.formData.positionNameStr = "";
    $scope.formData.position = [];
    $scope.getPositionName = function(i){
        var index = $scope.formData.position.indexOf(Number($scope.departmentData[i]["id"]));
        var indexs = $scope.formData.positionNameArray.indexOf($scope.departmentData[i]["dept_name"]);
        if(index > -1){
            $scope.formData.position.splice(index, 1);
            $scope.formData.positionNameArray.splice(indexs, 1);
        } else {
            $scope.formData.position.push(Number($scope.departmentData[i]["id"]));
            $scope.formData.positionNameArray.push($scope.departmentData[i]["dept_name"]);
        }
        $scope.formData.positionNameStr = $scope.formData.positionNameArray.join("、");  //生成选择的职位
    }
    
    //选择角色-默认
    $scope.formList = formStruct.form_data;
    if(!!$scope.formList["position"] && $scope.formList["position"] != "" && typeof $scope.formList["position"] != "undefined"){
        $scope.formList["position"] = $scope.formList["position"].split(",");  //字符串转换成字符串数组  "1,2,3" ==> ["1","2","3"]
        $scope.formList["position"] = $scope.formList["position"].map(function(data){
            return +data;  //["1","2","3"] ==> [1,2,3]
        });
    } else {
    	$scope.formList["position"] = [];
    }

    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }
    $scope.getCheckId = function(role, id){
        if(role && role != "" && typeof role != "undefined"){
            if(typeof role == "string"){
                role = role.split(",");  //字符串转换成字符串数组  "1,2,3" ==> ["1","2","3"]
                role = role.map(function(data){
                    return +data;  //["1","2","3"] ==> [1,2,3]
                })
            }
            if(role.indexOf(Number(id)) > -1){
                return true;
            }
        }
    }
    if(!!$scope.formData.position){
        $scope.formData["positionNameStr"] = "";
        $scope.formData["positionNameArray"] = [];
        var position = $scope.formData.position;
        for(var key in position){
            for(var keys in $scope.departmentData){
                if(position[key] == $scope.departmentData[keys]["id"]){
                    var position_name = $scope.departmentData[keys]["dept_name"];
                    $scope.formData["positionNameArray"].push(position_name);
                    $scope.formData["positionNameStr"] = $scope.formData["positionNameArray"].join("、");
                }
            }
        }
    }
    
    //添加用户
    $scope.addAdmin = function(){
        if($scope.formData["position"] instanceof Array && $scope.formData["position"].length != 0){
            $scope.formData["position"] = $scope.formData["position"].join(",");
        }
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + subUrl, $scope.formData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }

    //关闭弹窗
    $scope.closeAdmin = function(){
        parent.layer.closeAll();
    }
})


module.exports = roleManagement;