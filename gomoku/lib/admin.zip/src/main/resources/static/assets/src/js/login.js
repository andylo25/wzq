require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var loginApp = angular.module('loginApp',['validation', 'validation.rule','dyDir','dyService']);
loginApp.controller('loginCtrl',function($scope,$http,postUrl,scopeService){
	$scope.loginData = {};
    var initbtnText = "登录";
    $scope.btnText = "立即" + initbtnText;
    $scope.btnStatus = false;
	$scope.loginSub = function(){
        $scope.btnText = initbtnText + "中...";
        $scope.btnStatus = true;
        postUrl.events('/common/index/checkLogin', $scope.loginData).success(function (_data) {
            if(_data.status==200){
                scopeService.safeApply($scope, function () {
                    $scope.btnText = initbtnText;
                    $scope.btnStatus = false;
                });
                layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    window.location.href = "/";
                }); 
            }else{
                layer.msg(_data.description,{icon: 2,shade: 0.3,time:1000},function(){
                    //window.location.reload();
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
	}
	
});
module.exports = loginApp;