/*
* 二手房数据报表
*/
require("./dyDirective.js");
require("./dyService.js");
var AnalysisApp = angular.module("AnalysisApp", ["dyDir", "dyService"]);


AnalysisApp.controller("allListCtrl",function($scope, $http, postUrl){
    $scope.formStruct = formStruct;
    $scope.srcData = {};
    $scope.srcData.year = new Date().getFullYear();
    $scope.srcData.companyId = $scope.formStruct.companyId;
    $scope.srcData.companyName = $scope.formStruct.companyName;
    var submit_url = formStruct.submit_url;

    function toArray(list, col){
        var re = [];
        for(var i in list){
            re.push(list[i][col]);
        }
        return re;
    }
    
    var table1_items=null;
    if($scope.formStruct.series1){
    	table1_items=$scope.formStruct.series1;
    }else{
    	table1_items=['trans_count','back_count','overdue_wait_count','chase_count','mon_bad_count','wait_count'];
    }
    
    var table2_items=null;
    if($scope.formStruct.series2){
    	table2_items=$scope.formStruct.series2;
    }else{
    	table2_items=['trans_count','back_count','overdue_wait_count','chase_count','mon_bad_count','wait_count'];
    }
    
    var table3_items=null;
    if($scope.formStruct.series3){
    	table3_items=$scope.formStruct.series3;
    }else{
    	table3_items=['back_rate','overdue_rate','chase_rate','bad_rate'];
    }
    
    
    $scope.srcSubmit = function(){
        var srcData = $scope.srcData;
        postUrl.events("/" + submit_url, srcData).success(function(_data){
            $scope.chartData = _data.data;
            
            var table1_series=[];
            angular.forEach(table1_items, function(item,index,array){
    	    	table1_series.push({
    	                name: $scope.formStruct.legend1[index],
    	                type: "bar",
    	                //label: {normal: {show: true,}},
    	                data: toArray($scope.chartData.info,table1_items[index])
    	            });
            })
            var table2_series=[];
		    angular.forEach(table2_items, function(item,index,array){
		    	table2_series.push({
		    		name: $scope.formStruct.legend2[index],
		    		type: "bar",
		    		//label: {normal: {show: true,}},
		    		data: toArray($scope.chartData.info,table2_items[index])
		    	});
		    })
		    var table3_series=[];
    
		    angular.forEach(table3_items, function(item,index,array){
		    	table3_series.push({
		    		name: $scope.formStruct.legend3[index],
		    		type: "line",
		    		//label: {normal: {show: true,}},
		    		data: toArray($scope.chartData.info,table3_items[index])
		    	});
		    })
            
            $scope.loan_type_Data = {
                title: {
                    text: "件数情况走势图",
                    x: "center"
                },
                tooltip: {
                    trigger: "axis",
                    //formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    //orient: "vertical",
                    data: $scope.formStruct.legend1,
                    bottom: "bottom"
                },
                toolbox: {
                    feature: {
                        saveAsImage: {},
                        magicType : {show: true, type: ['line', 'bar']}
                    }
                },
                xAxis: {
                    type: "category",
                    //boundaryGap: false,
                    axisLabel: {interval: 0,rotate:30},
                    data: $scope.chartData.x_axis
                },
                yAxis: {
                    type: "value",
                    name: "件数(件)",
                }
                
            };
            $scope.loan_type_Data.series=table1_series;
            	
            $scope.loan_type_money_Data = {
                title: {
                    text: "金额情况走势图",
                    x: "center"
                },
                tooltip: {
                    trigger: "axis",
                    //formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    //orient: "vertical",
                    data: $scope.formStruct.legend2,
                    bottom: "bottom"
                },
                toolbox: {
                    feature: {
                        saveAsImage: {},
                        magicType : {show: true, type: ['line', 'bar']}
                    }
                },
                xAxis: {
                    type: "category",
                    //boundaryGap: false,
                    axisLabel: {interval: 0,rotate:30},
                    data: $scope.chartData.x_axis
                },
                yAxis: {
                    type: "value",
                    name: "金额(万元)",
                }
            };
            $scope.loan_type_money_Data.series=table2_series;
            
            $scope.loan_type_rate_Data = {
                title: {
                    text: "各比例走势图",
                    x: "center"
                },
                tooltip: {
                    trigger: "axis",
                    //formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    //orient: "vertical",
                    data: $scope.formStruct.legend3,
                    bottom: "bottom"
                },
                toolbox: {
                    feature: {
                        saveAsImage: {},
                    }
                },
                xAxis: {
                    type: "category",
                    //boundaryGap: false,
                    axisLabel: {interval: 0,rotate:30},
                    data: $scope.chartData.x_axis
                },
                yAxis: {
                    type: "value",
                    name: "占比率(%)",
                }
                
            };
            
            $scope.loan_type_rate_Data.series=table3_series;
        });
    };
    $scope.srcSubmit();

    //客户名称列表搜索
    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }
    $scope.customerList = false;
    var timer1 = null;
    $scope.getList = function(values){
        clearTimeout(timer1);
        timer1 = setTimeout(function(){
            postUrl.events("/"+$scope.formStruct.company_url, {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.customerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        $scope.searchall = _data.list;
                    } else {
                        $scope.searchall = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillCustomer = function(id, name){
        $scope.srcData.companyId = id;
        $scope.srcData.companyName = name;
        $scope.srcData.companyInputName = name;
        $scope.customerList = false;
    }
});

AnalysisApp.controller("priceLogCtrl",function($scope, $http, postUrl){
	$scope.formStruct = formStruct;
	
	$scope.srcData = {};
	$scope.srcData.month = formStruct.month;
	if(formStruct.pledgeId){
		$scope.srcData.pledgeId=formStruct.pledgeId;
		$scope.srcData.companyId=formStruct.companyId;
		$scope.srcData.companyName=formStruct.companyName;
		$scope.srcData.companyInputName=formStruct.companyInputName;
	}
	var submit_url = formStruct.submit_url;
	
	function toArray(list, col){
		var re = [];
		for(var i in list){
			re.push(list[i][col]);
		}
		return re;
	}
	
	var table1_items=null;
	if($scope.formStruct.series1){
		table1_items=$scope.formStruct.series1;
	}
	
	$scope.srcSubmit = function(){
		var srcData = $scope.srcData;
		postUrl.events("/" + submit_url, srcData).success(function(_data){
			$scope.chartData = _data.data;
			
			var table1_series=[];
			angular.forEach(table1_items, function(item,index,array){
				table1_series.push({
					name: $scope.formStruct.legend1[index],
					type: "line",
					//label: {normal: {show: true,}},
					data: toArray($scope.chartData.info,table1_items[index])
				});
			})
			
			$scope.table1 = {
				title: {
					text: "",
					x: "center"
				},
				tooltip: {
					trigger: "axis",
					//formatter: "{a} <br/>{b} : {c} ({d}%)"
				},
				legend: {
					//orient: "vertical",
					data: $scope.formStruct.legend1,
					bottom: "bottom"
				},
				toolbox: {
					feature: {
						saveAsImage: {},
						magicType : {show: true, type: ['line', 'bar']}
					}
				},
				xAxis: {
					type: "category",
					//boundaryGap: false,
					axisLabel: {interval: 0,rotate:30},
					data: $scope.chartData.x_axis
				},
				yAxis: {
					type: "value",
					name: "单位(%)",
				}
			};
			$scope.table1.series=table1_series;
			
		});
	};
	$scope.srcSubmit();
	
	//客户名称列表搜索
	$scope.isEmptyObject = function(obj){
		for (var key in obj) {
			return false;
		}
		return true;
	}
	$scope.customerList = false;
	var timer1 = null;
	$scope.getList = function(values){
		clearTimeout(timer1);
		timer1 = setTimeout(function(){
			postUrl.events("/"+$scope.formStruct.company_url, {"name": values}).success(function(_data){
				if(_data.status == 200){
					$scope.customerList = true;
					if (!$scope.isEmptyObject(_data.list)) {
						$scope.searchall = _data.list;
					} else {
						$scope.searchall = [];
					}
				}
			})
		}, 500)
	}
	$scope.fillCustomer = function(id, name){
		$scope.srcData.companyId = id;
		$scope.srcData.companyName = name;
		$scope.srcData.companyInputName = name;
		$scope.customerList = false;
	}
	
	$scope.$watch('srcData.companyId',function(newValue,oldValue){
    	if(newValue){
    		postUrl.events("/warehouse/warehousePledge/options", {'id':newValue,"receiptStatus":2}).success(function (_data) {
	            if(_data.status==200){
	                $scope.formStruct.pledges=_data.data;
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
    	}
    });
});

// 年度分析
AnalysisApp.controller("yearBussCtrl",function($scope, $http, postUrl){

    $scope.formStruct = formStruct;
    $scope.srcData = {};
    $scope.srcData.year = new Date().getFullYear();
    var submit_url = formStruct.submit_url;

    function toArray(list,col){
        var re = [];
        for(var i in list){
            re.push(list[i][col]);
        }
        return re;
    }

    $scope.srcSubmit = function(){
        var srcData = $scope.srcData;
        postUrl.events("/" + submit_url, srcData).success(function(_data){
            $scope.chartData = _data.data;
            if($scope.formStruct.legend1){
                var series_type = [];
                for(i in $scope.formStruct.legend1){
                    series_type.push({
                        name: $scope.formStruct.legend1[i],
                        type: "bar",
                        //label: {normal: {show: true,}},
                        data: toArray($scope.chartData.info,$scope.formStruct.col1[i])
                    });
                }
                $scope.loan_type_Data = {
                        title: {
                            text: $scope.formStruct.title1,
                            x: "center"
                        },
                        tooltip: {
                            trigger: "axis",
                            //formatter: "{a} <br/>{b} : {c} ({d}%)"
                        },
                        legend: {
                            //orient: "vertical",
                            data: $scope.formStruct.legend1,
                            bottom: "bottom"
                        },
                        toolbox: {
                            feature: {
                                saveAsImage: {},
                                magicType : {show: true, type: ['line', 'bar']}
                            }
                        },
                        xAxis: {
                            type: "category",
                            //boundaryGap: false,
                            axisLabel: {interval: 0,rotate:30},
                            data: $scope.chartData.x_axis
                        },
                        yAxis: {
                            type: "value",
                            name: "期数(期)",
                        },
                        series: series_type
                };
            }
            if($scope.formStruct.legend2){
                var series_type_money = [];
                for(i in $scope.formStruct.legend2){
                    series_type_money.push({
                        name: $scope.formStruct.legend2[i],
                        type: "bar",
                        //label: {normal: {show: true,}},
                        data: toArray($scope.chartData.info,$scope.formStruct.col2[i])
                    });
                }
                $scope.loan_type_money_Data = {
                        title: {
                            text: $scope.formStruct.title2,
                            x: "center"
                        },
                        tooltip: {
                            trigger: "axis",
                            //formatter: "{a} <br/>{b} : {c} ({d}%)"
                        },
                        legend: {
                            //orient: "vertical",
                            data: $scope.formStruct.legend2,
                            bottom: "bottom"
                        },
                        toolbox: {
                            feature: {
                                saveAsImage: {},
                                magicType : {show: true, type: ['line', 'bar']}
                            }
                        },
                        xAxis: {
                            type: "category",
                            //boundaryGap: false,
                            axisLabel: {interval: 0,rotate:30},
                            data: $scope.chartData.x_axis
                        },
                        yAxis: {
                            type: "value",
                            name: "金额(万元)",
                        },
                        series: series_type_money
                };
            }
            if($scope.formStruct.legend3){
                var series_type_rate = [];
                for(i in $scope.formStruct.legend3){
                    series_type_rate.push({
                        name: $scope.formStruct.legend3[i],
                        type: "line",
                        //label: {normal: {show: true,}},
                        data: toArray($scope.chartData.info,$scope.formStruct.col3[i])
                    });
                }
                $scope.loan_type_rate_Data = {
                        title: {
                            text: $scope.formStruct.title3,
                            x: "center"
                        },
                        tooltip: {
                            trigger: "axis",
                            //formatter: "{a} <br/>{b} : {c} ({d}%)"
                        },
                        legend: {
                            //orient: "vertical",
                            data: $scope.formStruct.legend3,
                            bottom: "bottom"
                        },
                        toolbox: {
                            feature: {
                                saveAsImage: {},
                            }
                        },
                        xAxis: {
                            type: "category",
                            //boundaryGap: false,
                            axisLabel: {interval: 0,rotate:30},
                            data: $scope.chartData.x_axis
                        },
                        yAxis: {
                            type: "value",
                            name: "占比率(%)",
                        },
                        series: series_type_rate
                };
            }
            if($scope.formStruct.legend5){
                var series_type_backm = [];
                for(i in $scope.formStruct.legend5){
                    series_type_backm.push({
                        name: $scope.formStruct.legend5[i],
                        type: "bar",
                        //label: {normal: {show: true,}},
                        data: toArray($scope.chartData.info,$scope.formStruct.col5[i])
                    });
                }
                $scope.loan_type_backm_Data = {
                        title: {
                            text: $scope.formStruct.title5,
                            x: "center"
                        },
                        tooltip: {
                            trigger: "axis",
                            //formatter: "{a} <br/>{b} : {c} ({d}%)"
                        },
                        legend: {
                            //orient: "vertical",
                            data: $scope.formStruct.legend5,
                            bottom: "bottom"
                        },
                        toolbox: {
                            feature: {
                                saveAsImage: {},
                                magicType : {show: true, type: ['line', 'bar']}
                            }
                        },
                        xAxis: {
                            type: "category",
                            //boundaryGap: false,
                            axisLabel: {interval: 0,rotate:30},
                            data: $scope.chartData.x_axis
                        },
                        yAxis: {
                            type: "value",
                            name: "金额(万元)",
                        },
                        series: series_type_backm
                };
            }
            if($scope.formStruct.legend4){
                var series_type_back = [];
                for(i in $scope.formStruct.legend4){
                    series_type_back.push({
                        name: $scope.formStruct.legend4[i],
                        type: "bar",
                        //label: {normal: {show: true,}},
                        data: toArray($scope.chartData.info,$scope.formStruct.col4[i])
                    });
                }
                $scope.loan_type_back_Data = {
                        title: {
                            text: $scope.formStruct.title4,
                            x: "center"
                        },
                        tooltip: {
                            trigger: "axis",
                            //formatter: "{a} <br/>{b} : {c} ({d}%)"
                        },
                        legend: {
                            //orient: "vertical",
                            data: $scope.formStruct.legend4,
                            bottom: "bottom"
                        },
                        toolbox: {
                            feature: {
                                saveAsImage: {},
                                magicType : {show: true, type: ['line', 'bar']}
                            }
                        },
                        xAxis: {
                            type: "category",
                            //boundaryGap: false,
                            axisLabel: {interval: 0,rotate:30},
                            data: $scope.chartData.x_axis
                        },
                        yAxis: {
                            type: "value",
                            name: "期数(期)",
                        },
                        series: series_type_back
                };
            }
        });
    };
    $scope.srcSubmit();
});

module.exports = AnalysisApp;