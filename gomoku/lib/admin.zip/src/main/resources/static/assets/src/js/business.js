/*
* 二手房业务
*/
require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
require("./plugins/ueditor/angular-ueditor.js");  //完整版的编辑器指令
var businessApp = angular.module("businessApp", ["validation", "validation.rule", "ng.ueditor", "dyDir", "dyService"]);


//收件侧滑-基本信息
businessApp.controller("busiInfoCtrl", function($scope, $http, $location, postUrl, getUrlParams){
    $scope.formData = {};
    $scope.formStruct = formStruct;

    //获取url的参数
    // $scope.getUrlParams = function(param){
    //     var reg = new RegExp("(^|&)"+ param +"=([^&]*)(&|$)");
    //     var r = window.location.search.substr(1).match(reg);
    //     if(r != null)return unescape(r[2]); return null;
    // }
    // $scope.params = {
    //     "pageUrl": location.pathname.slice(1),
    //     "id": $scope.getUrlParams("id"),
    //     "snode_id": $scope.getUrlParams("snode_id")
    // };
    getUrlParams.events();

    $scope.tabName = "info";
    $scope.tabChange = function(type){
        $scope.tabName = type;
    }

    //获取侧滑头部事件按钮
    for(i in $scope.formStruct.listUrl){
        if($scope.pageUrl_ == $scope.formStruct.listUrl[i].data){
            $scope.listButton = $scope.formStruct.listUrl[i].button;
            $scope.listTableButton = $scope.formStruct.listUrl[i].tableBtns;
        }
    }

    //编辑基本信息
    $scope.editInfo = function(url, title){
        parent.layer.open({
            type: 2,
            title: title ? title : "编辑",
            shadeClose: false,
            maxmin: true,
            shade: 0.3,
            area: ["750px", "650px"],
            content: url + "?id=" + $scope.formStruct.form_data.contract.id
        });
    }

    //信息变更申请弹窗
    $scope.changeInfo = function(url, title){
        parent.layer.open({
            type: 2,
            title: title,
            shadeClose: false,
            maxmin: true,
            shade: 0.3,
            area: ["750px", "650px"],
            content: "/" + url + "?id=" +  $scope.formStruct.form_data.contract.id
        });
    }

    //侧滑关闭
    $scope.hideRightDetail = function(){
        if($scope.params.slide == 3){
            $("#subSlideRight", parent.document).animate({right: "-920px"}, 500, function(){  //三级侧滑
                window.parent.document.getElementById("subRightDialog").src = "";
            });
        } else {
            $("#frameSlideRight", parent.document).animate({right: "-920px"},500);  //一级侧滑
        }
    }
    
    $scope.delAttach = function(index,recId,docId){
    	var docs = $scope.formStruct.documents;
    	docs.splice(index,1);
    	var dids = [];
    	for(var i in docs){
    		dids.push(docs[i].id);
    	}
    	postUrl.events("/credit/recheck/delattach", {recid:recId,docId:dids.join(',')}).success(function(_data){
            if(_data.status == 200){
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000});
            }
        });
    }
})

//收件侧滑-税费清单
businessApp.controller("busiTaxCtrl", function($scope, $http, $location, postUrl, getUrlParams){
    $scope.formData = {};
    $scope.formStruct = formStruct;

    //获取url的参数
    getUrlParams.events();

    //获取侧滑头部事件按钮
    for(i in $scope.formStruct.listUrl){
        if($scope.pageUrl_ == $scope.formStruct.listUrl[i].data){
            $scope.listButton = $scope.formStruct.listUrl[i].button;
        }
    }

    //编辑税费弹窗
    $scope.editTax = function(url){
        parent.layer.open({
            type: 2,
            title: "编辑税费清单",
            shadeClose: false,
            maxmin: true,
            shade: 0.3,
            area: ["750px", "650px"],
            content: "/" + url + "&id=" + $scope.params.id
        });
    }

    //侧滑关闭
    $scope.hideRightDetail = function(){
        if($scope.params.slide == 3){
            $("#subSlideRight", parent.document).animate({right: "-920px"}, 500, function(){  //三级侧滑
                window.parent.document.getElementById("subRightDialog").src = "";
            });
        } else {
            $("#frameSlideRight", parent.document).animate({right: "-920px"},500);  //一级侧滑
        }
    }
})

//收件侧滑-新建盖章件弹窗
businessApp.controller("createStampCtrl", function($scope, $http, $location, postUrl, getUrlParams, scopeService){
    $scope.formData = {};
    $scope.formStruct = formStruct;
    var subUrl = formStruct.submit_url;//获取提交地址

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    //获取url的参数
    // $scope.getUrlParams = function(param){
    //     var reg = new RegExp("(^|&)"+ param +"=([^&]*)(&|$)");
    //     var r = window.location.search.substr(1).match(reg);
    //     if(r != null)return unescape(r[2]); return null;
    // }
    getUrlParams.events();

    //改变选择的数据
    $scope.changeData = function(){
        $scope.formData.notice = [];
        angular.forEach($scope.formStruct.accountList, function(item){
            if(item.checked){
                var notice_obj = item.id + ":" + item.noRepayMoney;
                $scope.formData.notice.push(notice_obj);
            }
        })
    }
    //全选
    $scope.formData.notice = [];
    $scope.selectAll = function(){
        if($scope.formData.select_all){
            angular.forEach($scope.formStruct.accountList, function(item){
                item.checked = true;
            })
        } else {
            angular.forEach($scope.formStruct.accountList, function(item){
                item.checked = false;
            })
        }
        $scope.changeData();
    };
    $scope.selectOne = function(){
        $scope.changeData();
        if($scope.formStruct.accountList.length === $scope.formData.notice.length){
            $scope.formData.select_all = true;
        } else {
            $scope.formData.select_all = false;
        }
    }

    //保存新建盖章件
    $scope.addStamp = function(){
        $scope.formData.id = $scope.params.id;
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + subUrl, $scope.formData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
    $scope.closeStamp = function(){
        parent.layer.closeAll();
    }
})

//二级侧滑-详情
businessApp.controller("detailsCtrl", function($scope, $http, $location, postUrl, getUrlParams){
    $scope.formData = {};
    $scope.formStruct = formStruct;

    //获取url的参数
    getUrlParams.events();

    //确认收费
    $scope.comfirnCharge = function(){
        var btnStatus = true;
        parent.layer.confirm("是否确认已收费？", {
            time: 0, //不自动关闭
            icon: 3,
            shade: 0.3,
            title: "确认",
            btn: ["确定", "取消"]
        }, function(){
            if(btnStatus){
                btnStatus = false;
                postUrl.events("/buss/Finance/saveCharge", {id: $scope.params.id}).success(function(_data){
                    if(_data.status == 200){
                        parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                            // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                            top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                            window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                            parent.layer.closeAll();
                        });
                    }else{
                        layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                            //window.location.reload();
                        });
                    }
                });
            }
        });
    }

    //驳回
    $scope.rejectCharge = function(){
        parent.layer.open({
            type: 2,
            title: "驳回",
            shadeClose: false,
            maxmin: true,
            shade: 0.3,
            area: ["520px", "460px"],
            content: "/buss/Finance/addReject&id=" + $scope.params.id
        });
    }

    //侧滑关闭
    $scope.hideRightDetail = function(){
        if($scope.params.slide == 3){
            $("#subSlideRight", parent.document).animate({right: "-920px"}, 500, function(){  //三级侧滑
                window.parent.document.getElementById("subRightDialog").src = "";
            });
        } else {
            $("#frameSlideRight", parent.document).animate({right: "-920px"},500);  //一级侧滑
        }
    }
    //关闭二级侧滑
    $scope.hideSubDetail = function(){
        window.parent.document.getElementById("detailDialog").src = "";  //清空侧滑iframe内容
        window.parent.document.getElementById("detailFrameSlide").style.right = "-920px";  //隐藏侧滑
        window.parent.document.getElementById("slideMask").style.display = "none";
    }
})

//预览打印弹窗
businessApp.controller("printCtrl", function($scope, $http, $location, postUrl){
    $scope.formStruct = formStruct;
    $scope.formData = {}

    $scope.closePrint = function(type){
        if(!!type){
            var index = parent.layer.getFrameIndex(window.name);  //先得到当前iframe层的索引
            parent.layer.close(index);
        } else {
            parent.layer.closeAll();
        }
    }
    $scope.closePrintWindow = function(){
        parent.layer.closeAll();
        window.close();
    }
})

//收件侧滑-编辑质押账款合同
businessApp.controller("editAccountContractCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
    $scope.formData = {};
    $scope.formStruct = formStruct.form_struct;
    $scope.formList = formStruct.form_data;
    var subUrl = formStruct.submit_url;  //获取提交地址
    var subUrl2 = formStruct.submit_url2;  //获取保存地址
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initbtnText2 = formStruct.btnText2 ? formStruct.btnText2 : "保 存";
    $scope.btnText2 = initbtnText2;
    $scope.btnStatus2 = false;

    //改变选择的数据
    $scope.changeData = function(){
        $scope.formData.notice = [];
        angular.forEach($scope.formStruct.accountList, function(item){
            if(item.checked){
                var notice_obj = item.id + ":" + item.noRepayMoney;
                $scope.formData.notice.push(notice_obj);
            }
        })
    }
    //全选
    $scope.formData.notice = [];
    $scope.selectAll = function(){
        if($scope.formData.select_all){
            angular.forEach($scope.formStruct.accountList, function(item){
                item.checked = true;
            })
        } else {
            angular.forEach($scope.formStruct.accountList, function(item){
                item.checked = false;
            })
        }
        $scope.changeData();
        $scope.changeTotal();  //申请转让金额
    };
    $scope.selectOne = function(){
        $scope.changeData();
        $scope.changeTotal();  //申请转让金额
        if($scope.formStruct.accountList.length === $scope.formData.notice.length){
            $scope.formData.select_all = true;
        } else {
            $scope.formData.select_all = false;
        }
    }


    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }

    //客户名称列表搜索
    $scope.customerList = false;
    var timer1 = null;
    $scope.getList = function(values){
        clearTimeout(timer1);
        timer1 = setTimeout(function(){
            postUrl.events("/loan/searchcore", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.customerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.customerList = true;
                        $scope.formStruct.searchall = _data.list;
                    } else {
                        // $scope.customerList = false;
                        $scope.formStruct.searchall = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillCustomer = function(id, name){
    	$scope.formData.companyId = id;
        $scope.formData.companyName = name;
        $scope.formData.companyInputName = name;
    	$scope.customerList = false;
    }

    //买方客户名称列表搜索
    $scope.buyerCustomerList = false;
    var timer2 = null;
    $scope.getBuyerCustomerList = function(values){
        clearTimeout(timer2);
        timer2 = setTimeout(function(){
            postUrl.events("/loan/searchall", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.buyerCustomerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.buyerCustomerList = true;
                        $scope.formStruct.searchCustomer = _data.list;
                    } else {
                        // $scope.buyerCustomerList = false;
                        $scope.formStruct.searchCustomer = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillBuyerCustomer = function(id, name){
    	$scope.formData.companyCoreId = id;
    	$scope.formData.companyCoreName = name;
        $scope.formData.companyCoreInputName = name;
    	$scope.buyerCustomerList = false;
    }

    //删除合同附件
    $scope.deleteAttachment = function(index){
        $scope.formData.import_file.splice(index, 1);
    }

    //新增应收账款-到期日、最迟付款日
    function getNowFormatDate() {
        var date = new Date();
        var seperator1 = "-";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
        return currentdate;
    }
    $scope.getEndTime1 = function(number1, number2, date1){
        number1 = number1 || 0;
        number2 = number2 || 0;
        date1 = date1 || getNowFormatDate();
        var date_date1 = date1.substring(8);
        $scope.formData.billEndTime1 = $filter("date")(new Date(date1).setDate(Number(date_date1) + Number(number1)), "yyyy-MM-dd");

        $scope.getEndTime2(number2, $scope.formData.billEndTime1);
    }
    $scope.getEndTime2 = function(number2, date2){
        if(!!date2){
            if(number2 == 0){
                $scope.formData.lastPayTime1 = date2;
                return;
            }
            var date_date2 = date2.substring(8);
            $scope.formData.lastPayTime1 = $filter("date")(new Date(date2).setDate(Number(date_date2) + Number(number2)), "yyyy-MM-dd");
        }
    }


    //提交质押账款合同
    $scope.saveAccountContract = function(time){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        $scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
        postUrl.events("/" + subUrl, $scope.formData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
		        $scope.formData.import_file = angular.fromJson($scope.formData.import_file,true);
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: time || 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
    
  //保存质押账款合同
    $scope.saveContract = function(time){
        $scope.btnText2 = initbtnText2 + " 中...";
        $scope.btnStatus2 = true;
        $scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
        postUrl.events("/" + subUrl2, $scope.formData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText2 = initbtnText2;
                        $scope.btnStatus2 = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: time || 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText2 = initbtnText2;
                        $scope.btnStatus2 = false;
                    });
                });
            }
        });
    }

    
    //申请转让操作
    $scope.formData.total = 0;
    $scope.changeTotal = function(){
        $timeout(function(){
            $scope.formData.total = 0;
            angular.forEach($scope.formStruct.accountList, function(item){
                if(item.checked){
                    $scope.formData.total += Number(item.financing_money);
                }
            })
        }, 100)
    }

    //保存申请转让
    $scope.saveApplyTransfer = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + subUrl, {"count": $scope.formData.notice.length, "sumMoney": $scope.formData.total, "notice": $scope.formData.notice}).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
})

businessApp.controller("warehouseTransferCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
	    $scope.formData = {};
	    $scope.formStruct = formStruct.form_struct;
	    $scope.formList = formStruct.form_data;
	    var subUrl = formStruct.submit_url;  //获取提交地址
	    var subUrl2 = formStruct.submit_url2;  //获取保存地址
	    var initformdata = $scope.formList;
	    if(initformdata != ""){
	        for (var key in initformdata) {
	            $scope.formData[key] = initformdata[key];
	        }
	    }

	    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
	    $scope.btnText = initbtnText;
	    $scope.btnStatus = false;
	    
	    var initbtnText2 = formStruct.btnText2 ? formStruct.btnText2 : "保 存";
	    $scope.btnText2 = initbtnText2;
	    $scope.btnStatus2 = false;

	    //改变选择的数据
	    $scope.changeData = function(){
	        $scope.formData.notice = [];
	        angular.forEach($scope.formData.dataList, function(item){
	            if(item.checked){
	                var notice_obj = item.id;// + ":" + item.noRepayMoney;
	                $scope.formData.notice.push(notice_obj);
	            }
	        })
	    }
	    //全选
	    $scope.formData.notice = [];
	    $scope.selectAll = function(){
	        if($scope.formData.select_all){
	            angular.forEach($scope.formData.dataList, function(item){
	                item.checked = true;
	            })
	        } else {
	            angular.forEach($scope.formData.dataList, function(item){
	                item.checked = false;
	            })
	        }
	        $scope.changeData();
	        $scope.changeTotal();  //申请转让金额
	    };
	    $scope.selectOne = function(){
	        $scope.changeData();
	        $scope.changeTotal();  //申请转让金额
	        if($scope.formData.dataList.length === $scope.formData.notice.length){
	            $scope.formData.select_all = true;
	        } else {
	            $scope.formData.select_all = false;
	        }
	    }
	    
	    //申请转让操作
	    $scope.formData.total = 0;
	    $scope.changeTotal = function(){
	        $timeout(function(){
	            $scope.formData.total = 0;
	            angular.forEach($scope.formData.dataList, function(item){
	                if(item.checked){
                        if(typeof $scope.formData.pledgeRate == "undefined"){
                            var pledgeRate = 0;
                        } else {
                            var pledgeRate = $scope.formData.pledgeRate;
                        }
	                    $scope.formData.total += Number(item.checked_amount) * pledgeRate/100;
	                }
	            })
	        }, 100)
	    }

        //展开
	    $scope.collateralToggle = function(index){
        	if(!$scope.formData.dataList[index].collaterals){
        		postUrl.events("/warehouse/warehouseCollateral/listData", {isList:true,receiptId: $scope.formData.dataList[index].id}).success(function(_data){
		            if(_data.status == 200){
		            	$scope.formData.dataList[index].collaterals=_data.data;
		            }else{
		                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
		                });
		            }
		        });
        	}
            $scope.formData.dataList[index]["toggle"] = !$scope.formData.dataList[index]["toggle"];
        }

	    //保存申请转让
	    $scope.saveTransfer = function(){
	        $scope.btnText = initbtnText + " 中...";
	        $scope.btnStatus = true;
	        postUrl.events("/" + subUrl, {"dataJson": angular.toJson($scope.formData.notice)}).success(function(_data){
	            if(_data.status == 200){
	                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
	                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
	                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                    parent.layer.closeAll();
	                });
	            }else{
	                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                });
	            }
	        });
	    }
	})
	
	businessApp.controller("warehouseAccountCheckCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
			$scope.formData = {};
			$scope.formStruct = formStruct.form_struct;
			$scope.formList = formStruct.form_data;
			var subUrl = formStruct.submit_url;  //获取提交地址
			var subUrl2 = formStruct.submit_url2;  //获取保存地址
			var initformdata = $scope.formList;
			if(initformdata != ""){
				for (var key in initformdata) {
					$scope.formData[key] = initformdata[key];
				}
			}
			
			var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
			$scope.btnText = initbtnText;
			$scope.btnStatus = false;
			
			var initbtnText2 = formStruct.btnText2 ? formStruct.btnText2 : "保存";
			$scope.btnText2 = initbtnText2;
			$scope.btnStatus2 = false;
			
            if($scope.formData.dataList){
    			$scope.formData.amount=0;
    			angular.forEach($scope.formData.dataList, function(item){
    				$scope.formData.amount+=Number(item.check_price)*Number(item.num);
    			})
            }

            $scope.changeReason = function(){
                if($scope.formData.accountCheckResult == 1){
                    $scope.formData.noEqualReason = "";
                }
            }
			
			$scope.submit = function(){
				$scope.btnText = initbtnText + " 中...";
				$scope.btnStatus = true;
				
				postUrl.events("/" + subUrl, $scope.formData).success(function(_data){
					if(_data.status == 200){
						layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
							scopeService.safeApply($scope, function () {
								$scope.btnText = initbtnText;
								$scope.btnStatus = false;
							});
							// window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
							top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
							window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
							parent.layer.closeAll();
						});
					}else{
						layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
							scopeService.safeApply($scope, function () {
								$scope.btnText = initbtnText;
								$scope.btnStatus = false;
							});
						});
					}
				});
			}
		})
	
	businessApp.controller("warehouseChangePriceCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
		$scope.formData = {};
		$scope.formStruct = formStruct.form_struct;
		$scope.formList = formStruct.form_data;
		var subUrl = formStruct.submit_url;  //获取提交地址
		var subUrl2 = formStruct.submit_url2;  //获取保存地址
		var initformdata = $scope.formList;
		if(initformdata != ""){
			for (var key in initformdata) {
				$scope.formData[key] = initformdata[key];
			}
		}
		
		var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
		$scope.btnText = initbtnText;
		$scope.btnStatus = false;
		
		var initbtnText2 = formStruct.btnText2 ? formStruct.btnText2 : "保存";
		$scope.btnText2 = initbtnText2;
		$scope.btnStatus2 = false;
		
		$scope.formData.alert.before_amount=0;
		angular.forEach($scope.formData.dataList, function(item){
			$scope.formData.alert.before_amount+=Number(item.check_price)*Number(item.num);
		})
		$scope.formData.alert.after_amount=0;
		
		//改变选择的数据
		$scope.genJson = function(){
			$scope.formData.notice = [];
			$scope.formData.alert.after_amount=0;
			angular.forEach($scope.formData.dataList, function(item){
				var notice_obj = {"id":item.id,"before_amount":item.check_price,"receipt_id":item.receipt_id,"after_amount":item.after_price};
				$scope.formData.notice.push(notice_obj);
				if(item.after_price)
					$scope.formData.alert.after_amount+=Number(item.after_price)*Number(item.num);
			})
		}
		
		//保存申请转让
		$scope.saveTransfer = function(){
			$scope.btnText = initbtnText + " 中...";
			$scope.btnStatus = true;
			
			$scope.genJson();
			var submitData=$scope.formData.alert;
			submitData.dataJson=angular.toJson($scope.formData.notice);
			postUrl.events("/" + subUrl, submitData).success(function(_data){
				if(_data.status == 200){
					layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
						scopeService.safeApply($scope, function () {
							$scope.btnText = initbtnText;
							$scope.btnStatus = false;
						});
						// window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
						top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
						window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
						parent.layer.closeAll();
					});
				}else{
					layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
						scopeService.safeApply($scope, function () {
							$scope.btnText = initbtnText;
							$scope.btnStatus = false;
						});
					});
				}
			});
		}
	})
	
	businessApp.controller("warehouseReceiptReplaceCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
				$scope.formData = {};
				$scope.formStruct = formStruct.form_struct;
				$scope.formList = formStruct.form_data;
				var subUrl = formStruct.submit_url;  //获取提交地址
				var initformdata = $scope.formList;
				if(initformdata != ""){
					for (var key in initformdata) {
						$scope.formData[key] = initformdata[key];
					}
				}
				
				var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
				$scope.btnText = initbtnText;
				$scope.btnStatus = false;

                if(typeof $scope.formData.pledgeList == "undefined" || $scope.formData.pledgeList == ""){
                    $scope.formData.pledgeList = [];
                }
                if(typeof $scope.formData.todoList == "undefined" || $scope.formData.todoList == ""){
                    $scope.formData.todoList = [];
                }
				
			    //全选
			    $scope.selectAll1 = function(){
			        if($scope.formData.select_all1){
			            angular.forEach($scope.formData.pledgeList, function(item){
			                item.checked = true;
			            })
			        } else {
			            angular.forEach($scope.formData.pledgeList, function(item){
			                item.checked = false;
			            })
			        }
			        $scope.changeData();
			    };
			    $scope.selectOne1 = function(){
			        $scope.changeData();
			        if($scope.formData.pledgeList.length === $scope.formData.pledgeIds.length){
			            $scope.formData.select_all1 = true;
			        } else {
			            $scope.formData.select_all1 = false;
			        }
			    }
			    $scope.selectAll2 = function(){
			    	if($scope.formData.select_all2){
			    		angular.forEach($scope.formData.todoList, function(item){
			    			item.checked = true;
			    		})
			    	} else {
			    		angular.forEach($scope.formData.todoList, function(item){
			    			item.checked = false;
			    		})
			    	}
			    	$scope.changeData();
			    };
			    $scope.selectOne2 = function(){
			    	$scope.changeData();
			    	if($scope.formData.todoList.length === $scope.formData.todoIds.length){
			    		$scope.formData.select_all2 = true;
			    	} else {
			    		$scope.formData.select_all2 = false;
			    	}
			    }
			    
		        //展开
			    $scope.collateralToggle = function(index){
		        	if(!$scope.formData.dataList[index].collaterals){
		        		postUrl.events("/warehouse/warehouseCollateral/listData", {isList:true,receiptId: $scope.formData.dataList[index].id}).success(function(_data){
				            if(_data.status == 200){
				            	$scope.formData.dataList[index].collaterals=_data.data;
				            }else{
				                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
				                });
				            }
				        });
		        	}
		            $scope.formData.dataList[index]["toggle"] = !$scope.formData.dataList[index]["toggle"];
		        }
				
			    
				$scope.afterPledgeChange=function(){
					$scope.pledgeTotal=0;
				    $scope.formData.now_amount=0;
				    angular.forEach($scope.formData.pledgeList, function(item){
				    	$scope.formData.now_amount+=Number(item.checked_amount);
					})
					$scope.formData.select_all1=0;
			    }
				$scope.afterTodoChange=function(){
					$scope.todoTotal=0;
					$scope.formData.select_all2=0;
			    }
				//改变选择的数据
				$scope.changeData = function(){
					$scope.formData.todoIds = [];
					$scope.todoTotal=0;
					angular.forEach($scope.formData.todoList, function(item){
						if(item.checked){
							var notice_obj = item.id;
							$scope.formData.todoIds.push(notice_obj);
							$scope.todoTotal+=Number(item.checked_amount);
						}
					})
					$scope.formData.pledgeIds = [];
					$scope.pledgeTotal=0;
					angular.forEach($scope.formData.pledgeList, function(item){
						if(item.checked){
							var notice_obj = item.id;
							$scope.formData.pledgeIds.push(notice_obj);
							$scope.pledgeTotal+=Number(item.checked_amount);
						}
					})
				}
			    
			    $scope.isEmptyObject = function(obj){
			        for (var key in obj) {
			            return false;
			        }
			        return true;
			    }
			    
			  //客户名称列表搜索
			    $scope.customerList = false;
			    var timer1 = null;
			    $scope.getList = function(values){
			        clearTimeout(timer1);
			        timer1 = setTimeout(function(){
			            postUrl.events("/loan/searchcore", {"name": values}).success(function(_data){
			                if(_data.status == 200){
			                    $scope.customerList = true;
			                    if (!$scope.isEmptyObject(_data.list)) {
			                        // $scope.customerList = true;
			                        $scope.formStruct.searchall = _data.list;
			                    } else {
			                        // $scope.customerList = false;
			                        $scope.formStruct.searchall = [];
			                    }
			                }
			            })
			        }, 500)
			    }
			    $scope.fillCustomer = function(id, name){
			    	$scope.formData.companyId = id;
			        $scope.formData.companyName = name;
			        $scope.formData.companyInputName = name;
			    	$scope.customerList = false;
			    }
			    
			    $scope.$watch('formData.companyId',function(newValue,oldValue){
			    	if(newValue){
			    		postUrl.events("/warehouse/warehousePledge/options", {'id':newValue,"receiptStatus":2}).success(function (_data) {
				            if(_data.status==200){
				                $scope.pledges=_data.data;
				            }else{
				                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
				                });
				            }
				        })
				        $scope.getReceipts(newValue,newValue);
			    	}
			    });
			    
			    $scope.$watch('formData.pledgeId',function(newValue,oldValue){
			    	if(newValue){
			    		$scope.getReceipts(newValue);
			    	}
			    });
			    
			    //仓单
			    $scope.getReceipts=function(pledgeId,pledgeCompId){
			    	if(pledgeId){
			    		postUrl.events("/warehouse/warehousePledge/receiptList", {'pledgeId':pledgeId,"receiptStatus":2}).success(function (_data) {
				            if(_data.status==200){
				                $scope.formData.pledgeList=_data.data;
				                
				                $scope.afterPledgeChange();
				            }else{
				                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
				                });
				            }
				        })
			    	}
			    	if(pledgeCompId){
			    		postUrl.events("/warehouse/warehousePledge/receiptList", {'pledgeCompanyId':pledgeCompId}).success(function (_data) {
				            if(_data.status==200){
				                $scope.formData.todoList=_data.data;
				                
				                $scope.afterTodoChange();
				            }else{
				                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
				                });
				            }
				        })
			    	}
			    	
			    }
				
				$scope.saveTransfer = function(){
					$scope.btnText = initbtnText + " 中...";
					$scope.btnStatus = true;
					var json={"todoIds": $scope.formData.todoIds,"pledgeIds": $scope.formData.pledgeIds};
					postUrl.events("/" + subUrl, {"id":$scope.formData.pledgeId,"dataJson":angular.toJson(json,true)}).success(function(_data){
						if(_data.status == 200){
							layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
								scopeService.safeApply($scope, function () {
									$scope.btnText = initbtnText;
									$scope.btnStatus = false;
								});
								// window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
								top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
								window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
								parent.layer.closeAll();
							});
						}else{
							layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
								scopeService.safeApply($scope, function () {
									$scope.btnText = initbtnText;
									$scope.btnStatus = false;
								});
							});
						}
					});
				}
			})
			
	businessApp.controller("warehouseReceiptChargeCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
		$scope.formData = {};
		$scope.formStruct = formStruct.form_struct;
		$scope.formList = formStruct.form_data;
		var subUrl = formStruct.submit_url;  //获取提交地址
		var subUrl2 = formStruct.submit_url2;  //获取保存地址
		var initformdata = $scope.formList;
		if(initformdata != ""){
			for (var key in initformdata) {
				$scope.formData[key] = initformdata[key];
			}
		}

		var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
		$scope.btnText = initbtnText;
		$scope.btnStatus = false;

		var initbtnText2 = formStruct.btnText2 ? formStruct.btnText2 : "保存";
		$scope.btnText2 = initbtnText2;
		$scope.btnStatus2 = false;

	    //全选
	    $scope.formData.notice = [];
	    $scope.selectAll = function(){
	        if($scope.formData.select_all){
	            angular.forEach($scope.formData.dataList, function(item){
	                item.checked = true;
	            })
	        } else {
	            angular.forEach($scope.formData.dataList, function(item){
	                item.checked = false;
	            })
	        }
	        $scope.changeData();
	    };
	    $scope.selectOne = function(){
	        $scope.changeData();
	        if($scope.formData.dataList.length === $scope.formData.notice.length){
	            $scope.formData.select_all = true;
	        } else {
	            $scope.formData.select_all = false;
	        }
	    }

        //展开
	    $scope.collateralToggle = function(index){
        	if(!$scope.formData.dataList[index].collaterals){
        		postUrl.events("/warehouse/warehouseCollateral/listData", {isList:true,receiptId: $scope.formData.dataList[index].id}).success(function(_data){
		            if(_data.status == 200){
		            	$scope.formData.dataList[index].collaterals=_data.data;
		            }else{
		                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
		                });
		            }
		        });
        	}
            $scope.formData.dataList[index]["toggle"] = !$scope.formData.dataList[index]["toggle"];
        }

		function calcCharge(checkTotal){
            if(checkTotal == 0){
                $scope.formData.debit.principal = 0.00;
                $scope.formData.debit.interest = 0.00;
                $scope.formData.debit.aheadInterest = 0.00;
                $scope.formData.debit.overdueFee = 0.00;
                $scope.formData.debit.amount = 0.00;
            } else {
            	postUrl.events("/warehouse/warehouseReceipt/calcCharge", {id:$scope.formData.notice.join(),checkTotal:checkTotal,pledgeRate:$scope.formData.pledgeRate}).success(function(_data){
                    if(_data.status == 200){
                        $scope.formData.debit.principal=_data.data.principal;
                        $scope.formData.debit.interest=_data.data.interest;
                        $scope.formData.debit.aheadInterest=_data.data.aheadInterest;
                        $scope.formData.debit.overdueFee=_data.data.overdueFee;
                        $scope.formData.debit.fee=_data.data.fee;
                        $scope.formData.debit.amount=_data.data.amount;
                    }
                });
            }
		}

		//改变选择的数据
		$scope.changeData = function(){
			$scope.formData.notice = [];
			var checkTotal=0;
			angular.forEach($scope.formData.dataList, function(item){
				if(item.checked){
					var notice_obj = item.id;
					$scope.formData.notice.push(notice_obj);
					checkTotal+=Number(item.checked_amount);
				}
			})
			calcCharge(checkTotal);
		}

		$scope.saveTransfer = function(){
			$scope.btnText = initbtnText + " 中...";
			$scope.btnStatus = true;
			postUrl.events("/" + subUrl, {"dataJson": angular.toJson($scope.formData.notice),"remark":$scope.formData.remark}).success(function(_data){
				if(_data.status == 200){
					layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
						scopeService.safeApply($scope, function () {
							$scope.btnText = initbtnText;
							$scope.btnStatus = false;
						});
						// window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
						top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
						window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
						parent.layer.closeAll();
					});
				}else{
					layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
						scopeService.safeApply($scope, function () {
							$scope.btnText = initbtnText;
							$scope.btnStatus = false;
						});
					});
				}
			});
		}
	})

businessApp.controller("addEcloudCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
    $scope.formData = {};
    $scope.formStruct = formStruct.form_struct;
    $scope.formList = formStruct.form_data;
    var subUrl = formStruct.submit_url;  //获取提交地址
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;


    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }

    //删除合同附件
    $scope.deleteAttachment = function(index){
        $scope.formData.import_file.splice(index, 1);
    }

    $scope.saveEcloud = function(time){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        $scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
        postUrl.events("/" + subUrl, $scope.formData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                $scope.formData.import_file = angular.fromJson($scope.formData.import_file,true);
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: time || 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
})

businessApp.controller("editAndAddContractCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
    $scope.formData = {};
    $scope.formStruct = formStruct.form_struct;
    $scope.formList = formStruct.form_data;
    var subUrl = formStruct.submit_url;  //获取提交地址
    var subUrl2 = formStruct.submit_url2;  //获取保存地址
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    var initbtnText2 = formStruct.btnText2 ? formStruct.btnText2 : "保 存";
    $scope.btnText2 = initbtnText2;
    $scope.btnStatus2 = false;

    //改变选择的数据
    $scope.changeData = function(){
        $scope.formData.notice = [];
        angular.forEach($scope.formStruct.accountList, function(item){
            if(item.checked){
                var notice_obj = item.id + ":" + item.noRepayMoney;
                $scope.formData.notice.push(notice_obj);
            }
        })
    }
    //全选
    $scope.formData.notice = [];
    $scope.selectAll = function(){
        if($scope.formData.select_all){
            angular.forEach($scope.formStruct.accountList, function(item){
                item.checked = true;
            })
        } else {
            angular.forEach($scope.formStruct.accountList, function(item){
                item.checked = false;
            })
        }
        $scope.changeData();
        $scope.changeTotal();  //申请转让金额
    };
    $scope.selectOne = function(){
        $scope.changeData();
        $scope.changeTotal();  //申请转让金额
        if($scope.formStruct.accountList.length === $scope.formData.notice.length){
            $scope.formData.select_all = true;
        } else {
            $scope.formData.select_all = false;
        }
    }


    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }

    //客户名称列表搜索
    $scope.customerList = false;
    var timer1 = null;
    $scope.getList = function(values){
        clearTimeout(timer1);
        timer1 = setTimeout(function(){
            postUrl.events("/loan/searchcore", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.customerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.customerList = true;
                        $scope.formStruct.searchall = _data.list;
                    } else {
                        // $scope.customerList = false;
                        $scope.formStruct.searchall = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillCustomer = function(id, name){
    	$scope.formData.companyId = id;
        $scope.formData.companyName = name;
        $scope.formData.companyInputName = name;
    	$scope.customerList = false;
    }

    //买方客户名称列表搜索
    $scope.buyerCustomerList = false;
    var timer2 = null;
    $scope.getBuyerCustomerList = function(values){
        clearTimeout(timer2);
        timer2 = setTimeout(function(){
            postUrl.events("/loan/searchall", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.buyerCustomerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.buyerCustomerList = true;
                        $scope.formStruct.searchCustomer = _data.list;
                    } else {
                        // $scope.buyerCustomerList = false;
                        $scope.formStruct.searchCustomer = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillBuyerCustomer = function(id, name){
    	$scope.formData.companyCoreId = id;
    	$scope.formData.companyCoreName = name;
        $scope.formData.companyCoreInputName = name;
    	$scope.buyerCustomerList = false;
    }

    //删除合同附件
    $scope.deleteAttachment = function(index){
        $scope.formData.import_file.splice(index, 1);
    }

    //新增应收账款-到期日、最迟付款日
    function getNowFormatDate() {
        var date = new Date();
        var seperator1 = "-";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
        return currentdate;
    }
    $scope.getEndTime1 = function(number1, number2, date1){
        number1 = number1 || 0;
        number2 = number2 || 0;
        date1 = date1 || getNowFormatDate();
        var date_date1 = date1.substring(8);
        $scope.formData.billEndTime1 = $filter("date")(new Date(date1).setDate(Number(date_date1) + Number(number1)), "yyyy-MM-dd");

        $scope.getEndTime2(number2, $scope.formData.billEndTime1);
    }
    $scope.getEndTime2 = function(number2, date2){
        if(!!date2){
            if(number2 == 0){
                $scope.formData.lastPayTime1 = date2;
                return;
            }
            var date_date2 = date2.substring(8);
            $scope.formData.lastPayTime1 = $filter("date")(new Date(date2).setDate(Number(date_date2) + Number(number2)), "yyyy-MM-dd");
        }
    }


    //提交质押账款合同
    $scope.saveAccountContract = function(time){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        $scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
        postUrl.events("/" + subUrl, $scope.formData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
            	$scope.formData.import_file = angular.fromJson($scope.formData.import_file,true);
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: time || 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }

    //申请转让操作
    $scope.formData.total = 0;
    $scope.changeTotal = function(){
        $timeout(function(){
            $scope.formData.total = 0;
            angular.forEach($scope.formStruct.accountList, function(item){
                if(item.checked){
                    $scope.formData.total += Number(item.financing_money);
                }
            })
        }, 100)
    }

    //业务员选择
    $scope.departmentData = $scope.formStruct.service_type.department_list;
    $scope.userToggle = false;
    $scope.departmentName = "";
    $scope.post = true;
    $scope.toggleUserBox = function(){
        $scope.userToggle = !$scope.userToggle;
        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
            var id = $scope.formData.service_type.salesman_department;
            postUrl.events("/" + $scope.formStruct.service_type.getlist_url, {pid: id}).success(function(_data){
                if(_data.status == 200){
                    $scope.formStruct.service_type.user_list = _data.data.items;
                    $scope.post = false;
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                        //window.location.reload();
                    });
                }
            });
        }
    }
    $scope.getUserList = function(id, name){
        $scope.departmentName = name;
        $scope.userListPost(id);
    }
    $scope.getUserName = function(user){
        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
        $scope.formData.managerId = $scope.formData.service_type.salesman;
    }
    $scope.userListPost = function(id){
    	$scope.formData.service_type.salesman_department = id;
        postUrl.events("/" + $scope.formStruct.service_type.getlist_url, {pid: id}).success(function(_data){
            if(_data.status == 200){
                $scope.formStruct.service_type.user_list = _data.data.items;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    //window.location.reload();
                });
            }
        });
    }
    $scope.hideUserBox = function(){
        $scope.userToggle = false;
    }
    //保存申请转让
    $scope.saveApplyTransfer = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + subUrl, {"count": $scope.formData.notice.length, "sumMoney": $scope.formData.total, "notice": $scope.formData.notice}).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
})

//移交
businessApp.controller("transferUserCtrl", function($scope, $http, $location, postUrl, scopeService){
    $scope.formData = {};
    $scope.formStruct = formStruct.form_struct;
    $scope.formList = formStruct.form_data;
    var subUrl = formStruct.submit_url;  //获取提交地址
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }

    //保存质押账款合同
    $scope.saveAccountContract = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + subUrl, {"salesman_department": $scope.formData.service_type.salesman_department, "salesman": $scope.formData.service_type.salesman}).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }


    //申请转让操作
    $scope.formData.total = 0;
    $scope.changeTotal = function(){
        $scope.formData.total = 0;
        angular.forEach($scope.formStruct.accountList, function(item){
            if(item.checked){
                $scope.formData.total += Number(item.noRepayMoney);
            }
        })
    }
    //业务员选择
    $scope.departmentData = $scope.formStruct.service_type.department_list;
    $scope.userToggle = false;
    $scope.departmentName = "";
    $scope.post = true;
    $scope.toggleUserBox = function(){
        $scope.userToggle = !$scope.userToggle;
        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
            var id = $scope.formData.service_type.salesman_department;
            postUrl.events("/" + $scope.formStruct.service_type.getlist_url, {pid: id}).success(function(_data){
                if(_data.status == 200){
                    $scope.formStruct.service_type.user_list = _data.data.items;
                    $scope.post = false;
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                        //window.location.reload();
                    });
                }
            });
        }
    }
    $scope.getUserList = function(id, name){
        $scope.formData.service_type.salesman_department = id;
        $scope.departmentName = name;
        $scope.userListPost(id);
    }
    $scope.getUserName = function(user){
        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
    }
    $scope.userListPost = function(id){
        $scope.formData.service_type.salesman = "";
        $scope.formData.service_type.user_name = "";
        postUrl.events("/" + $scope.formStruct.service_type.getlist_url, {pid: id}).success(function(_data){
            if(_data.status == 200){
                $scope.formStruct.service_type.user_list = _data.data.items;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    //window.location.reload();
                });
            }
        });
    }
    $scope.hideUserBox = function(){
        $scope.userToggle = false;
    }
    //保存申请转让
    $scope.saveApplyTransfer = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + subUrl, {"count": $scope.formData.notice.length, "sumMoney": $scope.formData.total, "notice": $scope.formData.notice}).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
})
//订阅发布模式，接收方在这里订阅消息，发布方在这里发布消息
businessApp.factory("EventBus", function() {
    var eventMap = {};

    var EventBus = {
        on : function(eventType, handler) {
            //multiple event listener
            if (!eventMap[eventType]) {
                eventMap[eventType] = [];
            }
            eventMap[eventType].push(handler);
        },

        off : function(eventType, handler) {
            for (var i = 0; i < eventMap[eventType].length; i++) {
                if (eventMap[eventType][i] === handler) {
                    eventMap[eventType].splice(i, 1);
                    break;
                }
            }
        },

        fire : function(event) {
            var eventType = event.type;
            if (eventMap && eventMap[eventType]) {
                for (var i = 0; i < eventMap[eventType].length; i++) {
                    eventMap[eventType][i](event);
                }
            }
        }
    };
    return EventBus;
});
businessApp.controller("saveBillCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout, EventBus){

    $scope.formData = {};
    $scope.formStruct = formStruct.form_struct;
    $scope.formList = formStruct.form_data;
    $scope.productInfo = formStruct.form_data.product;
    $scope.formData.payBillTypes = [];
    $scope.formData.payBillTypes[0] = 1;
    $scope.formData.total = 0;
    $scope.formData.validTotal = 0;
    $scope.formData.notice = [];
    $scope.billList = formStruct.form_data.billList ? formStruct.form_data.billList : [];
    
    var subUrl = formStruct.submit_url;
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

    var initbtnText0 = "保 存";
    var initbtnText1 = "提 交";
    $scope.btnText0 = initbtnText0;
    $scope.btnText1 = initbtnText1;
    $scope.btnStatus = false;

    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }

    // 客户名称列表搜索
    $scope.customerList = false;
    var timer1 = null;
    $scope.getList = function(values){
        clearTimeout(timer1);
        timer1 = setTimeout(function(){
            postUrl.events("/loan/searchcore", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.customerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.customerList = true;
                        $scope.formStruct.searchall = _data.list;
                    } else {
                        // $scope.customerList = false;
                        $scope.formStruct.searchall = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillCustomer = function(id, name){
        $scope.formData.companyId = id;
        $scope.formData.companyName = name;
        $scope.formData.companyInputName = name;
        $scope.customerList = false;
    }

    // 买方客户名称列表搜索
    $scope.buyerCustomerList = false;
    var timer2 = null;
    $scope.getBuyerCustomerList = function(values){
        clearTimeout(timer2);
        timer2 = setTimeout(function(){
            postUrl.events("/loan/searchall", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.buyerCustomerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.buyerCustomerList = true;
                        $scope.formStruct.searchCustomer = _data.list;
                    } else {
                        // $scope.buyerCustomerList = false;
                        $scope.formStruct.searchCustomer = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillBuyerCustomer = function(id, name){
        $scope.formData.companyCoreId = id;
        $scope.formData.companyCoreName = name;
        $scope.formData.companyCoreInputName = name;
        $scope.buyerCustomerList = false;
    }

    // 新增应收账款-到期日、最迟付款日
    function getNowFormatDate() {
        var date = new Date();
        var seperator1 = "-";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
        return currentdate;
    }
    $scope.getEndTime1 = function(number1, number2, date1){
        number1 = number1 || 0;
        number2 = number2 || 0;
        date1 = date1 || getNowFormatDate();
        var date_date1 = date1.substring(8);
        $scope.formData.billEndTime1 = $filter("date")(new Date(date1).setDate(Number(date_date1) + Number(number1)), "yyyy-MM-dd");

        $scope.getEndTime2(number2, $scope.formData.billEndTime1);
    }
    $scope.getEndTime2 = function(number2, date2){
        if(!!date2){
            if(number2 == 0){
                $scope.formData.lastPayTime1 = date2;
                return;
            }
            var date_date2 = date2.substring(8);
            $scope.formData.lastPayTime1 = $filter("date")(new Date(date2).setDate(Number(date_date2) + Number(number2)), "yyyy-MM-dd");
        }
    }

    // 提交融资
    $scope.saveBill = function(type){
    	if (type == 0) {
    		$scope.btnText0 = initbtnText0 + " 中...";
    	} else {
    		$scope.btnText1 = initbtnText1 + " 中...";
    	}
        $scope.btnStatus = true;
        
        $scope.formData.billJson = "";
        angular.forEach($scope.billList, function(item){
        	$scope.formData.billJson = $scope.formData.billJson + item.id + ",";
        });
        $scope.formData.billJson = $scope.formData.billJson.substring(0, $scope.formData.billJson.length - 1); 
        
        if ($scope.formData.payBillTypes) {
        	$scope.formData.payBillType = $scope.formData.payBillTypes[0];
        } else {
        	$scope.formData.payBillType = null;
        }
        
      //校验逾期罚息
        var first,second;
        for(var i=0;i<$scope.formData.overdueRateValues.length-1;i++){
        	first=$scope.formData.overdueRateValues[i];
        	second=$scope.formData.overdueRateValues[i+1];
        	if(first.end!=second.start){
        		parent.layer.msg("逾期罚息逾期日不连续",{icon: 2,shade: 0.3,time:1500},function(){
        			scopeService.safeApply($scope, function () {
                        $scope.btnText1 = initbtnText1;
                        $scope.btnStatus = false;
                    });
                });
        		return;
        	}
        }
        if($scope.formData.overdueRateValues&&$scope.formData.overdueRateValues.length>0){
        	second=$scope.formData.overdueRateValues[$scope.formData.overdueRateValues.length-1];
        	if(second&&second.end){
        		parent.layer.msg("逾期罚息最后一行截止日需为空",{icon: 2,shade: 0.3,time:1500},function(){
        			scopeService.safeApply($scope, function () {
                        $scope.btnText1 = initbtnText1;
                        $scope.btnStatus = false;
                    });
                });
        		return;
        	}
        }
        //其他费用
        $scope.formData.prodFeeId="";
		for(var i=0;i<$scope.formData.fees.length;i++){
			$scope.formData.prodFeeId+=$scope.formData.fees[i].value+(i==$scope.formData.fees.length-1?"":",");
		}
		//逾期
		$scope.formData.overdueRateValue = angular.toJson($scope.formData.overdueRateValues, false);
		
        postUrl.events("/" + subUrl + type, $scope.formData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    top.frames["rightcontent"].reloadings();  // 调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText0 = initbtnText0;
                        $scope.btnText1 = initbtnText1;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }

    // 选择产品
    $scope.getProduct = function(){
        postUrl.events("/loan/credit/getProduct", {productId:$scope.formData.productId}).success(function(_data){
            if(_data.status == 200){
                $scope.productInfo = _data.data;
                $scope.formData.loanApr = $scope.productInfo.loan_apr_start;
                $scope.formStruct.repayType = $scope.productInfo.repay;
                
                if(!$scope.formData.debitId)
                	$scope.formData.fees = $scope.productInfo.fees;
                if(!$scope.formData.debitId)
                	$scope.formData.overdueRateValues = angular.fromJson($scope.productInfo.overdue_rate_value);
            }
        });
    }
    
    // 改变选择的数据
    $scope.changeData = function(){
        $scope.formData.notice = [];
        angular.forEach($scope.billList, function(item){
            var notice_obj = item.id;
            $scope.formData.notice.push(notice_obj);
        })
    }
    $scope.changeTotal = function(){
    	$scope.formData.total = "0.00";
    	$scope.formData.validTotal = "0.00";
        angular.forEach($scope.billList, function(item){
        	$scope.formData.validTotal = ($scope.formData.validTotal * 1 + item.validMoney * 1).toFixed(2);
        })
        
    	var financeRate = !isNaN($scope.formData.financeRate) ? $scope.formData.financeRate : 0;
	    $scope.formData.total = ($scope.formData.validTotal*financeRate/100).toFixed(2);
    }
    
    if ($scope.billList) {
    	$scope.changeData();
        $scope.changeTotal();
    }
    
    EventBus.on("selectBillCtrl", function(evt){
        if(evt.list){
            $scope.billList = evt.list;
        } else if(evt.item){
            $scope.billList.push(evt.item);
        }
        
        $scope.changeData();
        $scope.changeTotal();
    });
    
    // 业务员选择
    $scope.departmentData = $scope.formStruct.service_type.department_list;
    $scope.userToggle = false;
    $scope.departmentName = "";
    $scope.post = true;
    $scope.toggleUserBox = function(){
        $scope.userToggle = !$scope.userToggle;
        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
            var id = $scope.formData.service_type.salesman_department;
            postUrl.events("/" + $scope.formStruct.service_type.getlist_url, {pid: id}).success(function(_data){
                if(_data.status == 200){
                    $scope.formStruct.service_type.user_list = _data.data.items;
                    $scope.post = false;
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                        // window.location.reload();
                    });
                }
            });
        }
    }
    $scope.getUserList = function(id, name){
        $scope.departmentName = name;
        $scope.userListPost(id);
    }
    $scope.getUserName = function(user){
        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
        $scope.formData.managerId = $scope.formData.service_type.salesman;
    }
    $scope.userListPost = function(id){
        $scope.formData.service_type.salesman_department = id;
        postUrl.events("/" + $scope.formStruct.service_type.getlist_url, {pid: id}).success(function(_data){
            if(_data.status == 200){
                $scope.formStruct.service_type.user_list = _data.data.items;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                });
            }
        });
    }
    $scope.hideUserBox = function(){
        $scope.userToggle = false;
    }
    
    // 添加
    $scope.selectBill = function(){
		if(!$scope.formData.productId){
			layer.msg("请先选择产品", {icon: 2, shade: 0.3, time: 1500});
			return;
		}
		
		if(!$scope.formData.companyId){
			layer.msg("请先选择授信客户", {icon: 2, shade: 0.3, time: 1500});
			return;
		}
		
		if(!$scope.formData.companyCoreId){
			layer.msg("请先选择买方客户", {icon: 2, shade: 0.3, time: 1500});
			return;
		}
		
		if(!$scope.formData.financeRate){
			layer.msg("请先输入融资比例", {icon: 2, shade: 0.3, time: 1500});
			return;
		}
		
		var index = layer.load();
		var param = {
					companyId: $scope.formData.companyId,
                    loanId: $scope.formData.loanId,
					coreCompanyId:$scope.formData.companyCoreId,
					financeRate:$scope.formData.financeRate,
					notices:$scope.formData.notice,
					creditorNo:""
					}
        postUrl.events("/loan/credit/getBills", param).success(function(_data){
        	if(_data.status == 200){
        		$timeout(function() {
		            layer.close(index);
		            EventBus.fire({type: "saveBillCtrl", showBill: true, params : param, bills : _data.data});
		        }, 1000);
        	} else {
	            layer.close(index);
        		layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
        	}
        })
    }
    
    // 删除
    $scope.removeBill = function(index){
        postUrl.events("/loan/credit/removeBill", $scope.billList[index]).success(function(_data){
            if(_data.status == 200){
                $scope.billList.splice(index, 1);
                $scope.changeData();
                $scope.changeTotal();
            } else {
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
            }
        })
    }
    
    $scope.newBill = function(){
		
		if(!$scope.formData.companyId){
			layer.msg("请先选择授信客户", {icon: 2, shade: 0.3, time: 1500});
			return;
		}
		
		if(!$scope.formData.companyCoreId){
			layer.msg("请先选择买方客户", {icon: 2, shade: 0.3, time: 1500});
			return;
		}
		
		if(!$scope.formData.financeRate){
			layer.msg("请先输入融资比例", {icon: 2, shade: 0.3, time: 1500});
			return;
		}
		
		var index = layer.load();
		var param = {
					companyId: $scope.formData.companyId,
					companyCoreId:$scope.formData.companyCoreId,
					financeRate:$scope.formData.financeRate,
					paymentTerm:$scope.formData.paymentTerm,
					gracePeriod:$scope.formData.gracePeriod,
					companyCoreName:$scope.formData.companyCoreName,
					editFlag : 1
					}
        postUrl.events("/loan/credit/newBill", param).success(function(_data){
        	if(_data.status == 200){
        		$timeout(function() {
		            layer.close(index);
		            EventBus.fire({type: "newBillCtrl", params:param,showNew: true, initData : _data.data});
		        }, 1000);
        	} else {
	            layer.close(index);
        		layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
        	}
        })
    }
});

// 选择应收账款
businessApp.controller("selectBillCtrl", function($scope, $http, $timeout, postUrl, scopeService, EventBus){
	$scope.formStruct = formStruct;
	$scope.billData = {};
	$scope.billData.showBill = false; // 默认隐藏
	EventBus.on("saveBillCtrl", function(evt){
		$scope.addBtn = "添 加";
        $scope.billData.showBill = evt.showBill; // 显示应收账单
        $scope.billData.params = evt.params;  // 查询参数
        $scope.billData.bills = evt.bills;  // 账单列表
        $scope.checkAll = false;
        $scope.checkvalue = [];
        if (evt.params.notices) {
        	
        	angular.forEach($scope.billData.bills, function(i){
        		angular.forEach(evt.params.notices, function(j){
        			if (i.id == j) {
        				$scope.checkvalue.push(i.id);
        				i.checked = true;
        			}
        		})
	        })

	        if($scope.billData.bills.length === $scope.checkvalue.length){
	            $scope.checkAll = true;
	        } else {
	            $scope.checkAll = false;
	        }
        }
    });

    $scope.searchByCreditorNo = function(){
    	// TODO 绑定 creditorNo
    	$scope.checkvalue = [];
    	$scope.checkAll = false;
		postUrl.events("/loan/credit/getBills", $scope.billData.params).success(function(_data){
        	if(_data.status == 200){
        		$scope.billData.bills = _data.data;
        	} else {
        		layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
        	}
        })
    }

	// 全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.billData.bills, function(i){
                i.checked = true;
                $scope.checkvalue.push(i.id);
            })
        } else {
            angular.forEach($scope.billData.bills, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.billData.bills, function(i){
            var index = $scope.checkvalue.indexOf(i.id);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i.id);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.billData.bills.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

	$scope.closePopup = function(){
		$scope.billData.showBill = false;
	}

	$scope.tableArray = [];
	$scope.addBillInfo = function(){
		$scope.addBtn = "添加中...";
		$scope.tableArray = [];
		angular.forEach($scope.billData.bills, function(i){
            if(i.checked){
                $scope.tableArray.push(i);
            };
        })
        if($scope.checkvalue.length == 0){
        	$scope.addBtn = "添 加";
        	layer.msg("请至少选择一项应收账款", {icon: 2, shade: 0.3, time: 1500});
        } else {
        	$timeout(function() {
	            EventBus.fire({type: "selectBillCtrl", list: $scope.tableArray});
	            $scope.billData.showBill = false;
	        }, 1000);
        }
	}
});

// 添加应收账款
businessApp.controller("newBillCtrl", function($scope, $http, $filter, $timeout, postUrl, scopeService, EventBus){
	$scope.formStruct = formStruct;
	$scope.formData = $scope.formStruct.form_struct.form_data;
	$scope.billData = {};
	$scope.billData.showNew = false; // 默认隐藏
	$scope.addBtn = "提 交";
	EventBus.on("newBillCtrl", function(evt){
		$scope.addBtn = "添 加";
        $scope.billData.showNew = evt.showNew; // 显示应收账单
        $scope.formStruct.form_struct = evt.initData;
        $scope.formData = evt.params;
    });

	$scope.closePopup = function(){
		$scope.billData.showNew = false;
	}

    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }
    
	// 客户名称列表搜索
    $scope.customerList = false;
    var timer1 = null;
    $scope.getList = function(values){
        clearTimeout(timer1);
        timer1 = setTimeout(function(){
            postUrl.events("/loan/searchcore", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.customerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        $scope.formStruct.searchall = _data.list;
                    } else {
                        $scope.formStruct.searchall = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillCustomer = function(id, name){
        $scope.formData.companyId = id;
        $scope.formData.companyName = name;
        $scope.formData.companyInputName = name;
        $scope.customerList = false;
    }

    // 买方客户名称列表搜索
    $scope.buyerCustomerList = false;
    var timer2 = null;
    $scope.getBuyerCustomerList = function(values){
        clearTimeout(timer2);
        timer2 = setTimeout(function(){
            postUrl.events("/loan/searchall", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.buyerCustomerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.buyerCustomerList = true;
                        $scope.formStruct.searchCustomer = _data.list;
                    } else {
                        // $scope.buyerCustomerList = false;
                        $scope.formStruct.searchCustomer = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillBuyerCustomer = function(id, name){
        $scope.formData.companyCoreId = id;
        $scope.formData.companyCoreName = name;
        $scope.formData.companyCoreInputName = name;
        $scope.buyerCustomerList = false;
    }
    
    // 删除合同附件
    $scope.deleteAttachment = function(index){
        $scope.formData.import_file_temp2.splice(index, 1);
    }


    //新增应收账款-到期日、最迟付款日
    function getNowFormatDate() {
        var date = new Date();
        var seperator1 = "-";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
        return currentdate;
    }
    $scope.getEndTime1 = function(number1, number2, date1){
        number1 = number1 || 0;
        number2 = number2 || 0;
        date1 = date1 || getNowFormatDate();
        var date_date1 = date1.substring(8);
        $scope.formData.billEndTime1 = $filter("date")(new Date(date1).setDate(Number(date_date1) + Number(number1)), "yyyy-MM-dd");

        $scope.getEndTime2(number2, $scope.formData.billEndTime1);
    }
    $scope.getEndTime2 = function(number2, date2){
        number2 = number2 || 0;
        if(!!date2){
            if(number2 == 0){
                $scope.formData.lastPayTime1 = date2;
                return;
            }
            var date_date2 = date2.substring(8);
            $scope.formData.lastPayTime1 = $filter("date")(new Date(date2).setDate(Number(date_date2) + Number(number2)), "yyyy-MM-dd");
        }
    }
    
	$scope.addBillInfo = function(){
        if($scope.formData.import_file_temp2 != undefined){
            $scope.formData.import_file2 = $scope.formData.import_file_temp2.join(",");
        }
		if ($scope.formData.editFlag != 1) {
			postUrl.events("/loan/credit/saveNewBill", $scope.formData).success(function(_data){
	            if(_data.status == 200){
	                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 2000}, function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                    top.frames["rightcontent"].reloadings();  // 调用table页面的自定义函数刷新当前页面
	                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
	                    parent.layer.closeAll();
	                });
	            }else{
	                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 2000}, function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                });
	            }
	        });
		} else {
			$scope.addBtn = "添加中...";
			postUrl.events("/loan/credit/saveNewBill", $scope.formData).success(function(_data){
				if(_data.status == 200){
					
					$timeout(function() {
						EventBus.fire({type: "selectBillCtrl", item: _data.data});
						$scope.billData.showNew = false;
					}, 1000);
				}else{
					$scope.addBtn = "添 加";
					layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
				}
			});
		}
	}
});

//核心企业回款
businessApp.controller("repayBillContractCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
	
	$scope.formData = {};
	$scope.formStruct = formStruct.form_struct;
	$scope.formData = {};
	$scope.bill = $scope.formStruct.bills[0];
	var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
	$scope.getBill = function(index){
		for (i in $scope.formStruct.bills) {
			var curBill = $scope.formStruct.bills[i];
			if (curBill.id == $scope.formData.billId) {
				$scope.bill = curBill;
			}
		}
    }
	
	//提交回款
    $scope.doRepay = function(time){
        $scope.btnStatus= true;
        $scope.btnText = initbtnText + " 中...";
        postUrl.events("/loan/credit/saveCoreRepay", $scope.formData).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: time || 2000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
});

businessApp.controller("signContractCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
    $scope.formData = formStruct.form_data;
    var subUrl = formStruct.submit_url;  //获取提交地址

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.deleteAttachment = function(index){
        $scope.formData.data[index].file = {};
    }
    $scope.isEmptyObject = function(obj){
        for (var keys in obj) {
            return false;
        }
        return true;
    }

    $scope.saveSignContract = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        var tmp = "";
        for(var key in $scope.formData.data){
            // var import_file = $scope.formData.data[key].import_file;
            // if(!$scope.isEmptyObject(import_file)) {
                tmp += $scope.formData.data[key].id + ":" + $scope.formData.data[key].import_file + ":" + $scope.formData.data[key].file.time + "," ;
            // }
        }
        tmp = tmp.substring(0, tmp.length-1);
        postUrl.events("/" + subUrl, {params:tmp}).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
})
//侧滑头部-预览附件弹窗
businessApp.controller("showEnclosureCtrl", function($scope){
    $scope.formStruct = formStruct;
})

//ng-bind-html后台返回html数据格式的过滤器
businessApp.filter("to_trusted", ["$sce", function($sce){
    return function(text){
        return $sce.trustAsHtml(text || "");
    };
}]);

module.exports = businessApp;