require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
require("./plugins/ueditor/angular-ueditor.js");  //完整版的编辑器指令
//判断某个值是否存在数组中，增加了Array的自身属性
Array.prototype.S=String.fromCharCode(2);
Array.prototype.in_array=function(e){
    var r=new RegExp(this.S+e+this.S);
    return (r.test(this.S+this.join(this.S)+this.S));
};
var formApp = angular.module("formApp",["validation", "validation.rule","ng.ueditor","dyDir","dyService"]);
//添加数据
formApp.controller("addCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = formStruct.form_data || {};
    var data = {};
    $scope.formStruct = formStruct;
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initbtnText1 = formStruct.btnText1 || "保存";
    $scope.btnText1 = initbtnText1;
    $scope.btnStatus1 = false;
    
    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
        if($scope.formlist[i].type == 'select'){
        	(function(j){
	        	$scope.$watch("formData." + $scope.formlist[j].name, function () {
	        		$scope.selectChange($scope.formlist[j]);
	        	})
        	})(i)
        }
    }
    
    // 转换option的value值类型
    for(var i=0,len=$scope.formlist.length;i<len;i++){
    	if($scope.formlist[i].options && $scope.formlist[i].options[0] && formStruct.form_data){
    		var fv = formStruct.form_data[$scope.formlist[i].name];
    		if(angular.isArray(fv) && $scope.formlist[i].type == 'checkbox'){
    			fv = fv[0];
    		}
    		var opv = $scope.formlist[i].options[0].value;
    		if(angular.isNumber(fv) && angular.isString(opv)){
    			// string => number
    			for(var j=0,lenj=$scope.formlist[i].options.length;j<lenj;j++){
    				$scope.formlist[i].options[j].value = Number($scope.formlist[i].options[j].value);
    			}
    		}else if(angular.isString(fv) && angular.isNumber(opv)){
    			// number => string
    			for(var j=0,lenj=$scope.formlist[i].options.length;j<lenj;j++){
    				$scope.formlist[i].options[j].value = String($scope.formlist[i].options[j].value);
    			}
    		}
    	}
    }
    
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    
    $scope.submitForm = function(type){
    	var submit_url = formStruct.submit_url;
    	if(type){
    		// 保存
    		$scope.btnText1 = initbtnText1 + " 中...";
    		submit_url = formStruct.submit_url1;
    	}else{
    		$scope.btnText = initbtnText + " 中...";
    	}
    	$scope.btnStatus = true;
    	$scope.btnStatus1 = true;
//        $scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
    	var subFormData = {};
    	if($scope.formStruct.beforeSubmit){
    		var result=$scope.formStruct.beforeSubmit();
    		if(!result){
    			scopeService.safeApply($scope, function () {
                	$scope.btnText = initbtnText;
                    $scope.btnText1 = initbtnText1;
                    $scope.btnStatus = false;
                    $scope.btnStatus1 = false;
                });
    			return;
    		}
    	}
        for(var att in $scope.formData){
        	if(angular.isArray($scope.formData[att])){
        		if(typeof $scope.formData[att][0] == "object"){
        			subFormData[att] = angular.toJson($scope.formData[att],true);
        		}else {
        			subFormData[att] = $scope.formData[att].join(",");
        		}
        	}else {
        		subFormData[att] = $scope.formData[att];
        	}
        }
        postUrl.events("/"+submit_url, subFormData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnText1 = initbtnText1;
                        $scope.btnStatus = false;
                        $scope.btnStatus1 = false;
                    });
                    if(top.frames["rightcontent"].reloadings){
                    	top.frames["rightcontent"].reloadings();
                    }else{
                    	window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    }
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                    	$scope.btnText = initbtnText;
                        $scope.btnText1 = initbtnText1;
                        $scope.btnStatus = false;
                        $scope.btnStatus1 = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
    $scope.selectChange = function(col){
        // 联动加载
        for(var n=0;n<$scope.formlist.length;n++){
            var fl = $scope.formlist[n];
            if(fl.dataparams && fl.dataparams.startsWith('&')){
                $scope.getLinkSelect(col,fl);
            }
            if(fl.dataparams && fl.dataparams.startsWith('=')){
                var dap = fl.dataparams.substring(1).split('.');
                if(dap[0] == col.name){
                    for(var i=0;i<col.options.length;i++){
                        if(col.options[i].value == $scope.formData[col.name]){
                            $scope.formData[fl.name] = col.options[i][dap[1]];
                            break;
                        }
                    }
                }
            }
        }
    }
    
    $scope.getLinkSelect = function(col,fl){
    	var adap = fl.dataparams.substring(1).split('.');
		if(adap[0] == col.name){
			if($scope.formData[col.name]){
				var subData_ = {};
				subData_['id'] = $scope.formData[col.name];
				postUrl.events("/"+fl.url, subData_).success(function (_data) {
					if(_data.status==200){
						if(fl.type == 'select'){
							fl.options = _data.data;
						}else{
							$scope.formData[fl.name] = _data.data[adap[1]];
						}
					}
				})
			}else{
				if(fl.type == 'select'){
					fl.options = [];
				}else{
					$scope.formData[fl.name] = "";
				}
			}
		}
    }
    
    $scope.parseVal = function(expre){
		return $scope.$eval(expre);
	}
    
});

//编辑数据
formApp.controller("editCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    $scope.formStruct = formStruct;
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initbtnText1 = formStruct.btnText1 || "保存";
    $scope.btnText1 = initbtnText1;

    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
        if($scope.formlist[i].type == 'select'){
        	(function(j){
	        	$scope.$watch("formData." + $scope.formlist[j].name, function () {
	        		$scope.selectChange($scope.formlist[j]);
	        	})
        	})(i)
        }
    }
    
    // 转换option的value值类型
    for(var i=0,len=$scope.formlist.length;i<len;i++){
    	if($scope.formlist[i].options && $scope.formlist[i].options[0] && formStruct.form_data){
    		var fv = formStruct.form_data[$scope.formlist[i].name];
    		if(angular.isArray(fv) && $scope.formlist[i].type == 'checkbox'){
    			fv = fv[0];
    		}
    		var opv = $scope.formlist[i].options[0].value;
    		if(angular.isNumber(fv) && angular.isString(opv)){
    			// string => number
    			for(var j=0,lenj=$scope.formlist[i].options.length;j<lenj;j++){
    				$scope.formlist[i].options[j].value = Number($scope.formlist[i].options[j].value);
    			}
    		}else if(angular.isString(fv) && angular.isNumber(opv)){
    			// number => string
    			for(var j=0,lenj=$scope.formlist[i].options.length;j<lenj;j++){
    				$scope.formlist[i].options[j].value = String($scope.formlist[i].options[j].value);
    			}
    		}
    	}
    }
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
  //删除合同附件
    $scope.deleteAttachment = function(index){
        $scope.formData.import_file.splice(index, 1);
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    
    $scope.submitForm = function(type){
        var submit_url = formStruct.submit_url;
    	if(type){
    		// 保存
    		$scope.btnText1 = initbtnText1 + " 中...";
    		submit_url = formStruct.submit_url1;
    	}else{
    		$scope.btnText = initbtnText + " 中...";
    	}
        $scope.btnStatus = true;
//        $scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
        var subFormData = {};
        for(var att in $scope.formData){
        	if(angular.isArray($scope.formData[att])){
        		if(typeof $scope.formData[att][0] == "object"){
        			subFormData[att] = angular.toJson($scope.formData[att],true);
        		}else{
        			subFormData[att] = $scope.formData[att].join(",");
        		}
        	}else {
        		subFormData[att] = $scope.formData[att];
        	}
        }
        postUrl.events("/"+formStruct.submit_url, subFormData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnText1 = initbtnText1;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnText1 = initbtnText1;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    $scope.selectChange = function(col){
        // 联动加载
        for(var n=0;n<$scope.formlist.length;n++){
            var fl = $scope.formlist[n];
            if(fl.dataparams && fl.dataparams.startsWith('&')){
                $scope.getLinkSelect(col,fl);
            }
            if(fl.dataparams && fl.dataparams.startsWith('=')){
                var dap = fl.dataparams.substring(1).split('.');
                if(dap[0] == col.name && col.options){
                    for(var i=0;i<col.options.length;i++){
                        if(col.options[i].value == $scope.formData[col.name]){
                            $scope.formData[fl.name] = col.options[i][dap[1]];
                            break;
                        }
                    }
                }
            }
        }
    }
    
    $scope.getLinkSelect = function(col,fl){
    	var adap = fl.dataparams.substring(1).split('.');
		if(adap[0] == col.name){
			if($scope.formData[col.name]){
				var subData_ = {};
				subData_['id'] = $scope.formData[col.name];
				postUrl.events("/"+fl.url, subData_).success(function (_data) {
					if(_data.status==200){
						if(fl.type == 'select'){
							fl.options = _data.data;
                            if($scope.formData[fl.name]){
                                $scope.selectChange(fl);
                            }
						}else{
							$scope.formData[fl.name] = _data.data[adap[1]];
						}
					}
				})
			}else{
				if(fl.type == 'select'){
					fl.options = [];
				}else{
					$scope.formData[fl.name] = "";
				}
			}
		}
    }
    
    $scope.parseVal = function(expre){
		return $scope.$eval(expre);
	}
    
    //银行-抵押查询-银行类型管理-添加-上传显示文件名称
    $scope.showUploadName = function(template){
        switch(template){
            case "single_template":
                if($scope.formData.single_template){
                    var index = $scope.formData.single_template.lastIndexOf("\/");
                    $scope.formData.single_name = $scope.formData.single_template.substring(index + 1, $scope.formData.single_template.length);
                }
                break;
            case "multi_template":
                if($scope.formData.multi_template){
                    var index = $scope.formData.multi_template.lastIndexOf("\/");
                    $scope.formData.multi_name = $scope.formData.multi_template.substring(index + 1, $scope.formData.multi_template.length);
                }
                break;
            case "template_statement":
                if($scope.formData.template_statement){
                    var index = $scope.formData.template_statement.lastIndexOf("\/");
                    $scope.formData.statement_name = $scope.formData.template_statement.substring(index + 1, $scope.formData.template_statement.length);
                }
                break;
            case "template_loan":
                if($scope.formData.template_loan){
                    var index = $scope.formData.template_loan.lastIndexOf("\/");
                    $scope.formData.loan_name = $scope.formData.template_loan.substring(index + 1, $scope.formData.template_loan.length);
                }
                break;
            case "template_relieve":
                if($scope.formData.template_relieve){
                    var index = $scope.formData.template_relieve.lastIndexOf("\/");
                    $scope.formData.relieve_name = $scope.formData.template_relieve.substring(index + 1, $scope.formData.template_relieve.length);
                }
                break;
            case "import_file":
            	if($scope.formData.import_file && ((typeof $scope.formData.import_file) =="string") ){
                    var index = $scope.formData.import_file.lastIndexOf("\/");
                    $scope.formData.import_name = $scope.formData.import_file.substring(index + 1, $scope.formData.import_file.length);
                }
                break;
        }
    	
    }
    $scope.showUploadName("single_template");
    $scope.showUploadName("multi_template");
    $scope.showUploadName("template_statement");
    $scope.showUploadName("template_loan");
    $scope.showUploadName("template_relieve");
    $scope.showUploadName("import_file");

    //银行-抵押查询-银行类型管理-删除上传的文件(只清除数据库的数据，文件还存在服务器)
    $scope.deleteUploadFile = function(template){
        switch(template){
            case "single_template":
                $scope.formData.single_template = "";
                $scope.formData.single_name = "";
                break;
            case "multi_template":
                $scope.formData.multi_template = "";
                $scope.formData.multi_name = "";
                break;
            case "template_statement":
                $scope.formData.template_statement = "";
                $scope.formData.statement_name = "";
                break;
            case "template_loan":
                $scope.formData.template_loan = "";
                $scope.formData.loan_name = "";
                break;
            case "template_relieve":
                $scope.formData.template_relieve = "";
                $scope.formData.relieve_name = "";
                break;
            case "import_file":
                $scope.formData.import_file="";
                $scope.formData.import_name = "";
                break;
        }
    }
});

formApp.controller("redeemGoodsCtrl",function($scope, $http, postUrl, scopeService){
	$scope.formData = formStruct.form_data || {};
    var data = {};
    $scope.formStruct = formStruct;
    
    $scope.formData.total_money = 0;
    $scope.formData.amountAll = $scope.formData.overdueFee+$scope.formData.interest+$scope.formData.fee;

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    $scope.calTotalMoney = function(list){
    	if(list.num-list.take_num < list.redeem_num){
    		list.redeem_num = list.num-list.take_num;
    	}
    	if($scope.formStruct.purList){
    		$scope.formData.total_money = 0;
    		for(var i=0;i<$scope.formStruct.purList.length;i++){
                if($scope.formStruct.purList[i].redeem_num){
                    $scope.formData.total_money += ($scope.formStruct.purList[i].redeem_num)*($scope.formStruct.purList[i].price);
                }
    		}
            $scope.formData.total_money = $scope.formData.total_money*(100-$scope.formData.depositRatio)/100
    	}
    	$scope.formData.amountAll = $scope.formData.total_money+$scope.formData.overdueFee+$scope.formData.interest+$scope.formData.fee;
    	
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        var submData = {}
        angular.copy($scope.formData,submData)
        var takeGoodsDetail = [];
        var ids = "";
        for(var i=0;i<$scope.formStruct.purList.length;i++){
        	var purlist = $scope.formStruct.purList[i];
        	if(purlist.redeem_num){
        		takeGoodsDetail.push({purchaseId:purlist.id,takeNum:purlist.redeem_num});
        		ids += ","+purlist.id;
        	}
        }
        if(ids.length <= 0){
        	$scope.btnText = initbtnText;
            $scope.btnStatus = false;
            return;
        }
        submData.takeGoodsDetail = angular.toJson(takeGoodsDetail,true);
        submData.ids = ids.substring(1);
        postUrl.events("/"+formStruct.submit_url, submData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
})

//货物管理-发起赎货
formApp.controller("redemptionCtrl", function($scope, $http, postUrl, $timeout, scopeService, EventBus){
    $scope.formStruct = formStruct;
    $scope.formData = {};

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.formData.goodsList = [];
    $scope.formData.repayList = [];
    $scope.formData.takeAmount = 0;

    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }

    $scope.customerList = false;
    var timer1 = null;
    $scope.getList = function(values){
        clearTimeout(timer1);
        timer1 = setTimeout(function(){
            postUrl.events("/loan/searchcore", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.customerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        $scope.formStruct.searchall = _data.list;
                    } else {
                        $scope.formStruct.searchall = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillCustomer = function(id, name){
        $scope.formData.companyId = id;
        $scope.formData.companyName = name;
        $scope.formData.companyInputName = name;
        $scope.customerList = false;

        $scope.$watch("formData.companyId", function(newValue, oldValue){
            if(newValue != oldValue){
                $scope.formData.goodsList = [];
                $scope.formData.repayList = [];
                $scope.formData.takeAmount = 0;
            }
        })
    }

    $scope.selectGoods = function(){
        if(!$scope.formData.companyId){
            layer.msg("请先选择授信企业", {icon: 2, shade: 0.3, time: 1500});
        } else {
            var index = layer.load();
            postUrl.events("/" + formStruct.selectSpa_url, {"companyId": $scope.formData.companyId}).success(function(_data){
                if(_data.status == 200){
                    $timeout(function() {
                        layer.close(index);
                        //传递控制显示隐藏原有业务信息到copyInfoCtrl
                        EventBus.fire({
                            type: "redemptionCtrl",
                            showGoods: true,
                            business: _data.data,
                            goodsList: $scope.formData.goodsList,
                            repayList: $scope.formData.repayList,
                            businessModel: "",
                            emptyList: [],
                            boolean: false
                        });
                        $scope.overflowClass = true;
                    }, 1000);
                } else {
                    layer.close(index);
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            })
        }
    }

    $scope.deleteGoods = function(index){
        $scope.formData.takeAmount = 0;

        for(var key in $scope.formData.repayList){
            if($scope.formData.repayList[key]["businessText"] == $scope.formData.goodsList[index]["businessText"]){
                var total = Number($scope.formData.goodsList[index]["takeNum"]) * Number($scope.formData.goodsList[index]["price"]);
                $scope.formData.repayList[key]["takeAmount"] = $scope.formData.repayList[key]["takeAmount"] - total * Number(100-$scope.formData.repayList[key]["deposit_ratio"]) / 100;
                $scope.formData.repayList[key]["total"] = $scope.formData.repayList[key]["total"] - total * Number(100-$scope.formData.repayList[key]["deposit_ratio"]) / 100;
            }
            if(Number($scope.formData.repayList[key]["takeAmount"]).toFixed(2) == 0.00){
                $scope.formData.repayList.splice(key, 1);
            }
        }

        for(var keys=0; keys<$scope.formData.repayList.length; keys++){
            $scope.formData.takeAmount += Number($scope.formData.repayList[keys]["total"]);
        }

        $scope.formData.goodsList.splice(index, 1);

    }

    EventBus.on("selectGoodsCtrl", function(evt){
        if(evt.goods){
            $scope.formData.goodsList = evt.goods;
        }
        if(evt.repayment){
            $scope.formData.repayList = evt.repayment;
            $scope.formData.takeAmount = 0;
            for(var keys=0; keys<$scope.formData.repayList.length; keys++){
                $scope.formData.takeAmount += Number($scope.formData.repayList[keys]["total"]);
            }
        }
        $scope.overflowClass = evt.overflowClass;
    });

    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;

        $scope.formData.goodsListJson = angular.toJson($scope.formData.goodsList, false);
        $scope.formData.repayListJson = angular.toJson($scope.formData.repayList, false);

        postUrl.events("/" + formStruct.submit_url, {
            "takeNo": $scope.formStruct.takeGoods.takeNo,
            "takeAmount": $scope.formData.takeAmount,
            "companyId": $scope.formData.companyId,
            "remark": $scope.formData.remarks,
            "takeGoodsDetail": $scope.formData.goodsListJson,
            "goodsRepay": $scope.formData.repayListJson
        }).success(function(_data){
            if(_data.status == 200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    top.frames["rightcontent"].reloadings();
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
})
formApp.controller("selectGoodsCtrl", function($scope, $http, postUrl, $timeout, scopeService, EventBus){
    $scope.formStruct = formStruct;
    $scope.goodsData = {};

    $scope.goodsData.showGoods = false;  //隐藏选择货物

    EventBus.on("redemptionCtrl", function(evt){
        $scope.goodsData.showGoods = evt.showGoods;  //传递选择货物显示隐藏的状态
        $scope.formStruct.business = evt.business;  //传递选择业务编号
        $scope.goodsList = evt.goodsList;
        $scope.repayList = evt.repayList;
        $scope.goodsData.business = evt.businessModel;
        $scope.goodsData.goodsList = evt.emptyList;
        $scope.checkAll = evt.boolean;
    });

    $scope.changeGoodsList = function(){
        $scope.checkvalue = [];
        $scope.checkAll = false;
        if($scope.goodsData.business){
            postUrl.events("/" + formStruct.select_url, {"id": $scope.goodsData.business}).success(function(_data){
                if(_data.status == 200){
                    $scope.goodsData.goodsList = _data.data;
                    for(var index in $scope.goodsData.goodsList){
                        $scope.goodsData.goodsList[index]["takeNum"] = 1;
                        $scope.goodsData.goodsList[index]["purchaseId"] = _data.data[index].id;
                        $scope.goodsData.goodsList[index]["pledgeId"] = $scope.goodsData.business;
                    }
                    for(var key in $scope.formStruct.business){
                        if($scope.goodsData.business == $scope.formStruct.business[key]["id"]){
                            $scope.goodsData.businessText = $scope.formStruct.business[key]["pledge_no"]
                        }
                    }
                } else {
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            })
        }
    }

    //全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.goodsData.goodsList, function(i){
                i.checked = true;
                $scope.checkvalue.push(i.id);
            })
        } else {
            angular.forEach($scope.goodsData.goodsList, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.goodsData.goodsList, function(i){
            var index = $scope.checkvalue.indexOf(i.id);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i.id);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.goodsData.goodsList.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

    
    $scope.addGoodsInfo = function(){
        $scope.principal = 0;
        if($scope.checkvalue.length == 0){
            layer.msg("请至少选择一项货物", {icon: 2, shade: 0.3, time: 1500});
        } else {
            postUrl.events("/" + formStruct.calcFee_url, {"id": $scope.goodsData.business}).success(function(_data){
                if(_data.status == 200){
                    angular.forEach($scope.goodsData.goodsList, function(i){
                        if(i.checked){
                            i.businessText = $scope.goodsData.businessText;
                            var takeNum = i.takeNum ? i.takeNum : 0;
                            var price = i.price ? i.price : 0;
                            $scope.principal += Number(takeNum) * Number(price);
                            if($scope.goodsList.length > 0){
                                var result = $scope.goodsList.every(function(item, index, array){
                                    return (item.id != i.id);
                                })
                                if(result){
                                    $scope.goodsList.push(i);
                                } else {
                                    var k;
                                    for(var j in $scope.goodsList){
                                        if($scope.goodsList[j]["id"] == i.id){
                                            k = j;
                                        }
                                    }
                                    $scope.principal = $scope.principal - Number($scope.goodsList[k]["takeNum"]) * Number($scope.goodsList[k]["price"]);
                                    $scope.goodsList.splice(k, 1);
                                    $scope.goodsList.push(i);
                                }
                            } else {
                                $scope.goodsList.push(i);
                            }
                        };
                    })

                    _data.data.businessText = $scope.goodsData.businessText;
                    _data.data.takeAmount = $scope.principal * Number(100-_data.data.deposit_ratio) / 100;
                    _data.data.total = _data.data.takeAmount + Number(_data.data.fee) + Number(_data.data.interest) + Number(_data.data.overdouFee);
                    _data.data.pledgeId = $scope.goodsData.business;

                    if($scope.repayList.length > 0){
                        var repay = $scope.repayList.every(function(item, index, array){
                            return (item.businessText != $scope.goodsData.businessText);
                        })
                        if(repay){
                            $scope.repayList.push(_data.data);
                        } else {
                            var indexs;
                            for(var keys in $scope.repayList){
                                if($scope.repayList[keys]["businessText"] == $scope.goodsData.businessText){
                                    indexs = keys;

                                    _data.data.takeAmount = $scope.repayList[keys]["takeAmount"] + _data.data.takeAmount;
                                    _data.data.total = _data.data.takeAmount + Number(_data.data.fee) + Number(_data.data.interest) + Number(_data.data.overdouFee);
                                }
                            }
                            $scope.repayList.splice(indexs, 1);
                            $scope.repayList.push(_data.data);
                        }
                    } else {
                        $scope.repayList.push(_data.data);
                    }

                    $timeout(function() {
                        EventBus.fire({type: "selectGoodsCtrl", goods: $scope.goodsList, repayment: $scope.repayList, overflowClass: false});
                        $scope.goodsData.showGoods = false;
                    }, 500);
                } else {
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            })
        }
    }

    $scope.closePopup = function(){
        EventBus.fire({type: "selectGoodsCtrl", overflowClass: false});
        $scope.goodsData.showGoods = false;
    }


})

formApp.controller("loanDepositCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
    function changeDebitList(){
    	if(!$scope.formData.companyId){
    		$scope.formData.debit_list=null;
    		return;
    	}
    	if(!$scope.formData.productId){
    		$scope.formData.debit_list=null;
    		return;
    	}
    	if($scope.formData.companyId&&$scope.formData.productId){
    		postUrl.events("/loan/credit/listData/options", {'companyId':$scope.formData.companyId,"productId":$scope.formData.productId}).success(function (_data) {
	            if(_data.status==200){
	                $scope.formData.debit_list=_data.data;
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
    	}
    }
    
    //下拉联动
    $scope.$watch('formData.companyId',function(newValue,oldValue){
    	changeDebitList();
    	if(newValue){
    		postUrl.events("/loan/credit/depositDetail", {'companyId':newValue}).success(function (_data) {
	            if(_data.status==200){
	                $scope.formData.balance=_data.data.accBalance;
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
    	}
    });
    $scope.$watch('formData.productId',function(newValue,oldValue){
    	changeDebitList();
    });
    $scope.$watch('formData.debitId',function(newValue,oldValue){
    	if(newValue){
    		postUrl.events("/loan/credit/debitDetail", {'debitId':newValue}).success(function (_data) {
	            if(_data.status==200){
	                $scope.formData.debit=_data.data;
	                $scope.formData.noPay=_data.data.noPay;
	                $scope.formData.amount=_data.data.loanAmount;
	                $scope.formData.deposit=_data.data.deposit;
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
    	}
    });
    
});

formApp.controller("workflowApproveCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
        var item = $scope.formlist[k];
        if(item.type == 'hidden' && !$scope.formData[item.name]){
            $scope.formData[item.name] = item.value;
        }
    }
    
    //删除合同附件
    $scope.deleteAttachment = function(index){
        $scope.formData.import_file.splice(index, 1);
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        //if($scope.formData.import_file){
        //	$scope.formData.docId=$scope.formData.import_file.did;
        //}
        if ($scope.formData.docId && $scope.formData.docId.length) {
            $scope.formData.docId = $scope.formData.docId.join(",");
        }
        
        $scope.postFormData=function(){
        	postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
	            if(_data.status==200){
	                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                    if(!!formStruct.refresh){
	                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
	                    } else if(!!formStruct.refresh_sub){
	                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
	                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
	                    } else {
	                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
	                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
	                    }
	                    parent.layer.closeAll();
	                });
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                });
	            }
	        })
        }
        
        //黑名单
        if($scope.formData.companyId){
        	postUrl.events("/system/company/detail", {'id':$scope.formData.companyId}).success(function (_data) {
	            if(_data.status==200){
	            	$scope.formData.blacklistType=_data.data.blacklist_type;
	            	if($scope.formData.blacklistType==0){
	            		parent.layer.msg('客户属于禁止类黑名单客户，不允许继续操作！',{icon: 2,shade: 0.3,time:1500},function(){
	            			scopeService.safeApply($scope, function () {
	    	                    $scope.btnText = initbtnText;
	    	                    $scope.btnStatus = false;
	    	                });
	            		});
	            	}else if($scope.formData.blacklistType==1){
	            		parent.layer.confirm("客户属于预警类客户，请确认是否继续？", {
                            time: 0, //不自动关闭
                            icon: 3,
                            shade: 0.3,
                            title: '预警提醒',
                            btn: ["确定", "取消"]
                        }, function(index){
                            if($scope.btnStatus){
                                $scope.postFormData();
                            } else {
                                return;
                            }
                        },function(){
                        	scopeService.safeApply($scope, function () {
        	                    $scope.btnText = initbtnText;
        	                    $scope.btnStatus = false;
        	                });
                        });
	            	}else{
	            		$scope.postFormData();
	            	}
        		}else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                	scopeService.safeApply($scope, function () {
    	                    $scope.btnText = initbtnText;
    	                    $scope.btnStatus = false;
    	                });
	                });
        		}
        	})
        }else{
        	$scope.postFormData();
        }
        
        
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
});

formApp.controller("warehouseRepayCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
        var item = $scope.formlist[k];
        if(item.type == 'hidden' && !$scope.formData[item.name]){
            $scope.formData[item.name] = item.value;
        }
    }
    $scope.$watch('formData.repayAmount',function(newValue,oldValue){
    	if(newValue){
            $scope.formData.allAmount=Number($scope.formData.repayAmount?$scope.formData.repayAmount:0)+Number($scope.formData.interest)+Number($scope.formData.overdue_fee)+Number($scope.formData.fee);
    	}
    });
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
});


formApp.controller("warehouseCollateralCategoryCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
        var item = $scope.formlist[k];
        if(item.type == 'hidden' && !$scope.formData[item.name]){
            $scope.formData[item.name] = item.value;
        }
    }
    $scope.list=formStruct.list;
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    $scope.$watch('formData.pid',function(newValue,oldValue){
    	if(newValue){
    		$scope.hideAlertRate=true;
    	}else{
    		$scope.hideAlertRate=false;
    	}
    });
    
});

formApp.controller("warehouseCollateralCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.list=formStruct.list;

    $scope.changeTotal = function() {
        if($scope.formData.num == undefined || $scope.product == undefined) {
            $scope.formData.sum = 0;
        }else{
            $scope.formData.sum = $scope.product.last_price * $scope.formData.num;
        }
    }

    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
    //下拉联动
    $scope.$watch('formData.category2',function(newValue,oldValue){
    	postUrl.events("/warehouse/warehouseProduct/option", {'category2':newValue}).success(function (_data) {
            if(_data.status==200){
                $scope.product_list=_data.data;
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                });
            }
        })
    });
    $scope.$watch('formData.warehouseProductId',function(newValue,oldValue){
        if(newValue){
	        postUrl.events("/warehouse/warehouseProduct/detail", {'id':newValue}).success(function (_data) {
	            if(_data.status==200){
	                $scope.product=_data.data;
	                if($scope.product) {
                        $scope.formData.goodName = $scope.product.product_name;
                        $scope.formData.unit = $scope.product.unit;
                        $scope.formData.lastPrice = $scope.product.last_price;
                        $scope.formData.priceDate = $scope.product.price_date;
                        if($scope.formData.num == undefined || $scope.product.last_price == undefined){
                            $scope.formData.sum = 0;
                        }else{
                            $scope.formData.sum = $scope.product.last_price * $scope.formData.num;
                        }
                    }
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
        }
    });
    
    
});

formApp.controller("warehouseCollateralPriceLogCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
        var item = $scope.formlist[k];
        if(item.type == 'hidden' && !$scope.formData[item.name]){
            $scope.formData[item.name] = item.value;
        }
    }
    $scope.list=formStruct.list;
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
  //下拉联动
    $scope.$watch('formData.category2',function(newValue,oldValue){
        postUrl.events("/warehouse/warehouseProduct/option", {'category2':newValue}).success(function (_data) {
            if(_data.status==200){
                $scope.product_list=_data.data;
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                });
            }
        })
    });
    $scope.$watch('formData.warehouseProductId',function(newValue,oldValue){
        postUrl.events("/warehouse/warehouseProduct/detail", {'id':newValue,"noPrice":true}).success(function (_data) {
            if(_data.status==200){
                $scope.product=_data.data;
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                });
            }
        })
    });
});

formApp.controller("warehouseAccountCheckAddCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
        var item = $scope.formlist[k];
        if(item.type == 'hidden' && !$scope.formData[item.name]){
            $scope.formData[item.name] = item.value;
        }
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
    postUrl.events("/system/company/options", {'company_role_type':4}).success(function (_data) {
        if(_data.status==200){
            $scope.company_list=_data.data;
        }else{
            parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
            });
        }
    })
    
    //下拉联动
    $scope.$watch('formData.companyId',function(newValue,oldValue){
        postUrl.events("/warehouse/warehousePledge/options", {'id':newValue,"receiptStatus":2}).success(function (_data) {
            if(_data.status==200){
                $scope.pledge_list=_data.data;
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                });
            }
        })
    });
});

function setDebit($scope){
	
    $scope.selectAll = function(){
        if($scope.formStruct.edit){
        	$scope.formData.select_all=true;
        	if(!$scope.formData.firstSelect){
        		$scope.formData.firstSelect=true;
        	}else{
        		return;
        	}
        }
        if($scope.formData.select_all){
            angular.forEach($scope.receiptList, function(item){
                item.checked = true;
            })
        } else {
            angular.forEach($scope.receiptList, function(item){
                item.checked = false;
            })
        }
        $scope.changeData();
        $scope.changeTotal();  //申请转让金额
    };
    
    
    $scope.selectOne = function(){
    	if($scope.formStruct.edit){
    		$scope.formData.select_all=true;
        	if(!$scope.formData.firstSelect){
        		$scope.formData.firstSelect=true;
        	}else{
        		return;
        	}
        }
        $scope.changeData();
        $scope.changeTotal();  //申请转让金额
        if($scope.receiptList.length === $scope.formData.notice.length){
            $scope.formData.select_all = true;
        } else {
            $scope.formData.select_all = false;
        }
    }

    $scope.isEmptyObject = function(obj){
        for (var key in obj) {
            return false;
        }
        return true;
    }

    //客户名称列表搜索
    $scope.customerList = false;
    var timer1 = null;
    $scope.getList = function(values){
        clearTimeout(timer1);
        timer1 = setTimeout(function(){
            postUrl.events("/loan/searchcore", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.customerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.customerList = true;
                        $scope.formStruct.searchall = _data.list;
                    } else {
                        // $scope.customerList = false;
                        $scope.formStruct.searchall = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillCustomer = function(id, name){
    	$scope.formData.companyId = id;
        $scope.formData.companyName = name;
        $scope.formData.companyInputName = name;
    	$scope.customerList = false;
    }

    //买方客户名称列表搜索
    $scope.buyerCustomerList = false;
    var timer2 = null;
    $scope.getBuyerCustomerList = function(values){
        clearTimeout(timer2);
        timer2 = setTimeout(function(){
            postUrl.events("/loan/searchall", {"name": values}).success(function(_data){
                if(_data.status == 200){
                    $scope.buyerCustomerList = true;
                    if (!$scope.isEmptyObject(_data.list)) {
                        // $scope.buyerCustomerList = true;
                        $scope.formStruct.searchCustomer = _data.list;
                    } else {
                        // $scope.buyerCustomerList = false;
                        $scope.formStruct.searchCustomer = [];
                    }
                }
            })
        }, 500)
    }
    $scope.fillBuyerCustomer = function(id, name){
    	$scope.formData.companyCoreId = id;
    	$scope.formData.companyCoreName = name;
        $scope.formData.companyCoreInputName = name;
    	$scope.buyerCustomerList = false;
    }

    //删除合同附件
    $scope.deleteAttachment = function(index){
        $scope.formData.import_file.splice(index, 1);
    }

    //新增应收账款-到期日、最迟付款日
    function getNowFormatDate() {
        var date = new Date();
        var seperator1 = "-";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
        return currentdate;
    }
    $scope.getEndTime1 = function(number1, number2, date1){
        number1 = number1 || 0;
        number2 = number2 || 0;
        date1 = date1 || getNowFormatDate();
        var date_date1 = date1.substring(8);
        $scope.formData.billEndTime1 = $filter("date")(new Date(date1).setDate(Number(date_date1) + Number(number1)), "yyyy-MM-dd");

        $scope.getEndTime2(number2, $scope.formData.billEndTime1);
    }
    $scope.getEndTime2 = function(number2, date2){
        if(!!date2){
            if(number2 == 0){
                $scope.formData.lastPayTime1 = date2;
                return;
            }
            var date_date2 = date2.substring(8);
            $scope.formData.lastPayTime1 = $filter("date")(new Date(date2).setDate(Number(date_date2) + Number(number2)), "yyyy-MM-dd");
        }
    }
}

//订阅发布模式，接收方在这里订阅消息，发布方在这里发布消息
formApp.factory("EventBus", function() {
    var eventMap = {};

    var EventBus = {
        on : function(eventType, handler) {
            //multiple event listener
            if (!eventMap[eventType]) {
                eventMap[eventType] = [];
            }
            eventMap[eventType].push(handler);
        },

        off : function(eventType, handler) {
            for (var i = 0; i < eventMap[eventType].length; i++) {
                if (eventMap[eventType][i] === handler) {
                    eventMap[eventType].splice(i, 1);
                    break;
                }
            }
        },

        fire : function(event) {
            var eventType = event.type;
            if (eventMap && eventMap[eventType]) {
                for (var i = 0; i < eventMap[eventType].length; i++) {
                    eventMap[eventType][i](event);
                }
            }
        }
    };
    return EventBus;
});

//添加出质仓单
formApp.controller("selectQualityCtrl", function($scope, $http, $timeout, postUrl, scopeService, EventBus){
	$scope.formStruct = formStruct;
	$scope.qualityData = {};

	$scope.qualityData.showQuality = false;  //隐藏选择仓单

	EventBus.on("warehousePledgeCtrl", function(evt){
        $scope.qualityData.showQuality = evt.showQuality;  //传递选择仓单显示隐藏的状态
        $scope.formStruct.warehouse = evt.warehouse;  //传递选择仓单的仓库
        $scope.formStruct.pledgeCompId = evt.pledgeCompId;  //出质人
        $scope.tableArray = evt.tableArray;
    });

    //选择仓库
    $scope.changeWarehouse = function(){
    	$scope.checkvalue = [];
    	$scope.checkAll = false;
    	if($scope.qualityData.warehouse){
    		postUrl.events("/warehouse/warehouseReceipt/options", {receiptStatus:0,companyId:$scope.formStruct.pledgeCompId,depotId: $scope.qualityData.warehouse}).success(function(_data){
	        	if(_data.status == 200){
	        		$scope.formStruct.receipts = _data.data;
	        	} else {
	        		layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
	        	}
	        })
    	}
    	
    }

    //展开押品
    $scope.collateralToggle = function(index){
    	if(!$scope.formStruct.receipts[index].collaterals){
    		postUrl.events("/warehouse/warehouseCollateral/listData", {isList:true,receiptId:$scope.formStruct.receipts[index].id}).success(function(_data){
		            if(_data.status == 200){
		            	$scope.formStruct.receipts[index].collaterals=_data.data;
		            }else{
		                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
		                });
		            }
		     });
    	}
    	$scope.formStruct.receipts[index].toggle = !$scope.formStruct.receipts[index].toggle;
    }


	//全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.formStruct.receipts, function(i){
                i.checked = true;
                $scope.checkvalue.push(i.id);
            })
        } else {
            angular.forEach($scope.formStruct.receipts, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.formStruct.receipts, function(i){
            var index = $scope.checkvalue.indexOf(i.id);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i.id);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.formStruct.receipts.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

	$scope.closePopup = function(){
		$scope.qualityData.showQuality = false;
	}

	$scope.addQualityInfo = function(){
        $scope.collaterals = [];
        var collaterals = true;
		angular.forEach($scope.formStruct.receipts, function(i){
            if(i.checked){
                if(i.have == "false"){
                    collaterals = false;
                }
                if(collaterals){
                    if($scope.tableArray.length > 0){
                        var result = $scope.tableArray.every(function(item, index, array){
                            return (item.id != i.id);
                        })
                        if(result){
                            $scope.tableArray.push(i);
                        }
                    } else {
                        $scope.tableArray.push(i);
                    }
                }
            };
        })
        if($scope.checkvalue.length == 0){
        	layer.msg("请至少选择一项仓单", {icon: 2, shade: 0.3, time: 1500});
        }else if(!collaterals){
            layer.msg("没有押品的仓单无法添加", {icon: 2, shade: 0.3, time: 2000});
        } else {
        	$timeout(function() {
	            EventBus.fire({type: "selectQualityCtrl", list: $scope.tableArray});
	            $scope.qualityData.showQuality = false;
	        }, 1000);
        }
	}
})


formApp.controller("warehousePledgeCtrl",function($scope, $http, postUrl, scopeService, $timeout,EventBus){
    $scope.formData = {};
    $scope.formlist = formStruct.form_struct;
    $scope.formStruct = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.receiptList = $scope.formStruct.receiptList ? $scope.formStruct.receiptList : [];
    $scope.formData.pledgeRate = 0;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    //添加
    $scope.selectQuality = function(){
		if(!$scope.formData.superviseCompId || !$scope.formData.pledgeCompId){
			layer.msg("请先选择监管公司和出质人", {icon: 2, shade: 0.3, time: 1500});
		} else {
			var index = layer.load();
	        postUrl.events("/warehouse/warehouseDepot/option", {'companyId': $scope.formData.superviseCompId}).success(function(_data){
	        	if(_data.status == 200){
	        		$timeout(function() {
			            layer.close(index);
			            //传递控制显示隐藏原有业务信息到copyInfoCtrl
			            EventBus.fire({
                            type: "warehousePledgeCtrl",
                            showQuality: true,
                            warehouse: _data.data,
                            pledgeCompId: $scope.formData.pledgeCompId,
                            tableArray: $scope.receiptList
                        });
			        }, 1000);
	        	} else {
		            layer.close(index);
	        		layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
	        	}
	        })
		}
    }


     //展开押品
    $scope.collateralToggle = function(index){
        $scope.receiptList[index].toggle = !$scope.receiptList[index].toggle;
        if(!$scope.receiptList[index].collaterals){
    		postUrl.events("/warehouse/warehouseCollateral/listData", {isList:true,receiptId:$scope.receiptList[index].id}).success(function(_data){
		            if(_data.status == 200){
		            	$scope.receiptList[index].collaterals=_data.data;
		            }else{
		                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
		                });
		            }
		     });
    	}
    }

    //删除仓单
    $scope.deleteReceipt = function(index){
        $scope.receiptList.splice(index, 1);
        $scope.formData.total = 0;
        angular.forEach($scope.receiptList, function(item){
              var itemAmount=Number(item.checked_amount)*Number($scope.formData.pledgeRate)/100;
              $scope.formData.total =(Number($scope.formData.total)+itemAmount).toFixed(2);
        })
    }
    
    //改变选择的数据
    $scope.changeData = function(){
        $scope.formData.notice = [];
        angular.forEach($scope.receiptList, function(item){
            //if(item.checked){
                var notice_obj = item.id;
                $scope.formData.notice.push(notice_obj);
            //}
        })
    }
    $scope.changeTotal = function(){
    	$scope.formData.total = 0;
        angular.forEach($scope.receiptList, function(item){
        	//if(item.checked){
        	  var itemAmount=Number(item.checked_amount)*Number($scope.formData.pledgeRate)/100;
        	  $scope.formData.total =(Number($scope.formData.total)+itemAmount).toFixed(2);
        	//}
        })
    }
    //全选
    $scope.formData.notice = [];
    
    EventBus.on("selectQualityCtrl", function(evt){
        if(evt.list){
            $scope.receiptList = evt.list;
            $scope.changeData();
            $scope.changeTotal();
        }
    });
    
    //监管公司名称
    $scope.getSuperviseComp = function(){
        postUrl.events("/warehouse/warehousePledge/getComapanyName", {'id':$scope.formData.superviseProtocolId}).success(function (_data) {
            if(_data.status==200){
            	$scope.formData.superviseComp=_data.data.companyName;
            	$scope.formData.superviseCompId=_data.data.companyId;
            }
        })
    }
    
    $scope.$watch('formData.pledgeRate',function(newValue,oldValue){
    	if(newValue){
    		$scope.changeTotal();
    		$scope.changeData();
    	}
    });
    
    //仓单
    /*$scope.getReceiptList=function(){
    	postUrl.events("/warehouse/warehousePledge/receiptList", {'pledgeCompanyId':id}).success(function (_data) {
            if(_data.status==200){
            	$scope.formData.receiptList=_data.data;
            }
        })
    }*/
    setDebit($scope);
    
    /*$scope.$watch('formData.pledgeCompId',function(newValue,oldValue){
    	if(newValue){
    		postUrl.events("/warehouse/warehousePledge/receiptList", {'pledgeCompanyId':newValue,"pledgeId":$scope.formData.id}).success(function (_data) {
	            if(_data.status==200){
	                $scope.receiptList=_data.data;
	                if($scope.formData.id){
	                  $scope.selectAll();
	                }
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
    	}
    	
    });*/
    
    function linkData(product){
    	if(!$scope.formData.id){
          $scope.formData.pledgeRate=(Number(product.max_finance_rate)*100).toFixed(2);
        }
        if(!$scope.formData.id){
          $scope.formData.loanApr=(Number(product.loan_apr_start)).toFixed(2);
        }
    	
		$scope.formData.loanFeeType = product.loan_fee_type;
		
        $scope.formData.overdueStatus = product.overdue_status;
		if(!$scope.formData.loanFeeValue)
			$scope.formData.loanFeeValue = (product.loan_fee_value*100).toFixed(2);
		//显示费用
		if(!$scope.formData.debitId)
        	$scope.formData.fees = product.fees;
		if(!$scope.formData.debitId)
			$scope.formData.overdueRateValues = angular.fromJson(product.overdue_rate_value);
	}
	
	function getDateStr(start_date,days) {     
	   var dd = new Date(start_date);    
	   dd.setDate(dd.getDate()+days);//获取AddDayCount天后的日期
	   var y = dd.getFullYear();     
	   var m = (dd.getMonth()+1)<10?"0"+(dd.getMonth()+1):(dd.getMonth()+1);//获取当前月份的日期，不足10补0
	   var d = dd.getDate()<10?"0"+dd.getDate():dd.getDate();//获取当前几号，不足10补0
	   return y+"-"+m+"-"+d;
	}
	
	$scope.$watch('formData.contractStartTime1',function(newValue,oldValue){
		if(!$scope.formData.contractEndTime1&&newValue&&$scope.productInfo && $scope.productInfo.mortgage_time_end){
			$scope.formData.contractEndTime1=getDateStr(newValue,$scope.productInfo.mortgage_time_end);
		}
	})
    
    $scope.$watch('formData.productId',function(newValue,oldValue){
    	if(newValue){
    		for(var i=0;i<$scope.formData.sc_warehouse_product.length;i++){
    			if(newValue==$scope.formData.sc_warehouse_product[i].value){
    				$scope.formData.productName=$scope.formData.sc_warehouse_product[i].text;
    				break;
    			}
    		}
    		
    		//资方
    		postUrl.events("/loan/credit/getProduct", {'productId':newValue}).success(function (_data) {
	            if(_data.status==200){
	            	$scope.productInfo=_data.data;
	            	linkData($scope.productInfo);
	            	postUrl.events("/system/company/options", {'id':$scope.productInfo.company_id}).success(function (_data) {
			            if(_data.status==200){
			            	$scope.formStruct.capitals=_data.data;
			            }
			        })
	            }
	        })
    	}
    });
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        $scope.formData.contractStartTime=new Date($scope.formData.contractStartTime1).getTime()/1000;
        $scope.formData.contractEndTime=new Date($scope.formData.contractEndTime1).getTime()/1000;
        angular.forEach($scope.formData.guarantees, function(item){
            if(item.fileId){
    			item.docId=item.fileId.did;
            }
        });
        $scope.formData.guaranteeJson = angular.toJson($scope.formData.guarantees, false);
        
        $scope.formData.receiptJson = [];
        angular.forEach($scope.receiptList, function(item){
        	$scope.formData.receiptJson.push(item.id);
        });
        $scope.formData.receiptJson=angular.toJson($scope.formData.receiptJson, false);
        $scope.formData.import_file1 = angular.toJson($scope.formData.import_file,true);
        
        if($scope.formStruct.beforeSubmit){
    		var result=$scope.formStruct.beforeSubmit();
    		if(!result){
    			scopeService.safeApply($scope, function () {
                	$scope.btnText = initbtnText;
                    // $scope.btnText1 = initbtnText1;
                    $scope.btnStatus = false;
                    // $scope.btnStatus1 = false;
                });
    			return;
    		}
    	}
        
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
  //删除合同附件
    $scope.deleteAttachment = function(index){
        $scope.formData.import_file.splice(index, 1);
    }
    
    $scope.removeFile = function(index){
        $scope.formData.guarantees[index].fileId=null;
    }
    
    //添加触发条件
    $scope.addGuarantee = function(){
        var guarantee = {
	            "id": null,
	            "pledgeId": null,
	            "policyNo": "",
	            "insuranceCompany":"",
	            "insuranceType":"",
	            "benefit":"",
	            "insuranceAmount":null,
	            "insuranceStartTime":"",
	            "insuranceEndTime":"",
	            "fileId":""
        };
        $scope.formData.guarantees.push(guarantee);
    }
    //删除触发条件
    $scope.deleteGuarantee = function(index){
        $scope.formData.guarantees.splice(index, 1);
    }
    
    if($scope.formData.guarantees==undefined||$scope.formData.guarantees.length==0){
    	$scope.formData.guarantees=[];
    	$scope.addGuarantee();
    }
});

formApp.controller("warehouseReceiptCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.depots=formStruct.depots;
    $scope.getDepot=function(){
    	postUrl.events("/warehouse/warehouseDepot/option", {'companyId':$scope.formData.superviseCompId}).success(function (_data) {
            if(_data.status==200){
            	$scope.depots=_data.data;
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                });
            }
        })
    }
    if($scope.formData.superviseCompId){
    	$scope.getDepot();
    }
    $scope.$watch('formData.depotId',function(newValue,oldValue){
    	postUrl.events("/warehouse/warehouseDepot/detail", {'id':newValue}).success(function (_data) {
            if(_data.status==200){
            	$scope.depot=_data.data;
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                });
            }
        })
    });
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;

        $scope.formData.fileId="";
        if ($scope.formData.import_file && $scope.formData.import_file.length) {
            for(var i=0;i<$scope.formData.import_file.length;i++){
                $scope.formData.fileId+=$scope.formData.import_file[i].did;
                if(i!=$scope.formData.import_file.length-1){
                    $scope.formData.fileId+=",";
                }
            }
        }
        if($scope.formData.import_file != undefined){
            $scope.formData.import_file = $scope.formData.import_file.join(",");
        }
        $scope.formData.signDate=new Date($scope.formData.signDate1).getTime()/1000;
        $scope.formData.openDate=new Date($scope.formData.openDate1).getTime()/1000;
        $scope.formData.endDate=new Date($scope.formData.endDate1).getTime()/1000;
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
});

formApp.controller("creditLimitAddCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formStruct = formStruct;
    $scope.formData = {};
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    $scope.grade = {};

    $scope.$watch("formData.companyId",function(newValue, oldValue){
    	if(newValue){
    		postUrl.events("/customer/cusGradeInfo/detail", {"companyId": newValue}).success(function(_data){
	            if(_data.status == 200){
	            	$scope.grade = _data.data;
	            } else {
	                parent.layer.msg(_data.description, {icon: 2,shade: 0.3,time:1500});
	            }
	        })
    	}
    });

    $scope.$watch("formData.bill + formData.b2b + formData.wh + formData.agpur",function(newValue, oldValue){
        if(newValue){
            var bill = Number($scope.formData.bill) > 0 ? Number($scope.formData.bill) : 0,
                b2b = Number($scope.formData.b2b) > 0 ? Number($scope.formData.b2b) : 0,
                wh = Number($scope.formData.wh) > 0 ? Number($scope.formData.wh) : 0,
                agpur = Number($scope.formData.agpur) > 0 ? Number($scope.formData.agpur) : 0;
            $scope.formData.creditLimit = bill + b2b + wh + agpur;
        }
    });

    $scope.submitForm = function(){

        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;

        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }

});

formApp.controller("creditLimitChangeCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formStruct = formStruct;
    $scope.formData = {};
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }

    //额度变更
    $scope.$watch("formData.changeType1 + formData.bill1",function(newValue, oldValue){
        if(newValue){
            var bill = Number($scope.formData.bill1) > 0 ? Number($scope.formData.bill1) : 0;
            if($scope.formData.changeType1 == 1){  //1为增加，2为减少
                $scope.formData.changeBill = Number($scope.formData.bill) + bill;  //变更后金额
            } else {
                $scope.formData.changeBill = Number($scope.formData.bill) - bill;  //变更后金额
            }
            $scope.formData.creditLimit = Number($scope.formData.changeBill) + Number($scope.formData.changeB2b) + Number($scope.formData.changeWh) + Number($scope.formData.changeAgpur);
        }
    });
    $scope.$watch("formData.changeType2 + formData.b2b1",function(newValue, oldValue){
        if(newValue){
            var b2b = Number($scope.formData.b2b1) > 0 ? Number($scope.formData.b2b1) : 0;
            if($scope.formData.changeType2 == 1){  //1为增加，2为减少
                $scope.formData.changeB2b = Number($scope.formData.b2b) + b2b;  //变更后金额
            } else {
                $scope.formData.changeB2b = Number($scope.formData.b2b) - b2b;  //变更后金额
            }
            $scope.formData.creditLimit = Number($scope.formData.changeBill) + Number($scope.formData.changeB2b) + Number($scope.formData.changeWh) + Number($scope.formData.changeAgpur);
        }
    });
    $scope.$watch("formData.changeType3 + formData.wh1",function(newValue, oldValue){
        if(newValue){
            var wh = Number($scope.formData.wh1) > 0 ? Number($scope.formData.wh1) : 0;
            if($scope.formData.changeType3 == 1){  //1为增加，2为减少
                $scope.formData.changeWh = Number($scope.formData.wh) + wh;  //变更后金额
            } else {
                $scope.formData.changeWh = Number($scope.formData.wh) - wh;  //变更后金额
            }
            $scope.formData.creditLimit = Number($scope.formData.changeBill) + Number($scope.formData.changeB2b) + Number($scope.formData.changeWh) + Number($scope.formData.changeAgpur);
        }
    });
    $scope.$watch("formData.changeType4 + formData.agpur1",function(newValue, oldValue){
        if(newValue){
            var agpur = Number($scope.formData.agpur1) > 0 ? Number($scope.formData.agpur1) : 0;
            if($scope.formData.changeType4 == 1){  //1为增加，2为减少
                $scope.formData.changeAgpur = Number($scope.formData.agpur) + agpur;  //变更后金额
            } else {
                $scope.formData.changeAgpur = Number($scope.formData.agpur) - agpur;  //变更后金额
            }
            $scope.formData.creditLimit = Number($scope.formData.changeBill) + Number($scope.formData.changeB2b) + Number($scope.formData.changeWh) + Number($scope.formData.changeAgpur);
        }
    });

    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }

});

formApp.controller("companyEcloudAddCtrl",function($scope, $http, postUrl, scopeService){
        $scope.formData = {};
        var data = {};
        data.hasShowandhide = true;
        $scope.formlist = formStruct.form_struct;
        var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
        $scope.btnText = initbtnText;
        $scope.btnStatus = false;
        
        var initformdata = formStruct.form_data;
        if(initformdata!=""){
            for (var i in initformdata) {
                $scope.formData[i] = initformdata[i];
            }
        }
        // 加入隐藏域作为参数
        for(var k in $scope.formlist){
            var item = $scope.formlist[k];
            if(item.type == 'hidden' && !$scope.formData[item.name]){
                $scope.formData[item.name] = item.value;
            }
        }
        $scope.$watch('formData.companyRoleType',function(newValue,oldValue){
            if(newValue){
                postUrl.events("/system/company/options", {'company_role_type':newValue}).success(function (_data) {
                    if(_data.status==200){
                        $scope.companyList=_data.data;
                    }else{
                        parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                        });
                    }
                })
            }
        });
        $scope.$watch('formData.companyId',function(newValue,oldValue){
            if(newValue){
                postUrl.events("/system/company/detail", {'id':newValue,'type':1}).success(function (_data) {
                    if(_data.status==200){
                        if(!$scope.formData.import_file)
                            $scope.formData.import_file={};
                        $scope.formData.import_file.url=_data.data.filePath;
                        $scope.formData.import_file.did=_data.data.docId;
                    }else{
                        parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                        });
                    }
                })
            }
        });
        
        $scope.submitForm = function(){
            $scope.btnText = initbtnText + " 中...";
            $scope.btnStatus = true;
            if(!$scope.formData.import_file||!$scope.formData.import_file.did){
                parent.layer.msg("印章未上传",{icon: 2,shade: 0.3,time:1500},function(){
                });
                return;
            }
            $scope.formData.docId=$scope.formData.import_file.did;
            postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
                if(_data.status==200){
                    parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                        scopeService.safeApply($scope, function () {
                            $scope.btnText = initbtnText;
                            $scope.btnStatus = false;
                        });
                        if(!!formStruct.refresh){
                            window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                            top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                        } else if(!!formStruct.refresh_sub){
                            window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                            window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                        } else {
                            window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                            top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                        }
                        parent.layer.closeAll();
                    });
                }else{
                    parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                        scopeService.safeApply($scope, function () {
                            $scope.btnText = initbtnText;
                            $scope.btnStatus = false;
                        });
                    });
                }
            })
        }
        $scope.closeForm = function(){
            parent.layer.closeAll();
        }
        
    });

formApp.controller("cusGradeInfoEditCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.tempData = {};
    if($scope.formData.items){
    	angular.forEach($scope.formData.items, function(item){
    		$scope.tempData[item.itemName]=item;
        });
    }
    //$scope.formlist=formStruct.fields;
    $scope.getFields=function(newValue,resetFieldValue){
    	if(newValue){
    		postUrl.events("/customer/cusGradeInfo/items", {'id':newValue}).success(function (_data) {
	            if(_data.status==200){
	            	$scope.formlist=_data.data;
	            	if(resetFieldValue)
	            		$scope.tempData = {};
                    for(var i=0;i<$scope.formlist.length;i++){
                        var name=$scope.formlist[i].name;
                        if(!$scope.tempData[name])
                            $scope.tempData[name]={};
                        $scope.tempData[name].templateItemId=$scope.formlist[i].remarks;
                        $scope.tempData[name].itemName=name;
                        //$scope.formData[name].point=$scope.formlist[i].text;
                    }
                    
                    initCompanyData($scope);
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
    	}
    }
    if($scope.formData.companyId){
    	$scope.edit=true;
    }
    
    //if($scope.formData.gradeTemplateId){
    //	$scope.getFields($scope.formData.gradeTemplateId);
    //}
    //企业类型
    $scope.$watch('formData.companyRoleType',function(newValue,oldValue){
    	if(newValue){
    		postUrl.events("/customer/cusGradeInfo/companyOptions", {'type':newValue,"checkblacklist":true,"companyId":($scope.edit?$scope.formData.companyId:null)}).success(function (_data) {
	            if(_data.status==200){
	            	$scope.companyList=_data.data;
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
    	}
    });
    
    function initCompanyData(scope){
    	if(!scope.formData.id&&scope.tempData.ZB0001&&scope.company){
    		scope.tempData.ZB0001.itemValue=scope.company.last_year_sale_amount;
        	scope.tempData.ZB0002.itemValue=scope.company.registerCapital;
        	if(scope.company.total_debt&&scope.company.total_asset)
        		scope.tempData.ZB0003.itemValue=scope.company.total_debt*1/scope.company.total_asset.toFixed(2);
        	else
        		scope.tempData.ZB0003.itemValue=0;
        	if(scope.company.companyCreateTime)
        		scope.tempData.ZB0005.itemValue=new Date().getFullYear()-new Date(scope.company.companyCreateTime*1000).getFullYear()+1;
        	else{
        		scope.tempData.ZB0005.itemValue=null;
        	}
        	scope.tempData.ZB0006.itemValue=scope.company.employee_college_count;
        	
        	if(scope.tempData.ZB0014)
        		scope.tempData.ZB0014.itemValue=scope.company.company_life_type!=null?scope.company.company_life_type+"":"";
        	if(scope.tempData.ZB0007)
        		scope.tempData.ZB0007.itemValue=scope.company.manage_status!=null?scope.company.manage_status+"":"";
        	if(scope.tempData.ZB0008)
        		scope.tempData.ZB0008.itemValue=scope.company.manage_feature_type!=null?scope.company.manage_feature_type+"":"";
    	}
    }

    $scope.$watch('formData.companyId',function(newValue,oldValue){
    	if(newValue){
    		postUrl.events("/system/company/detail", {'id':newValue}).success(function (_data) {
	            if(_data.status==200){
	            	$scope.company=_data.data;
	            	$scope.formData.companyCheckStatusName=_data.data.companyCheckStatusName;
	            	$scope.formData.businessLicTypeName=_data.data.businessLicTypeName;
	            	$scope.formData.businessLicNo=_data.data.businessLicNo;
	            	$scope.formData.companyScaleName=_data.data.companyScaleName;
	            	
	            	initCompanyData($scope);
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                });
	            }
	        })
    	}
    });
    //模板指标
    $scope.$watch('formData.gradeTemplateId',function(newValue,oldValue){
    	if(newValue){ 
            var resetFieldValue=newValue!=oldValue?true:false;
    		$scope.getFields(newValue,resetFieldValue);
    	}
    });
    //评分
    function getPoint(data,val){
        var point=0;
        if(data.type=="input"){
        	//var find=false,min={'k':0,'v':0},max={'k':0,'v':0};
        	for(var i=0;i<data.options.length;i++){
        		var option=data.options[i];
        		var a=Number(option.text),b=Number(option.text1);
        		if(a<=val&&val<b){
                    point=option.value;
                    //find=true;
                    break;
                }
        		//else{
                //	if(min.k>a)min={'k':a,'v':option.value};
                //	if(max.k<b)max={'k':b,'v':option.value};
                //}
        	}
        	//if(!find){
        	//	if(val<=min.k)point=min.v;
        	//	else if(val>=max.k)point=max.v;
        	//}
        	//if(point==null)
        	//	point=0;
        }else if(data.type=="select"){
            point=val;
        }
        return point;
    }
    
    $scope.calcTotal=function(){
        $scope.formData.tempTotalPoint = 0;
        // var endFlag=0;
        var result = false;
        if($scope.formlist.length > 0){
            result = $scope.formlist.every(function(item, index, array){
                return ($scope.tempData[item.name].itemValue !== "" && typeof $scope.tempData[item.name].itemValue != "undefined");
            })
        }

        if(result){
            angular.forEach($scope.formlist, function(item){
                var val = $scope.tempData[item.name].itemValue;
                var point = getPoint(item,Number(val));
                $scope.tempData[item.name].itemPoint = point;
                $scope.formData.tempTotalPoint += Number(point);
            })

            //评级指数得分之和/指数总分*100
            //年销售收入*销售收入归行率/100*行业系数*授信系数
            postUrl.events("/customer/cusGradeInfo/calcPoint", {
                "saleAmount": $scope.tempData.ZB0001.itemValue,
                "saleRate": $scope.tempData.ZB0019.itemValue,
                "totalPoint": $scope.formData.tempTotalPoint,
                "riskRuleId": $scope.formData.tradeTypeId,
                "templateId": $scope.formData.gradeTemplateId
            }).success(function (_data) {
                if(_data.status == 200){
                    $scope.formData.totalPoint = _data.data.totalPoint;
                    $scope.formData.riskLimit = _data.data.riskAmount;
                    $scope.formData.creditLevel = _data.data.creditLevel;
                    $scope.formData.creditLevelName = _data.data.creditLevelName;
                }else{
                    parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
                }
            })
        } else {
            parent.layer.msg("请先完善评级信息", {icon: 2, shade: 0.3, time: 1500});
        }
    }
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;

        $scope.formData.dataJson=[];
        angular.forEach($scope.tempData, function(value,key){
            $scope.formData.dataJson.push(value);
        })
        $scope.formData.dataJson=angular.toJson($scope.formData.dataJson, false);
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
});
	

formApp.controller("gradeItemEditCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;

        $scope.changeTotal();
        $scope.formData.params = angular.toJson($scope.formData.params1, false);
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.changeTotal = function(){
    	$scope.formData.point = 0;
        angular.forEach($scope.formData.params1, function(item){
        	var point=Number(item.value);
        	if(point>$scope.formData.point)
        		$scope.formData.point = point;
        })
    }
    //添加触发条件
    $scope.addItem = function(){
        var item = {
	            "text": "",
	            "text1": "",
	            "value": ""
        };
        $scope.formData.params1.push(item);
        $scope.changeTotal();
    }
    //删除触发条件
    $scope.deleteItem = function(index){
        $scope.formData.params1.splice(index, 1);
        $scope.changeTotal();
    }
    
    if($scope.formData.params1==undefined||$scope.formData.params1.length==0){
    	$scope.formData.params1=[];
    	$scope.addItem();
    }else{
    	$scope.formData.params1 = angular.fromJson($scope.formData.params1, false);
    }
    
});

formApp.controller("checkItemEditCtrl",function($scope, $http, postUrl, scopeService){
	$scope.formData = formStruct.form_data || {};
	$scope.formlist = formStruct.form_struct;
	var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
	$scope.btnText = initbtnText;
	$scope.btnStatus = false;
	
	$scope.submitForm = function(){
		$scope.btnText = initbtnText + " 中...";
		$scope.btnStatus = true;
		
		var subFormData = {};
        for(var att in $scope.formData){
        	if(angular.isArray($scope.formData[att])){
        		if(typeof $scope.formData[att][0] == "object"){
        			subFormData[att] = angular.toJson($scope.formData[att],true);
        		}else{
        			subFormData[att] = $scope.formData[att].join(",");
        		}
        	}else {
        		subFormData[att] = $scope.formData[att];
        	}
        }
        postUrl.events("/"+formStruct.submit_url, subFormData).success(function (_data) {
			if(_data.status==200){
				parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
					scopeService.safeApply($scope, function () {
						$scope.btnText = initbtnText;
						$scope.btnStatus = false;
					});
					if(!!formStruct.refresh){
						window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
						top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
					} else if(!!formStruct.refresh_sub){
						window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
					} else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
						window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
					} else {
						window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
						top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
					}
					parent.layer.closeAll();
				});
			}else{
				parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
					scopeService.safeApply($scope, function () {
						$scope.btnText = initbtnText;
						$scope.btnStatus = false;
					});
				});
			}
		})
	}
	if(!$scope.formData.params){
		$scope.formData.params = [];
	}
	//添加触发条件
	$scope.addItem = function(){
		$scope.formData.params.push({});
	}
	//删除触发条件
	$scope.deleteItem = function(index){
		$scope.formData.params.splice(index, 1);
	}
	
});

formApp.controller("checkInfoEditCtrl",function($scope, $http, postUrl, scopeService){
	$scope.formStruct = formStruct;
	$scope.formData = formStruct.form_data || {};
	$scope.formlist = formStruct.form_struct;
	var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
	$scope.btnText = initbtnText;
	$scope.btnStatus = false;
	
	$scope.submitForm = function(){
		$scope.btnText = initbtnText + " 中...";
		$scope.btnStatus = true;
		
		var subFormData = {};
		for(var att in $scope.formData){
			if(angular.isArray($scope.formData[att])){
				if(typeof $scope.formData[att][0] == "object"){
					subFormData[att] = angular.toJson($scope.formData[att],true);
				}else{
					subFormData[att] = $scope.formData[att].join(",");
				}
			}else if(angular.isObject($scope.formData[att])){
				subFormData[att] = angular.toJson($scope.formData[att],true);
			}else {
				subFormData[att] = $scope.formData[att];
			}
		}
		postUrl.events("/"+formStruct.submit_url, subFormData).success(function (_data) {
			if(_data.status==200){
				parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
					scopeService.safeApply($scope, function () {
						$scope.btnText = initbtnText;
						$scope.btnStatus = false;
					});
					if(!!formStruct.refresh){
						window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
						top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
					} else if(!!formStruct.refresh_sub){
						window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
					} else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
						window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
					} else {
						window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
						top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
					}
					parent.layer.closeAll();
				});
			}else{
				parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
					scopeService.safeApply($scope, function () {
						$scope.btnText = initbtnText;
						$scope.btnStatus = false;
					});
				});
			}
		})
	}
	
	$scope.getFields=function(){
		var tplId = $scope.formData.templateId;
    	if(tplId){
    		postUrl.events("/loan/after/check/getCheckItems", {'tplId':tplId}).success(function (_data) {
	            if(_data.status==200){
	            	$scope.formlist=_data.data;
	            	$scope.formData['checkInfo'] = {};
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500});
	            }
	        })
    	}else{
    		$scope.formlist=[];
    		$scope.formData['checkInfo'] = {};
    	}
    }
	$scope.getRecords=function(){
		var companyId = $scope.formData.companyId;
		if(companyId){
			postUrl.events("/loan/after/check/getRecords", {'id':companyId}).success(function (_data) {
				if(_data.status==200){
					$scope.formStruct.records=_data.data;
				}
			})
		}else{
			$scope.formStruct.records=[];
		}
	}
	$scope.changeRecord=function(){
		var debitId = $scope.formData.debitId;
		if(debitId){
			postUrl.events("/loan/after/check/getRecord", {'id':debitId}).success(function (_data) {
				if(_data.status==200){
					$scope.formData.loanId=_data.data.loanId;
					$scope.formData.bussType=_data.data.businessType;
					$scope.formData.bussNo=_data.data.loanContractNo;
					$scope.formData.productName=_data.data.companyName;// 通过companyName传递productName
					$scope.formData.loanAmount=_data.data.loanAmount;
					$scope.formData.contractStartTime=_data.data.contractStartTime;
					$scope.formData.contractEndTime=_data.data.contractEndTime;
				}
			})
		}else{
			$scope.formData.loanId="";
			$scope.formData.bussType="";
			$scope.formData.bussNo="";
			$scope.formData.productName="";
			$scope.formData.loanAmount="";
			$scope.formData.contractStartTime="";
			$scope.formData.contractEndTime="";
		}
	}
	
});

formApp.controller("clsifyInfoEditCtrl",function($scope, $http, postUrl, scopeService,dyUtil){
	dyUtil.ati(formStruct.clsTypes);
	dyUtil.ati(formStruct.twelveClsifysG0);
	dyUtil.ati(formStruct.twelveClsifys);
	dyUtil.ati(formStruct.twelveClsifysL);
	$scope.formStruct = formStruct;
	$scope.formData = formStruct.form_data || {};
	$scope.formlist = formStruct.form_struct;
	var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
	$scope.btnText = initbtnText;
	$scope.btnStatus = false;

	$scope.formData.flowInfo = $scope.formData.flowInfo || {};


    $scope.formStruct.cinfo = {};
    $scope.formData.clsGz = "";


	$scope.submitForm = function(){
		$scope.btnText = initbtnText + " 中...";
		$scope.btnStatus = true;

		var subFormData = {};
		for(var att in $scope.formData){
			if(angular.isArray($scope.formData[att])){
				if(typeof $scope.formData[att][0] == "object"){
					subFormData[att] = angular.toJson($scope.formData[att],true);
				}else{
					subFormData[att] = $scope.formData[att].join(",");
				}
			}else if(angular.isObject($scope.formData[att])){
				subFormData[att] = angular.toJson($scope.formData[att],true);
			}else {
				subFormData[att] = $scope.formData[att];
			}
		}
        if(Number($scope.formData.clsResult) < Number($scope.formData.clsGf) - 1){
            parent.layer.msg("G2不得优于G1两个级别",{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
            })
        } else {
            postUrl.events("/"+formStruct.submit_url, subFormData).success(function (_data) {
                if(_data.status==200){
                    parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1500},function(){
                        scopeService.safeApply($scope, function () {
                            $scope.btnText = initbtnText;
                            $scope.btnStatus = false;
                        });
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                        parent.layer.closeAll();
                    });
                }else{
                    parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                        scopeService.safeApply($scope, function () {
                            $scope.btnText = initbtnText;
                            $scope.btnStatus = false;
                        });
                    });
                }
            })
        }
	}

	$scope.getRecords=function(){
		var companyId = $scope.formData.companyId;
		if(companyId){
			postUrl.events("/aft/clsifyInfo/getRecords", {"id": companyId}).success(function (_data) {
				if(_data.status==200){
					$scope.formStruct.records = _data.data.records;
					$scope.formData.custGrade = _data.data.custGrade;
					$scope.formData.initClsify = _data.data.initClsify;
					$scope.formData.clsGz = _data.data.clsGz;
				}
			})
		}else{
			$scope.formStruct.records = [];
			$scope.formData.custGrade = "";
			$scope.formData.initClsify = "";
			$scope.formData.clsGz = "";

            $scope.formData.flowInfo = {};
		}
	}
	$scope.changeRecord=function(){
		var debitId = $scope.formData.debitId;
		if(debitId){
			postUrl.events("/aft/clsifyInfo/getRecord", {"id": debitId}).success(function (_data) {
				if(_data.status==200){
					$scope.formData.loanId = _data.data.loan_id;
					$scope.formData.bussType = _data.data.business_type;
					$scope.formData.bussNo = _data.data.loan_contract_no;
					$scope.formData.productName = _data.data.product_name;
					$scope.formData.loanAmount = _data.data.loan_amount;
					$scope.formData.contractStartTime = _data.data.contract_start_time;
					$scope.formData.contractEndTime = _data.data.contract_end_time;
                    if(_data.data.lastClsify){
                        var index = Number(_data.data.lastClsify) - 1;
                        $scope.formData.lastClsify = $scope.formStruct.twelveClsifys[index].text;
                    }

                    $scope.formStruct.cinfo = _data.data.cinfo;
                    for(var k=1; k<7; k++){
                        $scope.changeLevel(k);
                    }
				}
			})
		}else{
			$scope.formData.loanId = "";
			$scope.formData.bussType = "";
			$scope.formData.bussNo = "";
			$scope.formData.productName = "";
			$scope.formData.loanAmount = "";
			$scope.formData.contractStartTime = "";
			$scope.formData.contractEndTime = "";
            $scope.formData.lastClsify = "";

            $scope.formData.flowInfo = {};
            $scope.formStruct.cinfo = {};
		}
	}

    $scope.changeLevel = function(level){
        var cinfo = $scope.formStruct.cinfo,
            prefix = "";
        switch(level){
            case 1:
                var clsGz = $scope.formData.clsGz;
                if(cinfo.JCYZ001 == 1 && cinfo.JCYZ002 == 1 && cinfo.JCYZ003 == 1){
                    prefix = "加权因子有3个最优级，";
                    if(clsGz == 1 || clsGz == 2 || clsGz == 12){
                        $scope.formData.flowInfo.g1at = prefix + "不调整";
                    } else if (clsGz == "" || typeof clsGz == "undefined"){
                        $scope.formData.flowInfo.g1at = prefix + "G0为A1_A2_E1不调整，其它上调一级";
                    } else {
                        $scope.formData.flowInfo.g1at = prefix + "上调一级";
                    }
                } else if ((cinfo.JCYZ001 != 2 && cinfo.JCYZ002 == 3 && cinfo.JCYZ003 == 6) || (cinfo.JCYZ001 == 2 && cinfo.JCYZ002 != 3 && cinfo.JCYZ003 == 6) || (cinfo.JCYZ001 == 2 && cinfo.JCYZ002 == 3 && cinfo.JCYZ003 != 6)){
                    prefix = "加权因子有2个最末值，";
                    if(clsGz == 12){
                        $scope.formData.flowInfo.g1at = prefix + "不调整";
                    } else if (clsGz == "" || typeof clsGz == "undefined"){
                        $scope.formData.flowInfo.g1at = prefix + "G0优于C2级下调两级，为C2级下调一级，其它不调整";
                    } else {
                        $scope.formData.flowInfo.g1at = prefix + "下调二级";
                    }
                } else if (cinfo.JCYZ001 == 2 || cinfo.JCYZ002 == 3 || cinfo.JCYZ003 == 6){
                    prefix = "加权因子有1个最末值，";
                    if(clsGz == 12){
                        $scope.formData.flowInfo.g1at = prefix + "不调整";
                    } else if (clsGz == "" || typeof clsGz == "undefined"){
                        $scope.formData.flowInfo.g1at = prefix + "G0优于C1级下调一级，其它不调整";
                    } else {
                        $scope.formData.flowInfo.g1at = prefix + "下调一级";
                    }
                } else if (cinfo.JCYZ001 == 2 && cinfo.JCYZ002 == 3 && cinfo.JCYZ003 == 6){
                    prefix = "加权因子有3个最末值，";
                    if(clsGz == 10 || clsGz == 11 || clsGz == 12){
                        $scope.formData.flowInfo.g1at = prefix + "不调整";
                    } else if (clsGz == "" || typeof clsGz == "undefined"){
                        $scope.formData.flowInfo.g1at = prefix + "G0优于D1级下调至D1，其它不调整";
                    } else {
                        $scope.formData.flowInfo.g1at = prefix + "D1";
                    }
                } else {
                    $scope.formData.flowInfo.g1at = "不调整";
                }
                break;
            case 2:
                var g1a = $scope.formData.flowInfo.g1a;
                if(cinfo.JCYZ004 == 1){
                    prefix = "借款人当期现金流充足，";
                    $scope.formData.flowInfo.g1bt = prefix + "不调整";
                } else if (cinfo.JCYZ004 == 2){
                    prefix = "借款人当期现金流紧张，";
                    if(g1a == 1 || g1a == 2 || g1a == 3 || g1a == 4){
                        $scope.formData.flowInfo.g1bt = prefix + "不应优于B1级";
                    } else if (g1a == "" || typeof g1a == "undefined"){
                        $scope.formData.flowInfo.g1bt = prefix + "当G1A优于B1时，调整区间为[B1~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1bt = prefix + "不调整";
                    }
                } else if (cinfo.JCYZ004 == 3){
                    prefix = "借款人当期现金流明显不足，";
                    if((g1a > 1 || g1a == 1) && (g1a < 7 || g1a == 7)){
                        $scope.formData.flowInfo.g1bt = prefix + "不应优于C1级";
                    } else if (g1a == "" || typeof g1a == "undefined"){
                        $scope.formData.flowInfo.g1bt = prefix + "当G1A优于C1时，调整区间为[C1~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1bt = prefix + "不调整";
                    }
                }
                break;
            case 3:
                var g1b = $scope.formData.flowInfo.g1b;
                if(cinfo.JCYZ006 == 1){
                    prefix = "存在实质性有利影响，";
                    $scope.formData.flowInfo.g1ct = prefix + "最多上调一级";
                } else if (cinfo.JCYZ006 == 2){
                    prefix = "没有影响或影响程度极小或无重大事件，";
                    $scope.formData.flowInfo.g1ct = prefix + "不调整";
                } else if (cinfo.JCYZ006 == 3){
                    prefix = "存在一定不利影响，";
                    $scope.formData.flowInfo.g1ct = prefix + "至少下调一级";
                } else if (cinfo.JCYZ006 == 4){
                    prefix = "存在严重不良影响或导致资不抵债，";
                    $scope.formData.flowInfo.g1ct = prefix + "至少下调两级";
                }
                break;
            case 4:
                var g1c = $scope.formData.flowInfo.g1c;
                if(cinfo.JCYZ007 == 1){
                    prefix = "未逾期，";
                    $scope.formData.flowInfo.g1dt = prefix + "不调整";
                } else if (cinfo.JCYZ007 == 2){
                    prefix = "部分或全部贷款本金或利息逾期30天以下，";
                    if(g1c == 1 || g1c == 2){
                        $scope.formData.flowInfo.g1dt = prefix + "不应优于A3级";
                    } else if (g1c == "" || typeof g1c == "undefined"){
                        $scope.formData.flowInfo.g1dt = prefix + "当G1C优于A3时，调整区间为[A3~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1dt = prefix + "不调整";
                    }
                } else if (cinfo.JCYZ007 == 3){
                    prefix = "部分或全部贷款本金或利息逾期31－60天，";
                    if(g1c == 1 || g1c == 2 || g1c == 3 || g1c == 4){
                        $scope.formData.flowInfo.g1dt = prefix + "不应优于B1级";
                    } else if (g1c == "" || typeof g1c == "undefined"){
                        $scope.formData.flowInfo.g1dt = prefix + "当G1C优于B1时，调整区间为[B1~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1dt = prefix + "不调整";
                    }
                } else if (cinfo.JCYZ007 == 4){
                    prefix = "部分或全部贷款本金或利息逾期61—90天，";
                    if((g1c > 1 || g1c == 1) && (g1c < 6 || g1c == 6)){
                        $scope.formData.flowInfo.g1dt = prefix + "不应优于B3级";
                    } else if (g1c == "" || typeof g1c == "undefined"){
                        $scope.formData.flowInfo.g1dt = prefix + "当G1C优于B3时，调整区间为[B3~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1dt = prefix + "不调整";
                    }
                } else if (cinfo.JCYZ007 == 5){
                    prefix = "部分或全部贷款本金或利息逾期91—180天，";
                    if((g1c > 1 || g1c == 1) && (g1c < 7 || g1c == 7)){
                        $scope.formData.flowInfo.g1dt = prefix + "不应优于C1级";
                    } else if (g1c == "" || typeof g1c == "undefined"){
                        $scope.formData.flowInfo.g1dt = prefix + "当G1C优于C1时，调整区间为[C1~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1dt = prefix + "不调整";
                    }
                } else if (cinfo.JCYZ007 == 6){
                    prefix = "部分或全部贷款本金或利息逾期181—270天，";
                    if((g1c > 1 || g1c == 1) && (g1c < 8 || g1c == 8)){
                        $scope.formData.flowInfo.g1dt = prefix + "不应优于C2级";
                    } else if (g1c == "" || typeof g1c == "undefined"){
                        $scope.formData.flowInfo.g1dt = prefix + "当G1C优于C2时，调整区间为[C2~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1dt = prefix + "不调整";
                    }
                } else if (cinfo.JCYZ007 == 7){
                    prefix = "部分或全部贷款本金或利息逾期271－365天，";
                    if((g1c > 1 || g1c == 1) && (g1c < 9 || g1c == 9)){
                        $scope.formData.flowInfo.g1dt = prefix + "不应优于D1级";
                    } else if (g1c == "" || typeof g1c == "undefined"){
                        $scope.formData.flowInfo.g1dt = prefix + "当G1C优于D1时，调整区间为[D1~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1dt = prefix + "不调整";
                    }
                } else if (cinfo.JCYZ007 == 8){
                    prefix = "部分或全部贷款本金或利息逾期366天以上，";
                    if((g1c > 1 || g1c == 1) && (g1c < 10 || g1c == 10)){
                        $scope.formData.flowInfo.g1dt = prefix + "不应优于D2级";
                    } else if (g1c == "" || typeof g1c == "undefined"){
                        $scope.formData.flowInfo.g1dt = prefix + "当G1C优于D2时，调整区间为[D2~E]，否则不调整";
                    } else {
                        $scope.formData.flowInfo.g1dt = prefix + "不调整";
                    }
                }
                break;
            case 5:
                var g1d = $scope.formData.flowInfo.g1d;
                if(cinfo.JCYZ008 == 1){
                    prefix = "升值，";
                    if(g1d == 1 || g1d == 8){
                        $scope.formData.flowInfo.g1et = prefix + "不调整";
                    } else if (g1d == "" || typeof g1d == "undefined"){
                        $scope.formData.flowInfo.g1et = prefix + "G1为A1或C1时,不调整.否则至多上调一级.";
                    } else {
                        $scope.formData.flowInfo.g1et = prefix + "至多上调一级";
                    }
                } else if (cinfo.JCYZ008 == 2){
                    prefix = "不变，";
                    $scope.formData.flowInfo.g1et = prefix + "不调整";
                } else if (cinfo.JCYZ008 == 3){
                    prefix = "贬值，";
                    if(g1d == 12){
                        $scope.formData.flowInfo.g1et = prefix + "不调整";
                    } else {
                        $scope.formData.flowInfo.g1et = prefix + "至少下调一级";
                    }
                }
                break;
            case 6:
                var g1e = $scope.formData.flowInfo.g1e;
                $scope.formData.clsGf = g1e;
                if(g1e){
                    var index = Number(g1e) - 1;
                    $scope.formData.clsGfName = $scope.formStruct.twelveClsifys[index].text;
                }
                break;
        }
    }

    if($scope.formData.companyId){
        $scope.getRecords();
        $scope.changeRecord();
    }

});

formApp.controller("alertCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formStruct = formStruct;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        if($scope.formData.triggerTime==3){//触发时间之后,对应提醒时间
        	$scope.formData.triggerTimeDay=$scope.formData.triggerTimeDay1;
        }
        $scope.formData.triggers = angular.toJson($scope.formData.triggers, false);
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    //添加触发条件
    $scope.addTrigger = function(){
        var trigger = {
	            "receiverType": "",
	            "sendType": [],
	            "sendContent": ""
        };
        $scope.formData.triggers.push(trigger);
    }
    //删除触发条件
    $scope.deleteTrigger = function(index){
        $scope.formData.triggers.splice(index, 1);
    }
    
    if($scope.formData.triggers==undefined||$scope.formData.triggers.length==0){
    	$scope.formData.triggers=[];
    	$scope.addTrigger();
    }
});
//准入材料
formApp.controller("permitDatumCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
});
//添加联动值
formApp.controller("dictCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
		var paramData = angular.copy($scope.formData);
		paramData.dicts = angular.toJson(paramData.dicts, true);
        postUrl.events("/"+formStruct.submit_url, paramData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    $scope.addDict = function(){
        var dict = {
	            "label": "",
	            "value": ""
        };
        $scope.formData.dicts.push(dict);
    }
    //删除联动值
    $scope.deleteDict = function(index){
        $scope.formData.dicts.splice(index, 1);
    }
});


//添加产品
formApp.controller("productCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    $scope.formStruct = formStruct;
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    
    $scope.formData.settleMonthType = "3";
    $scope.formData.checkMonthType = "2";
    $scope.formData.tradeEndType = "1";
    $scope.formData.tradeStartType = "1";
    
    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.productConfig=1;
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        
        if($scope.formStruct.beforeSubmit){
    		var result=$scope.formStruct.beforeSubmit();
    		if(!result){
    			scopeService.safeApply($scope, function () {
                	$scope.btnText = initbtnText;
                    //$scope.btnText1 = initbtnText1;
                    $scope.btnStatus = false;
                    //$scope.btnStatus1 = false;
                });
    			return;
    		}
    	}
        
		var paramData = angular.copy($scope.formData);
		paramData.feeValues = angular.toJson(paramData.feeValues, false);
		
		if(paramData.repayTypeIds===true){
			paramData.repayTypeIds=[3];
		}
		if (paramData.businessTypeId == 1) {
			paramData.repayTypeIds = [paramData.repayTypeIds];
		}
        postUrl.events("/"+formStruct.submit_url, paramData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    /*if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }*/
                    window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
    
});
//授信企业移交
formApp.controller("transferUserCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    
    //业务员选择
    $scope.departmentData = $scope.formData.service_type.department_list;
    $scope.userToggle = false;
    $scope.departmentName = "";
    $scope.post = true;
    $scope.toggleUserBox = function(){
        $scope.userToggle = !$scope.userToggle;
        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
            var id = $scope.formData.service_type.salesman_department;
            postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
                if(_data.status == 200){
                	$scope.formData.service_type.user_list = _data.data.items;
                    $scope.post = false;
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                        //window.location.reload();
                    });
                }
            });
        }
    }
    $scope.getUserList = function(id, name){
        $scope.formData.service_type.salesman_department = id;
        $scope.departmentName = name;
        $scope.userListPost(id);
    }
    $scope.getUserName = function(user,id,checked){
	    	$scope.formData.salerId=id;
	        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
    }
    $scope.userListPost = function(id){
        $scope.formData.service_type.salesman = "";
        $scope.formData.service_type.user_name = "";
        postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
            if(_data.status == 200){
            	$scope.formData.service_type.user_list = _data.data.items;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    //window.location.reload();
                });
            }
        });
    }
    $scope.hideUserBox = function(){
        $scope.userToggle = false;
    }
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
});
//公司附件上传
formApp.controller("companyAttachCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
		var paramData = angular.copy($scope.formData);
		paramData.files = paramData.files.join(",");
        postUrl.events("/"+formStruct.submit_url, paramData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    //删除文件
    $scope.deleteFile = function(index,name){
        $scope.formData[name].splice(index, 1);
    }
});

//贸易信息
formApp.controller("companyRelationAddCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    $scope.formStruct = formStruct;
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }
     //控制表单内容显示隐藏
    var hideAndShow = {
        init: function () {
            var that = this,
                l = $scope.formlist.length;
            for (var i = 0; i < l; i++) {
                if ($scope.formlist[i].haschild) {
                    that.hideFn(i);
                }
            }
        },
        hideFn: function (i) {
            var n = "",
                m = "",
                lm = "",
                lms=[]; //用于存放复选框的值的数组
            m = $scope.formlist[i].name;

            $scope.$watch("formData." + m + "", function () {
                if($scope.formlist[i].type=="checkbox"&&$scope.formData[m]){ //适用于checkbox的联动，scope.formData[m]为一个数组
                    lms = [];
                    $.each($scope.formData[m], function (n, e) {
                        $.each($scope.formlist[i].options, function (n1, e1) {
                            if(e == e1.value&&typeof e1.childmark!="undefined"){
                                lms.push(e1.childmark); //先将复选框的所有选中的值存储起来
                            }
                        });
                    });
                    for (var k in $scope.formlist) {
                        if ($scope.formlist[k].parentname == m) {
                            if(lms.in_array($scope.formlist[k].mark)){
                                $scope.formlist[k].hide = false;
                            }else{
                                $scope.formlist[k].hide = true;
                            }
                        }
                    }
                }else{
                    $.each($scope.formlist[i].options, function (n, e) {
                        if($scope.formData[m] == $scope.formlist[i].options[n].value)
                        lm = $scope.formlist[i].options[n].childmark;
                    });
                    for (var k in $scope.formlist) {
                        if ($scope.formlist[k].parentname == m) {
                            if ($scope.formlist[k].mark == lm) {
                                $scope.formlist[k].hide = false;
                            } else {
                                $scope.formlist[k].hide = true;
                            }
                        }
                    }
                }
            }, true);
        }
    };
    if(data.hasShowandhide){
        hideAndShow.init(); //初始化控制显示隐藏联动，可在后台构建表单的时候，当有显示隐藏存在表单的时候，传一个字段过来，方便判断，提高js性能
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    $scope.addCoreCompany = function(){
        var company_info = {
            "coreCompanyId": "",
            "chainPosition": ""
        };
        $scope.formData.chains.push(company_info);
    }
    $scope.deleteCoreCompany = function(index){
        $scope.formData.chains.splice(index, 1);
    }
    
    $scope.postFormData=function(){
    	//$scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
    	if($scope.formData.chains&&$scope.formData.chains.length>0&&$scope.formData.chains[0].coreCompanyId)
    		$scope.formData.chains1 = angular.toJson($scope.formData.chains,true);
    	postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        $scope.postFormData();
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
});

//企业添加数据
formApp.controller("companyAddCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    $scope.formStruct = formStruct;
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    $scope.formlist1 = formStruct.form_struct1;

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;
    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }
     //控制表单内容显示隐藏
    var hideAndShow = {
        init: function () {
            var that = this,
                l = $scope.formlist.length;
            for (var i = 0; i < l; i++) {
                if ($scope.formlist[i].haschild) {
                    that.hideFn(i);
                }
            }
        },
        hideFn: function (i) {
            var n = "",
                m = "",
                lm = "",
                lms=[]; //用于存放复选框的值的数组
            m = $scope.formlist[i].name;

            $scope.$watch("formData." + m + "", function () {
                if($scope.formlist[i].type=="checkbox"&&$scope.formData[m]){ //适用于checkbox的联动，scope.formData[m]为一个数组
                    lms = [];
                    $.each($scope.formData[m], function (n, e) {
                        $.each($scope.formlist[i].options, function (n1, e1) {
                            if(e == e1.value&&typeof e1.childmark!="undefined"){
                                lms.push(e1.childmark); //先将复选框的所有选中的值存储起来
                            }
                        });
                    });
                    for (var k in $scope.formlist) {
                        if ($scope.formlist[k].parentname == m) {
                            if(lms.in_array($scope.formlist[k].mark)){
                                $scope.formlist[k].hide = false;
                            }else{
                                $scope.formlist[k].hide = true;
                            }
                        }
                    }
                }else{
                    $.each($scope.formlist[i].options, function (n, e) {
                        if($scope.formData[m] == $scope.formlist[i].options[n].value)
                        lm = $scope.formlist[i].options[n].childmark;
                    });
                    for (var k in $scope.formlist) {
                        if ($scope.formlist[k].parentname == m) {
                            if ($scope.formlist[k].mark == lm) {
                                $scope.formlist[k].hide = false;
                            } else {
                                $scope.formlist[k].hide = true;
                            }
                        }
                    }
                }
            }, true);
        }
    };
    if(data.hasShowandhide){
        hideAndShow.init(); //初始化控制显示隐藏联动，可在后台构建表单的时候，当有显示隐藏存在表单的时候，传一个字段过来，方便判断，提高js性能
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
    
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    $scope.addCoreCompany = function(){
        var company_info = {
            "coreCompanyId": "",
            "chainPosition": ""
        };
        $scope.formData.chains.push(company_info);
    }
    $scope.deleteCoreCompany = function(index){
        $scope.formData.chains.splice(index, 1);
    }
    
    
    //业务员选择
    $scope.departmentData = $scope.formData.service_type.department_list;
    $scope.userToggle = false;
    $scope.departmentName = "";
    $scope.post = true;
    $scope.toggleUserBox = function(){
        $scope.userToggle = !$scope.userToggle;
        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
            var id = $scope.formData.service_type.salesman_department;
            postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
                if(_data.status == 200){
                	$scope.formData.service_type.user_list = _data.data.items;
                    $scope.post = false;
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                        //window.location.reload();
                    });
                }
            });
        }
    }
    $scope.getUserList = function(id, name){
        $scope.formData.service_type.salesman_department = id;
        $scope.departmentName = name;
        $scope.userListPost(id);
    }
    $scope.getUserName = function(name,user,id){
	    	$scope.formData[name]=id;
	        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
    }
    $scope.userListPost = function(id){
        $scope.formData.service_type.salesman = "";
        $scope.formData.service_type.user_name = "";
        postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
            if(_data.status == 200){
            	$scope.formData.service_type.user_list = _data.data.items;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    //window.location.reload();
                });
            }
        });
    }
    $scope.hideUserBox = function(){
        $scope.userToggle = false;
    }
  //删除上传文件
    $scope.removeFile = function(){
    	$scope.formData.import_file = {};
    }
    
    $scope.postFormData=function(){
    	$scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
    	if($scope.formData.chains&&$scope.formData.chains.length>0&&$scope.formData.chains[0].coreCompanyId)
    		$scope.formData.chains1 = angular.toJson($scope.formData.chains,true);
    	postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        if(!$scope.formData.salerId){
        	parent.layer.msg("请选择经办人！",{icon: 2,time:1000},function(){
                scopeService.safeApply($scope, function () {
                    $scope.btnText = initbtnText;
                    $scope.btnStatus = false;
                });
            });
        }else{
        	postUrl.events("/system/cusCompanyBlacklist/blacklistType", {'businessLicNo':$scope.formData.businessLicNo}).success(function (_data) {
	            if(_data.status==200){
	            	$scope.formData.blacklistType=_data.data;
	            	if(_data.data==0){
	            		parent.layer.msg('客户属于禁止类黑名单客户，不允许继续操作！',{icon: 2,shade: 0.3,time:1500},function(){
	            			scopeService.safeApply($scope, function () {
	    	                    $scope.btnText = initbtnText;
	    	                    $scope.btnStatus = false;
	    	                });
	            		});
	            	}else if(_data.data==1){
	            		parent.layer.confirm("客户属于预警类客户，请确认是否继续？", {
                            time: 0, //不自动关闭
                            icon: 3,
                            shade: 0.3,
                            title: '预警提醒',
                            btn: ["确定", "取消"]
                        }, function(index){
                            if($scope.btnStatus){
                                $scope.postFormData();
                            } else {
                                return;
                            }
                        },function(){
                        	scopeService.safeApply($scope, function () {
        	                    $scope.btnText = initbtnText;
        	                    $scope.btnStatus = false;
        	                });
                        });
	            	}else{
	            		$scope.postFormData();
	            	}
        		}else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                	scopeService.safeApply($scope, function () {
    	                    $scope.btnText = initbtnText;
    	                    $scope.btnStatus = false;
    	                });
	                });
        		}
        	})
        }
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
    
});

//企业编辑数据
formApp.controller("companyEditCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    var data = {};
    $scope.formStruct = formStruct;
    data.hasShowandhide = true;
    $scope.formlist = formStruct.form_struct;
    $scope.formlist1 = formStruct.form_struct1;

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }
     //控制表单内容显示隐藏
    var hideAndShow = {
        init: function () {
            var that = this,
                l = $scope.formlist.length;
            for (var i = 0; i < l; i++) {
                if ($scope.formlist[i].haschild) {
                    that.hideFn(i);
                }
            }
        },
        hideFn: function (i) {
            var n = "",
                m = "",
                lm = "",
                lms=[]; //用于存放复选框的值的数组
            m = $scope.formlist[i].name;

            $scope.$watch("formData." + m + "", function () {
                if($scope.formlist[i].type=="checkbox"&&$scope.formData[m]){ //适用于checkbox的联动，scope.formData[m]为一个数组
                    lms = [];
                    $.each($scope.formData[m], function (n, e) {
                        $.each($scope.formlist[i].options, function (n1, e1) {
                            if(e == e1.value&&typeof e1.childmark!="undefined"){
                                lms.push(e1.childmark); //先将复选框的所有选中的值存储起来
                            }
                        });
                    });
                    for (var k in $scope.formlist) {
                        if ($scope.formlist[k].parentname == m) {
                            if(lms.in_array($scope.formlist[k].mark)){
                                $scope.formlist[k].hide = false;
                            }else{
                                $scope.formlist[k].hide = true;
                            }
                        }
                    }
                }else{
                    $.each($scope.formlist[i].options, function (n, e) {
                        if($scope.formData[m] == $scope.formlist[i].options[n].value)
                        lm = $scope.formlist[i].options[n].childmark;
                    });
                    for (var k in $scope.formlist) {
                        if ($scope.formlist[k].parentname == m) {
                            if ($scope.formlist[k].mark == lm) {
                                $scope.formlist[k].hide = false;
                            } else {
                                $scope.formlist[k].hide = true;
                            }
                        }
                    }
                }
            }, true);
        }
    };
    if(data.hasShowandhide){
        hideAndShow.init(); //初始化控制显示隐藏联动，可在后台构建表单的时候，当有显示隐藏存在表单的时候，传一个字段过来，方便判断，提高js性能
    }
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }
  //删除上传文件
    $scope.removeFile = function(){
    	$scope.formData.import_file = {};
    }
    $scope.addCoreCompany = function(){
        var company_info = {
            "coreCompanyId": "",
            "chainPosition": ""
        };
        $scope.formData.chains.push(company_info);
    }
    $scope.deleteCoreCompany = function(index){
        $scope.formData.chains.splice(index, 1);
    }
    
    //业务员选择
    $scope.departmentData = $scope.formData.service_type.department_list;
    $scope.userToggle = false;
    $scope.departmentName = "";
    $scope.post = true;
    $scope.toggleUserBox = function(){
        $scope.userToggle = !$scope.userToggle;
        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
            var id = $scope.formData.service_type.salesman_department;
            postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
                if(_data.status == 200){
                	$scope.formData.service_type.user_list = _data.data.items;
                    $scope.post = false;
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                        //window.location.reload();
                    });
                }
            });
        }
    }
    $scope.getUserList = function(id, name){
        $scope.formData.service_type.salesman_department = id;
        $scope.departmentName = name;
        $scope.userListPost(id);
    }
    $scope.getUserName = function(name,user,id){
	    	$scope.formData[name]=id;
	        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
    }
    $scope.userListPost = function(id){
        $scope.formData.service_type.salesman = "";
        $scope.formData.service_type.user_name = "";
        postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
            if(_data.status == 200){
            	$scope.formData.service_type.user_list = _data.data.items;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    //window.location.reload();
                });
            }
        });
    }
    $scope.hideUserBox = function(){
        $scope.userToggle = false;
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        if(!$scope.formData.salerId){
        	parent.layer.msg("请选择经办人！",{icon: 2,time:1000},function(){
                scopeService.safeApply($scope, function () {
                    $scope.btnText = initbtnText;
                    $scope.btnStatus = false;
                });
            });
        }else{
        	$scope.formData.import_file = angular.toJson($scope.formData.import_file,true);
        	if($scope.formData.chains&&$scope.formData.chains.length>0&&$scope.formData.chains[0].coreCompanyId)
        		$scope.formData.chains1 = angular.toJson($scope.formData.chains,true);
	        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
	            if(_data.status==200){
	                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                    if(!!formStruct.refresh){
	                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
	                    } else if(!!formStruct.refresh_sub){
	                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
	                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
	                    } else {
	                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
	                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
	                    }
	                    parent.layer.closeAll();
	                });
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                });
	            }
	        })
        }
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
});

//企业编辑数据
formApp.controller("companyCreditEditCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    $scope.formStruct = formStruct;
    $scope.formlist = formStruct.form_struct;
    $scope.formlist1 = formStruct.form_struct1;

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    for(var i=0,len=$scope.formlist.length;i<len;i++){
        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
            var dataResult = [];
            $.each($scope.formlist[i].options,function(n,v){
                dataResult.push({"text":v,"value":n});
            });
            //console.log(dataResult);
            $scope.formlist[i].options = dataResult;
        }
    }

    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    // 加入隐藏域作为参数
    for(var k in $scope.formlist){
    	var item = $scope.formlist[k];
    	if(item.type == 'hidden' && !$scope.formData[item.name]){
    		$scope.formData[item.name] = item.value;
    	}
    }

    //业务员选择
    $scope.departmentData = $scope.formData.service_type.department_list;
    $scope.userToggle = false;
    $scope.departmentName = "";
    $scope.post = true;
    $scope.toggleUserBox = function(){
        $scope.userToggle = !$scope.userToggle;
        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
            var id = $scope.formData.service_type.salesman_department;
            postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
                if(_data.status == 200){
                	$scope.formData.service_type.user_list = _data.data.items;
                    $scope.post = false;
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                        //window.location.reload();
                    });
                }
            });
        }
    }
    $scope.getUserList = function(id, name){
        $scope.formData.service_type.salesman_department = id;
        $scope.departmentName = name;
        $scope.userListPost(id);
    }
    $scope.getUserName = function(name,user,id){
	    	$scope.formData[name]=id;
	        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
    }
    $scope.userListPost = function(id){
        $scope.formData.service_type.salesman = "";
        $scope.formData.service_type.user_name = "";
        postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
            if(_data.status == 200){
            	$scope.formData.service_type.user_list = _data.data.items;
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    //window.location.reload();
                });
            }
        });
    }
    $scope.hideUserBox = function(){
        $scope.userToggle = false;
    }
    
    //删除上传文件
    // $scope.removeShareholderFile = function(index){
    //     $scope.formData.shareholders[index].fileId=null;
    // }
    // $scope.removePropertyFile = function(index){
    //     $scope.formData.properties[index].fileId=null;
    // }

    $scope.addShareholder = function(){
        var item = {
            "companyId": null,
            "shareholderType": null,
            "shareholderName": "",
            "legalRelation":"",
            "shareholderCardType":null,
            "cardNo":"",
            "currency":"人民币",
            "shareAmount":null,
            "shareRate":null,
            "shareWay":"",
            "inplaceRate":null,
            "remark":"",
            "fileId":""
        };
        $scope.formData.shareholders.push(item);
    }
    if(!$scope.formData.shareholders||$scope.formData.shareholders.length==0){
    	$scope.formData.shareholders=[];
    	$scope.addShareholder();
    }
    
    $scope.deleteShareholder = function(index){
        $scope.formData.shareholders.splice(index, 1);
    }
    $scope.addProperty = function(){
    	var item = {
    			"companyId": null,
    			"propertyDesc": "",
    			"currency":"人民币",
    			"amount":null,
    			"remark":"",
    			"fileId":""
    	};
    	$scope.formData.properties.push(item);
    }
    if(!$scope.formData.properties||$scope.formData.properties.length==0){
    	$scope.formData.properties=[];
    	$scope.addProperty();
    }
    $scope.deleteProperty = function(index){
    	$scope.formData.properties.splice(index, 1);
    }
    
    $scope.postFormData=function(){
    	$scope.formData.file = angular.toJson($scope.formData.import_file,true);
    	$scope.formData.file1 = angular.toJson($scope.formData.import_file1,true);
    	var properties=angular.copy($scope.formData.properties);
    	var shareholders=angular.copy($scope.formData.shareholders);
    	
    	// for(var i=0;i<properties.length;i++){
    	// 	var fileId=properties[i].fileId;
    	// 	if(fileId){
    	// 		properties[i].fileId=fileId.did;
    	// 	}
    	// }
    	// var shareholdFile="";
    	// for(var i=0;i<shareholders.length;i++){
    	// 	var fileId=shareholders[i].fileId;
    	// 	if(fileId){
    	// 		shareholders[i].fileId=fileId.did;
    	// 	}
    	// }
    	
    	$scope.formData.propertyJson = angular.toJson(properties,true);
    	$scope.formData.shareholderJson = angular.toJson(shareholders,true);
        
    	postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
    if(!$scope.formData.currency){
    	$scope.formData.currency="人民币";
    }
    
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        if(!$scope.formData.salerId){
        	parent.layer.msg("请选择经办人！",{icon: 2,time:1000},function(){
                scopeService.safeApply($scope, function () {
                    $scope.btnText = initbtnText;
                    $scope.btnStatus = false;
                });
            });
        }else{
        	postUrl.events("/system/cusCompanyBlacklist/blacklistType", {'businessLicNo':$scope.formData.businessLicNo}).success(function (_data) {
	            if(_data.status==200){
	            	$scope.formData.blacklistType=_data.data;
	            	if(_data.data==0){
	            		parent.layer.msg('客户属于禁止类黑名单客户，不允许继续操作！',{icon: 2,shade: 0.3,time:1500},function(){
	            			scopeService.safeApply($scope, function () {
	    	                    $scope.btnText = initbtnText;
	    	                    $scope.btnStatus = false;
	    	                });
	            		});
	            	}else if(_data.data==1){
	            		parent.layer.confirm("客户属于预警类客户，请确认是否继续？", {
                            time: 0, //不自动关闭
                            icon: 3,
                            shade: 0.3,
                            title: '预警提醒',
                            btn: ["确定", "取消"]
                        }, function(index){
                            if($scope.btnStatus){
                                $scope.postFormData();
                            } else {
                                return;
                            }
                        },function(){
                        	scopeService.safeApply($scope, function () {
        	                    $scope.btnText = initbtnText;
        	                    $scope.btnStatus = false;
        	                });
                        });
	            	}else{
	            		$scope.postFormData();
	            	}
        		}else{
	                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
	                	scopeService.safeApply($scope, function () {
    	                    $scope.btnText = initbtnText;
    	                    $scope.btnStatus = false;
    	                });
	                });
        		}
        	})
        }
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
});

//通用form数据-添加
formApp.controller("commonAddCtrl", function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    $scope.formStruct = formStruct;
    var subUrl = formStruct.submit_url;//获取提交地址

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.commonSave = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + subUrl, $scope.formData).success(function(_data){
            if(_data.status == 200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
    $scope.commonClose = function(){
        parent.layer.closeAll();
    }
})

//通用form数据-编辑
formApp.controller("commonEditCtrl", function($scope, $http, postUrl, scopeService){
    $scope.formData = {};
    $scope.formStruct = formStruct;
    $scope.formList = formStruct.form_data;
    var subUrl = formStruct.submit_url;//获取提交地址
    var initformdata = $scope.formList;
    if(typeof initformdata != 'undefined' && initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
        //银行-查询件管理-编辑，复制业务编号作为联系函编号
        if (initformdata.id) {
            $scope.show_copy_buss_no = true;
        }
    }

    $scope.$watch('copy_buss_no', function(newValue, oldValue) {
        if (newValue !== oldValue) {
            $scope.formData.contact_input = initformdata.buss_no;
        }
    });

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    //银行-抵押查询-银行类型管理-添加-上传显示文件名称
    $scope.showUploadName = function(template){
        switch(template){
            case "single_template":
                if($scope.formData.single_template){
                    var index = $scope.formData.single_template.lastIndexOf("\/");
                    $scope.formData.single_name = $scope.formData.single_template.substring(index + 1, $scope.formData.single_template.length);
                }
                break;
            case "multi_template":
                if($scope.formData.multi_template){
                    var index = $scope.formData.multi_template.lastIndexOf("\/");
                    $scope.formData.multi_name = $scope.formData.multi_template.substring(index + 1, $scope.formData.multi_template.length);
                }
                break;
            case "template_statement":
                if($scope.formData.template_statement){
                    var index = $scope.formData.template_statement.lastIndexOf("\/");
                    $scope.formData.statement_name = $scope.formData.template_statement.substring(index + 1, $scope.formData.template_statement.length);
                }
                break;
            case "template_loan":
                if($scope.formData.template_loan){
                    var index = $scope.formData.template_loan.lastIndexOf("\/");
                    $scope.formData.loan_name = $scope.formData.template_loan.substring(index + 1, $scope.formData.template_loan.length);
                }
                break;
            case "template_relieve":
                if($scope.formData.template_relieve){
                    var index = $scope.formData.template_relieve.lastIndexOf("\/");
                    $scope.formData.relieve_name = $scope.formData.template_relieve.substring(index + 1, $scope.formData.template_relieve.length);
                }
                break;
            case "import_file":
                if($scope.formData.import_file){
                    var index = $scope.formData.import_file.lastIndexOf("\/");
                    $scope.formData.import_name = $scope.formData.import_file.substring(index + 1, $scope.formData.import_file.length);
                }
                break;
        }
    }
    $scope.showUploadName("single_template");
    $scope.showUploadName("multi_template");
    $scope.showUploadName("template_statement");
    $scope.showUploadName("template_loan");
    $scope.showUploadName("template_relieve");
    $scope.showUploadName("import_file");

    //银行-抵押查询-银行类型管理-删除上传的文件(只清除数据库的数据，文件还存在服务器)
    $scope.deleteUploadFile = function(template){
        switch(template){
            case "single_template":
                $scope.formData.single_template = "";
                $scope.formData.single_name = "";
                break;
            case "multi_template":
                $scope.formData.multi_template = "";
                $scope.formData.multi_name = "";
                break;
            case "template_statement":
                $scope.formData.template_statement = "";
                $scope.formData.statement_name = "";
                break;
            case "template_loan":
                $scope.formData.template_loan = "";
                $scope.formData.loan_name = "";
                break;
            case "template_relieve":
                $scope.formData.template_relieve = "";
                $scope.formData.relieve_name = "";
                break;
        }
    }

    //批量设置时间、工作站
    $scope.setChangeAll = function(row_name, col_name, col_value){
        if(!$scope.formData.row) $scope.formData.row = {};
        for(var i in $scope.formStruct.form_struct[row_name]){
            var value = $scope.formStruct.form_struct[row_name][i];
            if(!$scope.formData.row[value]) {
                $scope.formData.row[value] = {};
            }
            $scope.formData.row[value][col_name] = $scope.formData[col_value];
        }
    }

    $scope.commonSave = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + subUrl, $scope.formData).success(function(_data){
            if(_data.status == 200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if($scope.formStruct.reload_page == "1"){  //一手房-工作台-一手产权代办全部刷新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }
    $scope.commonClose = function(){
        parent.layer.closeAll();
    }
})

//贷前评估内容
formApp.controller("evaluationCtrl", function($scope, $http, postUrl, scopeService){
    $scope.formStruct = formStruct;
    $scope.formData = {};

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.toggleBox = [true, true, true];
    $scope.showBox = function(index, boolean){
        for(var key in $scope.toggleBox){
            $scope.toggleBox[key] = false;
        }
        $scope.toggleBox[index] = boolean;
    }
    $scope.hideBox = function(index, boolean){
        $scope.toggleBox[index] = boolean;
    }
    var initformdata = formStruct.form_data;
    if(initformdata!=""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
    }
    $scope.submitForm = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
            if(_data.status==200){
                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    if(!!formStruct.refresh){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    } else if(!!formStruct.refresh_sub){
                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    } else {
                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                    }
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }
})

	//巡库、核库添加数据
	formApp.controller("inspectAddCtrl",function($scope, $http, postUrl, scopeService){
	    $scope.formData = {};
	    var data = {};
	    $scope.formStruct = formStruct;
	    data.hasShowandhide = true;
	    $scope.formlist = formStruct.form_struct;
	    $scope.formlist1 = formStruct.form_struct1;

	    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
	    $scope.btnText = initbtnText;
	    $scope.btnStatus = false;
	    for(var i=0,len=$scope.formlist.length;i<len;i++){
	        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
	            var dataResult = [];
	            $.each($scope.formlist[i].options,function(n,v){
	                dataResult.push({"text":v,"value":n});
	            });
	            //console.log(dataResult);
	            $scope.formlist[i].options = dataResult;
	        }
	    }
	    // 加入隐藏域作为参数
	    for(var k in $scope.formlist){
	    	var item = $scope.formlist[k];
	    	if(item.type == 'hidden' && !$scope.formData[item.name]){
	    		$scope.formData[item.name] = item.value;
	    	}
	    }
	    
	    var initformdata = formStruct.form_data;
	    if(initformdata!=""){
	        for (var i in initformdata) {
	            $scope.formData[i] = initformdata[i];
	        }
	    }
	    	    
	    //业务员选择
	    $scope.departmentData = $scope.formData.service_type.department_list;
	    $scope.userToggle = false;
	    $scope.departmentName = "";
	    if($scope.formData.service_type.department_name){
	    	$scope.departmentName=$scope.formData.service_type.department_name
	    }
	    $scope.post = true;
	    $scope.toggleUserBox = function(){
	        $scope.userToggle = !$scope.userToggle;
	        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
	            var id = $scope.formData.service_type.salesman_department;
	            postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
	                if(_data.status == 200){
	                	$scope.formData.service_type.user_list = _data.data.items;
	                    $scope.post = false;
	                }else{
	                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
	                        //window.location.reload();
	                    });
	                }
	            });
	        }
	    }
	    $scope.getUserList = function(id, name){
	        $scope.formData.service_type.salesman_department = id;
	        $scope.departmentName = name;
	        $scope.userListPost(id);
	    }
	    $scope.getUserName = function(name,user,id){
		    	$scope.formData[name]=id;
		        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
	    }
	    $scope.userListPost = function(id){
	        $scope.formData.service_type.salesman = "";
	        $scope.formData.service_type.user_name = "";
	        postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
	            if(_data.status == 200){
	            	$scope.formData.service_type.user_list = _data.data.items;
	            }else{
	                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
	                    //window.location.reload();
	                });
	            }
	        });
	    }
	    $scope.hideUserBox = function(){
	        $scope.userToggle = false;
	    }
	    
	    $scope.changeCredit = function(credit){
	    	$scope.formData.companyId=credit.value;
	    }
	    $scope.$watch('formData.companyId',function(newValue,oldValue){
			if(newValue){
				postUrl.events("/warehouse/warehousePledge/options",{'id':newValue,'receiptStatus':2})
						.success(function(_data) {
							$scope.formData.pledges = _data.data;
						});
			}else{
				$scope.formData.pledges = [];
			}
        });
	    
	    $scope.submitForm = function(){
	        $scope.btnText = initbtnText + " 中...";
	        $scope.btnStatus = true;
	        if(!$scope.formData.checkManId){
	        	parent.layer.msg("请选择巡库/核库人",{icon: 2,time:1000},function(){
	                scopeService.safeApply($scope, function () {
	                    $scope.btnText = initbtnText;
	                    $scope.btnStatus = false;
	                });
	            });
	        }else{	        	
	        	postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
		            if(_data.status==200){
		                parent.layer.msg(_data.description,{icon: 1,time:1000},function(){
		                    scopeService.safeApply($scope, function () {
		                        $scope.btnText = initbtnText;
		                        $scope.btnStatus = false;
		                    });
		                    window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
		                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
		                    parent.layer.closeAll();
		                });
		            }else{
		                parent.layer.msg(_data.description,{icon: 2,time:1000},function(){
		                    scopeService.safeApply($scope, function () {
		                        $scope.btnText = initbtnText;
		                        $scope.btnStatus = false;
		                    });
		                });
		            }
		        })
	        }
	    }
	    $scope.closeForm = function(){
	        parent.layer.closeAll();
	    }
	    
	});

	//巡库、核库编辑数据
	formApp.controller("inspectEditCtrl",function($scope, $http, postUrl, scopeService){
	    $scope.formData = {};
	    var data = {};
	    $scope.formStruct = formStruct;
	    data.hasShowandhide = true;
	    $scope.formlist = formStruct.form_struct;

	    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
	    $scope.btnText = initbtnText;
	    $scope.btnStatus = false;

	    for(var i=0,len=$scope.formlist.length;i<len;i++){
	        if($scope.formlist[i].options&&typeof($scope.formlist[i].options[0])=="undefined"){
	            var dataResult = [];
	            $.each($scope.formlist[i].options,function(n,v){
	                dataResult.push({"text":v,"value":n});
	            });
	            //console.log(dataResult);
	            $scope.formlist[i].options = dataResult;
	        }
	    }

	    var initformdata = formStruct.form_data;
	    if(initformdata!=""){
	        for (var i in initformdata) {
	            $scope.formData[i] = initformdata[i];
	        }
	    }
	    // 加入隐藏域作为参数
	    for(var k in $scope.formlist){
	    	var item = $scope.formlist[k];
	    	if(item.type == 'hidden' && !$scope.formData[item.name]){
	    		$scope.formData[item.name] = item.value;
	    	}
	    }
	    
	    //业务员选择
	    $scope.departmentData = $scope.formData.service_type.department_list;
	    $scope.userToggle = false;
	    $scope.departmentName = "";
	    if($scope.formData.service_type.department_name){
	    	$scope.departmentName=$scope.formData.service_type.department_name
	    	if($scope.formData.service_type.user_name){
	    		$scope.formData.service_type.user_name=$scope.departmentName+ "-" +$scope.formData.service_type.user_name;
	    	}
	    }
	    $scope.post = true;
	    $scope.toggleUserBox = function(){
	        $scope.userToggle = !$scope.userToggle;
	        if($scope.formData.service_type.salesman_department && $scope.userToggle && $scope.post){
	            var id = $scope.formData.service_type.salesman_department;
	            postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
	                if(_data.status == 200){
	                	$scope.formData.service_type.user_list = _data.data.items;
	                    $scope.post = false;
	                }else{
	                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
	                        //window.location.reload();
	                    });
	                }
	            });
	        }
	    }
	    $scope.getUserList = function(id, name){
	        $scope.formData.service_type.salesman_department = id;
	        $scope.departmentName = name;
	        $scope.userListPost(id);
	    }
	    $scope.getUserName = function(name,user,id){
		    	$scope.formData[name]=id;
		        $scope.formData.service_type.user_name = $scope.departmentName + "-" + user;
	    }
	    $scope.userListPost = function(id){
	        $scope.formData.service_type.salesman = "";
	        $scope.formData.service_type.user_name = "";
	        postUrl.events("/" + $scope.formData.service_type.getlist_url, {pid: id}).success(function(_data){
	            if(_data.status == 200){
	            	$scope.formData.service_type.user_list = _data.data.items;
	            }else{
	                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
	                    //window.location.reload();
	                });
	            }
	        });
	    }
	    $scope.hideUserBox = function(){
	        $scope.userToggle = false;
	    }
	    $scope.changeCredit = function(credit){
	    	$scope.formData.companyId=credit.value;	
	    }
	    $scope.$watch('formData.companyId',function(newValue,oldValue){
			if(newValue){
				postUrl.events("/warehouse/warehousePledge/options",{'id':newValue,'receiptStatus':2})
						.success(function(_data) {
							$scope.formData.pledges = _data.data;
						});
			}else{
				$scope.formData.pledges = [];
			}
        });
        $scope.$watch('formData.pledgeId',function(newValue,oldValue){
				if(newValue){
					postUrl.events("/warehouse/warehousePledge/detail",{'id':newValue})
							.success(function(_data) {
								$scope.formData.pledge = _data.data;
								$scope.formData.remindAmount=_data.data.no_pay;
								$scope.formData.totalValue=_data.data.totalValue;
								$scope.formData.deposit=_data.data.deposit;
							});
				}else{
					$scope.formData.pledge = null;
					$scope.formData.remindAmount=null;
					$scope.formData.totalValue=null;
					$scope.formData.deposit=null;
				}
            });
	    
	    $scope.submitForm = function(){
	        $scope.btnText = initbtnText + " 中...";
	        $scope.btnStatus = true;
	        if(!$scope.formData.checkManId){
	        	parent.layer.msg("请选择巡库/核库人",{icon: 2,time:1000},function(){
	                scopeService.safeApply($scope, function () {
	                    $scope.btnText = initbtnText;
	                    $scope.btnStatus = false;
	                });
	            });
	        }else{
		        postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
		            if(_data.status==200){
		                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
		                    scopeService.safeApply($scope, function () {
		                        $scope.btnText = initbtnText;
		                        $scope.btnStatus = false;
		                    });
		                    if(!!formStruct.refresh){
		                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
		                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
		                    } else if(!!formStruct.refresh_sub){
		                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
		                    } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
		                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
		                    } else {
		                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
		                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
		                    }
		                    parent.layer.closeAll();
		                });
		            }else{
		                parent.layer.msg(_data.description,{icon: 2,shade: 0.3,time:1500},function(){
		                    scopeService.safeApply($scope, function () {
		                        $scope.btnText = initbtnText;
		                        $scope.btnStatus = false;
		                    });
		                });
		            }
		        })
	        }
	    }
	    $scope.closeForm = function(){
	        parent.layer.closeAll();
	    }
	});
	
	//巡库、核库添加数据
	formApp.controller("prodFeeItemCtrl",function($scope, $http, postUrl, scopeService){
	    $scope.formData = {};
	    var data = {};
	    $scope.formStruct = formStruct;
	    data.hasShowandhide = true;
	    $scope.formlist = formStruct.form_struct;

	    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
	    $scope.btnText = initbtnText;
	    $scope.btnStatus = false;
	    
	    // 加入隐藏域作为参数
	    for(var k in $scope.formlist){
	    	var item = $scope.formlist[k];
	    	if(item.type == 'hidden' && !$scope.formData[item.name]){
	    		$scope.formData[item.name] = item.value;
	    	}
	    }
	    
	    var initformdata = formStruct.form_data;
	    if(initformdata!=""){
	        for (var i in initformdata) {
	            $scope.formData[i] = initformdata[i];
	        }
	    }
	    
	    $scope.getData=function(){
	    	if($scope.formData.chargeType){
	    		var type=$scope.formData.chargeType;
	    		$scope.formData["calcDayType"+type]=$scope.formData["calcDayType"];
	    		$scope.formData["day"+type]=$scope.formData["day"];
	    		$scope.formData["amountType"+type]=$scope.formData["amountType"];
	    		$scope.formData["amountRate"+type]=$scope.formData["amountRate"];
	    		$scope.formData["amountFee"+type]=$scope.formData["amountFee"];
	    	}
	    }
	    
	    $scope.postData=function(){
	    	if($scope.formData.chargeType){
	    		var type=$scope.formData.chargeType;
	    		$scope.formData["calcDayType"]=$scope.formData["calcDayType"+type];
	    		$scope.formData["day"]=$scope.formData["day"+type];
	    		$scope.formData["amountType"]=$scope.formData["amountType"+type];
	    		$scope.formData["amountRate"]=$scope.formData["amountRate"+type];
	    		$scope.formData["amountFee"]=$scope.formData["amountFee"+type];
	    	}
	    }
	    
	    $scope.amount_type_all=angular.copy($scope.formData.amount_type);
	    $scope.amount_type_payed=[];//不包括未还
	    angular.forEach($scope.formData.amount_type,function(d){
	    	if(!d.text.startsWith("未还")){
	    		$scope.amount_type_payed.push(d);
	    	}
	    });
	    $scope.$watch("formData.chargePoint", function(newValue, oldValue){
            if(newValue==1||oldValue==1||newValue != oldValue){
                if(newValue==1){
                	$scope.formData.amount_type=$scope.amount_type_payed;
                }else if(oldValue==1){
                	$scope.formData.amount_type=$scope.amount_type_all;
                }
            }
        })
	    
	    
	    $scope.getData();
	    
	    $scope.submitForm = function(){
	        $scope.btnText = initbtnText + " 中...";
	        $scope.btnStatus = true;
	        
	        $scope.postData();
	        
        	postUrl.events("/"+formStruct.submit_url, $scope.formData).success(function (_data) {
	            if(_data.status==200){
	                parent.layer.msg(_data.description,{icon: 1,time:1000},function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                    window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
	                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                    parent.layer.closeAll();
	                });
	            }else{
	                parent.layer.msg(_data.description,{icon: 2,time:1000},function(){
	                    scopeService.safeApply($scope, function () {
	                        $scope.btnText = initbtnText;
	                        $scope.btnStatus = false;
	                    });
	                });
	            }
	        })
	    }
	    $scope.closeForm = function(){
	        parent.layer.closeAll();
	    }
	    
	});
	

//风控管理-自动分类触发条件配置、规则配置
formApp.controller("clsifyCondCtrl",function($scope, $http, postUrl, scopeService){
    $scope.formStruct = formStruct;
    $scope.formData = {};

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    $scope.formData.condInfo = [
        {"field": "1", "type": "1"}
    ];
    $scope.formData.resultInfo = [
        {}
    ];
    $scope.formStruct.subOptions = [
        {"options": []}
    ];

    var initformdata = formStruct.form_data;
    if(initformdata != ""){
        for (var i in initformdata) {
            $scope.formData[i] = initformdata[i];
        }
        for(var a=0, len=$scope.formData.condInfo.length; a<len; a++){
            angular.forEach($scope.formStruct.clsifyFields, function(x){
                if($scope.formData.condInfo[a]["field"] == x.value){
                    $scope.formStruct.subOptions.push({"options": []});
                    $scope.formStruct.subOptions[a]["options"] = x.options;
                }
            })
        }
    }



    $scope.chnageField = function(index){
        if($scope.formData.condInfo[index]["field"]){
            angular.forEach($scope.formStruct.clsifyFields, function(i){
                if($scope.formData.condInfo[index]["field"] == i.value){
                    $scope.formData.condInfo[index]["type"] = i.type;
                    $scope.formStruct.subOptions[index]["options"] = i.options;
                }
            })
        } else {
            $scope.formData.condInfo[index]["type"] = "";
            $scope.formStruct.subOptions[index]["options"] = [];
        }
    }

    //增加触发条件配置
    $scope.addCondInfo = function(){
        var condInfoObj = {"field": "1", "type": "1"};
        $scope.formData.condInfo.push(condInfoObj);
        $scope.formStruct.subOptions.push({"options": []});
    }
    $scope.deleteCondInfo = function(index){
        $scope.formData.condInfo.splice(index, 1);
        $scope.formStruct.subOptions.splice(index, 1);
    }

    //增加调整规则结果
    $scope.addResultInfo = function(){
        var resultInfoObj = {};
        $scope.formData.resultInfo.push(resultInfoObj);
    }
    $scope.deleteResultInfo = function(index){
        $scope.formData.resultInfo.splice(index, 1);
    }

    $scope.submitForm = function(){
        var subFormData = {};
        for(var att in $scope.formData){
            if(angular.isArray($scope.formData[att])){
                if(typeof $scope.formData[att][0] == "object"){
                    subFormData[att] = angular.toJson($scope.formData[att],true);
                }else {
                    subFormData[att] = $scope.formData[att].join(",");
                }
            }else {
                subFormData[att] = $scope.formData[att];
            }
        }
        var callBack = function(){
            $scope.btnText = initbtnText + " 中...";
            $scope.btnStatus = true;
            postUrl.events("/" + $scope.formStruct.submit_url, subFormData).success(function(_data){
                if(_data.status == 200){
                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                        scopeService.safeApply($scope, function () {
                            $scope.btnText = initbtnText;
                            $scope.btnStatus = false;
                        });
                        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                        parent.layer.closeAll();
                    });
                }else{
                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                        scopeService.safeApply($scope, function () {
                            $scope.btnText = initbtnText;
                            $scope.btnStatus = false;
                        });
                    });
                }
            });
        }
        if($scope.formData.resultInfo && $scope.formData.resultInfo.length > 1){  //分类调整结果
            var len = $scope.formData.resultInfo.length;
            var result = true;
            for(var i=0; i<len; i++){
                for(var j=i+1; j<len; j++){
                    if($scope.formData.resultInfo[i]["grade"] == $scope.formData.resultInfo[j]["grade"]){
                        parent.layer.msg("一个初分值只能选择一次", {icon: 2, shade: 0.3, time: 1500})
                        return result = false;
                    }
                }
            }
            if(result){
                callBack();
            }
        } else {
            callBack();
        }
    }
})
module.exports = formApp;
