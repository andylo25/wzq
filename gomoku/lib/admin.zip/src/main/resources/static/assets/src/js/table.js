require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var tableApp = angular.module("tableApp",["validation", "validation.rule","dyDir","dyService"]);
tableApp.controller("tableCtrl",function($scope,$http,postUrl){

    var nav4 = [];
    // 从父级页面获取4级菜单过滤侧滑页
    angular.forEach(window.parent.menu4, function (item) {  
        if (item['rtype'] != 2) {
        	nav4.push(item);
        }
    })
    $scope.nav4 = nav4;
    
    $scope.pageUrl = location.pathname.slice(1);  //返回URL中的目录和（或）文件名


    //操作说明显示隐藏
    $scope.descriptionToggle = false;
    $scope.toggleDescription = function(){
        $scope.descriptionToggle = !$scope.descriptionToggle;
    }

    //筛选条件显示隐藏
    $scope.filterToggle = false;
    $scope.toggleFilter = function(){
        $scope.filterToggle = !$scope.filterToggle;
        $scope.filterListData = {};
    }

    layer.load(1);
    $scope.srcData = {};
    $scope.filterListData = {};
    /****************
        *获取列表数据
        *params：1、url =>请求地址；
                 2、params：参数，
                    （1）、srcData =>搜索框数据；
                    （2）、filterListData =>筛选内容数据；
                    （3）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        var dataUrlParams = {};
        var dataUrl = url.slice(1).split('&');
        for(var key in dataUrl){  //判断不是第一个的第四级菜单是否需要刷新(no_refresh为1则不需要刷新)
            if(key > 0){
                var temp = dataUrl[key].split('=');
                switch(temp[0]){
                    case 'no_refresh':
                        dataUrlParams.no_refresh = temp[1];
                        break;
                }
            }
        }

        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.snode_id = _data.data.snode_id;  //列表id
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            $scope.operation_instruction = _data.data.operation_instruction;  //操作说明
            $scope.checkvalue = [];  //清空已选的选项
            $scope.checkAll = false;  //取消全选的选中状态
            layer.closeAll("loading");

            if(dataUrlParams.no_refresh != "1"){  //判断不是第一个的第四级菜单是否需要刷新(no_refresh为1则不需要刷新)
                window.top.reloadMsg(_data.data.total_items);   //更新左侧菜单msg数据
            }

            $scope.formData = {};
            $scope.formData.limit = $scope.Epage || 20;

            $scope.topInfoData = _data.data.top_info;  //营销台账、经办台账统计信息
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct!="undefined"&&table_struct!=""){
    	if(table_struct.search && angular.isArray(table_struct.search)){
    		$scope.search = table_struct.search[0]; //搜索框
    	}else{
    		$scope.search = table_struct.search; //搜索框
    	}
        $scope.filter = table_struct.filter; //数据筛选
        $scope.file = table_struct.file; //工作台-附件管理列表需要
        $scope.fields = table_struct.fields; //待我处理-待处理的异常
        $scope.showPager = table_struct.pager; //是否显示分页
        $scope.pageOptions = table_struct.page_options; //分页条数的配置项
        $scope.toollist = table_struct.toollist; //工具栏
        $scope.rowLink = table_struct.rowLink;  //报表弹出页面url
        $scope.rowLinkTitle = table_struct.rowLinkTitle;  //报表弹出页面标题
        $scope.tableHeader = table_struct.tableHeader; //列表表头
        $scope.checkAll = table_struct.checkAll;  //全选checkbox
        $scope.listUrl = table_struct.listUrl;
        $scope.rightUrl = table_struct.rightUrl;
        $scope.checkId = table_struct.check ? true : false;
        $scope.checkIName = table_struct.check ? table_struct.check : "id"; //用作选中列表的辨识

        $scope.topInfo = table_struct.top_info;  //营销台账、经办台账统计信息

        $scope.readUrl = table_struct.read_url;

        if($scope.listUrl){
            $scope.getData($scope.listUrl); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, $scope.filterListData, {"page": currentPage, "limit": itemsPerPage});
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, $scope.filterListData, {"page": 1, "limit": itemsPerPage});
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    /*** 处理搜索栏搜索数据 ***/
    $scope.srcSubmit = function(){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20});
        var url = $scope.listUrl;
        $scope.filterToggle = false;
        $scope.getData(url, params);
    }
    $scope.srcKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            $scope.srcSubmit();
        }
    }

    //点击选中列表=>单选
    $scope.radioBtn = function (val, $event) {
        $event.stopPropagation();
        if ($scope.checkId) {
            $scope.radioList = [];
            $scope.radioList[val] = !$scope.radioList[val];
            $scope.checkvalue = val; //选中某一行后，传递给后台的id值
        } else {
            return false;
        }
    };

    //全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.tableB, function(i){
                i.checked = true;
                $scope.checkvalue.push(i[$scope.checkIName]);
            })
        } else {
            angular.forEach($scope.tableB, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.tableB, function(i){
            var index = $scope.checkvalue.indexOf(i[$scope.checkIName]);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i[$scope.checkIName]);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.tableB.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

    //筛选数据的区间操作
    for(var keys in $scope.tableHeader){
        if(!!$scope.tableHeader[keys].filter){
            if($scope.tableHeader[keys].filter.type == "multi_input"){
                $scope.tableHeader[keys].filter.area_start = "";
                $scope.tableHeader[keys].filter.area_end = "";
                $scope.tableHeader[keys].filter.showMe = false;
            }
        }
    }
    $scope.toggleArea = function(index){
        for(var keys in $scope.tableHeader){
            if(!!$scope.tableHeader[keys].filter){
                if($scope.tableHeader[keys].filter.type == "multi_input"){
                    $scope.tableHeader[keys].filter.showMe = false;
                }
            }
        }
        $scope.tableHeader[index].filter.showMe = true;
    }
    $scope.mergeArea = function(name, index){
        var area_start = $scope.tableHeader[index].filter.area_start >= 0 ? $scope.tableHeader[index].filter.area_start : "";
        var area_end = $scope.tableHeader[index].filter.area_end >= 0 ? $scope.tableHeader[index].filter.area_end : "";
        if(area_start >= 0 && area_end >= 0 && area_start != null && area_end != null){
            $scope.filterListData[name] = area_start + "-" + area_end;
        } else {
            $scope.filterListData[name] = "";
        }
        $scope.tableHeader[index].filter.showMe = false;

        //构建筛选数据，包含筛选栏，分页页码
        var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20});
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    $scope.cancelArea = function(index){
        $scope.tableHeader[index].filter.showMe = false;
    }

    //筛选数据的下拉框操作
    $scope.selectChange = function(){
        //构建筛选数据，包含筛选栏，分页页码
        var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20});
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    //筛选数据的input回车操作
    $scope.inputKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            //构建筛选数据，包含筛选栏，分页页码
            var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20});
            var url = $scope.listUrl;
            $scope.getData(url, params);
        }
    }

    //排序
    $scope.orderDate = function(name){
        var order_name = '';
        if(name != ''){
            var order_name = name;
        }
        //构建筛选数据，包含筛选栏，分页页码
        var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20,"order":order_name}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    //筛选数据的日期选择回调操作
    $scope.rangeDate = function(){
        //构建筛选数据，包含筛选栏，分页页码
        var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20});
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

});

//银行业务表格
tableApp.controller("tableSingleCtrl",function($scope,$http,postUrl){

	var nav4 = [];
    // 从父级页面获取4级菜单过滤侧滑页
    angular.forEach(window.parent.menu4, function (item) {  
        if (item['rtype'] != 2) {
        	nav4.push(item);
        }
    })
    $scope.nav4 = nav4;
    
    $scope.pageUrl = location.pathname.slice(1);  //返回URL中的目录和（或）文件名


    //筛选条件显示隐藏
    $scope.filterToggle = false;
    $scope.toggleFilter = function(){
        $scope.filterToggle = !$scope.filterToggle;
        $scope.filterListData = {};
    }

    layer.load(1);
    $scope.srcData = {};
    $scope.filterListData = {};
    /****************
        *获取列表数据
        *params：1、url =>请求地址；
                 2、params：参数，
                    （1）、srcData =>搜索框数据；
                    （2）、filterListData =>筛选内容数据；
                    （3）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        var dataUrlParams = {};
        var dataUrl = url.slice(1).split('&');
        for(var key in dataUrl){  //判断不是第一个的第四级菜单是否需要刷新(no_refresh为1则不需要刷新)
            if(key > 0){
                var temp = dataUrl[key].split('=');
                switch(temp[0]){
                    case 'no_refresh':
                        dataUrlParams.no_refresh = temp[1];
                        break;
                }
            }
        }

        postUrl.events("/" + url, params).success(function (_data) {
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.snode_id = _data.data.snode_id;  //列表id
            $scope.Total = _data.data.total_items; //总条数
            $scope.Pages = _data.data.total_pages; //总页数
            $scope.Epage = _data.data.epage; //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            $scope.checkvalue = [];  //清空已选的选项
            $scope.checkAll = false;  //取消全选的选中状态
            layer.closeAll("loading");

            if(dataUrlParams.no_refresh != "1"){  //判断不是第一个的第四级菜单是否需要刷新(no_refresh为1则不需要刷新)
                window.top.reloadMsg && window.top.reloadMsg(_data.data.total_items);   //更新左侧菜单msg数据
            }
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct!="undefined"&&table_struct!=""){
    	if(table_struct.search && angular.isArray(table_struct.search)){
    		$scope.search = table_struct.search[0]; //搜索框
    	}else{
    		$scope.search = table_struct.search; //搜索框
    	}
        $scope.filter = table_struct.filter; //数据筛选
        $scope.showPager = table_struct.pager; //是否显示分页
        $scope.pageOptions = table_struct.page_options; //分页条数的配置项
        $scope.toollist = table_struct.toollist; //工具栏
        $scope.rowLink = table_struct.rowLink;  //报表弹出页面url
        $scope.rowLinkTitle = table_struct.rowLinkTitle;  //报表弹出页面标题
        //$scope.headerData = table_struct.header_data; //头部表单数据
        $scope.selectOption = table_struct.select_option; //头部下拉框选项


        $scope.formData = {};
        $scope.formList = table_struct.header_data;
        var initformdata = $scope.formList;
        if(initformdata != ""){
            for (var key in initformdata) {
                $scope.formData[key] = initformdata[key];
            }
        }

        // $scope.formData.limit = $scope.itemsPerPage || 20;

        $scope.filterArray = table_struct.filter_array; //头部筛选内容
        $scope.tableHeader = table_struct.tableHeader; //列表表头

        $scope.firstTitle = table_struct.first_title; //数据统计的表格第一个标题

        $scope.listUrl = table_struct.listUrl;
        $scope.rightUrl = table_struct.rightUrl;
        $scope.checkId = table_struct.check ? true : false;
        $scope.checkIName = table_struct.check ? table_struct.check : "id"; //用作选中列表的辨识
        if($scope.listUrl){
            $scope.getData($scope.listUrl, $scope.formData); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, $scope.filterListData, {"page": currentPage, "limit": itemsPerPage}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, $scope.filterListData, {"page": 1, "limit": itemsPerPage}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    /*** 处理搜索栏搜索数据 ***/
    $scope.srcSubmit = function(){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, $scope.srcData, {"page": $scope.currentPage || 1, "limit": $scope.itemsPerPage || 20}, $scope.formData);
        var url = $scope.listUrl;
        $scope.filterToggle = false;
        $scope.getData(url, params);
    }
    $scope.srcKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            $scope.srcSubmit();
        }
    }

    //点击选中列表=>单选
    $scope.radioBtn = function (val, $event) {
        $event.stopPropagation();
        if ($scope.checkId) {
            $scope.radioList = [];
            $scope.radioList[val] = !$scope.radioList[val];
            $scope.checkvalue = val; //选中某一行后，传递给后台的id值
        } else {
            return false;
        }
    };

    //全选
    $scope.checkvalue = [];
    $scope.selectAll = function(){
        if($scope.checkAll){
            $scope.checkvalue = [];
            angular.forEach($scope.tableB, function(i){
                i.checked = true;
                $scope.checkvalue.push(i[$scope.checkIName]);
            })
        } else {
            angular.forEach($scope.tableB, function(i){
                i.checked = false;
                $scope.checkvalue = [];
            })
        }
    };
    $scope.selectOne = function($event){
        $event.stopPropagation();
        angular.forEach($scope.tableB, function(i){
            var index = $scope.checkvalue.indexOf(i[$scope.checkIName]);
            if(i.checked && index === -1){
                $scope.checkvalue.push(i[$scope.checkIName]);
            } else if (!i.checked && index !== -1){
                $scope.checkvalue.splice(index, 1);
            };
        })

        if($scope.tableB.length === $scope.checkvalue.length){
            $scope.checkAll = true;
        } else {
            $scope.checkAll = false;
        }
    }

    $scope.selectData = function(key, value){
        $scope.formData[key] = value;
        var params = angular.extend({},$scope.formData);
        var url = $scope.listUrl;
        var toollist = [];
        if(table_struct.select_type == "2"){
            window.parent.document.getElementById("rightcontent").src = "/"+ location.pathname.slice(1) + "?" + key + "=" + value;
        }
        if(table_struct.select_operate != "" && typeof table_struct.select_operate != "undefined"){
            var select_operate = table_struct.select_operate[$scope.formData[key]];
            for(var i in table_struct.toollist){
                if(select_operate.indexOf(Number(i)) > -1){
                    toollist.push(table_struct.toollist[i]);
                }
            }
            $scope.toollist = toollist;
        }
        $scope.getData(url, params);
    }
    $scope.filterItem = {};
    $scope.filterData = function(key, index){
        $scope.filterItem[key] = index;
        $scope.formData[key] = index;
        var toollist = [];
        if(table_struct.status_operate != "" && typeof table_struct.status_operate != "undefined"){
            var status_operate = table_struct.status_operate[$scope.formData[key]];
            for(var i in table_struct.toollist){
                if(status_operate.indexOf(Number(i)) > -1){
                    toollist.push(table_struct.toollist[i]);
                }
            }
            $scope.toollist = toollist;
        }

        var params = angular.extend({},$scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    for(var j in $scope.selectOption){
        if($scope.formList[j] !== "" && typeof $scope.formList[j] != "undefined"){
            var current = $scope.formList[j];
            if(table_struct.select_type != "2"){
                $scope.selectData(j, current)  //初始化显示操作的类型
            }
        }
    }
    for(var j in $scope.filterArray){
        if($scope.formList[j] !== "" && typeof $scope.formList[j] != "undefined"){
            var current = $scope.formList[j];
            $scope.filterData(j, current)  //初始化显示操作的类型
        }
    }


    //筛选数据的区间操作
    for(var keys in $scope.tableHeader){
        if(!!$scope.tableHeader[keys].filter){
            if($scope.tableHeader[keys].filter.type == "multi_input"){
                $scope.tableHeader[keys].filter.area_start = "";
                $scope.tableHeader[keys].filter.area_end = "";
                $scope.tableHeader[keys].filter.showMe = false;
            }
        }
    }
    $scope.toggleArea = function(index){
        for(var keys in $scope.tableHeader){
            if(!!$scope.tableHeader[keys].filter){
                if($scope.tableHeader[keys].filter.type == "multi_input"){
                    $scope.tableHeader[keys].filter.showMe = false;
                }
            }
        }
        $scope.tableHeader[index].filter.showMe = true;
    }
    $scope.mergeArea = function(name, index){
        var area_start = $scope.tableHeader[index].filter.area_start >= 0 ? $scope.tableHeader[index].filter.area_start : "";
        var area_end = $scope.tableHeader[index].filter.area_end >= 0 ? $scope.tableHeader[index].filter.area_end : "";
        if(area_start >= 0 && area_end >= 0 && area_start != null && area_end != null){
            $scope.filterListData[name] = area_start + "-" + area_end;
        } else {
            $scope.filterListData[name] = "";
        }
        $scope.tableHeader[index].filter.showMe = false;

        //构建筛选数据，包含筛选栏，分页页码
        var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    $scope.cancelArea = function(index){
        $scope.tableHeader[index].filter.showMe = false;
    }

    //筛选数据的下拉框操作
    $scope.selectChange = function(){
        //构建筛选数据，包含筛选栏，分页页码
        var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    //筛选数据的input回车操作
    $scope.inputKeyup = function(e){
        var keycode = window.event ? e.keyCode : e.which;
        if(keycode == 13){
            //构建筛选数据，包含筛选栏，分页页码
            var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20}, $scope.formData);
            var url = $scope.listUrl;
            $scope.getData(url, params);
        }
    }

    //排序
    $scope.orderDate = function(name){
        var order_name = '';
        if(name != ''){
            var order_name = name;
        }
        //构建筛选数据，包含筛选栏，分页页码
        var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20,"order":order_name}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }

    //筛选数据的日期选择回调操作
    $scope.rangeDate = function(){
        //构建筛选数据，包含筛选栏，分页页码
        var params = angular.extend({}, $scope.filterListData, {"page": $scope.currentPage || 1, "limit":$scope.itemsPerPage || 20}, $scope.formData);
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
});

//业务通知列表------先完成了静态页，未添加数据
tableApp.controller("noticeCtrl", function($scope, $http, postUrl){

    $scope.nav4 = window.parent.menu4;  //从父级页面获取的4级菜单
    $scope.pageUrl = location.pathname.slice(1);  //返回URL中的目录和（或）文件名

    layer.load(1);
    /****************
        *获取列表数据
        *params：1、url =>请求地址；,
                 2、params：参数
                    （1）、page =>页码参数
    *****************/
    $scope.getData = function(url, params){
        var dataUrlParams = {};
        var dataUrl = url.slice(1).split('&');
        for(var key in dataUrl){  //判断不是第一个的第四级菜单是否需要刷新(no_refresh为1则不需要刷新)
            if(key > 0){
                var temp = dataUrl[key].split('=');
                switch(temp[0]){
                    case 'no_refresh':
                        dataUrlParams.no_refresh = temp[1];
                        break;
                }
            }
        }

        postUrl.events("/" + url, params).success(function(_data){
            $scope.tableData = _data.data;
            $scope.tableB = _data.data.items;
            $scope.Total = _data.data.total_items;  //总条数
            $scope.Pages = _data.data.total_pages;  //总页数
            $scope.Epage = _data.data.epage;  //每页条数
            $scope.reloadPage = _data.data.page; //当前页
            layer.closeAll("loading");

            if(dataUrlParams.no_refresh != '1'){  //判断不是第一个的第四级菜单是否需要刷新(no_refresh为1则不需要刷新)
                window.top.reloadMsg(_data.data.total_items);   //更新左侧菜单msg数据
            }
        })
    }

    //var url = "/tablelist.php"; //请求数据需要用到的接口，一般是默认用window.location.href
    //第一次请求，请求页面和页面结构数据，构建列表结构和自动请求列表的数据
    if(typeof table_struct != "undefined" && table_struct != ""){
        $scope.listUrl = table_struct.listUrl;
        $scope.rightUrl = table_struct.rightUrl;
        $scope.showPager = table_struct.pager; //是否显示分页
        $scope.pageOptions = table_struct.page_options; //分页条数的配置项

        $scope.readUrl = table_struct.read_url;
        $scope.readId = table_struct.read_id;

        if($scope.listUrl){
            $scope.getData($scope.listUrl); //自动请求第一次列表的数据
        }
        layer.closeAll("loading");
    }

    /*** 分页操作 ***/
    $scope.gotoPage = function(currentPage, itemsPerPage){
        if(!itemsPerPage){
            itemsPerPage = $scope.Epage;
        }
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, {"page": currentPage, "limit": itemsPerPage});
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
    //一页显示条数操作
    $scope.perChange = function(itemsPerPage){
        //构建搜索数据，包含搜索栏，分页页码
        var params = angular.extend({}, {"page": 1, "limit": itemsPerPage});
        var url = $scope.listUrl;
        $scope.getData(url, params);
    }
});

//ng-bind-html后台返回html数据格式的过滤器
tableApp.filter("to_trusted", ["$sce", function($sce){
    return function(text){
        return $sce.trustAsHtml(text || "");
    };
}]);

module.exports = tableApp;
