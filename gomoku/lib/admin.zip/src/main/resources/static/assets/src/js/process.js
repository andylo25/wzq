/*
* 业务设置-业务管理-业务流程
*/
require("./dyDirective.js");
require("./dyService.js");
var processApp = angular.module("processApp", ["dyDir", "dyService"]);


//银行-阶段担保业务-流程配置
processApp.controller("bankFlowsCtrl", function($scope, $http, $location, postUrl, getUrlParams, scopeService){

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    for(var d in formStruct){
        if(formStruct[d]["role"]){
            formStruct[d]["role"] = formStruct[d]["role"].split(",");  //字符串转换成字符串数组  "1,2,3" ==> ["1","2","3"]
            formStruct[d]["role"] = formStruct[d]["role"].map(function(data){
                return +data;  //["1","2","3"] ==> [1,2,3]
            });
        }
    }

    $scope.listData = formStruct;  //节点列表数据
    $scope.memberData = memberData;  //组合数据
    $scope.departmentData = departmentData;  //部门数据
    $scope.roleData = roleData;  //角色数据
    $scope.defId = defId;  //流程定义id
    $scope.saveUrl = url;

    for(var j in $scope.listData){
        if($scope.listData[j]["level"] > 0 && $scope.listData[j]["level"] < 99){
            $scope.listData[j]["level"] = j;
        }
    }

    //添加节点
    $scope.addNode = function(index){
        var domObj = {
            "node_name": "审核",
            "type": "2",
            "role": [],
            "roleNameStr": "",
            "roleNameArray": [],
            "showMe": false,
            "roleNameStr": "",
            "roleNameArray": [],
            "assignRole": [],  //指定角色
            "assignData": [{"id": "1", "name": "指定经办人"}],  //指定角色数据
            "single_role": ""
        };
        $scope.listData.splice(index+1, 0, domObj);
    }

    //删除节点(需重新排序level值)
    $scope.deleteNode = function(index){
        $scope.listData.splice(index, 1);
    }

    //任务手动、自动分配切换
    $scope.changeAuto = function(){
        if($scope.listData[1].open == true){
            $scope.listData[1].auto = false;
        } else {
            $scope.listData[1].auto = true;
        }
    }

    //获取url的参数
    getUrlParams.events();

    //选择角色-显示
    $scope.showRoleBox = function(index, id){
        for(var key in $scope.listData){
            $scope.listData[key]["showMe"] = false;  //隐藏所有下拉内容
        }
        $scope.listData[index]["showMe"] = true;  //点击的当前下拉内容显示
        $scope.department = id;  //重置角色选中的位置
    }
    //选择角色-隐藏
    $scope.hideRoleBox = function(index){
        $scope.listData[index]["showMe"] = false;  //关闭下拉内容
    }

    //清空选择角色
    $scope.clearRoleBox = function(index){
        $scope.listData[index]["role"] = [];
        $scope.listData[index]["roleNameStr"] = "";
        $scope.listData[index]["roleNameArray"] = [];

        $scope.listData[index]["assignRole"] = [];
        $scope.listData[index]["assignData"][0]["checked"] = false;
        // $scope.listData[index]["assignData"][1]["checked"] = false;
    }

    //选择角色-获取
    $scope.getRoleList = function(id){
        $scope.department = id;
    }
    //选择角色-默认
    for(var l in $scope.listData){
        $scope.listData[l]["roleNameStr"] = "";
        $scope.listData[l]["roleNameArray"] = [];
        $scope.listData[l]["assignRole"] = [];  //指定角色
        $scope.listData[l]["assignData"] = [{"id": "1", "name": "指定经办人"}];  //指定角色数据
        $scope.listData[l]["single_role"] = "";
        var role = $scope.listData[l]["role"];
        for(var r in role){
            if(role[r] == 1){
                $scope.listData[l]["assignData"][0]["checked"] = true;
                $scope.listData[l]["roleNameStr"] = "指定角色-指定经办人";
                $scope.listData[l]["assignRole"] = [1];
            } else {
                var role_data = $scope.roleData[role[r]],
                department_data = role_data ? $scope.departmentData[role_data["department_id"]] : "",
                role_name = (department_data ? (department_data["name"] + "-") : "") + (role_data ? role_data["name"] : "");  //部门-角色
                // role_name = role_data ? role_data["name"] : "";  //角色
                $scope.listData[l]["roleNameArray"].push(role_name);
                $scope.listData[l]["roleNameStr"] = $scope.listData[l]["roleNameArray"].join("、");
                $scope.listData[l]["single_role"] = role[r];
            }
        }
    }

    $scope.getCheckId = function(role, id){
        if(role && role != "" && typeof role != "undefined"){
            if(typeof role == "string"){
                role = role.split(",");  //字符串转换成字符串数组  "1,2,3" ==> ["1","2","3"]
                role = role.map(function(data){
                    return +data;  //["1","2","3"] ==> [1,2,3]
                })
            }
            if(role.indexOf(Number(id)) > -1){
                return true;
            }
        }
    }

    //指定角色-选择
    $scope.assignRoleOperate = function(cur, array, id, name){
        var idx = array["assignRole"].indexOf(id);
        var indexs = array["roleNameArray"].indexOf("指定角色-" + name);
        array["role"] = [];  //清空选择的角色id
        array["roleNameArray"] = [];  //清空选择的角色名称
        array["roleNameStr"] = "";
        for(var i in array["assignData"]){
            array["assignData"][i].checked = false;
        }
        if(idx > -1){
            array["assignRole"].splice(idx, 1);
            array["role"].splice(idx, 1);
            array["assignData"][cur].checked = false;
            array["roleNameArray"].splice(indexs, 1);
        } else {
            array["assignRole"] = [];
            array["role"] = [];
            array["assignRole"].push(id);
            array["role"].push(id);
            array["assignData"][cur].checked = true;
            array["roleNameArray"].push("指定角色-" + name);
        }
        array["roleNameStr"] = array["roleNameArray"].join("、");  //生成选择的角色
    }

    //选择角色-选择(单选)
    $scope.getRoleName = function(array, parent, child){
        array["role"] = [];
        array["roleNameStr"] = "";
        array["roleNameArray"] = [];
        array["role"].push(Number(child["id"]));
        array["roleNameArray"].push(parent["name"] + "-" + child["name"]);  //部门-角色
        // array["roleNameArray"].push(child["name"]);  //角色
        array["roleNameStr"] = array["roleNameArray"].join("、");  //生成选择的角色
    }

    //选择角色-选择(多选)
    $scope.getRoles = function(array, child){
        var index = array["role"].indexOf(Number(child["id"]));
        var indexs = array["roleNameArray"].indexOf(child["name"]);
        if(index > -1){
            array["role"].splice(index, 1);
            array["roleNameArray"].splice(indexs, 1);
        } else {
            array["role"].push(Number(child["id"]));
            array["roleNameArray"].push(child["name"]);
        }
        array["roleNameStr"] = array["roleNameArray"].join("、");  //生成选择的职位
    }

    //保存设置
    $scope.saveBusinessSet = function(){
        for(var s in $scope.listData){
            if($scope.listData[s]["role"] instanceof Array && $scope.listData[s]["role"].length != 0){
                $scope.listData[s]["role"] = $scope.listData[s]["role"].join(",");
            }
        }
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
        postUrl.events("/" + $scope.saveUrl, {node_list: angular.toJson($scope.listData, true),id:$scope.defId}).success(function(_data){
            if(_data.status == 200){
                layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                    window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        })
    }

    //取消设置
    $scope.cancelSet = function(){
        window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
    }
    $scope.closeForm = function(){
        parent.layer.closeAll();
    }
})

module.exports = processApp;