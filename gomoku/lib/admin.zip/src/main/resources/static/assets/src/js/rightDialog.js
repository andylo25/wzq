/*
* 侧滑页js
*/
require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var rightDiaApp = angular.module("rightDiaApp", ["validation", "validation.rule", "dyDir", "dyService"]);

//侧滑页
rightDiaApp.controller("rightDiaCtrl", function($scope, $http, $location, postUrl,scopeService, getUrlParams, $parse){
    $scope.formData = formStruct.form_data || {};
    $scope.formStruct = formStruct;
    
    getUrlParams.events();

    $scope.tabName = "info";
    $scope.tabChange = function(type){
        $scope.tabName = type;
    }

    //获取侧滑头部事件按钮
    for(var i in $scope.formStruct.listUrl){
        if($scope.pageUrl_ == $scope.formStruct.listUrl[i].data){
            $scope.listButton = $scope.formStruct.listUrl[i].button;
            $scope.listTableButton = $scope.formStruct.listUrl[i].tableBtns;
            $scope.defaultTab = $scope.formStruct.listUrl[i].name;
        }
    }
    
    $scope.parseVal = function(expre,conte){
    	if(expre.startsWith('=')){
    		if(conte){
    			return $parse(expre.substring(1))(conte)
    		}else{
    			return $parse(expre.substring(1))($scope.formData)
    		}
    	}
    	if(conte){
    		return $parse(expre)(conte);
    	}
    	return $scope.$eval('formData.'+expre);
	}

})


module.exports = rightDiaApp;
