/*
* 公积金业务js
*/
require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var fundApp = angular.module("fundApp", ["validation", "validation.rule", "dyDir", "dyService"]);

//工作台-业务管理
fundApp.controller("fundInfoCtrl", function($scope, $http, $location, postUrl, getUrlParams){
    $scope.formData = {};
    $scope.formStruct = formStruct;
    $scope.formStruct.type = 1;
    if($scope.formStruct.company_role_type=='4'){
    	$scope.formStruct.type = 2;
    }else if($scope.formStruct.company_role_type=='5'){
    	$scope.formStruct.type = 3;
    }else if($scope.formStruct.company_role_type=='6'){
    	//普通企业
    	$scope.formStruct.type = 2;
    }else if($scope.formStruct.company_role_type=='7'){	
    	$scope.formStruct.type = 5;
    }
    //获取url的参数
    getUrlParams.events();

    $scope.tabName = "info";
    $scope.tabChange = function(type){
        $scope.tabName = type;
    }

    //编辑基本信息
    $scope.editInfo = function(url, title){
        parent.layer.open({
            type: 2,
            title: title ? title : "编辑",
            shadeClose: false,
            maxmin: true,
            shade: 0.3,
            area: ["750px", "650px"],
            content: url + "?id=" + $scope.formStruct.form_data.contract.id
        });
    }

    //获取侧滑头部事件按钮
    for(i in $scope.formStruct.listUrl){
        if($scope.pageUrl_ == $scope.formStruct.listUrl[i].data){
            $scope.listButton = $scope.formStruct.listUrl[i].button;
            $scope.tableBtns = $scope.formStruct.listUrl[i].tableBtns;
        }
    }

    //公积金业务编辑
    $scope.editMulti = function(url, title){
        parent.layer.open({
            type: 2,
            title: title || "修改",
            shadeClose: false,
            maxmin: true,
            shade: 0.3,
            area: ["750px", "650px"],
            content: "/" + url+"?id="+$scope.formStruct.company_id
        });
    }

    //侧滑关闭
    $scope.hideRightDetail = function(){
        if($scope.params.slide == 3){
            $("#subSlideRight", parent.document).animate({right: "-920px"}, 500, function(){  //三级侧滑
                window.parent.document.getElementById("subRightDialog").src = "";
            });
        } else {
            $("#frameSlideRight", parent.document).animate({right: "-920px"},500);  //一级侧滑
        }
    }
    //删除附件
    $scope.deleteMaterial = function(id,index){
    	parent.layer.confirm("确认删除附件？", {
            time: 0, //不自动关闭
            icon: 3,
            shade: 0.3,
            title: "确认",
            btn: ["确定", "取消"]
        }, function(){
	    	postUrl.events("/system/company/deleteMaterial",{'id':id}).success(function (_data) {
	            if(_data.status==200){
	                parent.layer.msg(_data.description,{icon: 1,shade: 0.3,time:1000},function(){
	                	$scope.formStruct.documents.splice(index, 1);
	                	$scope.$apply(function () {
                            $scope.formStruct.documents = $scope.formStruct.documents;
                        });
	                    parent.layer.closeAll();
	                });
	            } 
	    	});
        });
    }
})

//预览打印弹窗
fundApp.controller("printCtrl", function($scope, $http, $location, postUrl){
    $scope.formStruct = formStruct;
    $scope.closePrint = function(){
        parent.layer.closeAll();
    }
    $scope.closePrintWindow = function(){
        window.close();
    }
})

module.exports = fundApp;
