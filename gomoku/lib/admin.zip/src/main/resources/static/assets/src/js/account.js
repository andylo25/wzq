/*
* 账户系统
*/
require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var accountApp = angular.module("accountApp", ["validation", "validation.rule", "dyDir", "dyService"]);

//账户系统-额度管理-分配限额
accountApp.controller("allotLimitCtrl", function($scope, $http, postUrl, scopeService){
    $scope.formStruct = formStruct;
    // $scope.formData = {};
    var subUrl = formStruct.submit_url;//获取提交地址

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    // 初始化
    $scope.formStruct.form_data_old = {};
    for(var t in $scope.formStruct.form_struct){
        if($scope.formStruct.form_struct[t]["type"] == "input"){
            var name = $scope.formStruct.form_struct[t]["name"];
            $scope.formStruct.form_data_old[name] = $scope.formStruct.form_data[name];
            $scope.formStruct.form_data[name] = 0;
        }
    }

    $scope.limitTotal = 0;
    $scope.getLimit = function(){
        $scope.limitTotal = 0;
        for(var t in $scope.formStruct.form_struct){
            if($scope.formStruct.form_struct[t]["type"] == "input"){
                var name = $scope.formStruct.form_struct[t]["name"];
                $scope.limitTotal += Number($scope.formStruct.form_data[name]);
            }
        }
    }
    $scope.getLimit();

    $scope.saveLimit = function(){
        if(Number($scope.limitTotal) > Number($scope.formStruct.form_data.totalAvali)){
            parent.layer.msg("平台可授信金额不足，请先添加平台授信", {icon: 2, shade: 0.3, time: 3000});
        } else {
        	parent.layer.confirm("确定要重新进行分配限额吗？", {
                time: 0, //不自动关闭
                icon: 3,
                shade: 0.3,
                title: "确认",
                btn: ["确定", "取消"]
            }, function(){
        		$scope.btnText = initbtnText + " 中...";
        		$scope.btnStatus = true;
        		postUrl.events("/" + subUrl, $scope.formStruct.form_data).success(function(_data){
        			if(_data.status == 200){
        				parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
        					scopeService.safeApply($scope, function () {
        						$scope.btnText = initbtnText;
        						$scope.btnStatus = false;
        					});
        					top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
        					parent.layer.closeAll();
        				});
        			}else{
        				parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
        					scopeService.safeApply($scope, function () {
        						$scope.btnText = initbtnText;
        						$scope.btnStatus = false;
        					});
        				});
        			}
        		});
        	});
        }
    }
})


//查看
accountApp.controller("viewCtrl", function($scope, $http, postUrl, scopeService){
    $scope.formStruct = formStruct;
})


//ng-bind-html后台返回html数据格式的过滤器
accountApp.filter("to_trusted", ["$sce", function($sce){
    return function(text){
        return $sce.trustAsHtml(text || "");
    };
}]);

module.exports = accountApp;