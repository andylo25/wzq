/*!
 * Created By:xihun;
 * Created Time:2016-11-07;
 * 网站公用指令
 */
require("./plugins/angular-pagination.min.js");
require("./dyService.js");
require("./dyFilters.js");
require("./plugins/uploaderFile/angular-file-upload.js");
var dyDir = angular.module("dyDir", ["angularPagination","dyService","dyFilters","angularFileUpload"])
    .directive("dyValicode", function(scopeService) { //图形验证码
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                scope.valicode = '/common/public/getImageCode?' + Math.random();
                element.click(function(){
                    scopeService.safeApply(scope, function() {
                        scope.valicode = '/common/public/getImageCode?' + Math.random();
                    });
                });
                
            }
        }
    })
    //复选框指令
    .directive('checklistModel', ['$parse', '$compile', function ($parse, $compile) {
        // contains
        function contains(arr, item, comparator) {
            if (angular.isArray(arr)) {
                for (var i = arr.length; i--;) {
                    if (comparator(arr[i], item)) {
                        return true;
                    }
                }
            }
            return false;
        }

        // add
        function add(arr, item, comparator) {
            arr = angular.isArray(arr) ? arr : [];
            if (!contains(arr, item, comparator)) {
                arr.push(item);
            }
            return arr;
        }

        // remove
        function remove(arr, item, comparator) {
            if (angular.isArray(arr)) {
                for (var i = arr.length; i--;) {
                    if (comparator(arr[i], item)) {
                        arr.splice(i, 1);
                        break;
                    }
                }
            }
            return arr;
        }

        // http://stackoverflow.com/a/19228302/1458162
        function postLinkFn(scope, elem, attrs) {
            // exclude recursion, but still keep the model
            var checklistModel = attrs.checklistModel;
            attrs.$set("checklistModel", null);
            // compile with `ng-model` pointing to `checked`
            $compile(elem)(scope);
            attrs.$set("checklistModel", checklistModel);

            // getter / setter for original model
            var getter = $parse(checklistModel);
            var setter = getter.assign;
            var checklistChange = $parse(attrs.checklistChange);
            var checklistBeforeChange = $parse(attrs.checklistBeforeChange);

            // value added to list
            var value = attrs.checklistValue ? $parse(attrs.checklistValue)(scope.$parent) : attrs.value;


            var comparator = angular.equals;

            if (attrs.hasOwnProperty('checklistComparator')) {
                if (attrs.checklistComparator[0] == '.') {
                    var comparatorExpression = attrs.checklistComparator.substring(1);
                    comparator = function (a, b) {
                        return a[comparatorExpression] === b[comparatorExpression];
                    };

                } else {
                    comparator = $parse(attrs.checklistComparator)(scope.$parent);
                }
            }

            // watch UI checked change
            scope.$watch(attrs.ngModel, function (newValue, oldValue) {
                if (newValue === oldValue) {
                    return;
                }

                if (checklistBeforeChange && (checklistBeforeChange(scope) === false)) {
                    scope[attrs.ngModel] = contains(getter(scope.$parent), value, comparator);
                    return;
                }

                setValueInChecklistModel(value, newValue);

                if (checklistChange) {
                    checklistChange(scope);
                }
            });

            function setValueInChecklistModel(value, checked) {
                var current = getter(scope.$parent);
                if (angular.isFunction(setter)) {
                    if (checked === true) {
                        setter(scope.$parent, add(current, value, comparator));
                    } else {
                        setter(scope.$parent, remove(current, value, comparator));
                    }
                }

            }

            // declare one function to be used for both $watch functions
            function setChecked(newArr, oldArr) {
                if (checklistBeforeChange && (checklistBeforeChange(scope) === false)) {
                    setValueInChecklistModel(value, scope[attrs.ngModel]);
                    return;
                }
                scope[attrs.ngModel] = contains(newArr, value, comparator);
            }

            // watch original model change
            // use the faster $watchCollection method if it's available
            if (angular.isFunction(scope.$parent.$watchCollection)) {
                scope.$parent.$watchCollection(checklistModel, setChecked);
            } else {
                scope.$parent.$watch(checklistModel, setChecked, true);
            }
        }

        return {
            restrict: 'A',
            priority: 1000,
            terminal: true,
            scope: true,
            compile: function (tElement, tAttrs) {
                if ((tElement[0].tagName !== 'INPUT' || tAttrs.type !== 'checkbox') && (tElement[0].tagName !== 'MD-CHECKBOX') && (!tAttrs.btnCheckbox)) {
                    throw 'checklist-model should be applied to `input[type="checkbox"]` or `md-checkbox`.';
                }

                if (!tAttrs.checklistValue && !tAttrs.value) {
                    throw 'You should provide `value` or `checklist-value`.';
                }

                // by default ngModel is 'checked', so we set it if not specified
                if (!tAttrs.ngModel) {
                    // local scope var storing individual checkbox model
                    tAttrs.$set("ngModel", "checked");
                }

                return postLinkFn;
            }
        };
    }])
    //处理select联动，如省市联动等
    .directive("dySelect", function($http) { 
        return {
            require: '?ngModel',
            //scope:{
                //'dyParams':'@?'
            //},
            restrict: 'ACE',
            link: function(scope, element, attrs) {
                var url = attrs.dataurl,//联动的地址
                    params = attrs.dataparams ? eval('('+attrs.dataparams+')') : "",
                    len = params != "" ? params.length : 0;
                scope.linkData = {}; //存放请求回来的数据
                $http.post(url).success(function(data){
                    scope.linkData[0] = data.data;
                });
                //console.log(params[0]);
                scope.linkFn = function(params){
                	var linklist = scope.list ? scope.list.linklist:scope.linklist;
                    if((params.index+1)== linklist.length){
                        return;
                    }
                    if(params[linklist[params.index].name]){
                    	$http({
                    		method: 'post',
                    		url: url,
                    		data: $.param(params),
                    		headers: {
                    			'Content-Type': 'application/x-www-form-urlencoded'
                    		}
                    	}).success(function(data) {
                    		scope.linkData[params.index+1] = data.data;
                    	});
                    }else{
                    	scope.linkData[params.index+1] = [];
                    }
                }

                //初始化选择省-市-区  dataparams="[{pid: 值, index: 0},{pid: 值, index: 1},{pid: 值, index: 2}]"
                // if(len > 0){
                //     for(var key=0; key<len; key++){
                //         scope.linkFn(params[key]);
                //     }
                // }

                /*for(var i=0;i<len-1;i++){
                    console.log(i);*/
                if(len==2){  //初始化选择省-市-区  dataparams="['省字段', '市字段', '县字段']"
                    scope.$watch('formData[params[0]]',function(newValue,oldValue){
                        var linkparams = {
                            'index':0
                        };
                        linkparams[params[0]] = scope.formData[params[0]];
                        scope.linkFn(linkparams);
                    });
                }else if(len==3){
                    scope.$watch('formData[params[0]]',function(newValue,oldValue){
                        var linkparams = {
                            'index':0
                        };
                        linkparams[params[0]] = scope.formData[params[0]];
                        scope.linkFn(linkparams);
                    });
                    scope.$watch('formData[params[1]]',function(newValue,oldValue){
                        var linkparams = {
                            'index':1
                        };
                        linkparams[params[1]] = scope.formData[params[1]];
                        scope.linkFn(linkparams);
                    });
                }
                /*}*/
                    
                
                
            }
        }
    })
    //日历
    .directive("datePicker", function ($injector) {
        return {
            require: '?ngModel',
            link: function (scope, element, attrs, ngModel) {
                if(typeof WdatePicker=='undefined'){
                    window.WdatePickerUrl = '/assets/src/js/plugins/datepicker/';
                    var script=document.createElement('script'); 
                    script.src= WdatePickerUrl+'WdatePicker.js'; 
                    script.type='text/javascript'; 
                    script.defer=true; 
                    $('body').eq(0).append(script);
                }
                var defaults, options;
                scope.deVal = element.attr('data-default-val') ? element.attr('data-default-val') : '';
                ngModel.$render = function () {
                    element.val(ngModel.$viewValue || scope.deVal);
                };
                var typeArr = new Array('start_time', 'end_time');
                // Write data to the model
                function read() {
                    var val = element.val();
                    ngModel.$setViewValue(val);
                }

                function contains(arr, obj) {
                    var i = arr.length;
                    while (i--) {
                        if (arr[i] === obj) {
                            return true;
                        }
                    }
                    return false;
                }

                function setPicker(than) {
                    if (!contains(typeArr, than)) {
                        options = angular.extend({}, {
                            el: attrs.id
                        }, options);
                    }
                    WdatePicker(options);
                }

                defaults = {
                    readOnly: true,
                    dateFmt: 'yyyy-MM-dd'
                };

                // switch (attrs.id) {
                //     case 'start_time':
                //         options = {
                //             maxDate: '#F{$dp.$D(\'end_time\')}',
                //             el: 'start_time'
                //         };
                //         break;
                //     case 'end_time':
                //         options = {
                //             minDate: '#F{$dp.$D(\'start_time\')}',
                //             el: 'end_time'
                //         };
                //         break;
                // }

                function dateTime(start, end){
                    switch (attrs.id) {
                        case start:
                            options = {
                                maxDate: '#F{$dp.$D('+ end +')}',
                                el: start
                            };
                            break;
                        case end:
                            options = {
                                minDate: '#F{$dp.$D('+ start +')}',
                                el: end
                            };
                            break;
                    }
                }
                dateTime("start_time", "end_time");
                dateTime("start_time2", "end_time2");
                dateTime("start_time3", "end_time3");

                options = angular.extend({}, options, defaults, scope.$eval(attrs.datePicker));
                element.on("focus click", function () {
                    setPicker(attrs.id);
                    scope.$apply(read);
                });
                $('.date-picker-icon').on('click', function () {
                    setPicker($(this).prev().attr('id'));
                });
            }
        }
    })
    //双日历时间范围
    .directive("dateRangePicker", function($timeout){
        return {
            restrict: "EA",
            scope: {
                filterDate: '&'  //列表选完日期后筛选数据的回调事件
            },
            require: "?ngModel",
            link: function(scope, element, attr, ctrl){
                if(typeof dateRangePickerUrl == "undefined"){
                    window.dateRangePickerUrl = "/assets/src/js/plugins/dateRangePicker/";

                    var style1 = document.createElement("link");
                    style1.href = dateRangePickerUrl + "daterangepicker.css";
                    style1.rel = "stylesheet";
                    style1.type = "text/css";
                    $("body").eq(0).append(style1);

                    var script1 = document.createElement("script");
                    script1.src = dateRangePickerUrl + "moment.min.js";
                    script1.type ="text/javascript";
                    script1.defer = true;
                    $("body").eq(0).append(script1);

                    var script2 = document.createElement("script");
                    script2.src = dateRangePickerUrl + "jquery.daterangepicker.js";
                    script2.type ="text/javascript";
                    script2.defer = true;
                    $("body").eq(0).append(script2);
                }

                var defaults = {
                    format: "YYYY/MM/DD",
                    separator: "-"
                },
                options = angular.extend({}, defaults, scope.$eval(attr.pickerOptions));
                $timeout(function(){
                    $("#" + attr.id).dateRangePicker(options).bind('datepicker-apply',function(){
                        scope.$apply(function() {
                            ctrl.$setViewValue($("#" + attr.id).val());
                        });
                    }).bind('datepicker-clear',function(){
                        scope.$apply(function() {
                            $("#" + attr.id).val("");
                            ctrl.$setViewValue("");  //清除选中日期
                        });
                        scope.filterDate();  //列表选完日期后筛选数据的回调事件
                    }).bind('datepicker-closed',function(){
                        scope.filterDate();  //列表选完日期后筛选数据的回调事件
                    })
                }, 500);
            }
        }
    })
    //表单里的文章编辑器
    .directive('ueditor', function ($timeout) {
        return {
            require: '?ngModel',
            scope: {},
            link: function ($S, element, attr, ctrl) {
                if(typeof UM === 'undefined') {
                    window.UMEDITOR_HOME_URL = '/assets/src/js/plugins/umeditor/'; //配置编辑器的路径，建议用绝对路径
                    var style1 = document.createElement('link');
                    style1.href = UMEDITOR_HOME_URL+'themes/default/css/umeditor.css';
                    style1.rel = 'stylesheet';
                    style1.type = 'text/css';
                     $('head').eq(0).append(style1);
                    
                    var script1 = document.createElement('script'); 
                    script1.src = UMEDITOR_HOME_URL+'umeditor.config.js'; 
                    script1.type = 'text/javascript'; 
                    script1.defer = true; 
                    $('head').eq(0).append(script1);
                    var script2 = document.createElement('script'); 
                    script2.src = UMEDITOR_HOME_URL+'umeditor.min.js'; 
                    script2.type = 'text/javascript'; 
                    script2.defer = true; 
                    $('head').eq(0).append(script2);
                    //window.UMEDITOR_CONFIG.UMEDITOR_HOME_URL = 'assets/src/js/plugins/umeditor/';
                }
                var _NGUeditor, _updateByRender;
                _updateByRender = false;
                _NGUeditor = (function () {
                    function _NGUeditor() {
                        this.bindRender();
                        this.initEditor();
                        return;
                    }

                    /**
                     * 初始化编辑器
                     * @return {[type]} [description]
                     */

                    _NGUeditor.prototype.initEditor = function () {
                        var _UEConfig, _editorId,
                            _self;
                        _self = this;
                        if (typeof UM === 'undefined') {
                            console.error("Please import the local resources of ueditor!");
                            return;
                        }
                        //_editor+name+[10000000~99999999]随机数
                        _editorId = attr.id ? attr.id : "_editor_" + element[0].name + parseInt(Math.random() * 90000000 + 10000000, 10);
                        element[0].id = _editorId;
                        this.editor = UM.getEditor(_editorId);
                        return this.editor.ready(function () {
                            _self.editorReady = true;
                            _self.editor.addListener("contentChange", function () {
                                ctrl.$setViewValue(_self.editor.getContent());
                                if (!_updateByRender) {
                                    if (!$S.$$phase) {
                                        $S.$apply();
                                    }
                                }
                                _updateByRender = false;
                            });

                            _self.editor.addListener('fullscreenchanged', function (type, isfullscreen) {
                                if (!isfullscreen) {
                                    // 重置编辑器内容区域高度，这个高度在切换全屏时会改变，应该是 UMEditor 自身的BUG
                                    $("body").css({"overflow-y": "scroll"});

                                    // 重新布局外部容器
                                    //_self.updateLayout();
                                }
                            });
                            if (_self.modelContent.length > 0) {
                                _self.setEditorContent();
                            }
                            if (typeof $S.ready === "function") {
                                $S.ready(_self.editor);
                            }
                        });
                    };

                    _NGUeditor.prototype.setEditorContent = function (content) {
                        if (content == null) {
                            content = this.modelContent;
                        }
                        if (this.editor && this.editorReady) {
                            this.editor.setContent(content);
                        }
                    };

                    _NGUeditor.prototype.bindRender = function () {
                        var _self;
                        _self = this;
                        ctrl.$render = function () {
                            _self.modelContent = (ctrl.$isEmpty(ctrl.$viewValue) ? "" : ctrl.$viewValue);
                            _updateByRender = true;
                            _self.setEditorContent();
                        };
                    };

                    return _NGUeditor;

                })();
                new _NGUeditor();
            }
        };
    })
    // 文件上传指令
    .directive("snailUploadify", function ($timeout, postUrl) {
        return {
            scope: {
                changeFileName: '&'  //银行-抵押查询-银行类型管理-添加-上传显示文件名称
            },
            require: '?ngModel',
            restrict: 'A',
            link: function (scope, element, attrs, ngModel) {
                var eleSiblings = element.closest(".single-img-box"),
                    tempOpt = {},
                    ajaxResult = function (data) {
                        try {
                            return eval('(' + data + ')');
                        } catch (e) {
                            return false;
                        }
                    },
                    optFu = function (name) {
                        switch (name) {
                            case 'uploadMulti': //上传多张
                                return tempOpt = {
                                    auto: false,
                                    onUploadSuccess: function (file, d, response) {
                                        var result = ajaxResult(d);
                                        if (result.status == 200) {
                                            var g = ngModel.$viewValue ? ngModel.$viewValue : [],
                                                m = [];
                                            g.push({
                                                imgurl: result.data.Filedata.file_url,
                                                minimg: result.data.Filedata.url,
                                                did:result.data.did,
                                                title: ''
                                            });
                                            scope.$apply(function () {
                                                ngModel.$setViewValue(g);
                                            });
                                        } else {
                                            layer.msg(result.description, {icon: 2, shade: 0.3, time: 1000});
                                        }
                                    }
                                }
                                break;
                            case 'uploadSola': //上传单张
                                return tempOpt = {
                                    queueSizeLimit: 1,
                                    onUploadSuccess: function (file, d, response) {
                                        var result = ajaxResult(d);
                                        var imgRemove = eleSiblings.find('.oldpic'),
                                            imgAdd = eleSiblings.find('.newpic'),
                                            imgLoad = "/assets/css/images/loading.gif";
                                        var repeatStatus = angular.equals(imgAdd.attr("data-original"), result.data.Filedata.url);
                                        if (result.status == 200) {
                                            // if (repeatStatus) return false;
                                            // if (imgRemove) imgRemove.remove();
                                            // imgAdd.show();
                                            // imgAdd.attr("src", imgLoad);
                                            // imgAdd.attr("data-original", result.data.Filedata.url);
                                            // scope.$apply(function () {
                                            //     ngModel.$setViewValue(result.data.Filedata.file_url);
                                            // });

                                            //收件侧滑-上传附件弹窗
                                            scope.getUrlParams = function(){
                                                scope.params = {};
                                                var pageUrl = location.pathname.slice(1).split('&');
                                                scope.params.pageUrl = pageUrl[0];
                                                for(var i in pageUrl){
                                                    if(i > 0){
                                                        var temp = pageUrl[i].split('=');
                                                        switch(temp[0]){
                                                            case 'id':
                                                                scope.params.id = temp[1];
                                                                break;
                                                            case 'attachment_id':
                                                                scope.params.attachment_id = temp[1];
                                                                break;
                                                            case 'annex_type':
                                                                scope.params.annex_type = temp[1];
                                                                break;
                                                            case 'snode_id':
                                                                scope.params.snode_id = temp[1];
                                                                break;
                                                            case 'from':
                                                                scope.params.from = temp[1];
                                                                break;
                                                            case 'slide':
                                                                scope.params.slide = temp[1];
                                                                break;
                                                        }
                                                    }
                                                }
                                            }
                                            scope.getUrlParams();
                                            var params = {
                                                "id": scope.params.id,
                                                "attachment_id": scope.params.attachment_id,
                                                "annex_type": scope.params.annex_type,
                                                "snode_id": scope.params.snode_id,
                                                "from": scope.params.from,
                                                "slide": scope.params.slide,
                                                "file_url": result.data.Filedata.file_url,
                                                "url": result.data.Filedata.url,
                                                "size": result.data.Filedata.size
                                            }
                                            layer.load(1);
                                            postUrl.events("/buss/enter/saveFile", params).success(function(_data){
                                                if(_data.status == 200){
                                                    layer.closeAll("loading");
                                                    layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                                                        window.parent.parent.document.getElementById("rightDialog").src = "/buss/enter/enclosure&id=" + params.id + "&snode_id=" + params.snode_id + "&annex_type=" + params.annex_type + "&slide=" + params.slide + "&from=" + params.from
                                                        parent.layer.closeAll();
                                                    });
                                                }else{
                                                    layer.closeAll("loading");
                                                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                                                        //window.location.reload();
                                                    });
                                                }
                                            });

                                        } else {
                                        	layer.msg(result.description, {icon: 2, shade: 0.3, time: 1000});
                                        }
                                    }
                                }
                                break;
                            case 'uploadSolaFile': //上传单个附件
                                return tempOpt = {
                                    queueSizeLimit: 1,
                                    fileSizeLimit: '20MB',
                                    fileTypeExts: '*.pdf; *.apk; *.rar; *.zip; *.docx; *.doc; *.xls; *.xlsx; *.gif; *.jpg; *.jpeg; *.bmp; *.png',
                                    onUploadSuccess: function (file, d, response) {
                                        var result = ajaxResult(d);
                                        if (result.status == 200) {
                                            var g = ngModel.$viewValue ? ngModel.$viewValue : {};
                                            g = {
	                                                file_url: result.data.Filedata.file_url,
	                                                url: result.data.Filedata.url,
	                                                name: file.name,
	                                                did:result.data.did,
	                                                size: result.data.Filedata.size,
	                                                time: result.data.Filedata.time,
	                                                format: result.data.Filedata.format
	                                            }
                                            scope.$apply(function () {
                                                ngModel.$setViewValue(g);
                                                scope.changeFileName();  //银行-抵押查询-银行类型管理-添加-上传显示文件名称
                                            });
                                        } else {
                                        	layer.msg(result.description, {icon: 2, shade: 0.3, time: 1000});
                                        }
                                    }
                                }
                                break;
                            case 'uploadMultiFile': //上传多个附件
                                return tempOpt = {
                                    fileSizeLimit: '20MB',
                                    fileTypeExts: '*.pdf; *.apk; *.rar; *.zip; *.docx; *.xlsx; *.gif; *.jpg; *.jpeg; *.bmp; *.png;',
                                    onUploadSuccess: function (file, d, response) {
                                        var result = ajaxResult(d);
                                        if (result.status == 200) {
                                            var g = ngModel.$viewValue ? ngModel.$viewValue : [],
                                                m = [];
                                            g.push({
                                                file_url: result.data.Filedata.file_url,
                                                url: result.data.Filedata.url,
                                                name: file.name,
                                                did:result.data.did,
                                                size: result.data.Filedata.size,
                                                time: result.data.Filedata.time,
                                                format: result.data.Filedata.format
                                            });
                                            scope.$apply(function () {
                                                ngModel.$setViewValue(g);
                                            });
                                        } else {
                                            layer.msg(result.description, {icon: 2, shade: 0.3, time: 1000});
                                        }
                                    }
                                }
                                break;
                        }
                    };
                var defaultOpts = {
                    'fileObjName': 'Filedata',
                    'auto': true,
                    'swf': '/assets/src/js/plugins/uploadify/scripts/uploadify.swf',
                    'uploader': attrs.uploader || '/common/upload/upload', //上传方法
                    'buttonImage': '',
                    'buttonClass': '',
                    'queueID': '',
                    'queueSizeLimit': 999,
                    'buttonText': '请选择',
                    'width': 50,
                    'height': 32,
                    'fileSizeLimit': '2048KB',
                    'fileTypeExts': '*.gif; *.jpg; *.png; *.ico',
                    'onUploadSuccess': function (file, d, response) {
                        uploadSola(d);
                    }
                };
                $timeout(function () {
                    var options = scope.$eval(attrs.snailUploadify);
                    var opts = angular.extend({}, defaultOpts, options, optFu(options.onUploadSuccess));

                    $('#' + attrs.id).uploadify(opts);
                    $('.file_upload').on('click', function () {
                        var than = $(this).attr('data-id');
                        $('#' + than).uploadify('upload', '*');
                    });
                });
            }
        };
    })
    //h5文件上传指令
    .directive("ngFileUpload", function(FileUploader){
        return {
            restrict: "A",
            require: "?ngModel",
            templateUrl: "/assets/ngtpl/upload.html",
            scope: {
                "ngFileUpload": "="
            },
            link: function(scope, element, attrs, ngModel){
                scope.sumData = scope.ngFileUpload.sumData;
                scope.showData = scope.ngFileUpload.showData || {};
                scope.names = scope.ngFileUpload.name;

                scope.type = scope.ngFileUpload.type || "files";  //{"files": "文件", "images": "图片"}
                scope.required = scope.ngFileUpload.required || "0";  //{"0": "不必填", "1": "必填"}
                scope.multiple = scope.ngFileUpload.multiple || "1";  //{"0": "单个", "1": "多个"}
                scope.template = scope.ngFileUpload.template || "list";  //{"list": "列表", "table": "表格"}

                scope.random = Math.floor(Math.random()*10000000);

                scope.uploader = new FileUploader({
                    url: "/common/fileupload/file/picture",
                    autoUpload: true,
                    // queueLimit: 1,
                    alias: "upload"
                });
                
                //初始化显示
                if(scope.sumData[scope.names] && scope.multiple == 0){
                    var index = scope.sumData[scope.names].lastIndexOf("/");
                    scope.tempData = scope.showData.upload = {
                        url: scope.sumData[scope.names],
                        name: scope.sumData[scope.names].substring(index+1),
                        format: scope.sumData[scope.names].slice(-4)
                    }
                }else if(scope.multiple == "1"){
                    if(scope.showData.upload){
                        scope.tempData = scope.showData.upload;
                    } else {
                        scope.tempData = scope.showData.upload = [];
                    }
                }

                scope.uploader.onSuccessItem = function(fileItem, response, status, headers) {
                    if(response.status == 200){
                        scope.$apply(function () {
                            if(scope.multiple == "1"){
                                scope.sumData[scope.names] = scope.ngFileUpload.sumData[scope.names] || [];
                                scope.sumData[scope.names].push(response.data.did);  //后台需要的did值
                                scope.tempData.push({  //页面展示需要的参数
                                    file_url: response.data.Filedata.file_url,
                                    url: response.data.Filedata.url,
                                    name: response.data.Filedata.name,
                                    did: response.data.did,
                                    size: response.data.Filedata.size,
                                    time: response.data.Filedata.time,
                                    format: response.data.Filedata.format
                                });
                            } else {
                                scope.sumData[scope.names] = response.data.did;  //后台需要的did值
                                scope.tempData = scope.showData.upload = {  //页面展示需要的参数
                                    file_url: response.data.Filedata.file_url,
                                    url: response.data.Filedata.url,
                                    name: response.data.Filedata.name,
                                    did: response.data.did,
                                    size: response.data.Filedata.size,
                                    time: response.data.Filedata.time,
                                    format: response.data.Filedata.format
                                }
                                if(scope.template == "loopTable"){
                                    scope.sumData["file"] = {
                                        file_url: response.data.Filedata.file_url,
                                        url: response.data.Filedata.url,
                                        name: response.data.Filedata.name,
                                        did: response.data.did,
                                        size: response.data.Filedata.size,
                                        time: response.data.Filedata.time,
                                        format: response.data.Filedata.format
                                    }
                                }
                            }
                        });
                    } else {
                        layer.msg(response.description, {icon: 2, time: 2000, shade: 0.3})
                    }
                };

                //清除队列
                scope.clearQueue = function(){
                    scope.uploader.clearQueue();
                }
                
                //删除上传文件
                scope.removeFile = function(index){
                	if(scope.multiple == '0'){
                		scope.tempData = {};
                        scope.sumData[scope.names] = "";
                	}else if(scope.multiple == '1'){
                		scope.tempData.splice(index, 1);
                        scope.sumData[scope.names].splice(index, 1);
                	}
                }
            }
        }
    })
    //上传图片
    .directive('uploadFile', function ($timeout) {
        return {
            require: '?ngModel',
            scope: {},
            link: function ($S, element, attr, ctrl) {
                if(typeof WebUploader==='undefined'){
                    var style3 = document.createElement('link');
                    style3.href = '/assets/src/js/plugins/webuploader/webuploader.css';
                    style3.rel = 'stylesheet';
                    style3.type = 'text/css';
                     $('head').eq(0).append(style3);
                    var script3=document.createElement('script'); 
                    script3.src='/assets/src/js/plugins/webuploader/webuploader.min.js'; 
                    script3.type='text/javascript'; 
                    script3.defer=true; 
                    $('head').eq(0).append(script3);
                }
                var $this = element,
                    // 优化retina, 在retina下这个值是2
                    ratio = window.devicePixelRatio || 1,
                    // 缩略图大小
                    thumbnailWidth = 100 * ratio,
                    thumbnailHeight = 100 * ratio,
                    $list = $this.siblings('.uploader-list');
                var uploader = WebUploader.create({

                    // 自动上传。
                    auto: false,

                    // swf文件路径
                    // swf: BASE_URL + '/js/Uploader.swf',
                    swf: 'Uploader.swf',

                    // 文件接收服务端。
                    //server: 'http://webuploader.duapp.com/server/fileupload.php',
                    server: 'http://2betop.net/fileupload.php',

                    // 选择文件的按钮。可选。
                    // 内部根据当前运行是创建，可能是input元素，也可能是flash.
                    // pick: '#filePicker',
                    pick: $this,

                    // 只允许选择文件，可选。
                    accept: {
                        title: 'Images',
                        extensions: 'gif,jpg,jpeg,bmp,png',
                        mimeTypes: 'image/*'
                    }
                });
                // 当有文件添加进来的时候
                uploader.on( 'fileQueued', function( file ) {
                    var $li = $(
                            '<div id="' + file.id + '" class="file-item thumbnail">' +
                                '<img>' +
                                '<div class="info">' + file.name + '</div>' +
                            '</div>'
                            ),
                    $img = $li.find('img');
                    $list.append( $li );

                    // 创建缩略图
                    uploader.makeThumb( file, function( error, src ) {
                        if ( error ) {
                            $img.replaceWith('<span>不能预览</span>');
                            return;
                        }

                        $img.attr( 'src', src );
                    }, thumbnailWidth, thumbnailHeight );
                });

                // 文件上传过程中创建进度条实时显示。
                uploader.on( 'uploadProgress', function( file, percentage ) {
                    var $li = $( '#'+file.id ),
                        $percent = $li.find('.progress span');

                    // 避免重复创建
                    if ( !$percent.length ) {
                        $percent = $('<p class="progress"><span></span></p>')
                                .appendTo( $li )
                                .find('span');
                    }

                    $percent.css( 'width', percentage * 100 + '%' );
                });

                // 文件上传成功，给item添加成功class, 用样式标记上传成功。
                uploader.on( 'uploadSuccess', function( file ) {
                    $( '#'+file.id ).addClass('upload-state-done');
                });

                // 文件上传失败，现实上传出错。
                uploader.on( 'uploadError', function( file ) {
                    var $li = $( '#'+file.id ),
                        $error = $li.find('div.error');

                    // 避免重复创建
                    if ( !$error.length ) {
                        $error = $('<div class="error"></div>').appendTo( $li );
                    }

                    $error.text('上传失败');
                });

                // 完成上传完了，成功或者失败，先删除进度条。
                uploader.on( 'uploadComplete', function( file ) {
                    $( '#'+file.id ).find('.progress').remove();
                });
            }
        };
    })
    //数据列表的分页指令
    .directive('ngPaginationskip', function ($rootScope, Pagination) {
        return {
            scope: {
                ngPaginationskip: '=',
                currentPage: '=',
                itemsPerpage:'=',
                pageOptions:'=',  //分页条数的配置项
                pageChange: '&',
                perChange:'&'
            },
            controller: function ($scope, $element) {
                $scope.paginationInt = function ($data) {
                    // 分页创建
                    pagination = $scope.pagination = Pagination.create({
                        itemsCount: $data.total_items, // 总数
                        itemsPerPage: $data.epage, // 每页条数
                        currentPage: $data.page // 当前页码
                    });
                    // 分页操作回调
                    pagination.onChange = function (page, epage) {
                        $scope.currentPage = page;
                    };
                };

                // 页码跳转操作
                $scope.skipInput = function (page, endPage) {
                    if (!isNaN(page)) {
                        var page = parseInt(page, 10),
                            endPage = parseInt(endPage, 10);
                        if (page > endPage || page <= 0) {
                            $scope.skipError = true;
                        } else {
                            $scope.skipError = false;
                        }
                    } else {
                        $scope.skipError = true;
                    }
                };

                $scope.perpageChange = function(perpage){
                    $scope.itemsPerpage = perpage;
                }
            },
            templateUrl: '/assets/dist/tpl/pagination_skip.html',
            link: function (scope, element, attrs) {
                var i = 0;
                scope.$watch('ngPaginationskip', function (newVal, oldVal) {
                    if (newVal) {
                        if (i > 1) {
                            scope.pagination.setCurrent(scope.pagination.currentPage);
                        } else {
                            scope.paginationInt(scope.ngPaginationskip);
                        }
                    }
                });
                scope.$watch('currentPage', function (newValue, oldValue, scope) {
                    if (newValue) {
                        scope.pageChange();
                    }
                }, true);
                scope.$watch('itemsPerpage', function (newValue, oldValue, scope) {
                    if (newValue) {
                        scope.perChange();
                    }
                }, true);
            }
        };
    })
    //图表Echarts
    .directive("dyEcharts", function () {
        return {
            scope: {
                dyEcharts: '=?'
            },
            link: function (scope, element, iAttrs, ctrl) {
                var _chartsId = iAttrs.id ? iAttrs.id : "_echarts" + (Date.now());
                element[0].id = _chartsId;
                // 指定图表的配置项和数据
                var option = {
                    title: {
                        text: ''
                    },
                    tooltip: {},
                    legend: {},
                    series: []
                };

                // 使用刚指定的配置项和数据显示图表。
                scope.$watch('dyEcharts', function (newVal, oldVal) {
                    // 基于准备好的dom，初始化echarts实例
                    myChart = echarts.init(document.getElementById(_chartsId));
                    myChart.showLoading();
                    if (newVal) {
                        var optionConfig = angular.extend({}, option, newVal);
                        myChart.setOption(optionConfig);
                        myChart.hideLoading();
                    }

                });

            }
        }
    })
    //添加
    .directive("dyAdd", function($http){
        return {
            require: "?ngModel",
            scope: {
                "dyAdd": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyAdd;
                    parent.layer.open({
                        type: 2,
                        title: params.title,
                        shadeClose: false,
                        maxmin: true,
                        shade: 0.3,
                        area: ["750px", "650px"],
                        content: "/" + params.url //iframe的url
                    });
                })
            }
        }
    })
    //添加-带参数
    .directive("commonAdd", function($http){
        return {
            require: "?ngModel",
            scope: {
                "commonAdd": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.commonAdd;
                    var url = "/" + params.url + "?",
                        key;
                    for(key in params.form_data){
                        url += key + "=" + params.form_data[key] + "&"
                    }
                    url = url.substring(0, url.length-1);
                    parent.layer.open({
                        type: 2,
                        title: params.title,
                        shadeClose: false,
                        maxmin: true,
                        shade: 0.3,
                        area: ["750px", "650px"],
                        content: url //iframe的url
                    });
                })
            }
        }
    })
    //编辑
    .directive("dyEdit", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyEdit": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyEdit;
                    params.title = params.title || "编辑";
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        if(params.click == "900"){
                            parent.layer.open({
                                type: 2,
                                title: params.title,
                                shadeClose: false,
                                maxmin: true,
                                shade: 0.3,
                                area: ["900px", "650px"],
                                content: "/" + params.url + "?id=" + checkValue //编辑的页面地址，需要传递id给后台
                            });
                        } else if(params.click == "full"){
                            var index = parent.layer.open({
                                type: 2,
                                title: params.title,
                                shadeClose: false,
                                maxmin: false,
                                shade: 0.3,
                                area: ["750px", "650px"],
                                content: "/" + params.url + "?id=" + checkValue //编辑的页面地址，需要传递id给后台
                            });
                            parent.layer.full(index);
                        } else {
                            parent.layer.open({
                                type: 2,
                                title: params.title,
                                shadeClose: false,
                                maxmin: true,
                                shade: 0.3,
                                area: ["750px", "650px"],
                                content: "/" + params.url + "?id=" + checkValue //编辑的页面地址，需要传递id给后台
                            });
                        }
                    }
                })
            }
        }
    })
    //编辑-带参数
    .directive("commonEdit", function($http){
        return {
            require: "?ngModel",
            scope: {
                "commonEdit": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.commonEdit;
                    params.title = params.title || "编辑";
                    var url = "/" + params.url + "?",
                        key;
                    for(key in params.form_data){
                        url += key + "=" + params.form_data[key] + "&"
                    }
                    // url = url.substring(0, url.length-1);
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        parent.layer.open({
                            type: 2,
                            title: params.title,
                            shadeClose: false,
                            maxmin: true,
                            shade: 0.3,
                            area: ["750px", "650px"],
                            content: url + "id=" + checkValue  //编辑的页面地址，需要传递id给后台
                        });
                    }
                })
            }
        }
    })
    //请求后判断
    .directive("dyEditConfirm", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyEditConfirm": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyEditConfirm;
                    params.title = params.title || "编辑";
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        postUrl.events("/" + params.valUrl, {id: checkValue}).success(function(_data){
                            if(_data.data.status == 1){
                                parent.layer.open({
                                    type: 2,
                                    title: params.title,
                                    shadeClose: false,
                                    maxmin: true,
                                    shade: 0.3,
                                    area: ["750px", "650px"],
                                    content: "/" + params.url + "?id=" + checkValue  //编辑的页面地址，需要传递id给后台
                                });
                            } else if(_data.data.status == 2){
                                parent.layer.confirm("确定是否" + params.title, {
                                    time: 0, //不自动关闭
                                    icon: 3,
                                    shade: 0.3,
                                    title: params.title,
                                    btn: ["确定", "取消"]
                                }, function(index){
                                    postUrl.events("/" + params.url, {id: checkValue}).success(function(_data){
                                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                        parent.layer.closeAll();
                                    })
                                });
                            } else if(_data.data.status == 3) {
                                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500})
                            }
                        });
                    }
                })
            }
        }
    })
    //点击工具栏按钮侧滑 <a href="javascript:;" ng-if="list.type == 'dyshowright'" dy-show-right="{'url': list.url, 'single': list.single, 'title': list.title}"></a>
	    .directive("dyShowRight", function($http, postUrl){
	        return {
	            require: "?ngModel",
	            scope: {
	                "dyShowRight": "=",
	                "checkValue": "="
	            },
	            link: function(scope, element, attrs){
	                element.click(function(){
	                    var params = scope.dyShowRight;
	                    params.title = params.title || "查看";
	                    if(scope.checkValue.length > 1 && params.single == 1){
	                        parent.layer.msg(params.title + "的选项只能为一项", {
	                            icon: 2,
	                            shade: 0.3,
	                            time: 2000
	                        })
	                    } else if (scope.checkValue.length == 0){
	                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
	                            icon: 2,
	                            shade: 0.3,
	                            time: 2000
	                        })
	                    } else {
	                        var checkValue = scope.checkValue.join(",");
	                        if(typeof params.url != "undefined" && params.url != ""){
	                            if(params.url.indexOf("&") == 0){
	                                params.url = rec[params.url.substr(1)];
	                            }
	                            var srcUrl = params.url.indexOf("http") == 0 ? params.url : ("/" + params.url + "?id=" + checkValue);
	                            window.parent.document.getElementById("rightDialog").src = srcUrl;
	                            window.parent.document.getElementById("subRightDialog").src = "";  //清空三级侧滑iframe内容
	                            window.parent.document.getElementById("subSlideRight").style.right = "-920px";  //隐藏三级侧滑
	                            parent.layer.msg("数据加载中...", {shade: 0.3, time: 1000}, function(){
	                                $("#frameSlideRight", window.parent.document).animate({right: "0px"}, 500);
	                                $timeout(function(){
	                                    // window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                                }, 500)
	                            });
	                        }else{
	                            return;
	                        }
	                    }
	                })
	            }
	        }
	    })
    //查看
    .directive("dyView", function($http){
        return {
            require: "?ngModel",
            scope: {
                "dyView": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyView;
                    params.title = params.title || "查看";
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        parent.layer.open({
                            type: 2,
                            title: params.title,
                            shadeClose: false,
                            maxmin: true,
                            shade: 0.3,
                            area: ["750px", "650px"],
                            content: "/" + params.url + "?id=" + checkValue //查看的页面地址，需要传递id给后台
                        });
                    }
                })
            }
        }
    })
    //批量提交操作(传或者不传ID都可以，弹窗打开)
    .directive("commonBatch", function($http){
        return {
            require: "?ngModel",
            scope: {
                "commonBatch": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.commonBatch;
                    params.title = params.title || "编辑";
                    var url = "/" + params.url + "?",
                        key;
                    for(key in params.form_data){
                        url += key + "=" + params.form_data[key] + "&"
                    }
                    url1 = url.substring(0, url.length-1);
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.open({
                            type: 2,
                            title: params.title,
                            shadeClose: false,
                            maxmin: true,
                            shade: 0.3,
                            area: ["750px", "650px"],
                            content: url1  //编辑的页面地址，无需传id
                        });
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        parent.layer.open({
                            type: 2,
                            title: params.title,
                            shadeClose: false,
                            maxmin: true,
                            shade: 0.3,
                            area: ["750px", "650px"],
                            content: url + "id=" + checkValue  //编辑的页面地址，需要传递id给后台
                        });
                    }
                })
            }
        }
    })
    //批量下载操作(传或者不传ID都可以，新窗口打开)
    .directive("commonBatchDownload", function($http){
        return {
            require: "?ngModel",
            scope: {
                "commonBatchDownload": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.commonBatchDownload;
                    params.title = params.title || "下载";
                    var url = "/" + params.url + "?",
                        key;
                    for(key in params.form_data){
                        url += key + "=" + params.form_data[key] + "&"
                    }
                    url1 = url.substring(0, url.length-1);
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        window.open(url1);
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        window.open(url + "id=" + checkValue);
                    }
                })
            }
        }
    })
    //下载(新窗口打开)
    .directive("commonDownload", function($http){
        return {
            require: "?ngModel",
            scope: {
                "commonDownload": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.commonDownload;
                    params.title = params.title || "下载";
                    var url = "/" + params.url + "?",
                        key;
                    for(key in params.form_data){
                        url += key + "=" + params.form_data[key] + "&"
                    }
                    // url = url.substring(0, url.length-1);
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        window.open(url + "id=" + checkValue);
                    }
                })
            }
        }
    })
    //创建账户(新窗口打开)
    .directive("createAccount", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "createAccount": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.createAccount;
                    params.title = params.title || "创建账户";
                    var url = "/" + params.url + "?",
                        key;
                    for(key in params.form_data){
                        url += key + "=" + params.form_data[key] + "&"
                    }
                    // url = url.substring(0, url.length-1);
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        postUrl.events("/account/plat/accountExist", {id: checkValue}).success(function(_data){
                            if(_data.status != 200){
                                parent.layer.msg(_data.description, {
                                    icon: 2,
                                    shade: 0.3,
                                    time: 2000
                                })
                            }
                            if(_data.data.accountStatus == false){
                                window.open(url + "id=" + checkValue);
                            } else {
                                parent.layer.msg(_data.description, {
                                    icon: 2,
                                    shade: 0.3,
                                    time: 2000
                                })
                            }
                        })
                    }
                })
            }
        }
    })
    //侧滑导出按钮
    // common-export="{url: 'url'}" form-data="{id: 'id'}"
    .directive("commonExport", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "commonExport": "=",
                "formData": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.commonExport;
                    var url = "/" + params.url + "?",
                        key;
                    for(key in scope.formData){
                        url += key + "=" + scope.formData[key] + "&"
                    }
                    url = url.substring(0, url.length-1);
                    window.open(url);
                })
            }
        }
    })
    //只发送请求
    .directive("dyPost", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyPost": "="
            },
            link: function(scope, element, attrs){
            	element.click(function(){
                    var params = scope.dyPost;
                    var btnStatus = true;
                    var _confirmRecall = function(){
                    	postUrl.events("/" + params.url).success(function(_data){
	                        if(_data.status == 200){
	                            parent.layer.msg(_data.description, {icon: 1, time: 1000}, function(){
	                                if(!!params.refresh_sub){
	                                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
	                                } else {
	                                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
	                                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
	                                }
	                                layer.closeAll();
	                            });
	                        }else{
	                            parent.layer.msg(_data.description, {icon: 2, time: 1000});
	                        }
	                    });
                    }
                    if(!!params.confirm){
                    	parent.layer.confirm("确定是否" + params.title, {
                            time: 0, //不自动关闭
                            icon: 3,
                            shade: 0.3,
                            title: params.title,
                            btn: ["确定", "取消"]
                        }, function(index){
                            if(btnStatus){
                                btnStatus = false;
                                _confirmRecall();
                            } else {
                                return;
                            }
                        });
                    } else {
                    	_confirmRecall();
                    }
                })
            }
        }
    })
    //删除
    .directive("dyDel", function($http,postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyDel": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyDel;
                    params.title = params.title || "删除";
                    var btnStatus = true;
                    var _recallAjax = function(){
                        parent.layer.confirm("确定是否" + params.title, {
                            time: 0, //不自动关闭
                            icon: 3,
                            shade: 0.3,
                            title: params.title,
                            btn: ["确定", "取消"]
                        }, function(index){
                            if(btnStatus){
                                btnStatus = false;
                                var checkValue = scope.checkValue.join(",");
                                parent.layer.closeAll();
                                parent.layer.load(1);
                                postUrl.events("/" + params.url, {id: checkValue}).success(function(_data){
                                    if(_data.status == 500 || _data.status == 100){  //返回错误提示
                                        parent.layer.closeAll("loading");
                                        parent.layer.msg(_data.description, {
                                            icon: 2,
                                            shade: 0.3,
                                            time: 3000
                                        })
                                    } else if (_data.status == 600){  //返回超时弹窗
                                        parent.layer.closeAll("loading");
                                        parent.layer.open({
                                            type: 2,
                                            title: "超时说明",
                                            shadeClose: false,
                                            maxmin: true,
                                            shade: 0.3,
                                            area: ["520px", "460px"],
                                            content: "/workbench/buss/addOutExp?id=" + _data.description
                                        });
                                    } else {
                                        parent.layer.closeAll("loading");
                                        parent.layer.msg(_data.description, {icon: 1, time: 1000}, function(){
                                            if(!!params.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                                                window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                                            } else {
                                                top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                            }
                                            layer.closeAll();
                                        });
                                    }
                                });
                            } else {
                                return;
                            }
                        });
                    }
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        });
                    } else {
                        if(!!params.double){  //二手房-待保证号的完成报证-二次确认
                            parent.layer.confirm("请确认是否已经导出", {
                                time: 0, //不自动关闭
                                icon: 3,
                                shade: 0.3,
                                title: "导出确认",
                                btn: ["确定", "取消"]
                            }, function(){
                                _recallAjax();
                            });
                        }else{
                            _recallAjax();
                        }
                    }
                })
            }
        }
    })
    //分配
    .directive("dyAllot", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyAllot": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyAllot;
                    params.title = params.title || "分配";
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要" + params.title + "的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        postUrl.events("/" + params.url, {id: checkValue}).success(function(_data){
                            if(_data.status == 500){  //返回错误提示
                                parent.layer.msg(_data.description, {
                                    icon: 2,
                                    shade: 0.3,
                                    time: 3000
                                })
                            } else if (_data.status == 600){  //返回超时弹窗
                                parent.layer.open({
                                    type: 2,
                                    title: "超时说明",
                                    shadeClose: false,
                                    maxmin: true,
                                    shade: 0.3,
                                    area: ["520px", "460px"],
                                    content: "/workbench/buss/addOutExp?id=" + _data.description
                                });
                            } else {  //返回分配弹窗
                                parent.layer.open({
                                    type: 2,
                                    title: params.title,
                                    shadeClose: false,
                                    maxmin: true,
                                    shade: 0.3,
                                    area: ["750px", "650px"],
                                    content: "/" + params.url + "?id=" + checkValue
                                });
                            }
                        });
                    }
                })
            }
        }
    })
    //受理
    .directive("dyAccept", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyAccept": "=",
                "checkValue": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyAccept;
                    if(scope.checkValue.length > 1){
                        parent.layer.msg("受理的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if (scope.checkValue.length == 0){
                        parent.layer.msg("请先选择要受理的选项！", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else {
                        var checkValue = scope.checkValue.join(",");
                        postUrl.events("/" + params.url, {id: checkValue}).success(function(_data){
                            if(_data.status == 500){  //返回错误提示
                                parent.layer.msg(_data.description, {
                                    icon: 2,
                                    shade: 0.3,
                                    time: 3000
                                })
                            } else if(_data.status == 600){  //返回超时弹窗
                                parent.layer.open({
                                    type: 2,
                                    title: "超时说明",
                                    shadeClose: false,
                                    maxmin: true,
                                    shade: 0.3,
                                    area: ["520px", "460px"],
                                    content: "/workbench/buss/addOutExp?id=" + _data.description
                                });
                            } else {  //返回受理弹窗
                                parent.layer.open({
                                    type: 2,
                                    title: params.title,
                                    shadeClose: false,
                                    maxmin: true,
                                    shade: 0.3,
                                    area: ["520px", "460px"],
                                    content: "/" + params.url + "?id=" + checkValue
                                });
                            }
                        });
                    }
                })
            }
        }
    })
    //一级侧滑-驳回
    //<a href="javascript:;" class="cancel-btn" dy-reject="{url: formStruct.reject_url, id: params.id}">驳回</a>
    .directive("dyReject", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyReject": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyReject,
                    url;
                    if(typeof params.id == "undefined" || params.id == ""){
                        url = "/" + params.url
                    } else {
                        url = "/" + params.url + "?id=" + params.id
                    }
                    parent.layer.open({
                        type: 2,
                        title: params.title || "驳回",
                        shadeClose: false,
                        maxmin: true,
                        shade: 0.3,
                        area: ["520px", "460px"],
                        content: url
                    });
                })
            }
        }
    })
    //一级侧滑-确认
    //<a href="javascript:;" class="submit-btn" dy-confirm="{url: formStruct.comfirm_url, id: params.id}">确认</a>
    .directive("dyConfirm", function($http, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyConfirm": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyConfirm;
                    var btnStatus = true;
                    parent.layer.confirm(params.content || "是否确认？", {
                        time: 0, //不自动关闭
                        icon: 3,
                        shade: 0.3,
                        title: params.title || "确认",
                        btn: ["确定", "取消"]
                    }, function(){
                        if(btnStatus){
                            btnStatus = false;
                            postUrl.events("/" + params.url, {id: params.id}).success(function(_data){
                                if(_data.status == 200){
                                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                                        if(!!formStruct.refresh){
                                            window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                                            top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                        } else if(!!formStruct.refresh_sub){
                                            window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                                        } else if(!!formStruct.refresh_tree){  //组织架构-部门管理全部刷新，否则左侧的树数据无法更新
                                            window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                                        } else {
                                            window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                                            top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                        }
                                        parent.layer.closeAll();
                                    });
                                }else{
                                    layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                                        //window.location.reload();
                                    });
                                }
                            });
                        } else {
                            return;
                        }
                    });
                })
            }
        }
    })
    //表单提交
    //<input type="submit" class="submit-btn" dy-submit="{url: formStruct.submit_url}" form-data="formData" value="提交">
    .directive("dySubmit", function(postUrl, scopeService){
        return {
            scope: {
                dySubmit: "=",
                dyFormData: "=formData",
                btnStatus: "=btnStatus"  //给按钮添加disabled的状态
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    scope.$apply(function () {
                        scope.btnStatus = true;  //防止重复提交
                    })
                    postUrl.events("/" + scope.dySubmit.url, scope.dyFormData).success(function(_data){
                        if(_data.status == 200){
                            parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                                scopeService.safeApply(scope, function () {
                                    scope.btnStatus = false;
                                });
                                if(!!scope.dySubmit.refresh_sub){
                                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                                } else if(!!scope.dySubmit.refresh_all){
                                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                                } else {
                                    // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                                    top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                    window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                                }
                                parent.layer.closeAll();
                            });
                        }else{
                            parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                                scopeService.safeApply(scope, function () {
                                    scope.btnStatus = false;
                                });
                            });
                        }
                    });
                })
            }
        }
    })
    //表单提交前的确认提示
    //<input type="submit" class="submit-btn" dy-submit-confirm="{url: formStruct.submit_url, text: formStruct.text}" form-data="formData" value="提交">
    .directive("dySubmitConfirm", function(postUrl){
        return {
            scope: {
                dySubmitConfirm: "=",
                dyFormData: "=formData"
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var btnStatus = true;
                    parent.layer.confirm(scope.dySubmitConfirm.text || "是否已经打印完成？", {
                        time: 0, //不自动关闭
                        icon: 3,
                        shade: 0.3,
                        title: "确认",
                        btn: ["确定", "取消"]
                    }, function(){
                        if(btnStatus){
                            btnStatus = false;
                            postUrl.events("/" + scope.dySubmitConfirm.url, scope.dyFormData).success(function(_data){
                                if(_data.status == 200){
                                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                                        // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                                        top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                        window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                                        parent.layer.closeAll();
                                    });
                                }else{
                                    parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                                        //window.location.reload();
                                    });
                                }
                            });
                        } else {
                            return;
                        }
                    });
                })
            }
        }
    })
    //<input type="submit" class="submit-btn" layer-confirm="{url: formStruct.submit_url, text: formStruct.text, title: formStruct.title}" form-data="formData" value="提交">
    .directive("layerConfirm", function(postUrl){
        return {
            scope: {
                layerConfirm: "=",
                dyFormData: "=formData"
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var btnStatus = true;
                    parent.layer.confirm(scope.layerConfirm.text || "是否确认？", {
                        time: 0, //不自动关闭
                        icon: 3,
                        shade: 0.3,
                        title: scope.layerConfirm.title || "确认",
                        btn: ["确定", "取消"]
                    }, function(){
                        if(btnStatus){
                            btnStatus = false;
                            postUrl.events("/" + scope.layerConfirm.url, scope.dyFormData).success(function(_data){
                                if(_data.status == 500){
                                    parent.layer.msg(_data.description, {
                                        icon: 2,
                                        shade: 0.3,
                                        time: 3000
                                    })
                                } else if(_data.status == 600){  //返回超时弹窗
                                    parent.layer.open({
                                        type: 2,
                                        title: "超时说明",
                                        shadeClose: false,
                                        maxmin: true,
                                        shade: 0.3,
                                        area: ["520px", "460px"],
                                        content: "/workbench/buss/addOutExp?id=" + _data.description
                                    });
                                } else {
                                    parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1000}, function(){
                                        if(!!scope.layerConfirm.refresh_sub){
                                            window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                                        } else if(!!scope.layerConfirm.refresh_all){
                                            top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                            window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                                        } else {
                                            // window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                                            top.frames["rightcontent"].reloadings();  //调用table页面的自定义函数刷新当前页面
                                            window.parent.document.getElementById("frameSlideRight").style.right = "-920px";
                                        }
                                        parent.layer.closeAll();
                                    });
                                }
                            });
                        } else {
                            return;
                        }
                    });
                })
            }
        }
    })
    //弹窗取消按钮
    .directive("layerClose", function(){
        return {
            link: function(scope, element, attrs){
                element.click(function(){
                    parent.layer.closeAll();
                })
            }
        }
    })

    //打开弹窗
    .directive("layerOpen", function(postUrl){
        return {
            restrict: "A",
            scope: {
                "layerOpen": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.layerOpen,
                        param = params.param ? "&param=" + params.param : "";
                    if(!!params.reback){  //侧滑头部打印模版弹窗
                        if(!!params.id){
                            parent.layer.open({
                                type: 2,
                                title: params.title || "审核",
                                shadeClose: false,
                                maxmin: true,
                                shade: 0.3,
                                area: ["750px", "650px"],
                                content: "/" + params.url + "?id=" + params.id + param
                            });
                        } else {
                            parent.layer.msg("请选择打印模板！", {icon: 2, time: 2000});
                        }
                    } else {
                        var url = params.url;
                        if(url.indexOf('&') == 0){
                            url = params.col[url.substr(1)];
                        }
                        var srcUrl = url.indexOf('http') == 0?url:("/" + url + "?id=" + params.id + param);
                        if(params.type == "full"){  //是否全屏显示
                            var index = parent.layer.open({
                                type: 2,
                                title: params.title || "审核",
                                shadeClose: false,
                                maxmin: false,
                                shade: 0.3,
                                area: ["750px", "650px"],
                                content: srcUrl
                            });
                            parent.layer.full(index);
                        } else {
                            parent.layer.open({
                                type: 2,
                                title: params.title || "审核",
                                shadeClose: false,
                                maxmin: true,
                                shade: 0.3,
                                area: [params.width || "750px", params.height || "650px"],
                                content: srcUrl
                            });
                        }
                    }
                })
            }
        }
    })

    //侧滑-删除
    .directive("layerDel", function(postUrl){
        return {
            restrict: "A",
            scope: {
                "layerDel": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.layerDel;
                    params.title = params.title || "删除";
                    var btnStatus = true;
                    parent.layer.confirm("确定是否" + params.title, {
                        time: 0, //不自动关闭
                        icon: 3,
                        shade: 0.3,
                        title: params.title,
                        btn: ["确定", "取消"]
                    }, function(index){
                        if(btnStatus){
                            btnStatus = false;
                            postUrl.events("/" + params.url, {id: params.id}).success(function(_data){
                                if(_data.status == 200){
                                    parent.layer.msg(_data.description, {icon: 1, time: 1000}, function(){
                                        window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);  //刷新一级侧滑

                                        window.parent.document.getElementById("detailDialog").src = "";  //清空侧滑iframe内容
                                        window.parent.document.getElementById("detailFrameSlide").style.right = "-920px";  //隐藏侧滑
                                        window.parent.document.getElementById("slideMask").style.display = "none";

                                        parent.layer.closeAll();
                                    });
                                }else{
                                    parent.layer.msg(_data.description, {icon: 2, time: 1000});
                                }
                            });
                        } else {
                            return;
                        }
                    });
                })
            }
        }
    })

    //打开新窗口
    .directive("windowOpen", function(){
        return {
            restrict: "A",
            scope: {
                "windowOpen": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.windowOpen;
                    window.open("/" + params.url + "?id=" + params.id, "_blank", "width=800, height=600, top=0px, left=0px");
                })
            }
        }
    })

    //预览打印
    .directive("dyPreview", function(){
        return {
            restrict: "A",
            scope: {
                "dyPreview": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var params = scope.dyPreview;
                    parent.layer.open({
                        type: 2,
                        title: params.title,
                        shadeClose: false,
                        maxmin: true,
                        shade: 0.3,
                        area: ["750px", "650px"],
                        content: "/" + params.url + "?id=" + params.id
                    });
                })
            }
        }
    })

    //跳转到配置的界面
    .directive("dyTarget", function($http,postUrl) {
        return {
            require: '?ngModel',
            scope: {
                'dyTarget':'=',
                'checkValue':'='
            },
            link: function(scope, element, attrs) {
                element.click(function(){
                    var params = scope.dyTarget;
                    params.title = params.title ||'授权';
                    if(scope.checkValue.length > 1 && params.single == 1){
                        parent.layer.msg(params.title + "的选项只能为一项", {
                            icon: 2,
                            shade: 0.3,
                            time: 2000
                        })
                    } else if(scope.checkValue.length == 0){
                        parent.layer.msg('请先选择要'+params.title+'的选项！',{
                            icon:2,
                            shade: 0.3,
                            time:1000
                        });
                    }else{
                        var checkValue = scope.checkValue.join(",");
                        window.location.href = '/'+params.url+'?id='+checkValue;
                    }
                })
            }
        }
    })



    //窗口变化，右侧内容随着变化
    // .directive("dyIframe", function($http){
    //     return {
    //         require: "?ngModel",
    //         scope: {
    //             "dyIframe": "="
    //         },
    //         link: function(scope, element, attrs){
    //             function iframeH(){
    //                 var t = element.offset().top,
    //                     c_h = document.body.clientHeight;
    //                 element.height(c_h - t);
    //             }
    //             window.onresize = function(){
    //                 iframeH();
    //             }
    //             iframeH();
    //         }
    //     }
    // })
    .directive("autoHeight", function($http){
        return {
            require: "?ngModel",
            scope: {
                "autoHeight": "="
            },
            link: function(scope, element, attrs){
                // function iframeH() {
                //     var bodyHeight = $("body").outerHeight(true) - 100 || 0,
                //         topHeight = $(".detail-top").outerHeight(true) || 0,
                //         navHeight = $(".detail-nav").outerHeight(true) || 0,
                //         tabHeight = $(".tab-nav").outerHeight(true) || 0;
                //     $(".detail-con").css("height", bodyHeight - topHeight - navHeight - tabHeight);

                //     var subTopHeight = $(".sub-detail-top").outerHeight(true) || 0;
                //     $(".sub-detail-con").css("height", bodyHeight - subTopHeight);
                // }
                // window.onresize = function() {
                //     iframeH();
                // }
                // iframeH();
            }
        }
    })
    //控制右侧列表的的tbody的高度自适应
    .directive("dyTable", function($http, $timeout){
        return {
            require: "?ngModel",
            scope: {
                "dyTable": "="
            },
            link: function(scope, element, attrs){
                function iframeH(){
                    var t = element.offset().top,
                        c_h = document.documentElement.clientHeight;
                    element.height(c_h - t - 46);
                }
                window.onresize = function(){
                    iframeH();
                }
                $timeout(function(){
                    iframeH();
                }, 1000);
            }
        }
    })
    //一级侧滑详情
    .directive("dyRight", function($http, $timeout, postUrl){
        return {
            require: "?ngModel",
            scope: {
                "dyRight": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var url = scope.dyRight.url,
                        id = scope.dyRight.id,
                        rec = scope.dyRight.col,
                        readurl = scope.dyRight.readUrl,
                        readid = scope.dyRight.readId,
                        show = scope.dyRight.show,
                        snode_id = scope.dyRight.snode_id;
                    element.addClass("current").siblings("tr").removeClass("current");
                    if(typeof url != "undefined" && url != ""){
                        if(show == 1){
                            var srcUrl = "/" + url+"?id="+id;  //二手房业务通知的侧滑不需要id与snode_id
                            postUrl.events("/" + readurl, {id: readid}).success(function(_data){
                                // var headTotal = Number($("#messageTotal", window.parent.document).text());
                                var listTotal = Number($("#slideMenu", window.parent.document).find("dd.on .msg").text());
                                // if(!!readid){
                                //     $("#messageTotal", window.parent.document).text(headTotal - 1);
                                // }
                                // $("#slideMenu", window.parent.document).find("dd.on .msg").text(listTotal - 1);
                                window.parent.document.getElementById("rightDialog").src = srcUrl;
                                parent.layer.msg("数据加载中...", {shade: 0.3, time: 1000}, function(){
                                    $("#frameSlideRight", window.parent.document).animate({right: "0px"}, 500);
                                });
                            });
                        } else {
                            if(url.indexOf('&') == 0){
                                url = rec[url.substr(1)];
                            }
                            var srcUrl = url.indexOf('http') == 0?url:("/" + url + "?id=" + id);
                            window.parent.document.getElementById("rightDialog").src = srcUrl;
                            window.parent.document.getElementById("subRightDialog").src = "";  //清空三级侧滑iframe内容
                            window.parent.document.getElementById("subSlideRight").style.right = "-920px";  //隐藏三级侧滑
                            parent.layer.msg("数据加载中...", {shade: 0.3, time: 1000}, function(){
                                $("#frameSlideRight", window.parent.document).animate({right: "0px"}, 500);
                                $timeout(function(){
                                    // window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                                }, 500)
                            });
                        }
                    }else{
                        return;
                    }
                })
            }
        }
    })
    //二级侧滑详情
    .directive("dyDetail", function($http, $timeout, $rootScope, getUrlParams){
        return {
            require: "?ngModel",
            scope: {
                "dyDetail": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var url = scope.dyDetail.url,
                        buss_id = scope.dyDetail.buss_id,
                        id = scope.dyDetail.id;
                    getUrlParams.events();  //获取slide参数
                    if(typeof url != "undefined"){
                        var srcUrl = "/" + url + "?id=" + id + "&buss_id=" + buss_id;
                        if($rootScope.params.slide == 3){
                            window.parent.document.getElementById("subRightDialog").src = "";  //清空三级侧滑iframe内容
                            window.parent.document.getElementById("subSlideRight").style.right = "-920px";  //隐藏三级侧滑

                            window.parent.document.getElementById("detailDialog").src = srcUrl;
                            window.parent.document.getElementById("slideMask").style.display = "block";
                            window.parent.document.getElementById("detailFrameSlide").style.right = "0";
                        } else {
                            window.parent.document.getElementById("detailDialog").src = srcUrl;
                            window.parent.document.getElementById("slideMask").style.display = "block";
                            parent.layer.msg("数据加载中...", {shade: 0.3, time: 1000}, function(){
                                $("#detailFrameSlide", window.parent.document).animate({"right": "0px", "z-index": "1002"}, 500);
                            });
                        }
                    }else{
                        return;
                    }
                })
            }
        }
    })
    //三级侧滑详情
    .directive("dySubDetail", function($http, $timeout){
        return {
            require: "?ngModel",
            scope: {
                "dySubDetail": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var url = scope.dySubDetail.url,
                        buss_id = scope.dySubDetail.buss_id;
                    if(typeof url != "undefined"){
                        var srcUrl = "/" + url + "?id=" + buss_id;
                        window.parent.document.getElementById("slideMask").style.display = "none";
                        window.parent.document.getElementById("subRightDialog").src = srcUrl;  //三级侧滑内容
                        parent.layer.msg("数据加载中...", {shade: 0.3, time: 1000}, function(){
                            $("#subSlideRight", window.parent.document).animate({right: "0px"}, 500, function(){  //显示三级侧滑
                                window.parent.document.getElementById("detailDialog").src = "";  //清空二级侧滑iframe内容
                                window.parent.document.getElementById("detailFrameSlide").style.right = "-920px";  //隐藏二级侧滑
                            });
                        });
                    }else{
                        return;
                    }
                })
            }
        }
    })
    //侧滑关闭
    .directive("closeDetail", function($http){
        return {
            require: "?ngModel",
            scope: {
                "closeDetail": "="
            },
            link: function(scope, element, attrs){
                element.click(function(){
                    var frameId = window.frameElement && window.frameElement.id || "";  //获取iframe的id
                    switch(frameId){
                        case "rightDialog":
                            $("#frameSlideRight", parent.document).animate({right: "-920px"}, 500, function(){  //一级侧滑
                                window.parent.document.getElementById("rightDialog").src = "";
                            });
                            break;
                        case "detailDialog":
                            window.parent.document.getElementById("detailDialog").src = "";  //清空二级侧滑iframe内容
                            window.parent.document.getElementById("detailFrameSlide").style.right = "-920px";  //隐藏侧滑
                            window.parent.document.getElementById("slideMask").style.display = "none";
                            break;
                        case "subRightDialog":
                            $("#subSlideRight", parent.document).animate({right: "-920px"}, 500, function(){  //三级侧滑
                                window.parent.document.getElementById("subRightDialog").src = "";
                            });
                            break
                    }
                })
            }
        }
    })

    //金额数字千位格式化
    .directive("numberFormat", function($parse){
        return {
            link: function(scope, element, attrs, ctrl){
                //控制输入框只能输入数字和小数点
                function limit(){
                    var limitV = element[0].value;
                    limitV = limitV.replace(/[^0-9.]/g, "");
                    element[0].value = limitV;
                    $parse(attrs['ngModel']).assign(scope, limitV);
                    format();
                }
                //对输入数字的整数部分插入千位分隔符
                function format(){
                    var formatV = element[0].value;
                    var array = new Array();
                    array = formatV.split(".");
                    var re = /(-?\d+)(\d{3})/;
                    while(re.test(array[0])){
                        array[0] = array[0].replace(re, "$1,$2")
                    }
                    var returnV = array[0];
                    for(var i=1; i<array.length; i++){
                        returnV += "." + array[i].substring(0, 2);
                    }
                    element[0].value = returnV;
                    $parse(attrs['ngModel']).assign(scope, formatV);
                }
                scope.$watch(attrs.ngModel, function(){
                    limit();
                })
            }
        };
    })

    //业务员选择
    .directive("dyUserSelect", function(scopeService,postUrl) { 
        return {
            restrict: 'AE',
            require: "?ngModel",
            template: '<div class="user-box">\
                            <span class="iconfont">&#xe60b;</span>\
                            <div class="add-user" title="{{user_name}}" ng-click="toggleUserBox();" ng-bind="user_name"></div>\
                            <div class="select-user" ng-class="{\'show-box\': userToggle}">\
                                <div class="user-area fn-clear">\
                                    <ul class="left">\
                                        <li class="department" ng-class="{\'current\': departmentId == list.value}" ng-repeat="list in departmentData" ng-bind="list.text" title="{{list.name}}" ng-click="getUserList(list.value, list.name);"></li>\
                                    </ul>\
                                    <div class="right">\
                                        <label class="form-radio" ng-repeat="user in user_list">\
                                            <input type="radio" value="{{user.id}}" ng-model="formData[fname]" ng-click="getUserName(user);" >\
                                            <span ng-bind="user.real_name"></span>\
                                        </label>\
                                        <label class="form-radio" ng-if="user_list.length == 0">\
                                            <span>暂无用户</span>\
                                        </label>\
                                    </div>\
                                </div>\
                                <div class="select-btn">\
                                    <a href="javascript:;" class="submit" ng-click="hideUserBox();">确定</a>\
                                </div>\
                            </div>\
                        </div>',
            scope: {
                "dyUserSelect": "="
            },
            link: function(scope, element, attrs) {
                scope.formData = scope.dyUserSelect.formData;
                scope.fname = scope.dyUserSelect.fname;
                scope.user_name = scope.formData[scope.dyUserSelect.showName];
                
                postUrl.events("/system/dept/deptOptions").success(function(_data){
                    if(_data.status == 200){
                        scope.departmentData = _data.data;
                    }
                });
                
                scope.userToggle = false;
                scope.departmentName = "";
                scope.post = true;
                scope.toggleUserBox = function(){
                    scope.userToggle = !scope.userToggle;
                }
                scope.getUserList = function(id, name){
                    scope.departmentName = name;
                    scope.departmentId = id;
                    scope.userListPost(id);
                }
                scope.getUserName = function(user){
                    scope.user_name = scope.departmentName + "-" + user.real_name;
                    scope.formData.managerId = user.id;
                }
                scope.userListPost = function(id){
                    scope.user_list = [];
                    postUrl.events("/loan/contract/getuser", {pid: id}).success(function(_data){
                        if(_data.status == 200){
                            scope.user_list = _data.data.items;
                        }else{
                            layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1000}, function(){
                                //window.location.reload();
                            });
                        }
                    });
                }
                scope.hideUserBox = function(){
                    scope.userToggle = false;
                }
                
            }
        }
    })
	
	//客户列表搜索
	.directive("dyCust", function(scopeService,postUrl) { 
		return {
			restrict: 'AE',
			require: "?ngModel",
			template: '<input readonly="readonly" name="companyName" type="text" class="form-input input-size-middle" ng-model="formData.companyName" ng-focus="getList(formData.companyName);" validator="required">\
		                	<div class="search-list" ng-show="customerList">\
		                <input type="text" class="form-input input-size-middle" ng-model="companyInputName" ng-change="getList(companyInputName);" ng-focus="getList(companyInputName);">\
		        		<ul>\
		                    <li ng-repeat="(keys, values) in searchall" ng-bind="values" ng-click="fillCustomer(keys, values);"></li>\
		                    <li ng-if="searchall.length == 0">没有相对应的客户名称</li>\
		        		</ul>\
		        	</div>',
			scope: {
				"dyCust": "="
			},
			link: function(scope, element, attrs) {
				scope.formData = scope.dyCust;
				scope.customerList = false;
			    var timer1 = null;
			    scope.getList = function(values){
			        clearTimeout(timer1);
			        timer1 = setTimeout(function(){
			            postUrl.events("/loan/searchcore", {"name": values}).success(function(_data){
			                if(_data.status == 200){
			                	scope.customerList = true;
			                    if (!scope.isEmptyObject(_data.list)) {
			                        // $scope.customerList = true;
			                    	scope.searchall = _data.list;
			                    } else {
			                        // $scope.customerList = false;
			                    	scope.searchall = [];
			                    }
			                }
			            })
			        }, 500)
			    }
			    scope.fillCustomer = function(id, name){
			    	scope.formData.companyId = id;
			    	scope.formData.companyName = name;
			    	scope.companyInputName = name;
			    	scope.customerList = false;
			    }
				
			    scope.isEmptyObject = function(obj){
			        for (var key in obj) {
			            return false;
			        }
			        return true;
			    }
			}
		}
	})
	//核心企业列表搜索
	.directive("dyCustCore", function(scopeService,postUrl) { 
		return {
			restrict: 'AE',
			require: "?ngModel",
			template: '<input readonly="readonly" name="companyCoreName" type="text" class="form-input input-size-middle" ng-model="formData.companyCoreName" ng-focus="getBuyerCustomerList(formData.companyCoreName);" validator="required">\
		                	<div class="search-list" ng-show="buyerCustomerList">\
		                <input type="text" class="form-input input-size-middle" ng-model="companyCoreInputName" ng-change="getBuyerCustomerList(companyCoreInputName);" ng-focus="getBuyerCustomerList(companyCoreInputName);">\
		        		<ul>\
		                    <li ng-repeat="(keys, values) in searchCustomer" ng-bind="values" ng-click="fillBuyerCustomer(keys, values);"></li>\
		                    <li ng-if="searchCustomer.length == 0">没有相对应的买方客户名称</li>\
		        		</ul>\
		        	</div>',
			scope: {
				"dyCustCore": "="
			},
			link: function(scope, element, attrs) {
				scope.formData = scope.dyCustCore;
				scope.buyerCustomerList = false;
			    var timer2 = null;
			    scope.getBuyerCustomerList = function(values){
			        clearTimeout(timer2);
			        timer2 = setTimeout(function(){
			            postUrl.events("/loan/searchall", {"name": values}).success(function(_data){
			                if(_data.status == 200){
			                	scope.buyerCustomerList = true;
			                    if (!scope.isEmptyObject(_data.list)) {
			                        // $scope.buyerCustomerList = true;
			                    	scope.searchCustomer = _data.list;
			                    } else {
			                        // $scope.buyerCustomerList = false;
			                    	scope.searchCustomer = [];
			                    }
			                }
			            })
			        }, 500)
			    }
			    scope.fillBuyerCustomer = function(id, name){
			    	scope.formData.companyCoreId = id;
			    	scope.formData.companyCoreName = name;
			    	scope.companyCoreInputName = name;
			    	scope.buyerCustomerList = false;
			    }
				
				scope.isEmptyObject = function(obj){
					for (var key in obj) {
						return false;
					}
					return true;
				}
			}
		}
	})
    //上传附件
    .directive("uploadAtta", function(scopeService,postUrl) {
        return {
            restrict: 'AE',
            require: "?ngModel",
            templateUrl: '/assets/ngtpl/uploaddoc.html',
            scope: {
                "uploadAtta": "="
            },
            link: function(scope, element, attrs) {
                scope.formData = scope.uploadAtta.formData;
                scope.fname = scope.uploadAtta.fname;
                scope.ffname = 'fff_'+scope.uploadAtta.fname;
                scope.deleteAttachment = function(index){
                    scope.formData[scope.ffname].splice(index, 1);
                }
                scope.$watch('formData[ffname]',function(newValue,oldValue){
                    if(newValue){
                        scope.formData[scope.fname] = "";
                        for(var i=0;i<newValue.length;i++){
                            if(i==newValue.length-1){
                                scope.formData[scope.fname] += newValue[i].did;
                            }else{
                                scope.formData[scope.fname] += newValue[i].did+",";
                            }
                        }
                    }
                });
            }
        }
    })
	//附件信息
	.directive("attachShow", function(scopeService,postUrl) {
		return {
			restrict: 'AE',
			require: "?ngModel",
			templateUrl: '/assets/ngtpl/attach.html',
			scope: {
				"attachShow": "="
			},
			link: function(scope, element, attrs) {
				scope.documents = scope.attachShow;
			}
		}
	})
	
	//电子协议信息
	.directive("protocolShow", function(scopeService,postUrl) {
		return {
			restrict: 'AE',
			require: "?ngModel",
			templateUrl: '/assets/ngtpl/protocol.html',
			scope: {
				"protocolShow": "="
			},
			link: function(scope, element, attrs) {
				scope.protocols = scope.protocolShow;
			}
		}
	})
	//审批记录信息
	.directive("approveShow", function(scopeService,postUrl) {
		return {
			restrict: 'AE',
			require: "?ngModel",
			templateUrl: '/assets/ngtpl/approve.html',
			scope: {
				"approveShow": "="
			},
			link: function(scope, element, attrs) {
				scope.flowList = scope.approveShow;
			}
		}
	})
	//货物列表清单选择
	.directive("agPurList", function(scopeService,postUrl) {
		return {
			restrict: 'AE',
			require: "?ngModel",
			templateUrl: '/assets/ngtpl/agPurList.html',
			scope: {
				"agPurList": "="
			},
			link: function(scope, element, attrs) {
				scope.formlist = scope.agPurList.purlist;
				scope.formData = scope.agPurList.submData;

				// 转换option的value值类型
			    for(var i=0,len=scope.formlist.length;i<len;i++){
			    	if(scope.formlist[i].options && scope.formData){
			    		var fv = scope.formData[scope.formlist[i].name];
			    		var opv = scope.formlist[i].options[0].value;
			    		if(angular.isNumber(fv) && angular.isString(opv)){
			    			// string => number
			    			for(var j=0,lenj=scope.formlist[i].options.length;j<lenj;j++){
			    				scope.formlist[i].options[j].value = Number(scope.formlist[i].options[j].value);
			    			}
			    		}else if(angular.isString(fv) && angular.isNumber(opv)){
			    			// number => string
			    			for(var j=0,lenj=scope.formlist[i].options.length;j<lenj;j++){
			    				scope.formlist[i].options[j].value = String(scope.formlist[i].options[j].value);
			    			}
			    		}
			    	}
			    }

				scope.linklist = [{'name':'category1'},{'name':'category2'},{'name':'category3'}];
				scope.$watch('formData.category2',function(newValue,oldValue){
                    if(newValue){
                        postUrl.events("/warehouse/warehouseProduct/options",
                                {'category1':scope.formData.category1,'category2':scope.formData.category2})
                                .success(function(data) {
                                    scope.products = data.data;
                                });
                    }else{
                        scope.products = [];
                    }
                });
                scope.$watch('formData.category3',function(newValue,oldValue){
                    if(scope.formData.category2){
                        postUrl.events("/warehouse/warehouseProduct/options",
                                {'category1':scope.formData.category1,'category2':scope.formData.category2,'category3':scope.formData.category3})
                                .success(function(data) {
                                    scope.products = data.data;
                                });
                    }else{
                        scope.products = [];
                    }
                });
				
				scope.producChange = function(){
					var prod = {};
					if(scope.products){
						for(var i=0;i<scope.products.length;i++){
							if(scope.products[i].value ==  scope.formData.goodsProductId){
								prod = scope.products[i];
								break;
							}
						}
					}
					scope.formData.last_price = prod.last_price;
					scope.formData.last_price_date = prod.last_price_date;
					
				}
			}
		}
	})
	//货物列表清单选择1
	.directive("agPurListA", function(scopeService,postUrl) {
        return {
            restrict: 'AE',
            require: "?ngModel",
            templateUrl: '/assets/ngtpl/agPurListA.html',
            scope: {
                "agPurListA": "="
            },
            link: function(scope, element, attrs) {
                scope.curItem = {};
                scope.itemList = scope.agPurListA.purlist;
                scope.submData = scope.agPurListA.submData;
                if(!scope.submData[scope.agPurListA.colName]){
                    scope.submData[scope.agPurListA.colName] = [];
                }

                // scope.formData = scope.submData[scope.agPurListA.colName];

                scope.formData = {};
                scope.formData.tableB = scope.submData[scope.agPurListA.colName];

                scope.category1 = [];  //初始化selectLink
                scope.selectLink = [{"category2": []}, {"product": []}];
                scope.number = 0;

                scope.addPurchase = function(){
                    var purchase_list = {}
                    scope.formData.tableB.push(purchase_list);

                    var category = scope.category1;
                    if(category.length == 0){  //初始化selectLink一级分类
                        postUrl.events("/warehouse/warehouseCollateralCategory/options", {}).success(function(_data){
                            if(_data.status == 200){
                                scope.category1 = _data.data;  //缓存一级分类
                            }
                        })
                    } else {
                        scope.selectLink.push({"category2": []}, {"product": []});
                    }

                    scope.$watch("formData.tableB[" + scope.number + "].num + formData.tableB[" + scope.number + "].price", function(){
                        updateAmount();
                    })

                    scope.number++;

                }

                if(scope.formData.tableB.length > 0){
                    scope.number = scope.formData.tableB.length;
                    scope.selectLink = [];
                    postUrl.events("/warehouse/warehouseCollateralCategory/options", {}).success(function(_data){
                        if(_data.status == 200){
                            scope.category1 = _data.data;  //缓存一级分类
                        }
                    })
                    for(var key=0, len=scope.formData.tableB.length; key<len; key++){
                        (function(num) {
                            setTimeout(function() {
                                scope.selectLink.push({"category2": []}, {"product": []});
                                postUrl.events("/warehouse/warehouseCollateralCategory/options", {"category1": scope.formData.tableB[num].category1}).success(function(_data){
                                    scope.selectLink[num].category2 = _data.data;
                                })
                                postUrl.events("/warehouse/warehouseProduct/options", {"category2": scope.formData.tableB[num].category2}).success(function(product){
                                    scope.selectLink[num].product = product.data;
                                    scope.producChange(num);
                                })
                            }, 100);
                        })(key);

                        scope.$watch("formData.tableB[" + key + "].num + formData.tableB[" + key + "].price", function(){
                            updateAmount();
                        })
                    }
                }

                //产品联动
                scope.getCategory = function(index, type, value){
                    switch(type){
                        case "category1":
                            if(typeof value == "number" || typeof value == "string"){
                                postUrl.events("/warehouse/warehouseCollateralCategory/options", {"category1": value}).success(function(_data){
                                    scope.selectLink[index].category2 = _data.data;
                                })
                            } else {
                                scope.selectLink[index].category2 = [];
                                // scope.selectLink[index].category3 = [];
                                scope.selectLink[index].product = [];
                                scope.formData.last_price = "";
                                scope.formData.last_price_date = "";
                            }
                            break;
                        case "category2":
                            if(typeof value == "number" || typeof value == "string"){
                                // postUrl.events("/warehouse/warehouseCollateralCategory/options", {"category2": value}).success(function(_data){
                                //     scope.selectLink[index].category3 = _data.data;
                                // })

                                postUrl.events("/warehouse/warehouseProduct/options", {"category2": value}).success(function(product){
                                    scope.selectLink[index].product = product.data;
                                })
                            } else {
                                // scope.selectLink[index].category3 = [];
                                scope.selectLink[index].product = [];
                                scope.formData.last_price = "";
                                scope.formData.last_price_date = "";
                            }
                            break;
                        // case "category3":
                        //     if(typeof value == "number" || typeof value == "string"){
                        //         postUrl.events("/warehouse/warehouseProduct/options", {"category3": value}).success(function(product){
                        //             scope.selectLink[index].product = product.data;
                        //         })
                        //     } else {
                        //         scope.selectLink[index].product = [];
                        //         scope.formData.last_price = "";
                        //         scope.formData.last_price_date = "";
                        //     }
                        //     break;
                    }
                }

                scope.producChange = function(index){
                    var prod = {};
                    var product = scope.selectLink[index].product;
                    if(product.length != 0){
                        for(var i=0; i<product.length; i++){
                            if(product[i].value == scope.formData.tableB[index].goodsProductId){
                                prod = product[i];
                                break;
                            }
                        }
                    }
                    scope.formData.tableB[index].last_price = prod.last_price;
                    scope.formData.tableB[index].last_price_date = prod.last_price_date;
                    // scope.formData.tableB[index].price = prod.last_price;
                    scope.formData.tableB[index].unit = prod.unit;
                    scope.formData.tableB[index].goodName = prod.text;
                }

                scope.deleteIds = [];
                scope.delPurchase = function(index){
                    scope.deleteIds.push(scope.formData.tableB[index]["id"]);
                    scope.formData.tableB.splice(index, 1);

                    scope.number--;  //重置selectLink的添加序号

                    scope.selectLink.splice(index, 1);

                    updateAmount();

                    scope.submData.deleteIds = scope.deleteIds.join(",");
                }

                scope.submData.depositRatio = scope.submData.depositRatio || 0;  //保证金比例
                scope.$watch("submData.depositRatio + submData.depositType", function(){
                    updateAmount();
                })

                function updateAmount(){
                    scope.submData.amount = 0;
                    scope.submData.purAmount = 0;
                    for(var i=0; i<scope.formData.tableB.length; i++){
                        if(scope.formData.tableB[i].price && scope.formData.tableB[i].num){
                            scope.submData.purAmount += scope.formData.tableB[i].price*scope.formData.tableB[i].num;
                        }
                    }
                    if(scope.submData.depositType != 1){
                        scope.submData.amount = scope.submData.purAmount*(100-scope.submData.depositRatio)/100
                    }else{
                        scope.submData.amount = scope.submData.purAmount;
                    }
                }
            }
        }
    })
	//服务费
	.directive("dyFee", function(scopeService,postUrl, $timeout) {
        return {
            restrict: 'AE',
            require: "?ngModel",
            templateUrl: '/assets/ngtpl/fee.html',
            scope: {
                "dyFee": "="
            },
            link: function(scope, element, attrs) {
                scope.formData = scope.dyFee.formData;
                scope.fnames = scope.dyFee.fname.split(',');
                scope.textShow = function(){
                    if(scope.formData.loanFeeType == 1){
                        return "按月收取：借款金额*比例";
                    }else if(scope.formData.loanFeeType == 2){
                        return "按日收取：借款金额*比例";
                    }
                    return "关闭";
                }
                
            }
        }
    })
    //逾期费用
    .directive("dyOverdueFee", function(scopeService,postUrl, $timeout) {
        return {
            restrict: 'AE',
            require: "?ngModel",
            templateUrl: '/assets/ngtpl/overfee.html',
            scope: {
                "dyOverdueFee": "="
            },
            link: function(scope, element, attrs) {
                scope.formData = scope.dyOverdueFee.formData;
                scope.fnames = scope.dyOverdueFee.fname.split(',');
                scope.textShow = function(){
                    if(scope.formData.overdueStatus){
                        return "按待还本金*";
                    }
                    return "关闭";
                }
                
            }
        }
    })
    // 下拉选项变动监听
    .directive("fieldChangeLis", function(scopeService,postUrl, $timeout) {
    	return {
    		restrict: 'AE',
    		require: "?ngModel",
    		scope: {
    			"fieldChangeLis": "="
    		},
    		link: function(scope, element, attrs) {
    			scope.formData = scope.fieldChangeLis.formData;
    			var fl = scope.fieldChangeLis.field;
    			var formlist = scope.fieldChangeLis.formlist;
    			
    			if(fl.dataparams && fl.dataparams.startsWith('&')){
    				var adap = fl.dataparams.substring(1).split('.');
    				scope.$watch("formData." + adap, function () {
    					if(scope.formData[adap]){
    						postUrl.events("/"+fl.url, {id:scope.formData[adap]}).success(function (_data) {
    							if(_data.status==200){
    								for(var pro in _data.data){
    									var profi = {};
    									for(var i=0;i< formlist.length;i++){
    										if(formlist[i].name == pro){
    											profi = formlist[i];
    											break;
    										}
    									}
    									if(profi.type == 'select'){
    										profi.options = _data.data[pro];
    									}else {
    										scope.formData[pro] = _data.data[pro];
    									}
    								}
    							}
    						})
    					}
                    })
                }
    			
    		}
    	}
    })
    //代码片段指令(演示用)
		.directive("hello", function(scopeService,postUrl, $timeout) {
			return {
				restrict: 'A',
				link: function(scope, element, attrs) {
					console.log("hello! ",scope,scope.formData,scope.list)
				}
			}
		})
		//选择产品
		.directive("dyProductSele", function(scopeService,postUrl, $timeout) {
			return {
				restrict: 'AE',
				require: "?ngModel",
				templateUrl: '/assets/ngtpl/productSele.html',
				scope: {
					"dyProductSele": "="
				},
				link: function(scope, element, attrs) {
					scope.formData = scope.dyProductSele.formData;
					scope.list = scope.dyProductSele.col;
					scope.product = {};
					
					function linkData(product){
                        scope.formData.loanFeeType = product.loanFeeType;
                        scope.formData.loanFeeValue = (product.loanFeeValue*100).toFixed(2);
                        //scope.formData.overdueStatus = product.overdueStatus;
                        //scope.formData.overdueRateType = product.overdueRateType;
                        //scope.formData.overdueRateValue = (product.overdueRateValue*100).toFixed(2);
                        scope.formData.loanApr = (Number(product.loanAprStart)).toFixed(2);
                        scope.formData.depositType = product.depositType;
                        if(product.companyId){
                            scope.formData.capitalId = product.companyId+"";
                        }
                        //显示费用
                		if(!scope.formData.debitId)
                        	scope.formData.fees = product.fees;
                		if(!scope.formData.debitId)
                			scope.formData.overdueRateValues = angular.fromJson(product.overdueRateValue);
                    }
					
					scope.productSelectChange = function(){
						var proid = scope.formData[scope.list.name];
						var product = {}
						if(proid && proid != ""){
							if(scope.product[proid]){
								product = scope.product[proid];
							}else{
								postUrl.events("/prod/product/getOne",{'id':proid})
								.success(function(data_) {
									if(data_.status == 200){
										scope.product[data_.data.id] = data_.data;
										linkData(data_.data);
									}
								});
							}
						}
						linkData(product);
					}
				}
			}
		})
        //时间戳转换格式
        .directive("changeDateType", function($filter){
            return {
                restrict: 'AE',
                require: "?ngModel",
                scope: {
                    "changeDateType": "="
                },
                link: function(scope, element, attrs, ctrl){
                    var dateFilter = $filter("date");
                    var timeStampFilter = $filter("timestamp");
                    function formatter(value) {  //把时间戳转换为日期格式 model to view
                        return dateFilter(timeStampFilter(value), "yyyy-MM-dd");
                    }

                    function parser() {  //把日期格式转换为时间戳 view to model
                        if(ctrl.$viewValue){
                            return Date.parse(new Date(ctrl.$viewValue.replace(/-/g,  "/")))/1000;
                        } else {
                            return "";
                        }
                    }
                    ctrl.$formatters.push(formatter);
                    ctrl.$parsers.unshift(parser);
                }
            }
        })
		//formField
		.directive("dyFormField", function(scopeService,postUrl, $timeout,$templateCache) {
			return {
				restrict: 'AE',
				require: "?ngModel",
				replace: true,
				scope: {
					"dyFormField": "="
				},
				template: '<div ng-include="getContentUrl()"></div>',
				link: function(scope, element, attrs) {
					var tplName = scope.dyFormField.field.name+'_fftpl_'+scope.dyFormField.index+'.html';
					scope.formData = scope.dyFormField.formData;
					scope.list = scope.dyFormField.field;
					var list = scope.list;
					var direc = list.direc;
					var tpl = '';
					var validator = list.verify?'validator="{{list.verify}}"':'';
					if(list.type.startsWith('span')){
						var ngbind = '((list.dataparams && !list.dataparams.startsWith(\'=\') && !list.dataparams.startsWith(\'&\'))?parseVal(list.dataparams):formData[list.name])';
						tpl = '<div class="col-con-temp" '+direc+'>\
                                    <span ng-if="list.type == \'span\'" ng-bind="'+ngbind+'" class="txt"></span>\
                                    <span ng-if="list.type == \'span_n\'" ng-bind="'+ngbind+' | number:2" class="txt"></span>\
                                    <span ng-if="list.type == \'span_d\'" ng-bind="'+ngbind+' | timestamp | date:\'yyyy-MM-dd\'" class="txt"></span>\
                                    <span ng-if="list.type == \'span_dt\'" ng-bind="'+ngbind+' | timestamp | date:\'yyyy-MM-dd HH:mm:ss\'" class="txt"></span>\
                                    <span class="txt" ng-if="list.remarks" ng-bind="list.remarks"></span>\
                                </div>'
					}else if(list.type=='cust'){
						tpl = '<div class="col-con-temp" dy-cust="formData" '+direc+'></div>'
					}else if(list.type=='fee'){
						tpl = '<div class="col-con-temp" dy-fee="{formData:formData,fname:list.name}" '+direc+'></div>'
                    }else if(list.type=='overfee'){
                        tpl = '<div class="col-con-temp" dy-overdue-fee="{formData:formData,fname:list.name}" '+direc+'></div>'
                    }else if(list.type=='prosele'){
						tpl = '<div class="col-con-temp" dy-product-sele="{formData:formData,col:list}" '+direc+'></div>'
					}else if(list.type=='custcore'){
						tpl = '<div class="col-con-temp" dy-cust-core="formData" '+direc+'></div>'
					}else if(list.type=='usersele'){
						tpl = '<div class="col-con-temp" dy-user-select="{formData:formData,showName:list.dataparams,fname:list.name}" '+direc+'></div>'
					}else if(list.type=='uploadatta'){
						tpl = '<div class="col-con-temp" upload-atta="{formData:formData,fname:list.name}" '+direc+'></div>'
					}else if(list.type=='listener'){
						tpl = '<div field-change-lis="{formData:formData,field:list,formlist:formlist}" '+direc+'></div>'
					}else if(list.type=='editor'){
						tpl = '<div '+direc+'><div ueditor style="min-height:200px; width:80%;" name="{{list.name}}" ng-model="formData[list.name]"></div></div>'
					}else if(list.type=='ueditor'){
						tpl = '<div '+direc+'><div class="ueditor" name="{{list.name}}" ng-model="formData[list.name]"></div></div>'
					}else if(list.type=='date'){
						tpl = '<div class="col-con-temp" '+direc+'><input type="text" readonly class="form-input input-size-middle" change-date-type date-picker="{{list.dateOptions}}" ng-model="formData[list.name]" name="{{list.name}}" id="{{list.id}}" '+validator+'></div>'
					}else if(list.type=='texturl'){
						tpl = '<div class="col-con-temp" '+direc+'>\
		                      	<span class="txt">可下载调用字段<a class="c-blue" href="/template/business_fields.xlsx">《业务件字段表》</a>，将要调用的字段代码放入对应的内容，打印时即可调用到该内容</span>\
	                          </div>'
					}else if(list.type=='input' || list.type=='pwd'){
						var type = (list.type=='pwd'?'password':'text');
						tpl = '<div class="col-con-temp" '+direc+'>\
			                        <span class="txt" ng-if="list.pre_text" ng-bind="list.pre_text"></span>\
			                        <input type="'+type+'" class="form-input input-size-middle {{list.clasz}}" name="{{list.name}}" placeholder="{{list.placeholder}}" ng-model="formData[list.name]" '+validator+' >\
			                        <span class="txt" ng-if="list.remarks" ng-bind="list.remarks"></span>\
			                    </div>'
					}else if(list.type=='textarea'){
						tpl = '<div class="col-con-temp" '+direc+'><textarea class="form-textarea textarea-size-big" name="{{list.name}}" placeholder="{{list.placeholder}}" ng-model="formData[list.name]" '+validator+'></textarea></div>'
					}else if(list.type=='radio'){
						tpl = '<div class="col-con-temp" '+direc+'>\
			                        <div ng-if="list.verify">\
				                        <label ng-repeat="radiolist in list.options" class="form-radio"><input type="radio" name="{{list.name}}" ng-model="formData[list.name]" value="{{radiolist.value}}" validator="{{list.verify}}" validation-group="{{list.name}}"><span ng-bind="radiolist.text"></span></label>\
				                        <span id="{{list.name}}"></span>\
				                    </div>\
				                    <div ng-if="!list.verify">\
				                        <label ng-repeat="radiolist in list.options" class="form-radio"><input type="radio" name="{{list.name}}" ng-model="formData[list.name]" value="{{radiolist.value}}"><span ng-bind="radiolist.text"></span></label>\
				                    </div>\
				                </div>'
					}else if(list.type=='checkbox'){
						tpl = '<div class="col-con-temp" '+direc+'>\
                                    <label ng-repeat="checkboxlist in list.options" class="form-checkbox"><input type="checkbox" name="{{checkboxlist.name}}" checklist-model="formData[list.name]" checklist-value="checkboxlist.value" ><span ng-bind="checkboxlist.text"></span></label>\
                                    <span id="{{list.name}}"></span>\
                                </div>'
					}else if(list.type=='select'){
						tpl = '<div class="col-con-temp" '+direc+'>\
			                        <select name="{{list.name}}" ng-model="formData[list.name]"\
			                                ng-options="a.value as a.text for a in list.options"\
			                                '+validator+' class="form-select select-size-middle">\
			                            <option value="">-- 请选择 --</option>\
			                        </select>\
			                </div>'
					}else if(list.type=='linkselect'){
						if(validator && validator != ''){
							validator += ' validation-group="{{list.name}}" ' ;
						}
						tpl = '<div class="col-con-temp" '+direc+'>\
				                        <div dy-select dataurl="{{list.url}}">\
					                        <select ng-repeat="items in list.linklist" name="{{items.name}}" ng-model="formData[items.name]"\
					                                ng-options="a.value as a.text for a in linkData[$index]"\
													'+validator+' class="form-select select-size-small" ng-change="linkFn({{{items.param}}:formData[items.name],index:$index})" style="margin-right: 4px;">\
					                            <option value="">-- 请选择 --</option>\
					                        </select>\
					                        <span id="{{list.name}}"></span>\
				                    </div>\
				                </div>'
					}
					$templateCache.put(tplName, tpl);
					scope.getContentUrl = function() {
	                    return tplName;
	                }
					
					scope.parseVal = function(expre){
						return scope.$eval(expre);
					}
					
				}
			}
		})
		//利息及费用模板
	    .directive("tplProdFee", function (scopeService) {
		    return {
		    	restrict: "EA",
		        require: "?ngModel",
		        templateUrl: "/assets/ngtpl/prodFee.html",
		        //scope: {
		        //    "tplProdFee": "="
		        //},
		        link: function(scope, element, attrs) {
		        	//借款期限及费率
		            scope.addFeeValue = function(){
		                var fee_value = {
		        	            "loanDay": "",
		        	            "loanFeeValue": null,
		        	            "loanApr": ""
		                };
		                scope.formData.feeValues.push(fee_value);
		            }
		            //删除买方基本信息
		            scope.deleteFeeValue = function(index){
		                scope.formData.feeValues.splice(index, 1);
		            }
		            
		            //逾期罚息
		            if(scope.formData.overdueRateValue){
		            	scope.formData.overdueRateValues=angular.fromJson(scope.formData.overdueRateValue);
		            }else{
		            	scope.formData.overdueRateValues=[];
		            }
		            scope.addOverdueRateValue = function(){
		                var item = {
		        	            "rate": null,
		        	            "start": null,
		        	            "end": null
		                };
		                scope.formData.overdueRateValues.push(item);
		            }
		            //if(!scope.formData.overdueRateValues||scope.formData.overdueRateValues.length==0){
		            //	scope.addOverdueRateValue();
		            //}
		            scope.deleteOverdueRateValue = function(index){
		                scope.formData.overdueRateValues.splice(index, 1);
		            }
		            //其他服务费
		            if(typeof scope.formData.fees == "undefined" || scope.formData.fees == ""){
		            	scope.formData.fees = [];
		            }
		            scope.addFee = function(){
		                var item = {value:"",label:"",description:""};
		                scope.formData.fees.push(item);
		            }
		            if(!scope.formData.fees||scope.formData.fees.length==0){
		            	//scope.addFee();
		            }
		            scope.deleteFee = function(index){
		                scope.formData.fees.splice(index, 1);
		            }
		            
		            scope.changeFormula=function(data){
		            	for(var i=0;i<scope.formStruct.prod_fee_item.length;i++){
		            		var item=scope.formStruct.prod_fee_item[i];
		            		if(data.value==item.value){
		            			data.description=item.description;
		            			break;
		            		}
		            	}
		            }
		            
		            scope.formStruct.beforeSubmit=function(){
		            	//校验逾期罚息
		                var first,second;
		                for(var i=0;i<scope.formData.overdueRateValues.length-1;i++){
		                	first=scope.formData.overdueRateValues[i];
		                	second=scope.formData.overdueRateValues[i+1];
		                	if(first.end!=second.start){
		                		parent.layer.msg("逾期罚息逾期日不连续",{icon: 2,shade: 0.3,time:1500},function(){
		                        });
		                		return false;
		                	}
		                }
		                if(scope.formData.overdueRateValues&&scope.formData.overdueRateValues.length>0){
		                	second=scope.formData.overdueRateValues[scope.formData.overdueRateValues.length-1];
		                	if(second&&second.end){
		                		parent.layer.msg("逾期罚息最后一行截止日需为空",{icon: 2,shade: 0.3,time:1500},function(){
		                        });
		                		return false;
		                	}
		                }
		                //其他费用
		                scope.formData.prodFeeId="";
		        		for(var i=0;i<scope.formData.fees.length;i++){
		        			scope.formData.prodFeeId+=scope.formData.fees[i].value+(i==scope.formData.fees.length-1?"":",");
		        		}
		        		//逾期
		        		angular.forEach(scope.formData.overdueRateValues, function(value, key){
		        			value.rate=value.rate?Number(value.rate).toFixed(2):null;
		        			value.start=value.start?Number(value.start):null;
		        			value.end=value.end?Number(value.end):null;
		        		})
		        		scope.formData.overdueRateValue = angular.toJson(scope.formData.overdueRateValues, false);
		        		return true;
		            }
				}
		    }
		})
	//逾期费用
    .directive("tplFeeList", function(scopeService,postUrl, $timeout) {
        return {
            restrict: 'AE',
            require: "?ngModel",
            templateUrl: '/assets/ngtpl/tplFeeList.html'
            //scope: {
            //    "tplFeeList": "="
            //},
            //link: function(scope, element, attrs) {
                //scope.formData = scope.tplFeeList.formData;
            //}
        }
    })
module.exports = dyDir;

