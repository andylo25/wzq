var dyFilters = angular.module("dyFilters", [])
    // angular.module('filters', [])
        /**
         * units Filter
         * @Param price
         * @Param units, default is "元"
         * @Param units2, default is "万元"
         * @return number
         */
        /**
         * Usage
         * var myText = "100000";
         * {{myText|units}}
         * {{myText|units:"元":"xx"}}
         * {{myText|units:"元":"xx","1000"}}
         * Output
         * "10万元"
         * "10xx"
         * "1000xx"
         */
        .filter('units', function() {
            return function(price, units, units2, min) {
                //数字加上千位分割
                function fmoney(s, n) {
                    n = n > 0 && n <= 20 ? n : 2;
                    s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
                    var l = s.split(".")[0].split("").reverse(),
                        r = s.split(".")[1];
                    t = "";
                    for (i = 0; i < l.length; i++) {
                        t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
                    }
                    return t.split("").reverse().join("") + "." + r;
                }

                if (isNaN(min))
                    min = 10000;

                if (units === undefined)
                    units = "元";

                if (units2 === undefined)
                    units2 = "万元";

                if (price >= min) {
                    var newPrice = fmoney((price / min), 2);
                    return newPrice + "<em>" + units2 + "</em>";
                } else {
                    return fmoney(price, 2) + "<em>" + units + "</em>";
                }

            };
        })
        /**
         * Truncate Filter
         * @Param text
         * @Param length, default is 10
         * @Param end, default is "..."
         * @return string
         */
        /**
         * Usage
         * var myText = "This is an example.";
         * {{myText|Truncate}}
         * {{myText|Truncate:5}}
         * {{myText|Truncate:25:" ->"}}
         * Output
         * "This is..."
         * "Th..."
         * "This is an e ->"
         */
        .filter('truncate', function() {
            return function(text, leng, end) {
                if (text != undefined) {
                    if (isNaN(leng))
                        leng = 10;
                    if (end === undefined)
                        end = '...';
                    if (text.length <= leng) {
                        return text;
                    } else {
                        return String(text).substring(0, leng) + end;
                    }
                }
            };
        })
        // 过滤undefined时，显示默认值
        .filter('judge', function() {
            return function(t, d) {
                if (d === undefined)
                    d = 0;
                if (t === undefined)
                    t = d;
                return t;
            }
        })
        //转换时间戳指令，将php返回过来的10位的时间戳转换为13位
        .filter("timestamp", function() {
            var filterfun = function(time) {
                if(time){
                    if(angular.isNumber(time) || time.length == 10){
                        return time += '000';
                    }
                    return time;
                }
                return "";
            };

            return filterfun;
        })
        //截取字符串
        .filter('dylimitTo', function() {
            return function(s, n, sg, sgn) {
                n = n || 3;
                sg = sg || '*';
                sgn = sgn || 2;
                s = s.length < n ? s : s.substring(0, n);
                var sgs = "";
                for (var i = 0; i < sgn; i++) {
                    sgs += sg;
                }
                return s + sgs;
            }
        })
        //解决标签被转义
        .filter('to_trusted', ['$sce', function($sce) {
            return function(text) {
                return $sce.trustAsHtml(text);
            };
        }])

    //强制转为浮点型
    .filter('numeric', function() {
        return function(number) {
            number = number.replace(',', '');
            number = parseFloat(number);
            return number;
        };
    })

    //空或0字符过滤
    .filter('empty', function() {
        return function(val, sign, unit) {
            sign = sign === undefined ? sign : '-';
            unit = unit ? unit : '';
            val = (sign === undefined || val == 0.00) ? sign : val + unit;
            return val;
        };
    })
    .filter('pretxt', function() {
        return function(val,txt) {
            return txt+val;
        };
    })
    .filter('percent', function() {
    	return function(val) {
    		if(!val && val != 0)return "";
    		var val = Math.round(parseFloat(val)*100)/100;
    		var xsd=val.toString().split(".");
    		if(xsd.length==1){
    			val=val.toString()+".00";
    			return val+"%";
    		}
    		if(xsd.length>1){
    			if(xsd[1].length<2){
    				alue=val.toString()+"0";
    			}
    			return val+"%";
    		}
    	}
    })
    // 金额显示
    .filter('currency', function() {
    	return function formatCurrency(num) {
    	    num = num.toString().replace(/\$|\,/g,'');
    	    if(isNaN(num)) num = "0";
    	    var sign = (num == (num = Math.abs(num)));
    	    num = Math.floor(num*100+0.50000000001);
    	    var cents = num%100;
    	    num = Math.floor(num/100).toString();
    	    if(cents<10) cents = "0" + cents;
    	    for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++){
    	    	num = num.substring(0,num.length-(4*i+3))+','+num.substring(num.length-(4*i+3));
    	    }
    	    return (((sign)?'':'-') + num + '.' + cents);
    	}
    })
  	//利率整数跟小数分隔
  	.filter('intdec', function() {
        return function (val, unit) {
            if (val) {
                var arr = val.split('.'),
                    unit = unit || null;
                return '<em class="dy-int">' + arr[0] + '</em><em class="dy-dec">.' + arr[1] + '</em>' + unit;
            }
        }
    });
module.exports = dyFilters;