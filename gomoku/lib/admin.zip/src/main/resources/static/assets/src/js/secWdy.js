/*
* 网盾云
*/
require("./plugins/angular-validation.min.js");
require("./plugins/angular-validation-rule.js");
require("./dyDirective.js");
require("./dyService.js");
var wdyApp = angular.module("wdyApp", ["validation", "validation.rule", "dyDir", "dyService"]);

wdyApp.filter("to_trusted", ["$sce", function($sce){
    return function(text){
        return $sce.trustAsHtml(text || "");
    };
}]);

//首页
wdyApp.controller("indexCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
    $scope.account = {};
    $scope.formStruct = formStruct.form_struct;
    $scope.formData = formStruct.form_data;
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

    var initbtnText = formStruct.btnText ? formStruct.btnText : "提 交";
    $scope.btnText = initbtnText;
    $scope.btnStatus = false;

    // 登记
    $scope.register = function(){
        $scope.btnText = initbtnText + " 中...";
        $scope.btnStatus = true;
    	var param = {username:$scope.account.username,password:$scope.account.password};
		postUrl.events("/wangdun/user/register", param).success(function(_data){
			if(_data.status==200){
				parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
					window.location.reload();
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                    scopeService.safeApply($scope, function () {
                        $scope.btnText = initbtnText;
                        $scope.btnStatus = false;
                    });
                });
            }
        });
    }

    // 重置
    $scope.reset = function(){
    	var param = {};
		postUrl.events("/wangdun/user/reset", param).success(function(_data){
			if(_data.status==200){
				parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
					window.location.reload();
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description,{icon: 2, shade: 0.3,time:1500},function(){});
            }
        });
    }

    // 导出报告
    $scope.report = function(){
    	var param = {};
    	window.open("/wangdun/client/down");
    }
});

// 拦截规则
wdyApp.controller("ruleCtrl", function($scope, $http, $filter, $location, postUrl, $timeout){
    $scope.formData = {};
    $scope.formStruct = formStruct.form_struct;
    $scope.formList = formStruct.form_data;
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

    // 启用/停用
    $scope.operaRule = function(id, rid){
    	var param = {id:id,rid:rid,ipid: $scope.formData.ipid};
		postUrl.events("/wangdun/client/operarule", param).success(function(_data){
			if(_data.status==200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    if(top.frames["rightcontent"].reloadings){
                    	top.frames["rightcontent"].reloadings();
                    }else{
                    	window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    }
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
            }
        });
    }
});

// 防护
wdyApp.controller("wafCtrl", function($scope, $http, $filter, $location, postUrl, $timeout){
    $scope.formData = {};
    $scope.formStruct = formStruct.form_struct;
    $scope.formList = formStruct.form_data;
    var initformdata = $scope.formList;
    if(initformdata != ""){
        for (var key in initformdata) {
            $scope.formData[key] = initformdata[key];
        }
    }

    // 启用/停用
    $scope.operaWaf = function(ipid, webservice, status){
    	var param = {ipid:ipid,type:webservice,oldStatus:status};
		postUrl.events("/wangdun/client/operawaf", param).success(function(_data){
			if(_data.status==200){
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                    if(top.frames["rightcontent"].reloadings){
                    	top.frames["rightcontent"].reloadings();
                    }else{
                    	window.parent.document.getElementById("rightcontent").contentWindow.location.reload(true);
                    }
                    window.parent.document.getElementById("rightDialog").contentWindow.location.reload(true);
                    window.parent.document.getElementById("detailDialog").contentWindow.location.reload(true);
                    parent.layer.closeAll();
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500});
            }
        });
    }
});

//cpu
wdyApp.controller("cpuCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){

	$scope.formStruct = formStruct;
	$scope.client = {clientId : formStruct.form_data.clients[0].id};
	$scope.param1 = {num:1,type:1};
	$scope.param2 = {num:1,type:1};
	
    drawLoadChart();
    drawStatChart();
    
    $scope.getLoadChart = function(num, type){
    	$scope.param1.num = num;
    	$scope.param1.type = type;
    	drawLoadChart();
    }
    
    $scope.getStatChart = function(num, type){
    	$scope.param2.num = num;
    	$scope.param2.type = type;
    	drawStatChart();
    }
    
    $scope.clientChange = function(){
    	drawLoadChart();
    	drawStatChart();
    }
    
    // 加载负载图表
    function drawLoadChart() {
    	var param = {ipid:$scope.client.clientId, num:$scope.param1.num, type:$scope.param1.type};
		postUrl.events("/wangdun/monitor/cpuLoadData", param).success(function(_data){
			if(_data.status==200){
                var formData = _data.data.form_data;
				if(formData.cpuLoad){

					var legendArr = []; // 领域
					var legendColors = []; 
					var seriesArr = []; // 数据值
					var chartdata = formData.cpuLoad.chart1.chart_data;
					var index = 0;
					for(var data in chartdata){
						if (data != "xaxis") {
							legendArr.push(
									{
										name:chartdata[data].data_name
									});
							
							var serie = {
									name: chartdata[data].data_name,
									type: "line",
									data: toArray(chartdata[data].data_array),
									itemStyle:{
							            normal:{
							                color: colors[index]
							            }
							        }
							};
							seriesArr.push(serie);
							index++;
						}
					}
					
					$scope.cpu_load = {
							title: {
	                            text: "CPU负载",
	                            subtext:formData.cpuLoad.st + " - " + formData.cpuLoad.et,
	                            x: "center"
	                        },
							tooltip: {
								trigger: "axis"
							},
							legend: {
								data: legendArr,
								bottom: "bottom"
							},
							toolbox: {
	                            feature: {
	                                saveAsImage: {},
	                                magicType : {show: false, type: ['line', 'bar']}
	                            }
	                        },
	                        grid: {
                                left: "3%",
                                right: "3%",
                                bottom: "8%",
                                containLabel: true
                            },
							xAxis: {
								type: "category",
								axisLabel: {interval: formData.cpuLoad.interval, rotate:0,textStyle:{fontSize:10}},
								data: formData.cpuLoad.chart1.chart_data.xaxis.map(function (str) {
	                                return str.replace(" ", "\n")
	                            })
							},
							yAxis: {
								type: "value",
								name: "负载比"
							},
							series: seriesArr
					};
				} 
            }
        });
    }
    
    // 加载利用率图表
    function drawStatChart() {
    	var param = {ipid:$scope.client.clientId, num:$scope.param2.num, type:$scope.param2.type};
		postUrl.events("/wangdun/monitor/cpuStatData", param).success(function(_data){
			if(_data.status==200){
                var formData = _data.data.form_data;
                var detail = formData.cpuStat;
				if(detail){
					
					$scope.ssTime = detail.st;
					$scope.esTime = detail.et;
					
					var legendArr = []; // 领域
					var seriesArr = []; // 数据值
					
					var chartdata = detail.chart1.chart_data;
					var index = 0;
					for(var data in chartdata){
						if (data != "xaxis") {
							legendArr.push(chartdata[data].data_name);
							
							var serie = {
									name: chartdata[data].data_name,
									type: "line",
									data: toArray(chartdata[data].data_array),
									itemStyle:{
							            normal:{
							                color: colors[index]
							            }
							        }
							};
							seriesArr.push(serie);
							index++;
						}
					}
					
					$scope.cpu_stat = {
							title: {
	                            text: "CPU利用率",
	                            subtext:detail.st + " - " + detail.et,
	                            x: "center"
	                        },
							tooltip: {
								trigger: "axis"
							},
							legend: {
								data: legendArr,
								bottom: "bottom"
							},
							toolbox: {
	                            feature: {
	                                saveAsImage: {},
	                                magicType : {show: false, type: ['line', 'bar']}
	                            }
	                        },
	                        grid: {
                                left: "3%",
                                right: "3%",
                                bottom: "8%",
                                containLabel: true
                            },
							xAxis: {
								type: "category",
								axisLabel: {interval: detail.interval, rotate:0,textStyle:{fontSize:10}},
								data: detail.chart1.chart_data.xaxis.map(function (str) {
	                                return str.replace(" ", "\n")
	                            })
							},
							yAxis: {
								type: "value",
								name: "利用率"
							},
							series: seriesArr
					};
				} 
            }
        });
    }
});

//memory
wdyApp.controller("memoryCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){

	$scope.formStruct = formStruct;
	$scope.client = {clientId : formStruct.form_data.clients[0].id};
	$scope.param1 = {num:1,type:1};
	$scope.param2 = {num:1,type:1};
	
    drawMemoryChart();
    drawSwapChart();
    
    $scope.getMemoryChart = function(num, type){
    	$scope.param1.num = num;
    	$scope.param1.type = type;
    	drawMemoryChart();
    }
    
    $scope.getSwapChart = function(num, type){
    	$scope.param2.num = num;
    	$scope.param2.type = type;
    	drawSwapChart();
    }
    
    $scope.clientChange = function(){
    	drawMemoryChart();
    	drawSwapChart();
    }
    
    // 加载memory图表
    function drawMemoryChart() {
    	var param = {ipid:$scope.client.clientId, num:$scope.param1.num, type:$scope.param1.type};
		postUrl.events("/wangdun/monitor/memoryData", param).success(function(_data){
			if(_data.status==200){
                var formData = _data.data.form_data;
                var detail = formData.memoryLoad;
				if(detail){
					
					var legendArr = []; // 领域
					var seriesArr = []; // 数据值
					
					var chartdata = detail.chart1.chart_data;
					var index = 0;
					for(var data in chartdata){
						if (data != "xaxis") {
							legendArr.push(chartdata[data].data_name);
							
							var serie = {
									name: chartdata[data].data_name,
									type: "line",
									data: toArray(chartdata[data].data_array),
									itemStyle:{
							            normal:{
							                color: colors[index]
							            }
							        }
							};
							seriesArr.push(serie);
							index++;
						}
					}
					
					$scope.memoryLoad = {
							title: {
	                            text: "内存空间",
	                            subtext:detail.st + " - " + detail.et,
	                            x: "center"
	                        },
							tooltip: {
								trigger: "axis"
							},
							legend: {
								data: legendArr,
								bottom: "bottom"
							},
							toolbox: {
	                            feature: {
	                                saveAsImage: {},
	                                magicType : {show: false, type: ['line', 'bar']}
	                            }
	                        },
	                        grid: {
                                left: "3%",
                                right: "3%",
                                bottom: "8%",
                                containLabel: true
                            },
							xAxis: {
								type: "category",
								axisLabel: {interval: detail.interval, rotate:0,textStyle:{fontSize:10}},
								data: detail.chart1.chart_data.xaxis.map(function (str) {
	                                return str.replace(" ", "\n")
	                            })
							},
							yAxis: {
								type: "value",
								name: "GB"
							},
							series: seriesArr
					};
				} 
            }
        });
    }
    
    // 加载利用率图表
    function drawSwapChart() {
    	var param = {ipid:$scope.client.clientId, num:$scope.param2.num, type:$scope.param2.type};
		postUrl.events("/wangdun/monitor/swapData", param).success(function(_data){
			if(_data.status==200){
                var formData = _data.data.form_data;
                var detail = formData.swapStat;
				if(detail){
					var legendArr = [];
					var seriesArr = [];
					for(var key1 in detail.da){
						if (key1.indexOf("swap") >= 0) {
							for(var key2 in detail.da[key1]){
								legendArr.push(key2);
								var item = {value: detail.da[key1][key2],name:key2};
								seriesArr.push(item);
							}
						}
					}
					
					$scope.swap_chart = {
					    title : {
					        text: 'swap空间',
					        subtext: detail.ti,
					        x:'center'
					    },
					    tooltip : {
					        trigger: 'item',
					        formatter: "{a} <br/>{b} : {c} ({d}%)"
					    },
					    legend: {
                            bottom: 10,
                            left: 'center',
                            data: legendArr
                        },
						toolbox: {
                            feature: {
                                saveAsImage: {},
                                magicType : {show: false, type: ['line', 'bar']}
                            }
                        },
					    series : [
					        {
					            name: 'swap空间',
					            type: 'pie',
					            radius : '55%',
					            center: ['50%', '60%'],
					            data: seriesArr,
					            itemStyle: {
					                emphasis: {
					                    shadowBlur: 10,
					                    shadowOffsetX: 0,
					                    shadowColor: 'rgba(0, 0, 0, 0.5)'
					                }
					            }
					        }
					    ]
					};
				} 
            }
        });
    }
});

//磁盘
wdyApp.controller("diskCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){

	$scope.formStruct = formStruct;
	$scope.client = {clientId : formStruct.form_data.clients[0].id};
	$scope.param = {num:1,type:1};
	$scope.charts = [];
	$scope.pies = [];
	drawChart();
	drawStatChart();
	
    $scope.getChart = function(num, type){
    	$scope.param.num = num;
    	$scope.param.type = type;
    	drawChart();
    	drawStatChart();
    }
    
    $scope.clientChange = function(){
    	drawChart();
    	drawStatChart();
    }
    
    // 加载利用率图表
    function drawChart() {
    	
    	$scope.charts =[];
    	var param = {ipid:$scope.client.clientId, num:$scope.param.num, type:$scope.param.type};
		postUrl.events("/wangdun/monitor/diskData", param).success(function(_data){
			if(_data.status==200){
                var formData = _data.data.form_data;
                var detail = formData.diskLoad;
				if(detail){

					// 循环生成图表
					for(var key in detail){
						if (key.indexOf('chart') < 0) {
							continue;
						}
						
						var chartdata = detail[key].chart_data
						var legendArr = []; // 领域
						var seriesArr = []; // 数据值
						var index = 0;
						for(var data in chartdata){
							if (data != "xaxis") {
								legendArr.push(chartdata[data].data_name);
								
								var serie = {
										name: chartdata[data].data_name,
										type: "line",
										data: toArray(chartdata[data].data_array),
										itemStyle:{
								            normal:{
								                color: colors[index]
								            }
								        }
								};
								seriesArr.push(serie);
								index++;
							}
						}
						
						$scope.charts.push(
						   {
							title: {
								text: detail[key].chart_name,
								subtext: detail.st + " - " + detail.et,
								x: "center"
							},
							tooltip: {
								trigger: "axis"
							},
							legend: {
								data: legendArr,
								bottom: "bottom"
							},
							toolbox: {
								feature: {
									saveAsImage: {},
									magicType : {show: false, type: ['line', 'bar']}
								}
							},
							grid: {
                                left: "3%",
                                right: "3%",
                                bottom: "10%",
                                containLabel: true
                            },
							xAxis: {
								type: "category",
								axisLabel: {interval: detail.interval * 2, rotate:0,textStyle:{fontSize:10}},
								data: chartdata.xaxis.map(function (str) {
	                                return str.replace(" ", "\n")
	                            })
							},
							yAxis: {
								type: "value",
								name: "kb/s"
							},
							series: seriesArr
						});
					}
					
				} 
            }
        });
    }
    
    // 加载磁盘图
    function drawStatChart() {
    	$scope.pies = [];
    	var param = {ipid:$scope.client.clientId, num:$scope.param.num, type:$scope.param.type};
		postUrl.events("/wangdun/monitor/diskStatData", param).success(function(_data){
			if(_data.status==200){
                var formData = _data.data.form_data;
                var detail = formData.diskStatLoad;
				if(detail){
					for(var key1 in detail.da){
						var legendArr = [];
						var seriesArr = [];
						for(var key2 in detail.da[key1]){
							legendArr.push(key2);
							var item = {value: detail.da[key1][key2],name:key2};
							seriesArr.push(item);
						}
						
						$scope.pies.push({
						    title : {
						        text: '',
						        subtext: '',
						        x:'center'
						    },
						    tooltip : {
						        trigger: 'item',
						        formatter: "{a} <br/>{b} : {c} ({d}%)"
						    },
						    legend: {
                                // orient: 'vertical',
                                bottom: 10,
                                left: 'center',
                                data: legendArr
                            },
							toolbox: {
	                            feature: {
	                                saveAsImage: {},
	                                magicType : {show: false, type: ['line', 'bar']}
	                            }
	                        },
						    series : [
						        {
						            name: 'swap空间',
						            type: 'pie',
						            radius : '55%',
						            center: ['50%', '60%'],
						            data: seriesArr,
						            itemStyle: {
						                emphasis: {
						                    shadowBlur: 10,
						                    shadowOffsetX: 0,
						                    shadowColor: 'rgba(0, 0, 0, 0.5)'
						                }
						            }
						        }
						    ]
						});
					}
				} 
            }
        });
    }
});

//网络
wdyApp.controller("webCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){

	$scope.formStruct = formStruct;
	$scope.client = {clientId : formStruct.form_data.clients[0].id};
	$scope.param = {num:1,type:1};
	$scope.charts = [];
	
	drawChart();
    
    $scope.getChart = function(num, type){
    	$scope.param.num = num;
    	$scope.param.type = type;
    	drawChart();
    }
    
    $scope.clientChange = function(){
    	drawChart();
    }
    
    // 加载利用率图表
    function drawChart() {
    	
    	$scope.charts =[];
    	var param = {ipid:$scope.client.clientId, num:$scope.param.num, type:$scope.param.type};
		postUrl.events("/wangdun/monitor/webData", param).success(function(_data){
			if(_data.status==200){
                var formData = _data.data.form_data;
                var detail = formData.webLoad;
				if(detail){

					// 循环生成图表
					for(var key in detail){
						if (key.indexOf('chart') < 0) {
							continue;
						}
						
						var chartdata = detail[key].chart_data
						var legendArr = []; // 领域
						var seriesArr = []; // 数据值
						var index = 0;
						for(var data in chartdata){
							if (data != "xaxis") {
								legendArr.push(chartdata[data].data_name);
								
								var serie = {
										name: chartdata[data].data_name,
										type: "line",
										data: toArray(chartdata[data].data_array),
										itemStyle:{
								            normal:{
								                color: colors[index]
								            }
								        }
								};
								seriesArr.push(serie);
								index++;
							}
						}
						
						$scope.charts.push(
						   {
							title: {
								text: detail[key].chart_name,
								subtext: detail.st + " - " + detail.et,
								x: "center"
							},
							tooltip: {
								trigger: "axis"
							},
							legend: {
								data: legendArr,
								bottom: "bottom"
							},
							toolbox: {
								feature: {
									saveAsImage: {},
									magicType : {show: false, type: ['line', 'bar']}
								}
							},
							grid: {
                                left: "3%",
                                right: "3%",
                                bottom: "10%",
                                containLabel: true
                            },
							xAxis: {
								type: "category",
								axisLabel: {interval: detail.interval, rotate:0,textStyle:{fontSize:10}},
								data: chartdata.xaxis.map(function (str) {
	                                return str.replace(" ", "\n")
	                            })
							},
							yAxis: {
								type: "value",
								name: "kb/s"
							},
							series: seriesArr
						});
					}
					
				} 
            }
        });
    }
});

// 告警规则设置
wdyApp.controller("warnCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){

	$scope.formStruct = formStruct;
	$scope.formData = formStruct.form_data;
    $scope.addEmail = function(){
    	if (!$scope.formData.email) {
    		return;
    	}
    	addWarn($scope.formData.email, null);
    }
    
    $scope.addPhone = function(){
    	if (!$scope.formData.phone) {
    		return;
    	}
    	addWarn(null, $scope.formData.phone);
    }
    
    $scope.deleteWarn = function(type, id) {
    	deleteWarn(type, id);
    }
    
    function addWarn(email, phone) {
    	var param = {
    			type:$scope.formData.ruleInfo.sonKey, 
    			level:$scope.formData.ruleInfo.grandsonKey, 
    			email:email,
    			phone:phone
    			};
		postUrl.events("/wangdun/client/savewarn", param).success(function(_data){
			if(_data.status==200){
				if (phone) {
					$scope.formData.phoneList = _data.data.phoneList;
				}
				if (email) {
					$scope.formData.emailList = _data.data.emailList;
				}
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                });
            }
        });
    }
    
    function deleteWarn(type, id) {
    	var param = {
    			wtype:$scope.formData.ruleInfo.sonKey, 
    			level:$scope.formData.ruleInfo.grandsonKey,
    			type:type, 
    			id:id
    			};
		postUrl.events("/wangdun/client/deletewarn", param).success(function(_data){
			if(_data.status==200){
				if (type == 'phone') {
					$scope.formData.phoneList = _data.data.phoneList;
				}
				if (type == 'email') {
					$scope.formData.emailList = _data.data.emailList;
				}
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                });
            }
        });
    }
});
    

// 告警规则设置
wdyApp.controller("strategyCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){

	$scope.formStruct = formStruct;
	$scope.formData = formStruct.form_data;
	$scope.strg = {};
	$scope.monitorList = $scope.formData.detailOptions[0];
	$scope.levelList = $scope.formData.levelOptions;
	
	$scope.addStrg = function() {
		addStrg();
    }
	
    $scope.deleteStrg = function(id) {
    	deleteStrg(id);
    }
    
    $scope.typeChange = function() {
    	$scope.monitorList = $scope.formData.detailOptions[$scope.strg.type - 1];
    	$scope.strg.detail = $scope.monitorList[0].value;
    }
    
    function addStrg() {
    	var param = {type:$scope.strg.type,
    				filed:$scope.strg.detail,
    				cvalue:$scope.strg.cvalue,
    				level:$scope.strg.level,
    				stid:$scope.formData.stid};
		postUrl.events("/wangdun/strategy/addDetail", param).success(function(_data){
			if(_data.status==200){
				$scope.formData.dataList = _data.data.dataList;
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                });
            }
        });
    }
    
    function deleteStrg(id) {
    	var param = {id:id,stid:$scope.formData.stid};
		postUrl.events("/wangdun/strategy/deleteDetail", param).success(function(_data){
			if(_data.status==200){
				$scope.formData.dataList = _data.data.dataList;
                parent.layer.msg(_data.description, {icon: 1, shade: 0.3, time: 1500}, function(){
                });
            }else{
                parent.layer.msg(_data.description, {icon: 2, shade: 0.3, time: 1500}, function(){
                });
            }
        });
    }
});
    
//help
wdyApp.controller("helpCtrl", function($scope, $http, $filter, $location, postUrl, scopeService, $timeout){
	$scope.formData = formStruct;
});

var colors = ['#C1232B','#B5C334','#FCCE10','#E87C25','#27727B',
    '#60C0DD','#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'];

    
    function toArray(list){
        var re = [];
        for(var i in list){
            re.push(list[i]);
        }
        return re;
    }


module.exports = wdyApp;