require("./dyDirective.js");
// require("./plugins/layer/layer.js");
var mainApp = angular.module("mainApp", ["dyDir"]);
mainApp.controller("navCtrl", function($scope, $http){

    $scope.userData = data;

	$scope.navlist = []; //存放导航数组的数组，导航有几层，数组就有几维
	$scope.navlist2 = []; //第二级数组
	$scope.navlistOn = ""; //控制一级导航高亮的标示
	$scope.navlist3On = ""; //控制左侧导航菜单的展开缩起
	$scope.navNow = ""; //当前位置
	$scope.rightUrl = "/system/index/main"; //右侧内容的链接地址
    $scope.msgData = {};  //存放左侧待处理的数字
    $scope.messageTotal = "";
//    $http({
//        method: "post",
//        url: "/workbench/notice/noticeListData",
//        headers: {
//            "Content-Type": "application/x-www-form-urlencoded"
//        }
//    }).success(function(data) {
//        if(data.status == "200"){
//            $scope.messageTotal = data.data.total_items;  //二手房业务通知数量
//        }
//    });
	$http({
        method: "post",
        url: "/system/nav/top",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    }).success(function(data) {
        if(data.status == "200"){
            $scope.navlist1 = data.data.items;
        }
        //$scope.navlist = data;
        $scope.getNav(2, $scope.navlist1[0].id);
    });

    //获取下一级的导航,需要传递两个参数，1、level =>导航层级；2、id =>父级的id值
    $scope.getNav = function(level, id){

        //判断是否显示添加业务员收件按钮
        id == "28" ? $scope.receive_id = true : $scope.receive_id = false;
    	$scope.navlistOn = id;
    	if(typeof $scope.navlist["nav"+id] != "undefined" && $scope.navlist["nav" + id] != ""){
    		$scope.navlist2 = $scope.navlist["nav" + id];
            $scope.getRightContent($scope.navlist["nav" + id][0].child[0].url, $scope.navlist["nav" + id][0].child[0].child);//默认请求第一个菜单下的第一个页面数据
            $scope.showNav3($scope.navlist["nav" + id][0].id);//默认展开左侧第一个菜单
    		return;
    	}else{
    		$http({
		        method: "post",
		        url: "/system/nav/menu",
		        data:$.param({"level":2,"id":id}),
		        headers: {
		            "Content-Type": "application/x-www-form-urlencoded"
		        }
		    }).success(function(data) {
                if(data.status == "200"){
                    $scope.navlist["nav" + id] = data.data.items; //将请求回来的值存储起来，减少第二次的请求
                    $scope.navlist2 = data.data.items;

                    $http({
                        method: "post",
                        url: "/system/nav/getPendingMenu",
                        data:$.param({"id": id}),
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded"
                        }
                    }).success(function(_data) {  //初始化左侧数字标识
                        if(_data.status == "200"){
                            $scope.menuData = _data.data;  //{"1": object}
                            if(!!$scope.menuData){
                            	for(var a in $scope.navlist2){
                                    var child = $scope.navlist2[a]["child"];
                                    var sum = 0;
                                    for(var b in child){
                                        var id = child[b]["id"];
                                        if(!!$scope.menuData[id]){
                                            $scope.msgData[id] = $scope.menuData[id]["num"];
                                            sum += $scope.msgData[id];
                                        }
                                    }
                                    if(sum > 0){
                                    	$scope.msgData[$scope.navlist2[a]["id"]] = sum;
                                    }
                                }
                            }
                        }else{
                            return;
                        }
                    });

                    $scope.receive = data.data.receive;  //判断接收类型显示收件按钮
                    $scope.getRightContent($scope.navlist["nav" + id][0].child[0].url, $scope.navlist["nav" + id][0].child[0].child);//默认请求第一个菜单下的第一个页面数据
                    $scope.showNav3($scope.navlist["nav" + id][0].id);//默认展开左侧第一个菜单
                }
		    });
    	}
    	var len = $scope.navlist.length;
    	for(var i=0; i<len; i++){
    		if($scope.navlist[i].id == id){
    			$scope.navNow = $scope.navlist[i].text;
    		}
    	}
    }

    //点击显示最后一级的菜单
    $scope.showNav3 = function(id){
    	$scope.navlist3On = id;
    }

    //展开收缩左侧侧滑
    $scope.toggleMenu = false;
    $scope.toggleSlideMenu = function(){
        $scope.toggleMenu = !$scope.toggleMenu;
    }

    //获取右侧内容界面
    $scope.getRightContent = function(url, child){
        menu4 = child;
        var rightUrl=url;
        /**三级菜单存在多个四级列表子项时，不用配置三级菜单url,默认加载有配置的第一个子项url
         * 解决url权限过虑以及多个四级列表时，没有配置第一个子项时，加载出错的问题
         * 如果多个子项都没有配置权限，右边会没有内容加载*/
        if(child&&child.length>0){
            rightUrl=child[0].url;
        }
        document.getElementById("rightDialog").src = "";  //清空侧滑iframe内容
        document.getElementById("frameSlideRight").style.right = "-920px";  //隐藏侧滑
        if(rightUrl){
            if($scope.rightUrl == "/" + rightUrl){
                //如果右侧的内容已经是该url的内容，则刷新页面
                // document.getElementById("rightcontent").contentWindow.location.reload(true);
                document.getElementById("rightcontent").src = "/" + rightUrl;
                return false;
            }
            $scope.rightUrl = "/" + rightUrl;
            $scope.navlist2On = rightUrl;
        }else{
            $scope.rightUrl = '';
            $scope.navlist2On = '';
        }
    }

    //更新左侧msg条数
    $scope.updateMsg = function(){
        if(msgnowNeed == 1){  //need_num为1时表示左侧菜单需标识出数据的总数
            $scope.msgData[msgnowId] = msgnowNumber;
            // 更新父菜单条数
            var child = $scope.navlist2[msgnowPidx]["child"];
            var sum = 0;
            for(var b in child){
                var id = child[b]["id"];
                if(!!$scope.msgData[id]){
                	sum += $scope.msgData[id];
                }
            }
            $scope.msgData[msgnowPid] = sum;
        }
    }

    //新建业务
    $scope.createBusiness = function(){
        layer.open({
            type: 2,
            title: "添加收件",
            shadeClose: false,
            maxmin: true,
            shade: 0.3,
            area: ["750px", "650px"],
            content: "/buss/receiver/add"
        });
    }
    //新建业务
    $scope.createNew = function(){
        layer.open({
            type: 2,
            title: "收件员收件",
            shadeClose: false,
            maxmin: true,
            shade: 0.3,
            area: ["750px", "650px"],
            content: "/buss/receiver/add&receiver=1"
        });
    }

    //关闭二级侧滑
    $scope.hideSubDetail = function(){
        document.getElementById("detailDialog").src = "";  //清空侧滑iframe内容
        document.getElementById("detailFrameSlide").style.right = "-920px";  //隐藏侧滑
        document.getElementById("slideMask").style.display = "none";
    }
})
module.exports = mainApp;