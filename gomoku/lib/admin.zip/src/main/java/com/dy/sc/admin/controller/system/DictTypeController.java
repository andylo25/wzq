package com.dy.sc.admin.controller.system;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.enumeration.DictType;
import com.dy.sc.entity.system.Dict;

/**
 * 联动名称
 * @ClassName: DictTypeController.java 
 * @Description: TODO 
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author diyou@diyou.cn
 * @date 2017年7月14日上午9:19:11 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * diyou 
 * </pre>
 */	
@Controller
@RequestMapping("/sys/dictType/")
public class DictTypeController extends AdminBaseController{

    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "description","type","create_time"});
		tableHeader.setTexts(new String[]{"ID", "联动名称", "后台组值", "添加时间"});
		tableHeader.setTypes(new String[]{"int","","","datetime"});
		tableHeader.setOptionTypes(new String[]{"","","",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"联动名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("sys/dictType/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 列表数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({"rawtypes" })
    @ResponseBody
	@RequestMapping(value="listData",method=RequestMethod.POST)
	public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,description,type,create_time");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("description", search));
		}
		queryItem.setWhere(Where.eq("dict_type",DictType.PARENT.getIndex()));
		queryItem.setWhere(Where.eq("del_flag",0));
		queryItem.setOrders("id");
		Page<Map> pageData=getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DICT);
		return createSuccessJsonResonse(pageData);
	}
	
    /**
     * 校验后台组名是否存在
     * @param type
     * @param id
     * @return
     * @throws Exception
     */
    private boolean isTypeExists(String type,Long id) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields(" count(1) as count ");
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "type", type);
        this.addWhereCondition(where, "del_flag", 0);
        this.addWhereCondition(where, "dict_type", DictType.PARENT.getIndex());
        query.setWhere(where);
        //编辑时，排除当前数据
        if(id!=null){       	
        	query.getWhere().add(Where.notEq("id", id));
        }
        Map<String, Object> result = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_DICT);
        if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
            return true;
        }
        return false;
    }
    
    /**
     * 校验联动名称是否存在
     * @param description
     * @param id
     * @return
     * @throws Exception
     */
    private boolean isDescriptionExists(String description,Long id) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields(" count(1) as count ");
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "description", description);
        this.addWhereCondition(where, "del_flag", 0);
        this.addWhereCondition(where, "dict_type", DictType.PARENT.getIndex());
        query.setWhere(where);
        //编辑时，排除当前数据
        if(id!=null){       	
        	query.getWhere().add(Where.notEq("id", id));
        }
        Map<String, Object> result = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_DICT);
        if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
            return true;
        }
        return false;
    }
	
	/**
	 * 编辑新增页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="add",method=RequestMethod.GET)
	public ModelAndView add() throws Exception {		
		List<FormField> formFieldList = new ArrayList<>();		
		formFieldList.add(FormField.builder().name("description").text("联动名称").verify("required").build());
		formFieldList.add(FormField.builder().name("type").text("后台组值").verify("required").build());		
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/dictType/save", formFieldList);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="save",method=RequestMethod.POST)
	public DyResponse save(Dict dict) throws Exception {
        if (isDescriptionExists(dict.getDescription(), null)) {
            return createErrorJsonResonse("联动名称已存在，不能新增，请重新输入！");
        }
        if (isTypeExists(dict.getType(),null)) {
            return createErrorJsonResonse("后台组值已存在，不能新增，请重新输入！");
        }
		dict.setDictType(DictType.PARENT.getIndex());
		this.insert(SCModule.SYSTEM, SCFunction.SYS_DICT, dict);
		return createSuccessJsonResonse(null,"添加成功");
	}
	
	/**
	 * 编辑更新页面
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
    @RequestMapping(value="edit")
	public ModelAndView edit(Long id) throws Exception {
		List<FormField> formFieldList = new ArrayList<>();		
		formFieldList.add(FormField.builder().name("description").text("联动名称").verify("required").build());
		formFieldList.add(FormField.builder().name("type").text("后台组值").type("span").build());		
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("id,description,type");
		Map entity = this.getOneByMap(queryItem , SCModule.SYSTEM, SCFunction.SYS_DICT);		
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/dictType/update", formFieldList,entity);		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update",method=RequestMethod.POST)
	public DyResponse update(Dict dict) throws Exception {
        if (isDescriptionExists(dict.getDescription(), dict.getId())) {
            return createErrorJsonResonse("联动名称已存在，不能更新，请重新输入！");
        }
        if (isTypeExists(dict.getType(),dict.getId())) {
            return createErrorJsonResonse("后台组值已存在，不能更新，请重新输入！");
        }
	    this.update(SCModule.SYSTEM, SCFunction.SYS_DICT,dict);
		return createSuccessJsonResonse(null,"修改成功");
	}
	
	/**
	 * 删除
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete",method=RequestMethod.POST)
	public DyResponse delete(Long id) throws Exception {
	    QueryItem queryItem=QueryItem.builder().where("id", id).where("dict_type", DictType.PARENT.getIndex()).build();
		Map<String,Object> dict=this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DICT);
		if(dict!=null){
		    queryItem = new QueryItem(Where.eq("type", dict.get("type")));
	        queryItem.setFields("id,del_flag");
	        queryItem.setWhere(Where.eq("del_flag",DelFlag.NOT_DELETE.getIndex()));
	        List<Map> items=this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DICT);
	        if(items!=null &&items.size()>1){
	            return createErrorJsonResonse("请先删除关联联动值");
	        }
	        //存在类型数据置为删除
	        if(CollectionUtils.isNotEmpty(items)){
	            for(Map item:items){
	                item.put("del_flag", AccConstants.DELETE_FLAG);
	                this.update(SCModule.SYSTEM, SCFunction.SYS_DICT, item);
	            }
	        }
		}
		
		return createSuccessJsonResonse(null,"删除成功");
	}
    
}