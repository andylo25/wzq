
/**
 * Copyright diyou
 */
package com.dy.sc.admin.controller.workflow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.FlowProcDefInfo;
import com.dy.ia.entity.common.Role;
import com.dy.ia.entity.custom.flow.RoleData;
import com.dy.ia.entity.custom.flow.TaskNode;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Lists;

/**
 * 流程定义节点
 * @author cuiwm
 */
@Controller
@RequestMapping(value = "flow/procDefInfo")
public class FlowProcDefInfoController extends AdminBaseController {
	
	@Override
	protected DateFormatType getDateFormatType() {
		return DateFormatType.DATETIME;
	}
	
	/**
     * 构建列表结构:流程定义节点
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","proc_name","update_time:datetime","real_name"});
		tableHeader.setTexts(new String[]{"ID","流程名称","最近更新时间","更新人"});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"proc_name"});
		search.setTexts(new String[]{"流程名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("flow/procDefInfo/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 获取列表数据:流程定义节点
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("listData")
	public DyResponse getListData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,proc_name,update_time,update_uid");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("proc_name", search));
		}
		// 其他过滤条件
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.FLOW, SCFunction.FLOW_PROC_DEF_INFO);
		this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "update_uid:real_name");
		
		return createSuccessJsonResonse(pagem);
	}

	/**
	 * 到添加界面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="toAdd")
	public ModelAndView toAdd() throws Exception {
		
		List<FormField> formFieldList = buidFormField();
		
		Map<String, Object> data = PageUtil.createFormPageStructure("flow/procDefInfo/save", formFieldList);
		
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	private List<FormField> buidFormField() {
		List<FormField> formFieldList = new ArrayList<>();
		formFieldList.add(FormField.builder().name("procName").text("流程名称").verify("required").build());
		formFieldList.add(FormField.builder().name("flowProcType").text("审批方式").type("radio").options(DictUtils.getOptionsInt("flow_proc_type")).verify("required").build());
		
		return formFieldList;
	}

	/**
	 * 保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="save")
	public DyResponse save(FlowProcDefInfo flowProcDefInfo) throws Exception {
		if(!check(flowProcDefInfo))return createErrorJsonResonse("缺失必填项");
		flowProcDefInfo.setTaskStart("{\"node_id\":\"-1\",\"node_name\":\"起点\",\"type\":\"3\",\"level\":\"-1\",\"role\":\"\"}");
		flowProcDefInfo.setTaskEnd("{\"node_id\":\"99\",\"node_name\":\"终点\",\"type\":\"3\",\"level\":\"99\",\"role\":\"3\"}");
		this.insert(SCModule.FLOW, SCFunction.FLOW_PROC_DEF_INFO, flowProcDefInfo);
		return createSuccessJsonResonse(null,"添加成功");
	}
	
	/**
	 * 校验输入
	 * @param flowProcDefInfo
	 * @return
	 */
	private boolean check(FlowProcDefInfo flowProcDefInfo){
		if(flowProcDefInfo.getFlowProcType() == null)return false;
		if(StringUtils.isBlank(flowProcDefInfo.getProcName()))return false;
		return true;
	}
	
	/**
	 * 到编辑页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="toEdit")
	public ModelAndView toEdit(Long id) throws Exception {

		List<FormField> formFieldList = buidFormField();
		
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		FlowProcDefInfo flowProcDefInfo = this.getOneByEntity(queryItem , SCModule.FLOW, SCFunction.FLOW_PROC_DEF_INFO, FlowProcDefInfo.class);
		Map<String, Object> data = PageUtil.createFormPageStructure("flow/procDefInfo/update", formFieldList,flowProcDefInfo);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update")
	public DyResponse update(FlowProcDefInfo flowProcDefInfo) throws Exception {
		if(!check(flowProcDefInfo))return createErrorJsonResonse("缺失必填项");
		this.update(SCModule.FLOW, SCFunction.FLOW_PROC_DEF_INFO, flowProcDefInfo);
		
		return createSuccessJsonResonse(null,"修改成功");
	}
	
	/**
	 * 删除
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete")
	public DyResponse delete(Long id) throws Exception {
		this.deleteById(id, SCModule.FLOW, SCFunction.FLOW_PROC_DEF_INFO);
		return createSuccessJsonResonse(null,"删除成功");
	}
	
	/**
     * 流程定义配置
     * @return
     * @throws Exception
     */
    @RequestMapping("conf")
    public ModelAndView conf(Long id) throws Exception {
    	
    	FlowProcDefInfo procDefInfo = this.getById(id, Module.FLOW, SCFunction.FLOW_PROC_DEF_INFO, FlowProcDefInfo.class);
    	if(procDefInfo == null)return null;
    	List<TaskNode> formStruct = new ArrayList<>();
    	TaskNode start = JsonUtils.fromJson(procDefInfo.getTaskStart(), TaskNode.class);
    	formStruct.add(start);
    	List<TaskNode> mid = Lists.newArrayList();
    	if(StringUtils.isNotBlank(procDefInfo.getTaskInfo())){
    		mid = JsonUtils.jsonToList(procDefInfo.getTaskInfo(), TaskNode[].class);
    	}
    	formStruct.addAll(mid);
    	TaskNode end = JsonUtils.fromJson(procDefInfo.getTaskEnd(), TaskNode.class);
    	formStruct.add(end);
		
		StringBuilder result = new StringBuilder(JsonUtils.object2JsonString(formStruct));
//		result.append(",formStruct=").append(JsonUtils.object2JsonString(formStruct));
		
		Map<String,RoleData> roleData = new HashMap<>();
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("id,role_name as roleName");
		List<Role> roles = this.getListByEntity(queryItem , Module.SYSTEM, SCFunction.SYS_ROLE, Role.class);
		for(Role role:roles){
			roleData.put(role.getId().toString(), new RoleData(role.getId().toString(),role.getRoleName()));
		}
		
		List<Map<String,Object>> memberData = new ArrayList<>();
		Map<String,Object> member = new HashMap<>();
		member.put("id", "1");
		member.put("pid", "0");
		member.put("name", "帝友总部");
		member.put("cname", "帝友总部");
		Map<String,Object> child = new HashMap<>();
		child.put("1", roleData.values());
		member.put("child", child);
		memberData.add(member);
		result.append(",memberData=").append(JsonUtils.object2JsonString(memberData));
		
		Map<String,Object> departmentData = new HashMap<>();
		Map<String,String> department = new HashMap<>();
		department.put("id", "1");
		department.put("pid", "0");
		department.put("name", "帝友总部");
		departmentData.put("1", department);
		result.append(",departmentData=").append(JsonUtils.object2JsonString(departmentData));
		
		result.append(",roleData=").append(JsonUtils.object2JsonString(roleData));
		result.append(",defId=").append(id);
		result.append(",url=").append("'flow/procDefInfo/flowSave'");
		return createSuccessModelAndView("system/flowConf", result);
    }
    
    /**
     * 流程定义配置
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("flowSave")
    public DyResponse flowSave(@RequestParam("node_list") String nodeLists,@RequestParam("id") String id) throws Exception {
    	List<TaskNode> nodeList = JsonUtils.jsonToList(nodeLists, TaskNode[].class);
    	FlowProcDefInfo procDefInfo = this.getById(id, Module.FLOW, SCFunction.FLOW_PROC_DEF_INFO, FlowProcDefInfo.class);
    	procDefInfo.setTaskStart(JsonUtils.object2JsonString(nodeList.get(0)));
    	List<TaskNode> newNodes = new ArrayList<>(nodeList.subList(1, nodeList.size()-1));
    	for(int i=0;i<newNodes.size();i++){
    		newNodes.get(i).setNode_id(String.valueOf(i));
    	}
    	if(newNodes.isEmpty()){
    		procDefInfo.setTaskInfo("");
        }else{
        	procDefInfo.setTaskInfo(JsonUtils.object2JsonString(newNodes));
        }
    	
    	TaskNode end = nodeList.get(nodeList.size()-1);
    	if(end != null){
    		end.setNode_id("99"); // 最后节点id固定为99
    	}
    	procDefInfo.setTaskEnd(JsonUtils.object2JsonString(end));
    	
    	this.update(SCModule.FLOW, SCFunction.FLOW_PROC_DEF_INFO, procDefInfo);
    	
    	return createSuccessJsonResonse(null,"配置成功");
    }

}