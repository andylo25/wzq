package com.dy.sc.admin.controller.org;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.TreeUtils;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.system.Department;
import com.google.common.collect.Maps;

/**
 * 
 * 部门管理
 * @ClassName: DeptController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年7月10日 下午2:56:16 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/system/dept/")
public class DeptController extends AdminBaseController{

    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "dept_name","dept_description"});
		tableHeader.setTexts(new String[]{"ID", "部门名称","部门描述"});
		tableHeader.setTypes(new String[]{"int","",""});
		//tableHeader.setOptionTypes(new String[]{"","",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
//		Search search = new Search();
//		search.setNames(new String[]{"search"});
//		search.setTexts(new String[]{"部门名称"});
//		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("system/dept/listData", "id", tableHeader,tool,null);
		Map treeData=Maps.newHashMap();
		treeData.put("items", TreeUtils.getDeptData());
		data.setTreeData(treeData);
		return createSuccessModelAndView("common/treetable", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 列表数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({"rawtypes" })
    @ResponseBody
	@RequestMapping(value="listData",method=RequestMethod.POST)
	public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,dept_name,dept_description");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("name", search));
		}
		queryItem.setWhere(Where.eq("del_flag",0));
		queryItem.setOrders("id");
		Page<Map> pageData=getPageByMap(queryItem, Module.SYSTEM, SCFunction.SYS_DEPT);
		return createSuccessJsonResonse(pageData);
	}
	
	/**
	 * 编辑新增页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="add",method=RequestMethod.GET)
	public ModelAndView add() throws Exception {
		
		List<FormField> formFieldList = buidFormField();
		
		Map<String, Object> data = PageUtil.createFormPageStructure("system/dept/save", formFieldList);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
    private List<FormField> buidFormField() {
		List<FormField> formFieldList = new ArrayList<>();
		formFieldList.add(FormField.builder().name("deptName").text("部门名称").verify("required").build());
		formFieldList.add(FormField.builder().name("deptDescription").text("部门描述").type("textarea").build());
		formFieldList.add(FormField.builder().name("pId").text("上级部门").type("select").options(TreeUtils.getDeptOptions()).build());
		return formFieldList;
	}
	
	/**
	 * 保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="save",method=RequestMethod.POST)
	public DyResponse save(Department dept) throws Exception {
	    
		this.insert(Module.SYSTEM, SCFunction.SYS_DEPT, dept);
		TreeUtils.clearDeptCache();
		return createSuccessJsonResonse(null,"添加成功");
	}
	
	/**
	 * 编辑更新页面
	 * @return
	 * @throws Exception
	 */
    @RequestMapping(value="edit")
	public ModelAndView edit(Long id) throws Exception {

		List<FormField> formFieldList = buidFormField();
		
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("id,pid as pId,dept_name as deptName,dept_description as deptDescription,sort");
		Map entity = this.getOneByMap(queryItem , Module.SYSTEM, SCFunction.SYS_DEPT);
		
		Map<String, Object> data = PageUtil.createFormPageStructure("system/dept/update", formFieldList,entity);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update",method=RequestMethod.POST)
	public DyResponse update(Department dept) throws Exception {
	    if(dept.getId()!=null){
	        this.update(Module.SYSTEM, SCFunction.SYS_DEPT, dept);
	        TreeUtils.clearDeptCache();
	    }
		return createSuccessJsonResonse(null,"修改成功");
	}
	
	/**
	 * 删除
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete",method=RequestMethod.POST)
	public DyResponse delete(Long id) throws Exception {
	    if(id!=null){
	        QueryItem queryItem=QueryItem.builder().where("dept_id", id).where("del_flag", DelFlag.NOT_DELETE.getIndex()).build();
	        Long count=this.getCount(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN);
	        if(count>0){
	            return createErrorJsonResonse("部门下有人员不能删除");
	        }
	        queryItem=QueryItem.builder().where("pid", id).where("del_flag", DelFlag.NOT_DELETE.getIndex()).build();
            count=this.getCount(queryItem, SCModule.SYSTEM, SCFunction.SYS_DEPT);
            if(count>0){
                return createErrorJsonResonse("部门有子部门不能删除");
            }
	        Map<String,Object> data=Maps.newHashMap();
	        data.put("del_flag", AccConstants.DELETE_FLAG);
	        data.put("id", id);
	        this.update(Module.SYSTEM, SCFunction.SYS_DEPT, data);
	        TreeUtils.clearDeptCache();
	    }
		return createSuccessJsonResonse(null,"删除成功");
	}
	
	/**
	 * 获取部门树形选择
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="deptOptions",method=RequestMethod.POST)
	public DyResponse deptOptions() throws Exception {
		return createSuccessJsonResonse(TreeUtils.getDeptOptions());
	}
	
    
}