package com.dy.sc.admin.controller.trust;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.entity.User;
import com.dy.core.trust.enumeration.TrustActionEnum;
import com.dy.core.utils.IpUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.encrypt.MessageEncryptUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.TrustLog;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.CompanyRoleType;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/trust/api/")
public class TrustApiController extends AdminBaseController {

    @Autowired 
    private MessageEncryptUtil messageEncryptUtil;
    @Value("${ia.apiUrl}")
    private String iaServiceUrl;
    @Value("${ia.notifyUrl}")
    private String iaNotifyUrl;
//    @Value("${MAIN_URL}")
//    private String mainUrl;
    
  //操作类型 0-register 1-qcard 2-pay_detail 3-transfer 4-transfer_out
    private Integer TYPE_REGISTER=0;
    private Integer TYPE_QCARD=1;
    private Integer TYPE_PAY_DETAIL=2;
    private Integer TYPE_TRANSFER=3;
    private Integer TYPE_TRANSFER_OUT=4;
    
    private void createTrustLog(Long userId,Long adminId,String trn_id,Integer type,String content,String sendIp,Integer amountType,
                                BigDecimal amount,Long amountId){
        TrustLog trustLog=new TrustLog();
        trustLog.setOrderId(trn_id);
        trustLog.setUserId(userId);
        trustLog.setAdminId(adminId);
        trustLog.setType(type);
        trustLog.setFormContents(content);
        trustLog.setSendIp(IpUtil.ipStrToLong(sendIp));
        trustLog.setAmount(amount);
        trustLog.setAmountType(amountType);
        trustLog.setAmountId(amountId);
        trustLog.setTrustStatus(0);//待处理
            
        try {
            this.insert(SCModule.TRUST, SCFunction.TRUST_LOG, trustLog);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 
     * 开户 跳转到资管系统开户页面
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "/openBankByAccount")
    public String openBankByAccount(Long id) throws Exception {
        AccAccount account=this.getById(id, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);
        return openBank(null, account.getCompanyId());
    }
    
    /**
     * 
     * 开户 跳转到资管系统开户页面
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "/openBank/{type}")
    public String openBank(@PathVariable("type") String type,Long id) throws Exception {
        //1-资方企业，2-核心企业，3-授信企业
        User admin=getUser();
        AccAccount accAccount = this.getById(id, Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        Company comp=BaseInfoUtils.getCompany(accAccount.getCompanyId());
        if(comp.getCompanyRoleType().equals(CompanyRoleType.COMPANY_CREDIT.getIndex())){
            type="3";
        }else if(comp.getCompanyRoleType().equals(CompanyRoleType.COMPANY_CORE.getIndex())){
            type="2";
        }else if(comp.getCompanyRoleType().equals(CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex())){
            type="1";
        }
        String trn_id=UUID.randomUUID().toString();
        Map<String,String> data=Maps.newHashMap();
        data.put("trn_id",trn_id);
        data.put("action", "register");
        data.put("company", comp.getCompanyName());
        data.put("type", type);//
        data.put("business_no", comp.getBusinessLicNo());
        data.put("card_type", comp.getLegalCardType()==null?"":comp.getLegalCardType());
        data.put("card_no", comp.getLegalCardNo()==null?"":comp.getLegalCardNo());//法人证件
        data.put("card_name", comp.getLegalName()==null?"":comp.getLegalName());//法人姓名
        data.put("mobile", comp.getLegalPhoneNumber()==null?"":comp.getLegalPhoneNumber());//法人手机
        data.put("notify_url", iaNotifyUrl);
//        data.put("return_url", mainUrl);
        
        createTrustLog(null, admin.getId(), trn_id, 0, JsonUtils.object2JsonString(data), this.getRemoteIp(), null, null, null);
        
        String redirectPath=messageEncryptUtil.getRedirectPath(String.format(iaServiceUrl,TrustActionEnum.ACTION_REGISTER.getIndex()), data);
        return "redirect:"+redirectPath;
    }
    
    
}
