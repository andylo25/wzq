package com.dy.sc.admin.controller.org;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.service.CompanyService;
import com.dy.core.service.CreditService;
import com.dy.core.utils.Constant;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.SecurityUtil;
import com.dy.core.utils.TreeUtils;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.Role;
import com.dy.ia.entity.enumeration.AccountTypeEnum;
import com.dy.ia.entity.enumeration.UserTypeEnum;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/org")
public class UserController extends AdminBaseController {
	
	@Autowired
	CompanyService companyService;
	@Autowired
	CreditService creditService;
	
	@Override
	protected DateFormatType getDateFormatType() {
		return DateFormatType.DATETIME;
	}
	
	/**
	 * 修改密码
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/admin/changePassword")
	public ModelAndView changePasswd() throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		
		formFieldList.add(FormField.builder().name("oldPassword").type("pwd").placeholder("请输入旧密码")
				.text("旧密码").br("br").verify("required").build());		
		formFieldList.add(FormField.builder().name("password").type("pwd").placeholder("请输入新密码")
				.text("新密码").br("br").verify("required,pwdchar=[8|16]").build());
		formFieldList.add(FormField.builder().name("rePassword").type("pwd").placeholder("请输入确认密码")
				.text("再次输入新密码").verify("required,pwdchar=[8|16],equals=password").build());
		
		Map<String, Object> data = PageUtil.createFormPageStructure("org/passwd/save", formFieldList);
		data.put("refresh_tree", true);
		return createSuccessModelAndView("common/edit", 
				JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 保存密码
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/passwd/save")
	public DyResponse savePasswd(String oldPassword,String password,String rePassword) throws Exception {
		OrgUser user = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
		//非空校验
		String errorMsg = validateNull(new Object[]{password, rePassword}, new String[2], new String[]{"登陆密码", "确认密码"});
		if(StringUtils.isNotBlank(errorMsg)) return createErrorJsonResonse(errorMsg);
		
		//新密码与确认密码是否一致
		if(!password.equals(rePassword))return createErrorJsonResonse(this.getMessage("system.errorNewPassword"));
		if(StringUtils.isBlank(oldPassword)||!SecurityUtil.md5(SecurityUtil.sha1(oldPassword)).equals(user.getPassword())){
			return createErrorJsonResonse("旧密码错误");
		}
		QueryItem queryItem = new QueryItem(Where.eq("username", user.getUsername()));
		OrgUser admin = this.getOneByEntity(queryItem , SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		admin.setPassword(SecurityUtil.md5(SecurityUtil.sha1(password)));
		
		this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, admin);
		this.setSessionAtrribute(Constant.SESSION_USER,admin);
		return createSuccessJsonResonse(null,"修改密码成功");
	}
	
	
	
	/**
	 * 获取所有用户
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/user/list/{type}")
	public ModelAndView getUserList(@PathVariable("type") int type) throws Exception {
		TableHeader tableHeader = new TableHeader();
		
		//if( type == AccountTypeEnum.ADMIN.getIndex() ){
			tableHeader.setNames(new String[]{"id", "username","real_name","role_name","dept_name","status"});
			tableHeader.setTexts(new String[]{"ID", "用户名","姓名","角色","部门","状态"});
			tableHeader.setTypes(new String[]{"int","", "","","",""});

		
		Tool tool = new Tool();
		tool.setList(buildTools());
	
		Search search = new Search();
		search.setNames(new String[]{"username"});
		search.setTexts(new String[]{"用户名"});
		search.setTypes(new String[]{"text"});
		PageStructure data = null;
		if( type == AccountTypeEnum.CUSTUMER.getIndex() ){
			data = PageUtil.createTablePageStructure("org/user/listData/" + type,"org/company/info", "id", tableHeader,tool,search);
		}else{
			data = PageUtil.createTablePageStructure("org/user/listData/" + type, "id", tableHeader,tool,search);
			Map treeData=Maps.newHashMap();
			treeData.put("items", TreeUtils.getDeptData());
			data.setTreeData(treeData);
		}
		return createSuccessModelAndView("common/treetable", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取用户数据
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping("/user/listData/{type}")
	public DyResponse getAdminListData(Integer page,Integer limit,String search,String username,
			String company_name,String saler_id,String superior_depart,Long pid,
			String create_time,@PathVariable("type") int type) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		List<Where> whereList = new ArrayList<Where>();
		// 管理员，部门，业务员
		if( type != AccountTypeEnum.CUSTUMER.getIndex() ){
			addWhereCondition(whereList, "type", LE, 3);//后台用户
			if(StringUtils.isNotBlank(search)){
				addWhereCondition(whereList, "username", LIKE_ALL, "%"+search+"%");
			}
			if(pid!=null&&pid!=1){//非总部
			    addWhereCondition(whereList, "dept_id", EQ, pid);
			}
			this.addWhereCondition(whereList, "del_flag", 0);
			queryItem.setWhere(whereList);
			queryItem.setOrders("create_time desc");
			return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN),"status","register_time"));
		}
		return null;
//		else{// 授信客户
//			if(StringUtils.isNotBlank(search)){
//				this.addWhereCondition(whereList, "username", LIKE_ALL, "%"+search+"%");
//			}
//			if(StringUtils.isNotBlank(username)){
//				this.addWhereCondition(whereList, "username", LIKE_ALL, "%"+username+"%");
//			}
//			if(StringUtils.isNotBlank(create_time)){
//				this.addDateWhereCondition(whereList, "create_time", create_time);
//			}
//			if(StringUtils.isNotBlank(saler_id)){
//				this.addWhereCondition(whereList, "saler_id", saler_id);
//			}
//			if(StringUtils.isNotBlank(superior_depart)){
//				this.addWhereCondition(whereList, "superior_depart", superior_depart);
//			}	
//			this.addWhereCondition(whereList, "type", AccountTypeEnum.CUSTUMER.getIndex());
//			this.addWhereCondition(whereList, "del_flag", NEQ, 1);// 不包含驳回
//			queryItem.setWhere(whereList);
//			queryItem.setOrders("create_time desc");
//			Page<Map> data = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN);
//			
//			this.idToName(data.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name,company_license");
//			this.idToName(data.getItems(), SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, "id#user_id:open_full_name as open_bank,account");
//			
//			// 跨表字段，过滤
//			if(StringUtils.isNotBlank(company_name)){
//				filterCrossTable(data, "company_name", company_name, page, limit);
//			}		
//			return createSuccessJsonResonse(dataConvert(data,"cust_status","create_time"));
//		}
	}
	
	private void filterCrossTable(Page<Map> data,String col,String value,Integer page,Integer limit){
		List<Map> tmpItems = new ArrayList();
		Integer totalItems = 0;
		for(Map item : data.getItems()){
			String tmp = item.get(col).toString();
			if( tmp.contains(value)){
				tmpItems.add(item);
				totalItems ++;
			}
		}
		
		Integer totalPage = (totalItems  +  limit  - 1) / limit;
		
		List<Map> rltItems = new ArrayList();
		Integer startIndex = limit * (page - 1);
		Integer endIndex = limit * page > totalItems ? totalItems : (limit * page - 1);
		for(Integer index = 0;index < tmpItems.size();index ++){
			Map item = tmpItems.get(index);
			if( index >= startIndex && index <= endIndex ){
				rltItems.add(item);
			}
		}
		
		data.setEpage(limit);
		data.setPage(page);
		data.setItems(rltItems);
		data.setTotal_items(totalItems);
		data.setTotal_pages(totalPage);
	}
	
	/**
	 * 授信客户企业信息
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="/company/info")
	public ModelAndView userCompanyInfo(Long id) throws Exception {
		//授信客户信息
		QueryItem item = new QueryItem();
		item.setWhere(Where.eq("id", id));
		OrgUser user=this.getOneByEntity(item, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		
		QueryItem q = new QueryItem();
		q.setWhere(Where.eq("id", user.getCompanyId()));
		Map company=this.getOneByMap(q, SCModule.SYSTEM, 
				SCFunction.SYS_COMPANY);
		
		Map<String,Object> account = BaseInfoUtils.getCompAccountMap(user.getCompanyId());
		if(account!=null){
			company.put("open_bank", account.get("open_bank").toString());
			company.put("open_bank_account",account.get("account").toString());
		}else{
			company.put("open_bank", null);
			company.put("open_bank_account", null);
		}
		
		QueryItem query=new QueryItem();
		query.setWhere(Where.eq("id", user.getSalerId()));
		query.setWhere(Where.eq("type", AccountTypeEnum.SALER.getIndex()));
		OrgUser s = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		company.put("saler_name", s.getRealName());
		
		
		return createSuccessModelAndView("system/companyInfo",JsonUtils.object2JsonString(company));
	}
	
	private List<FormField> buidFormFieldAdmin(boolean edit) throws Exception {
	    List<FormField>  formFieldList=Lists.newArrayList();
        formFieldList.add(FormField.builder().name("username").text("用户名").verify("required").build());
        formFieldList.add(FormField.builder().name("realName").text("真实姓名").verify("required").build());
        
        if(edit){
            formFieldList.add(FormField.builder().name("password").type("pwd").text("密码").build());
            formFieldList.add(FormField.builder().name("repassword").type("pwd").text("重复密码").verify("equals=password").build());
        }else{
            formFieldList.add(FormField.builder().name("password").type("pwd").text("密码").verify("required").build());
            formFieldList.add(FormField.builder().name("repassword").type("pwd").text("重复密码").verify("required,equals=password").build());
        }
        formFieldList.add(FormField.builder().name("phone").text("手机号码").verify("required,phone").build());
        formFieldList.add(FormField.builder().name("jobNumber").text("工号").build());
        formFieldList.add(FormField.builder().name("email").text("邮箱").verify("email").build());
        
        formFieldList.add(FormField.builder().name("sex").text("性别").type("radio").verify("required")
            .options("sex").build());
        formFieldList.add(FormField.builder().name("status").text("状态").type("radio").verify("required")
            .options("status").build());
        QueryItem queryItem = new QueryItem(Where.eq("status", 1));
        List<Role> roles = this.getListByEntity(queryItem , SCModule.SYSTEM, SCFunction.SYS_ROLE, Role.class);
        List<FormOption> roleOpt = new ArrayList<>();
        for(Role role : roles ){
            roleOpt.add(new FormOption(role.getRoleName(), role.getId().toString()));
        }
        formFieldList.add(FormField.builder().name("role1").text("所属角色").type("checkbox")
                .options(roleOpt).build());
        formFieldList.add(FormField.builder().name("deptId").text("所属部门").type("select").verify("required")
            .options(TreeUtils.getDeptOptions()).build());
        return formFieldList;
	}
	
	/**
	 * 用户新增页面
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/user/add/{type}")
	public ModelAndView toAddUser(@PathVariable("type")int type) throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();

		    formFieldList=buidFormFieldAdmin(false);
		    Map<String,Object> formData=Maps.newHashMap();
		    formData.put("status", "1");
//		    formData.put("realName", "1");
//		}
		Map<String, Object> data = PageUtil.createFormPageStructure("org/user/save/" + type, formFieldList,formData);
		
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	private OrgUser userIsExists(String param,String val) throws Exception{
		QueryItem query = new QueryItem();
		List<Where> where = new ArrayList<Where>();
		this.addWhereCondition(where, "username", val);
		this.addWhereCondition(where, "del_flag", 0);
		query.setWhere(where);
		
		OrgUser u = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		return u;
	}
	
	private Map<String, Object> getDepart(Object id) throws Exception{
	    QueryItem queryItem=new QueryItem(Where.eq("id", id));
	    queryItem.setFields("id,dept_name");
	    return this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DEPT);
	}
	
	/**
	 * 保存用户
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
    @RequestMapping(value="/user/save/{type}")
    public DyResponse saveUser(Company company,String role1,OrgUser user,String repassword,@PathVariable("type")int type,
    String openBankAccount,String openBank) throws Exception {
        OrgUser ses = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
        user.setUpdateAdminId(ses.getId().toString());
        Long now = System.currentTimeMillis() / 1000;
        user.setRegisterTime(now);
        user.setRegisterIp(this.getRemoteIp());
        user.setLastloginTime(now);
        //强制设置为业务员
        
        type=UserTypeEnum.SALER.getIndex();
        user.setType(type);
        user.setCreateUid(ses.getId());
        user.setUpdateTime(now);
        user.setUpdateUid(ses.getId());
        user.setCreateTime(now);
        OrgUser u = this.userIsExists("username", user.getUsername());
            if( u != null && u.getDelFlag() == 0 ){
                return createErrorJsonResonse("用户名重复");
            }
            if( !user.getPassword().equalsIgnoreCase(repassword) ){
                return createErrorJsonResonse("两次输入密码不一致");
            }
            
            if( StringUtils.isBlank(role1) ){
                return createErrorJsonResonse("所属角色必选");
            }
            user.setPassword(SecurityUtil.md5(SecurityUtil.sha1(user.getPassword())));
            String[] roles = role1.split(",");
            if(roles.length>0) {
                QueryItem queryItem = new QueryItem(Where.eq("id", roles[0]));
                Role r = this.getOneByEntity(queryItem , SCModule.SYSTEM, SCFunction.SYS_ROLE, Role.class);
                user.setRoleName(r.getRoleName());
            }
            user.setRole(role1);
            
            user.setDeptName(getDepart(user.getDeptId()).get("dept_name").toString());
            
            this.insert(SCModule.SYSTEM, SCFunction.SYS_ADMIN, user);

        return createSuccessJsonResonse(null,"新增成功");
    }
	
	/**
	 * 用户编辑更新页面
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
    @RequestMapping(value="/user/edit/{type}")
	public ModelAndView toEditUser(Long id,@PathVariable("type")int type) throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		
		formFieldList.add(FormField.builder().name("username").text("用户名称")
				.verify("required").build());

	    formFieldList=buidFormFieldAdmin(true);
		
		QueryItem query = new QueryItem(Where.eq("id", id));
		query.setFields("id,role,username,real_name as realName,phone,email,job_number as jobNumber,sex,status,dept_id as deptId");
		Map formdata = this.getOneByMap(query , SCModule.SYSTEM, SCFunction.SYS_ADMIN);
		if(formdata.get("role")!=null){
		    String role = formdata.get("role").toString();
		    String[] arr = role.split(",");
	        formdata.put("role1", arr);
		}
		Map<String, Object> data = PageUtil.createFormPageStructure("org/user/update/" + type, formFieldList,formdata);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新用户
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
    @RequestMapping(value="/user/update/{type}")
    public DyResponse updateUser(Company company,String role1,OrgUser user,@PathVariable("type")int type) throws Exception {
        OrgUser ses = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
        Long now = System.currentTimeMillis() / 1000;
        type=UserTypeEnum.SALER.getIndex();
        user.setType(type);
        user.setUpdateTime(now);
        user.setUpdateUid(ses.getId());
//        if( type == AccountTypeEnum.SALER.getIndex() ){
//        }else if( type == AccountTypeEnum.ADMIN.getIndex() ){
            String[] roles = role1.split(",");
            if(roles.length>0) {
                QueryItem queryItem = new QueryItem(Where.eq("id", roles[0]));
                Role r = this.getOneByEntity(queryItem , SCModule.SYSTEM, SCFunction.SYS_ROLE, Role.class);
                user.setRoleName(r.getRoleName());
            }
            user.setRole(role1);
            if(StringUtils.isNoneBlank(user.getPassword())){
                user.setPassword(SecurityUtil.md5(SecurityUtil.sha1(user.getPassword())));
            }
            //部门名
            user.setDeptName(getDepart(user.getDeptId()).get("dept_name").toString());
            
            this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, user);
//        }else{//部门
//
//        }
        return createSuccessJsonResonse(null,"修改成功");
    }
	
	/**
	 * 删除用户
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/user/del/{type}")
	public DyResponse deleteUser(OrgUser user,@PathVariable("type")int type) throws Exception {
//		if( type == AccountTypeEnum.CUSTUMER.getIndex() ){
//			QueryItem query = new QueryItem();
//			List<Where> w = new ArrayList<Where>();
//			//this.addWhereCondition(w, "type", AccountTypeEnum.CUSTUMER.getIndex());
//			this.addWhereCondition(w, "id", user.getId());
//			query.setWhere(w);
//			OrgUser u = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
//			this.deleteById(user.getId(), SCModule.SYSTEM, SCFunction.SYS_ADMIN);
//			this.deleteById(u.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY);
//		}else if(type == AccountTypeEnum.DEPARTMENT.getIndex() ){
//			QueryItem query = new QueryItem();
//			List<Where> w = new ArrayList<Where>();
//			//this.addWhereCondition(w, "type", AccountTypeEnum.SALER.getIndex());
//			this.addWhereCondition(w, "del_flag", 0);
//			this.addWhereCondition(w, "superior_depart", user.getId());
//			query.setWhere(w);
//			query.setFields("id");
//			List<OrgUser> list = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
//			if( list.size() > 0 ){
//				return this.createErrorJsonResonse("存在业务员，无法删除！");
//			}
//			
//			// 查询部门授信额度
//			QueryItem qu = new QueryItem();
//			List<Where> wh = new ArrayList<Where>();
//			this.addWhereCondition(wh, "user_id", user.getId());
//			qu.setWhere(wh);
//			CreLimitInfo cre = this.getOneByEntity(qu, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
//			if( cre.getCreditLimit().compareTo(BigDecimal.valueOf(0)) == 1 ){
//				return createErrorJsonResonse("授信额度不为0，无法删除！");
//			}
//			
//			// 删除部门授信额度
//			QueryItem q = new QueryItem();
//			List<Where> where = new ArrayList<Where>();
//			this.addWhereCondition(where, "user_id", user.getId());
//			q.setWhere(where);
//			CreLimitInfo credit = this.getOneByEntity(q, SCModule.CREDIT, SCFunction.CRE_LIMIT, CreLimitInfo.class);
//			this.deleteById(credit.getId(), SCModule.CREDIT, SCFunction.CRE_LIMIT);
//			
//			// 删除授信客户
//			this.deleteById(user.getId(), SCModule.SYSTEM, SCFunction.SYS_ADMIN);
//		}else if(type == AccountTypeEnum.SALER.getIndex() ){
			QueryItem query = new QueryItem();
			List<Where> w = new ArrayList<Where>();
			//this.addWhereCondition(w, "type", AccountTypeEnum.CUSTUMER.getIndex());
			this.addWhereCondition(w, "saler_id", user.getId());
			query.setWhere(w);
			query.setFields("id");
			List<OrgUser> list = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
			if( list.size() > 0 ){
				return this.createErrorJsonResonse("存在授信客户，无法删除！");
			}
			this.deleteById(user.getId(), SCModule.SYSTEM, SCFunction.SYS_ADMIN);
//		}else{//管理员
//			this.deleteById(user.getId(), SCModule.SYSTEM, SCFunction.SYS_ADMIN);
//		}
		
		return createSuccessJsonResonse(null,"删除成功");
	}
	
	/**
	 * 冻结用户
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/user/frozen/{type}")
	public DyResponse frozeUser(OrgUser user,@PathVariable("type")int type) throws Exception {
//		if( type == AccountTypeEnum.CUSTUMER.getIndex() ){
//			QueryItem queryItem = new QueryItem(Where.eq("id", user.getId()));
//			OrgUser admin = this.getOneByEntity(queryItem , SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
//			admin.setCustStatus(0);
//			this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, admin);
//		}else{//管理员
			QueryItem queryItem = new QueryItem(Where.eq("id", user.getId()));
			OrgUser admin = this.getOneByEntity(queryItem , SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
			admin.setStatus(0);
			this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, admin);
//		}
		return createSuccessJsonResonse(null,"冻结成功");
	}
	
	/**
	 * 启用用户
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/user/activate/{type}")
	public DyResponse activateUser(OrgUser user,@PathVariable("type")int type) throws Exception {
//		if( type == AccountTypeEnum.CUSTUMER.getIndex() ){
//			QueryItem queryItem = new QueryItem(Where.eq("id", user.getId()));
//			OrgUser admin = this.getOneByEntity(queryItem , SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
//			admin.setCustStatus(1);
//			this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, admin);
//		}else{//管理员
			QueryItem queryItem = new QueryItem(Where.eq("id", user.getId()));
			OrgUser admin = this.getOneByEntity(queryItem , SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
			admin.setStatus(1);
			this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, admin);
//		}
		return createSuccessJsonResonse(null,"启用成功");
	}
	
	/**
	 * 移交授信用户页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/user/transfer")
	public ModelAndView toTransferUser(Long id) throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();	
		QueryItem query = new QueryItem(Where.eq("id", id));
		OrgUser customer = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		
		QueryItem queryItem = new QueryItem(Where.eq("id", customer.getSalerId()));
		OrgUser saler = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		
		QueryItem queryItem1 = new QueryItem();
		List<Where> where = new ArrayList<Where>();
		this.addWhereCondition(where, "dept_id", saler.getDeptId());
		this.addWhereCondition(where, "type", AccountTypeEnum.SALER.getIndex());
		this.addWhereCondition(where, "del_flag", 0);
		queryItem1.setWhere(where);
		List<OrgUser> users = this.getListByEntity(queryItem1 , SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		
		List<FormOption> options = new ArrayList<>();
		for(OrgUser user : users ){
			options.add(new FormOption(user.getRealName(), user.getId()));
		}
		formFieldList.add(FormField.builder().name("salerId").text("移交业务员").verify("required")
				.type("select").options(options ).build());
		
		Map<String, Object> data = PageUtil.createFormPageStructure("org/user/transferUpdate/" + id, formFieldList);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 移交授信用户
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/user/transferUpdate/{id}")
	public DyResponse transferUser(OrgUser user,@PathVariable("id")int id) throws Exception {
		//查询授信客户信息
		QueryItem q = new QueryItem(Where.eq("id", id));
		OrgUser cus = this.getOneByEntity(q , SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		//查询授信客户所属业务员信息
		QueryItem qItem = new QueryItem(Where.eq("id", user.getSalerId()));
		OrgUser saler = this.getOneByEntity(qItem , SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		
		cus.setSalerId(user.getSalerId());
		cus.setSalerName(saler.getRealName());
		this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, cus);
		return createSuccessJsonResonse(null,"移交授信用户成功");
	}
	
	/**
	 * 用户密码编辑更新页面
	 * @param type 用户类型（1管理员，2部门，3业务员，4授信客户）
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/user/changepwdpage/{type}")
	public ModelAndView toChangeUserPwd(Long id,@PathVariable("type")int type) throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		formFieldList.add(FormField.builder().name("password").type("pwd").text("密码").verify("required,pwdchar=[8|16]").build());
		formFieldList.add(FormField.builder().name("repassword").type("pwd").text("重复密码").verify("required,pwdchar=[8|16],equals=password").build());
		Map<String, Object> data = PageUtil.createFormPageStructure("org/user/changepwd/" + type + "/" + id, formFieldList,null);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新用户密码
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/user/changepwd/{type}/{id}")
	public DyResponse updateUserPwd(@PathVariable("id")Long id,String repassword,OrgUser user,@PathVariable("type")int type) throws Exception {
		OrgUser ses = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
		Long now = System.currentTimeMillis() / 1000;
		type=UserTypeEnum.SALER.getIndex();
		user.setType(type);
		user.setUpdateTime(now);
		user.setUpdateUid(ses.getId());
		user.setId(id);
		if( !user.getPassword().equalsIgnoreCase(repassword) ){
			return createErrorJsonResonse("两次输入密码不一致");
		}
		user.setPassword(SecurityUtil.md5(SecurityUtil.sha1(user.getPassword())));
		if( type == AccountTypeEnum.CUSTUMER.getIndex() ){
			this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, user);
		}else{
			this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, user);
		}
		return createSuccessJsonResonse(null,"修改成功");
	}
}