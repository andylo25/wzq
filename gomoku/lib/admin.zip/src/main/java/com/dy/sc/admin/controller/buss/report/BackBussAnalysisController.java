package com.dy.sc.admin.controller.buss.report;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.RowLink;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.service.ReportService;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.ThreadUtils;
import com.dy.core.utils.excel.ExportExcel;
import com.dy.ia.entity.common.OrgUser;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.google.common.collect.Lists;

/**
 * 
 * @ClassName: BackBussAnalysisController 
 * 回款统计
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author cuiwenming@diyou.cn
 * @date 2017年8月3日 上午10:41:17
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * cuiwm 
 * </pre>
 */	
@Controller
@RequestMapping("loan/analysis")
public class BackBussAnalysisController extends AdminBaseController {
	
	@Autowired
	ReportService reportService;
	
	/**
	 * 回款统计全部
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="back/all/{tab}")
	public ModelAndView backAll(@PathVariable("tab") int tab) throws Exception {
		
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","rep_date","loan_count","loan_amount","back_count","back_amount","overdue_wait_count","overdue_wait_amount","overdue_count","overdue_amount","overdue_rate:percent","bad_count","bad_amount","bad_rate:percent"});
		tableHeader.setTexts(new String[]{"ID","月份","待回款期数","待回款总额（本金+利息）","已还款期数（当月+逾期已还）","实际回款总额","当月逾期未还期数","未还总额","累计逾期未还期数","逾期金额（本金+利息）","逾期率","坏账期数","坏账金额","坏账率"});
		
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"月份"});
		search.setTypes(new String[]{"date"});
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/back/allData/"+tab, "rep_date", tableHeader,tool,search);
		if(tab == 0){
			List<RowLink> rowLink=Lists.newArrayList();
			rowLink.add(new RowLink("回款明细","loan/analysis/back/detail"));
			rowLink.add(new RowLink("按业务类型","loan/analysis/back/category/4"));
			rowLink.add(new RowLink("按资方","loan/analysis/back/category/3"));
			rowLink.add(new RowLink("按部门","loan/analysis/back/category/5"));
			rowLink.add(new RowLink("按客户经理","loan/analysis/back/category/6"));
			rowLink.add(new RowLink("逾期明细","loan/analysis/back/overDetail"));
			
			data.setRowLink(rowLink);
			data.setRowLinkTitle("统计明细");
		}
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:回款统计全部
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="back/allData/{tab}")
	public DyResponse backAllData(Integer page,Integer limit,String search,@PathVariable("tab") int tab) throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,rep_date,relation_id,loan_count,loan_amount,loan_amount_prop,back_count,back_amount,back_amount_prop,overdue_wait_count,overdue_wait_amount,bad_count,bad_amount,wait_count,wait_amount,wait_amount_prop,overdue_count,overdue_amount,overdue_amount_prop,total_overdue_count,remark,rec_category,create_time");
		if(tab == 0){
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
		}else if(tab == 1){
			// 我的部门
			OrgUser user = getAdminUser();
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_DEPT));
			queryItem.setWhere(Where.eq("relation_id", user.getDeptId()));
		}else if(tab == 2){
			// 我的业务
			OrgUser user = getAdminUser();
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_SALER));
			queryItem.setWhere(Where.eq("relation_id", user.getId()));
		}
		
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("rep_date", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, Module.REPORT, SCFunction.MONTH_LOAN_BACK);
		
		buildLoanBack(pagem.getItems());
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}

	private void buildLoanBack(List<Map> list) {
		if(list != null){
			for(Map map:list){
				BigDecimal loan_count = new BigDecimal(map.get("loan_count").toString());
				if(NumberUtils.greaterThanZero(loan_count)){
					map.put("overdue_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("overdue_wait_count").toString()), loan_count),NumberUtils.ONE_HUNDRED));
					map.put("bad_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("bad_count").toString()), loan_count),NumberUtils.ONE_HUNDRED));
				}else{
					map.put("overdue_rate",0);
					map.put("bad_rate",0);
				}
			}
		}
	}
	
	/**
	 * 回款明细
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="back/detail")
	public ModelAndView backDetail(String id) throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","company_id","loan_contract_no","business_type","product_id","period_no","repay_time:date","principal","interest","overdue_days","amount","repay_time_yes:date","amount_yes","capital_id","saler_id","dept_id"});
		tableHeader.setTexts(new String[]{"ID","客户名称:credit_com","信贷合同号","业务类型:business_type","产品名称:product_list","期数","应还时间","应还本金","应还利息","逾期天数","应还总额","实际还款时间","实际还款总额","资方:capital_com","客户经理:manager","所属部门:sc_dept"});
		
		Tool tool = new Tool();
		tool.setUrl("loan/analysis/back/98/exportExcel");
		tool.setText("导出");
		tool.setType("commonbatchdownload");
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"信贷合同号"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/back/detailData?id="+id, "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single_open", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:回款明细
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="back/detailData")
	public DyResponse backDetailData(Integer page,String id,Integer limit,String search) throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,company_id,debit_id,loan_contract_no,period_no,repay_time,principal,interest,amount,repay_time_yes,amount_yes,saler_id");

		Date start = DateUtil.dateParse(id+"01");
		Date end = DateUtil.addSecond(DateUtil.addMonth(start, 1),-1);
		queryItem.setWhere(Where.between("repay_time", DateUtil.convert(start), DateUtil.convert(end)));
		
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("loan_contract_no", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
		
		this.idToName(pagem.getItems(), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:business_type,product_id,capital_id");
		this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "saler_id:dept_id");
		
		for(Map item:pagem.getItems()){
			Long repayTimeYes = MapUtils.getLong(item, "repay_time_yes");
			Long repayTime = MapUtils.getLong(item, "repay_time");
			long days = 0;
			if(repayTimeYes != null){
				days = repayTimeYes-repayTime;
			}else{
				days = (DateUtil.getCurrentDateLong()-repayTime);
			}
			if(days < 0)days=0;
			item.put("overdue_days", days/86400);
		}
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}
	
	/**
	 * 逾期明细
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="back/overDetail")
	public ModelAndView overDetail(String id) throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","company_id","loan_contract_no","business_type","product_id","period_no","repay_time:datetime","principal","interest","rep_date","rep_date","amount","saler_id","dept_id"});
		tableHeader.setTexts(new String[]{"ID","客户名称:credit_com","信贷合同号","业务类型:business_type","产品名称:sc_product","期数","应还时间","应还本金","应还利息","逾期天数","逾期费用","应还总额","客户经理:manager","所属部门:sc_dept"});
		
		Tool tool = new Tool();
		tool.setUrl("loan/analysis/back/99/exportExcel");
		tool.setText("导出");
		tool.setType("commonbatchdownload");
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"信贷合同号"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/back/overDetailData?id="+id, "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single_open", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:逾期明细
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="back/overDetailData")
	public DyResponse overDetailData(Integer page,Integer limit,String id,String search) throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,company_id,debit_id,loan_contract_no,period_no,repay_time,principal,interest,amount,repay_time_yes,amount_yes,saler_id");

		Date start = DateUtil.dateParse(id+"01");
		Date end = DateUtil.addSecond(DateUtil.addMonth(start, 1),-1);
		queryItem.setWhere(Where.between("repay_time", DateUtil.convert(start), DateUtil.convert(end)));
		queryItem.setWhere(Where.expression("(repay_time_yes > repay_time or repay_time_yes is null)", false));
		
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("loan_contract_no", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
		
		this.idToName(pagem.getItems(), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:business_type,product_id,capital_id");
		this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "saler_id:dept_id");
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}
	
	/**
	 * 生成上月月报
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("back/insert")
	public DyResponse insert() throws Exception {
		
		ThreadUtils.doSync(()->{
			try {
				reportService.createLastMonthLoanBackReport(DateUtil.dateShortFormat(DateUtil.addMonth(new Date(), -1)).substring(0, 6),false);
			} catch (Exception e) {
			}
			return null;
		});
		return createSuccessJsonResonse(null,"正在生成，1分钟后刷新查看结果");
	}
	
	/**
	 * 生成上月月报
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("back/update")
	public DyResponse update() throws Exception {
		ThreadUtils.doSync(()->{
			try {
				reportService.createLastMonthLoanBackReport(DateUtil.dateShortFormat(DateUtil.addMonth(new Date(), -1)).substring(0, 6),true);
//				reportService.createLastMonthCapReport(DateUtil.getCurrentDateStr().substring(0, 6));
			} catch (Exception e) {
			}
			return null;
		});
		return createSuccessJsonResonse(null,"正在生成，1分钟后刷新查看结果");
	}
	
	/**
	 * 导出excel
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="back/{type}/exportExcel")
	public String exportExcel(HttpServletResponse response,@PathVariable("type") int type,String id) throws Exception{
		String title = "";
		ExportExcel excel = null;
		List<Map> items = null;
		QueryItem queryItem = new QueryItem(Where.in("id", id));
		if(type == 99){//总统计
			title = "逾期明细记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID","客户名称","信贷合同号","业务类型","产品名称","期数","应还时间","应还本金","应还利息","逾期天数","逾期费用","应还总额","客户经理","所属部门:sc_dept"});
			excel.setFieldNames(new String[]{"id","company_id","loan_contract_no","business_type","product_id","period_no","repay_time","principal","interest","rep_date","rep_date","amount","saler_id","dept_id"});
			items = getListByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
			
			this.idToName(items, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:business_type,product_id,capital_id");
			this.idToName(items, SCModule.SYSTEM, SCFunction.SYS_ADMIN, "saler_id:dept_id");
			dataConvert(items,"company_id:credit_com,business_type:business_type,product_id:sc_product,saler_id:manager,dept_id:sc_dept","repay_time");
		}else if(type == 98){//分类统计
			title = "回款明细记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID","客户名称","信贷合同号","业务类型","产品名称","期数","应还时间","应还本金","应还利息","逾期天数","应还总额","实际还款时间","实际还款总额","资方","客户经理","所属部门"});
			excel.setFieldNames(new String[]{"id","company_id","loan_contract_no","business_type","product_id","period_no","repay_time","principal","interest","overdue_days","amount","repay_time_yes","amount_yes","capital_id","saler_id","dept_id"});
			items = getListByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
			
			this.idToName(items, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:business_type,product_id,capital_id");
			this.idToName(items, SCModule.SYSTEM, SCFunction.SYS_ADMIN, "saler_id:dept_id");
			dataConvert(items,"company_id:credit_com,business_type:business_type,product_id:sc_product,capital_id:capital_com,saler_id:manager,dept_id:sc_dept","repay_time,repay_time_yes");
		}else{
			queryItem.setFields("id,rep_date,relation_id,loan_count,loan_amount,loan_amount_prop,back_count,back_amount,back_amount_prop,overdue_wait_count,overdue_wait_amount,bad_count,bad_amount,wait_count,wait_amount,wait_amount_prop,overdue_count,overdue_amount,overdue_amount_prop,total_overdue_count,remark,rec_category,create_time");
			if(type == ScConstants.REP_TYPE_PLAT){
				queryItem = new QueryItem(Where.in("rep_date", id));
				queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
				title = "回款统计记录_"+DateUtil.getCurrentTimeStr();
				excel = new ExportExcel(title, new String[]{"ID","月份","待回款期数","待回款总额（本金+利息）","已还款期数（当月+逾期已还）","实际回款总额","当月逾期未还期数","未还总额","累计逾期未还期数","逾期金额（本金+利息）","逾期率(%)","坏账期数","坏账金额","坏账率(%)"});
				excel.setFieldNames(new String[]{"id","rep_date","loan_count","loan_amount","back_count","back_amount","overdue_wait_count","overdue_wait_amount","overdue_count","overdue_amount","overdue_rate","bad_count","bad_amount","bad_rate"});
				items = getListByMap(queryItem, Module.REPORT, SCFunction.MONTH_LOAN_BACK);
				buildLoanBack(items);
			}else {
				String typeName = "";
				String status = "";
				switch (type) {
				case ScConstants.REP_TYPE_PROD:
					typeName = "业务类型";
					status = "relation_id:business_type";
					title = "按业务类型统计记录_"+DateUtil.getCurrentTimeStr();
					break;
				case ScConstants.REP_TYPE_CAPITAL:
					typeName = "资方名称";
					status = "relation_id:capital_com";
					title = "按资方统计记录_"+DateUtil.getCurrentTimeStr();
					break;
				case ScConstants.REP_TYPE_DEPT:
					typeName = "部门名称";
					status = "relation_id:sc_dept";
					title = "按部门统计记录_"+DateUtil.getCurrentTimeStr();
					break;
				case ScConstants.REP_TYPE_SALER:
					typeName = "人员名称";
					status = "relation_id:manager";
					title = "按客户经理统计记录_"+DateUtil.getCurrentTimeStr();
					break;

				default:
					break;
				}
				excel = new ExportExcel(title, new String[]{typeName,"待回款期数","待回款总额（本金+利息）","占比(%)","已还款期数（当月+逾期已还）","实际回款总额","占比(%)","当月逾期未还期数","未还总额","占比(%)","累计逾期未还期数","逾期金额（本金+利息）"});
				excel.setFieldNames(new String[]{"relation_id","loan_count","loan_amount","loan_amount_prop","back_count","back_amount","back_amount_prop","overdue_wait_count","overdue_wait_amount","wait_amount_prop","overdue_count","overdue_amount"});
				items = getListByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_BACK);
				dataConvert(items, status);
			}
		}
		
		excel.setDataList(items);
		excel.write(response, title+".xlsx");
		
		return null;
	}
	
	/**
	 * 按业务类型
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="back/category/{type}")
	public ModelAndView category(String id,@PathVariable("type") Integer type) throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"relation_id","loan_count","loan_amount","loan_amount_prop:percent","back_count","back_amount","back_amount_prop:percent","overdue_wait_count","overdue_wait_amount","wait_amount_prop:percent","overdue_count","overdue_amount"});
		String typeName = "";
		switch (type) {
		case ScConstants.REP_TYPE_PROD:
			typeName = "业务类型:business_type";
			break;
		case ScConstants.REP_TYPE_CAPITAL:
			typeName = "资方名称:capital_com";
			break;
		case ScConstants.REP_TYPE_DEPT:
			typeName = "部门名称:sc_dept";
			break;
		case ScConstants.REP_TYPE_SALER:
			typeName = "人员名称:manager";
			break;

		default:
			break;
		}
		tableHeader.setTexts(new String[]{typeName,"待回款期数","待回款总额（本金+利息）","占比","已还款期数（当月+逾期已还）","实际回款总额","占比","当月逾期未还期数","未还总额","占比","累计逾期未还期数","逾期金额（本金+利息）"});

		Tool tool = new Tool();
		tool.setUrl("loan/analysis/back/"+type+"/exportExcel");
		tool.setText("导出");
		tool.setType("commonbatchdownload");
		
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/back/categoryData/"+type+"?id="+id, "id", tableHeader,tool,null);
		
		return createSuccessModelAndView("common/table_single_open", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:按业务类型
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="back/categoryData/{type}")
	public DyResponse categoryData(Integer page,Integer limit,String id,@PathVariable("type") Integer type,String search) throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,rep_date,relation_id,loan_count,loan_amount,loan_amount_prop,back_count,back_amount,back_amount_prop,overdue_wait_count,overdue_wait_amount,bad_count,bad_amount,wait_count,wait_amount,wait_amount_prop,overdue_count,overdue_amount,overdue_amount_prop,total_overdue_count,remark,rec_category,create_time");

		queryItem.setWhere(Where.eq("rec_category", type));
		queryItem.setWhere(Where.eq("rep_date", id));
		
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("rep_date", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_BACK);
		
//		this.idToName(pagem.getItems(), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:business_type,product_id,capital_id,sales_uid");
//		this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "sales_uid:dept_id");
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}
	
	
	
	
}