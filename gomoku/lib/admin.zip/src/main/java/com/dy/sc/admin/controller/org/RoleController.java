package com.dy.sc.admin.controller.org;

import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.Constant;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.AuthTree;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.Role;
import com.dy.ia.entity.common.RoleMenu;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/org")
public class RoleController extends AdminBaseController {

    /**
     * 获取所有用户
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/role/list")
    public ModelAndView getUserList() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "role_name", "role_description"});
        tableHeader.setTexts(new String[]{"ID", "角色名称", "角色描述"});
        tableHeader.setTypes(new String[]{"int", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"role_name"});
        search.setTexts(new String[]{"菜单名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("org/role/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取菜单树数据
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/role/listData")
    public DyResponse getAdminListData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.like("role_name", "%" + search + "%"));
        }
        queryItem.setOrders("id");

        return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ROLE), "status"));
    }

    /**
     * 角色新增页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/role/add")
    public ModelAndView toAddRole() throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        formFieldList.add(FormField.builder().name("roleName").text("角色名称").verify("required").build());
        formFieldList.add(FormField.builder().name("roleDescription").text("角色描述").build());
        //formFieldList.add(FormField.builder().name("authKey").text("角色首字母").build());
        Map<String, Object> data = PageUtil.createFormPageStructure("org/role/save", formFieldList);

        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存角色
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/role/save")
    public DyResponse saveUser(Role role) throws Exception {
        OrgUser admin = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
        role.setUpdateUid(admin.getId());
        Long now = System.currentTimeMillis() / 1000;
        role.setCreateTime(now);
        role.setCreateUid(admin.getId());
        role.setUpdateTime(now);
        this.insert(SCModule.SYSTEM, SCFunction.SYS_ROLE, role);
        return createSuccessJsonResonse(null, "新增角色成功");
    }

    /**
     * 角色编辑更新页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/role/edit")
    public ModelAndView toEditUser(Long id) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();

        formFieldList.add(FormField.builder().name("roleName").text("角色名称")
                .verify("required").build());
        formFieldList.add(FormField.builder().name("roleDescription").text("角色描述").build());
        //formFieldList.add(FormField.builder().name("authKey").text("角色首字母").build());

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        Role formdata = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_ROLE, Role.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("org/role/update", formFieldList, formdata);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新角色
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/role/update")
    public DyResponse updateUser(Role role) throws Exception {
        this.update(SCModule.SYSTEM, SCFunction.SYS_ROLE, role);
        return createSuccessJsonResonse(null, "更改角色信息成功");
    }

    /**
     * 分配权限(数据)
     *
     * @param id
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/role/roleFields")
    public ModelAndView getRoleFields(Long id) throws Exception {
        //获取菜单列表
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("id,pid,name");
        queryItem.setWhere(Where.eq("status", 1));
        queryItem.setOrders("sort,id");
        List<Map> menuList = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_MENU);
        if (menuList == null || menuList.size() <= 0) return null;

        //根据ID获取管理员类型权限
        queryItem = new QueryItem(new Where("id", id));
        queryItem.setFields("id,role_name,auth");
        Map<String, Object> map = (Map<String, Object>) this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ROLE);
        String auth = "," + (map.get("auth") == null ? "" : map.get("auth").toString()) + ",";
        String roleName = map.get("role_name").toString();

        //把pid相同的menu放到一个list
        Map<Integer, List<RoleMenu>> menuMap = new HashMap<Integer, List<RoleMenu>>();
        for (Object obj : menuList) {
            RoleMenu tmpMenu = gson.fromJson(gson.toJson(obj), RoleMenu.class);
            tmpMenu.setText(tmpMenu.getRole_name());
            tmpMenu.setValue(tmpMenu.getId());
            tmpMenu.setOpen(true);
            tmpMenu.setName(tmpMenu.getName());
            if (auth.contains("," + tmpMenu.getId() + ",")) {
                tmpMenu.setChecked(true);
            } else {
                tmpMenu.setChecked(false);
            }
            List<RoleMenu> menus = menuMap.get(tmpMenu.getPid());
            if (menus == null || menus.size() <= 0) menus = new ArrayList<RoleMenu>();
            menus.add(tmpMenu);
            menuMap.put(tmpMenu.getPid(), menus);
        }

        AuthTree tree = new AuthTree();
        //构造菜单树
        Map<String, String> ini = new HashMap<String, String>();
        List<RoleMenu> roleMenuList = new ArrayList<RoleMenu>();
        Integer index = 0;
        for (RoleMenu tmpMenu : menuMap.get(0)) {
            List<RoleMenu> subMenuList = new ArrayList<RoleMenu>();
            String tmp = tmpMenu.getId() + ",";

            List<RoleMenu> tempMenuList = menuMap.get(tmpMenu.getId());
            if (tempMenuList != null) {
                for (RoleMenu tmpSubMenu : tempMenuList) {
                    tmpSubMenu.setChildren(menuMap.get(tmpSubMenu.getId()));
                    subMenuList.add(tmpSubMenu);
                    if (tmpSubMenu != null && tmpSubMenu.getChecked()) {
                        tmp += tmpSubMenu.getId() + ",";
                    }


                    List<RoleMenu> subMenuList3 = new ArrayList<RoleMenu>();
                    List<RoleMenu> s3 = menuMap.get(tmpSubMenu.getId());
                    if (null == s3) continue;
                    for (RoleMenu sub3 : s3) {
                        sub3.setChildren(menuMap.get(sub3.getId()));
                        subMenuList3.add(sub3);
                        if (sub3.getChecked()) {
                            tmp += sub3.getId() + ",";
                        }
                        List<RoleMenu> subMenuList4 = new ArrayList<RoleMenu>();
                        List<RoleMenu> s = menuMap.get(sub3.getId());
                        if (null == s) continue;
                        for (RoleMenu sub4 : s) {
                            sub4.setChildren(menuMap.get(sub4.getId()));
                            subMenuList4.add(sub4);
                            if (sub4.getChecked()) {
                                tmp += sub4.getId() + ",";
                            }
                            if (sub4.getChildren() == null) continue;
//	                        for(RoleMenu ch : sub4.getChildren() ){
//	                            if( ch != null && ch.getChecked() ){
//	                                tmp += ch.getId() + ","; 
//	                            }
//	                        }
                            List<RoleMenu> subMenuList5 = new ArrayList<RoleMenu>();
                            List<RoleMenu> s5 = menuMap.get(sub4.getId());
                            for (RoleMenu sub5 : s5) {
                                sub5.setChildren(menuMap.get(sub5.getId()));
                                subMenuList5.add(sub5);
                                if (sub5.getChecked()) {
                                    tmp += sub5.getId() + ",";
                                }
                                if (sub5.getChildren() == null) continue;
//		                        for(RoleMenu ch : sub5.getChildren() ){
//		                            if( ch != null && ch.getChecked() ){
//		                                tmp += ch.getId() + ","; 
//		                            }
//		                        }
                                List<RoleMenu> subMenuList6 = new ArrayList<RoleMenu>();
                                List<RoleMenu> s6 = menuMap.get(sub5.getId());
                                for (RoleMenu sub6 : s6) {
                                    sub6.setChildren(menuMap.get(sub6.getId()));
                                    subMenuList6.add(sub6);
                                    if (sub6.getChecked()) {
                                        tmp += sub6.getId() + ",";
                                    }
                                    if (sub6.getChildren() == null) continue;
                                    for (RoleMenu ch : sub6.getChildren()) {
                                        if (ch != null && ch.getChecked()) {
                                            tmp += ch.getId() + ",";
                                        }
                                    }
                                }
                                sub5.setChildren(subMenuList6);
                            }
                            sub4.setChildren(subMenuList5);
                        }
                        sub3.setChildren(subMenuList4);
                    }
                    tmpSubMenu.setChildren(subMenuList3);
                }
//	            if( tmp.length() > 0 ){
//	                ini.put(index.toString(), tmp.substring(0, tmp.length() - 1));
//	            }
                if (tmpMenu.getChecked() && tmp.length() > 0) {
                    ini.put(index.toString(), tmp.substring(0, tmp.length() - 1));
                }
                index++;
                tmpMenu.setChildren(subMenuList);
                roleMenuList.add(tmpMenu);
            }
        }

        String menu[] = new String[roleMenuList.size()];
        RoleMenu mainMenu[] = new RoleMenu[roleMenuList.size()];

        for (int i = 0; i < roleMenuList.size(); i++) {
            menu[i] = JsonUtils.object2JsonString(roleMenuList.get(i)).replace("pid", "pId");
            mainMenu[i] = roleMenuList.get(i);
        }
        tree.setAuth(menu);
        tree.setTitle(mainMenu);
        tree.setId(id);
        tree.setRole_name(roleName);
        tree.setInitial(JsonUtils.object2JsonString(ini));

        return createSuccessModelAndView("system/auth", JsonUtils.object2JsonString(tree));
    }

    /**
     * 权限分配保存
     *
     * @param request
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/auth/saveAuth", method = RequestMethod.POST)
    public DyResponse editRoleSubmit(Long id, String auth) throws Exception {
        //更新权限
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("id", id);
        map.put("auth", auth == null ? "" : auth);

        DyResponse response = this.update(Module.SYSTEM, Function.SYS_ROLE, map);
        if (response != null || DyResponse.OK == response.getStatus()) {
            adminTypeMap.put(id.intValue(), true);
        }
        return response;
    }
}