/*
 * Copyright(c) 2017 diyou.com All rights reserved.
 * distributed with this file and available online at
 * http://www.diyou.com/
 */
package com.dy.sc.admin.controller.product;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.ChargeType;
import com.dy.sc.entity.product.ProdFeeItem;
import com.google.common.collect.Maps;

/**
 * 费用管理
 * @version 1.0
 * @author 
 */
@Controller
@RequestMapping("/product/prodFeeItem")
public class ProdFeeItemController extends AdminBaseController {
    
    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        
        tableHeader.setNames(new String[] { "id", "fee_name", "charge_point", "formula", "payer_type",
                "payee_type", "status", "remark", "real_name", "create_time" });
        tableHeader
                .setTexts(new String[] { "ID", "费用名称", "收费节点", "计费公式", "扣除对象", "收入对象", "状态", "费用说明", "操作人", "操作时间" });
        tableHeader.setTypes(new String[] { "int", "", "", "", "", "", "", "", "", "date" });
        tableHeader.setOptionTypes(
                new String[] { "", "", "charge_point", "", "payer_type", "payee_type", "status", "", "", "" });
        
        Tool tool = new Tool();
        tool.setList(buildTools());
        
        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[] { "费用名称" });
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("product/prodFeeItem/listData", "id", tableHeader,tool,search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 列表数据
     * @return
     * @throws Exception
     */
    @SuppressWarnings({"rawtypes" })
    @ResponseBody
    @RequestMapping(value="/listData",method=RequestMethod.POST)
    public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if(StringUtils.isNotBlank(search)){
            queryItem.setWhere(Where.likeAll("fee_name", search));
        }
        queryItem.setOrders("create_time desc");
        Page<Map> pageData=getPageByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM);
        // for (Map item : pageData.getItems()) {
        // item.put("charge_formula", formatFormula(item));
        // }
        this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name");
        return createSuccessJsonResonse(pageData);
    }
    
    private static final String FORMULA_1 = "%sx%s%%";
    private static final String FORMULA_2 = "固定费用%s元";
    private static final String FORMULA_3 = "周期%s%d天x%s%s%%";
    private static final String FORMULA_4 = "周期%s%d天x固定费用%s元";

    private String formatFormula(Map item) {
        Integer chargeType = MapUtils.getInteger(item, "charge_type");
        Integer calcDayType = MapUtils.getInteger(item, "calc_day_type");// 天数类型
        Long day = MapUtils.getLong(item, "day");// 天数
        Integer amount_type = MapUtils.getInteger(item, "amount_type");// 金额类型
        BigDecimal amount_rate = (BigDecimal) item.get("amount_rate");// 金额比例
        BigDecimal amount_fee = (BigDecimal) item.get("amount_fee");// 固定费用
        return formatFormula(chargeType, calcDayType, day, amount_type, amount_rate, amount_fee);
    }

    private String formatFormula(ProdFeeItem item) {
        return formatFormula(item.getChargeType(), item.getCalcDayType(), item.getDay(), item.getAmountType(),
                item.getAmountRate(), item.getAmountFee());
    }

    /**
     * 转换公式为中文
     * 
     * @param item
     * @return
     */
    private String formatFormula(Integer chargeType, Integer calcDayType, Long day, Integer amount_type,
            BigDecimal amount_rate, BigDecimal amount_fee) {
        String amountType = null;
        if (amount_type != null)
            amountType = DictUtils.getDictLabel(amount_type, "amount_type");
        String calcDayTypeStr = null;
        if (calcDayType != null)
            calcDayTypeStr = DictUtils.getDictLabel(calcDayType, "calc_day_type");
        String result = null;
        if (ChargeType.TYPE_1.getIndex() == chargeType) {
            result = String.format(FORMULA_1, amountType, NumberUtils.format(amount_rate));
        } else if (ChargeType.TYPE_2.getIndex() == chargeType) {
            result = String.format(FORMULA_2, NumberUtils.format(amount_fee));
        } else if (ChargeType.TYPE_3.getIndex() == chargeType) {
            result = String.format(FORMULA_3, calcDayTypeStr, day, amountType, NumberUtils.format(amount_rate));
        } else if (ChargeType.TYPE_4.getIndex() == chargeType) {
            result = String.format(FORMULA_4, calcDayTypeStr, day, NumberUtils.format(amount_fee));
        }
        return result;
    }

    private Map<String, Object> initFormData() {
        Map<String, Object> formData = Maps.newHashMap();
        formData.put("charge_point", DictUtils.getOptionsInt("charge_point"));
        formData.put("calc_day_type", DictUtils.getOptionsInt("calc_day_type"));
        formData.put("amount_type", DictUtils.getOptionsInt("amount_type"));
        formData.put("charge_type", DictUtils.getOptionsInt("charge_type"));
        formData.put("payer_type", DictUtils.getOptionsInt("payer_type"));
        formData.put("payer_account_type", DictUtils.getOptionsInt("payer_account_type"));
        formData.put("payee_type", DictUtils.getOptionsInt("payee_type"));
        formData.put("payee_account_type", DictUtils.getOptionsInt("payee_account_type"));
        return formData;
    }

    /**
     * 编辑新增页面
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/add",method=RequestMethod.GET)
    public ModelAndView add() throws Exception {        

        Map<String, Object> data = PageUtil.createFormPageStructure("product/prodFeeItem/save", null, initFormData());
        return createSuccessModelAndView("product/prodFeeItem/add", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/save",method=RequestMethod.POST)
    public DyResponse save(ProdFeeItem prodFeeItem) throws Exception {
        prodFeeItem.setFormula(formatFormula(prodFeeItem));
        this.insert(SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM, prodFeeItem);
        return createSuccessJsonResonse(null,"添加成功");
    }
    
    /**
     * 编辑更新页面
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/edit")
    public ModelAndView edit(Long id) throws Exception {

        ProdFeeItem entity = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM, ProdFeeItem.class);
        Map<String, Object> formData = new DataConvertUtil(entity, false).convert(Map.class);
        formData.putAll(initFormData());
        Map<String, Object> data = PageUtil.createFormPageStructure("product/prodFeeItem/update", null, formData);
        return createSuccessModelAndView("product/prodFeeItem/add", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 更新
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/update",method=RequestMethod.POST)
    public DyResponse update(ProdFeeItem prodFeeItem) throws Exception {
        //校验
        prodFeeItem.setFormula(formatFormula(prodFeeItem));
        this.update(SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM, prodFeeItem, true);
        return createSuccessJsonResonse(null,"修改成功");
    }
    
    /**
     * 删除
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/delete",method=RequestMethod.POST)
    public DyResponse delete(Long id) throws Exception {
        ProdFeeItem prodFeeItem=this.getById(id, SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM,ProdFeeItem.class);
        if(prodFeeItem!=null){
            this.deleteById(id,SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM);
        }
        return createSuccessJsonResonse(null,"删除成功");
    }

    @ResponseBody
    @RequestMapping("open")
    public DyResponse enable(ProdFeeItem item) throws Exception {
        ProdFeeItem oldItem = this.getById(item.getId(), SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM, ProdFeeItem.class);
        if (oldItem == null || oldItem.getStatus() != AccConstants.STATUS_CLOSE) {
            return createErrorJsonResonse("费用非关闭状态,不能开启");
        }
        item.setStatus(AccConstants.STATUS_OPEN);
        this.update(SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM, item);
        return createSuccessJsonResonse(null, "开启成功");
    }

    /**
     * 关闭
     * 
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("close")
    public DyResponse disable(ProdFeeItem item) throws Exception {
        ProdFeeItem oldItem = this.getById(item.getId(), SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM, ProdFeeItem.class);
        if (oldItem == null || oldItem.getStatus() != AccConstants.STATUS_OPEN) {
            return createErrorJsonResonse("费用非开启状态,不能关闭");
        }
        item.setStatus(AccConstants.STATUS_CLOSE);
        this.update(SCModule.PRODUCT, SCFunction.PROD_FEE_ITEM, item);
        return createSuccessJsonResonse(null, "关闭成功");
    }

}
