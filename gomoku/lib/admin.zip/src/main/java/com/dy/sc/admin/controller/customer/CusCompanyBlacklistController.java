/*
 * Copyright(c) 2017 diyou.com All rights reserved.
 * distributed with this file and available online at
 * http://www.diyou.com/
 */
package com.dy.sc.admin.controller.customer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.bussmodule.cus.CompanyModule;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.system.CusCompanyBlacklist;

/**
 * 企业黑名单
 * @version 1.0
 * @author 
 */
@Controller
@RequestMapping("/system/cusCompanyBlacklist")
public class CusCompanyBlacklistController extends AdminBaseController {
    
    @Autowired
    private CompanyModule companyModule;
    
    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        
        tableHeader.setNames(new String[]{"id", "company_name","business_lic_type","business_lic_no","blacklist_type","source","create_time","create_user","create_dept"});
        tableHeader.setTexts(new String[]{"ID", "企业名称","证件类型","证件号码","黑名单类型","来源","添加时间","添加人员","所属部门"});
        tableHeader.setTypes(new String[]{"int","","","","","","datetime","",""});
        tableHeader.setOptionTypes(new String[]{"","","business_lic_type","","blacklist_type","","","",""});
        
        Tool tool = new Tool();
        tool.setList(buildTools());
        
        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"企业名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("system/cusCompanyBlacklist/listData", "id", tableHeader,tool,search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 列表数据
     * @return
     * @throws Exception
     */
    @SuppressWarnings({"rawtypes" })
    @ResponseBody
    @RequestMapping(value="/listData",method=RequestMethod.POST)
    public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if(StringUtils.isNotBlank(search)){
            queryItem.setWhere(Where.likeAll("company_name", search));
        }
        queryItem.setOrders("create_time desc");
        Page<Map> pageData=getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_BLACKLIST);
        this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name as create_user,dept_name as create_dept");
        return createSuccessJsonResonse(pageData);
    }
    
    /**
     * 编辑新增页面
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/add/{type}",method=RequestMethod.GET)
    public ModelAndView add(@PathVariable("type")int type,Long id) throws Exception {        
        List<FormField> formFieldList = buidFormField(null,type);
        Map<String,Object> formData=null;
        if(id!=null){
            QueryItem queryItem=QueryItem.builder().field("company_name companyName,company_english_name companyEnglishName,business_lic_type businessLicType,business_lic_no businessLicNo")
                    .where("id",id).build();
            formData=this.getOneByMap(queryItem, SCModule.SYSTEM,SCFunction.SYS_COMPANY);
        }
        Map<String, Object> data = PageUtil.createFormPageStructure("system/cusCompanyBlacklist/save", formFieldList,formData);
        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    private List<FormField> buidFormField(Long id,Integer source) {
        List<FormField> formFieldList = new ArrayList<>();
        if(source==0){
            formFieldList.add(FormField.builder().name("companyName").text("企业名称").type("input").verify("required").build());
            formFieldList.add(FormField.builder().name("companyEnglishName").text("客户名称（英文）").type("input").build());
            formFieldList.add(FormField.builder().name("businessLicType").text("证件类型").verify("required").type("select").options(DictUtils.getOptionsInt("business_lic_type")).build());
            formFieldList.add(FormField.builder().name("businessLicNo").text("证件号码").verify("required").type(id==null?"input":"span").build());
            formFieldList.add(FormField.builder().name("blacklistType").text("黑名单类型").verify("required").type("select").options(DictUtils.getOptionsInt("blacklist_type")).build());
            formFieldList.add(FormField.builder().name("source").text("信息来源").verify("required").type("input").build());
            formFieldList.add(FormField.builder().name("remark").text("备注").type("textarea").build());
        }else if(source==1){
            formFieldList.add(FormField.builder().name("blacklistType").text("黑名单类型").verify("required").type("select").options(DictUtils.getOptionsInt("blacklist_type")).build());
            formFieldList.add(FormField.builder().name("remark").text("备注").type("textarea").build());
        }
        return formFieldList;
    }
    
    private boolean checkExists(Long id,String businessLicNo) throws Exception{
        QueryItem queryItem=new QueryItem();
        queryItem.setWhere(Where.eq("business_lic_no", businessLicNo));
        if(id!=null){
            queryItem.setWhere(Where.notEq("id", id));
        }
        return this.getCount(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_BLACKLIST)>0;
    }
    
    /**
     * 
     * 同步company blacklistType字段 
     * @param businessLicNo
     * @param blacklistType
     * @throws Exception
     * @author likf
     */
    private void setCompanyBlackList(String businessLicNo,Integer blacklistType) throws Exception{
        QueryItem queryItem=new QueryItem();
        queryItem.setFields("id");
        queryItem.setWhere(Where.eq("business_lic_no", businessLicNo));
        queryItem.setWhere(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
        List<Map> companys=this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        if(companys!=null&&companys.size()>0){
            for(Map company:companys){
                if(blacklistType==null)
                    company.put("blacklist_type", null);
                else
                    company.put("blacklist_type", 1);
                this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);
            }
        }
    }
    
    /**
     * 保存
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/save",method=RequestMethod.POST)
    public DyResponse save(CusCompanyBlacklist cusCompanyBlacklist) throws Exception {
        if(checkExists(null, cusCompanyBlacklist.getBusinessLicNo())){
            return createErrorJsonResonse("证件号码:"+cusCompanyBlacklist.getBusinessLicNo()+"的黑名单已存在");
        }
        this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_BLACKLIST, cusCompanyBlacklist);
        setCompanyBlackList(cusCompanyBlacklist.getBusinessLicNo(), cusCompanyBlacklist.getBlacklistType());
        return createSuccessJsonResonse(null,"添加成功");
    }
    
    /**
     * 编辑更新页面
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/edit")
    public ModelAndView edit(Long id) throws Exception {
        List<FormField> formFieldList = buidFormField(id,0);      
        CusCompanyBlacklist entity = this.getById(id , SCModule.SYSTEM, SCFunction.SYS_COMPANY_BLACKLIST,CusCompanyBlacklist.class);        
        Map<String, Object> data = PageUtil.createFormPageStructure("system/cusCompanyBlacklist/update", formFieldList,entity);        
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 更新
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/update",method=RequestMethod.POST)
    public DyResponse update(CusCompanyBlacklist cusCompanyBlacklist) throws Exception {
        if(checkExists(cusCompanyBlacklist.getId(), cusCompanyBlacklist.getBusinessLicNo())){
            return createErrorJsonResonse("证件号码:"+cusCompanyBlacklist.getBusinessLicNo()+"的黑名单已存在");
        }
        CusCompanyBlacklist old=this.getById(cusCompanyBlacklist.getId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY_BLACKLIST,CusCompanyBlacklist.class);
        if(!old.getBlacklistType().equals(cusCompanyBlacklist.getBlacklistType())){//类型变更
            setCompanyBlackList(cusCompanyBlacklist.getBusinessLicNo(), cusCompanyBlacklist.getBlacklistType());
        }
        this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY_BLACKLIST, cusCompanyBlacklist);
        return createSuccessJsonResonse(null,"修改成功");
    }
    
    /**
     * 删除
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/delete",method=RequestMethod.POST)
    public DyResponse delete(Long id) throws Exception {
        CusCompanyBlacklist cusCompanyBlacklist=this.getById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY_BLACKLIST,CusCompanyBlacklist.class);
        if(cusCompanyBlacklist!=null){
            setCompanyBlackList(cusCompanyBlacklist.getBusinessLicNo(), null);
            this.deleteById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY_BLACKLIST);
        }
        return createSuccessJsonResonse(null,"删除成功");
    }
    
    /**
     * 
     * 查询黑名单类型 
     * @param no
     * @return
     * @throws Exception
     * @author likf
     */
    @ResponseBody
    @RequestMapping(value="/blacklistType",method=RequestMethod.POST)
    public DyResponse getBlacklistList(String businessLicNo,Long id) throws Exception {
        Integer blacklistType=companyModule.getBlacklistType(businessLicNo,id);
        return createSuccessJsonResonse(blacklistType,"查询成功");
    }

}
