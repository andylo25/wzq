package com.dy.sc.admin.controller.workflow;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import com.dy.sc.bussmodule.utils.CommonLoanUtil;
import com.dy.sc.entity.credit.CreCompanyLimit;
import com.dy.sc.entity.customer.CusGradeInfo;
import com.dy.sc.entity.enumeration.GradeStatus;
import com.dy.sc.entity.system.Dict;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.adapter.AdapterManager;
import com.dy.core.adapter.FlowAdapter;
import com.dy.core.adapter.LoanAdapter;
import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.FDDUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.common.SpringContextHolder;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.common.FlowProcInst;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.SysDocument;
import com.dy.ia.entity.common.SysSystemConfig;
import com.dy.ia.entity.enumeration.AccountTypeEnum;
import com.dy.sc.admin.controller.customer.CompanyController;
import com.dy.sc.bussmodule.loan.LoanModule;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.bussmodule.utils.TodoUtils;
import com.dy.sc.bussmodule.utils.workflow.WorkflowUtil;
import com.dy.sc.entity.constant.SCFlow;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.CheckStatus;
import com.dy.sc.entity.product.ProdBusinessType;
import com.dy.sc.module.GradeModule;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 待办任务处理
 *
 * @author likf@diyou.cn
 * @version v1.0
 *          <p>
 *          <pre>
 *          修改人                修改时间        版本        修改内容
 *          ---------------------------------------------------------
 *          </pre>
 * @ClassName: TodoController Copyright (c) 2017 厦门帝网信息科技
 * @date 2017年7月14日 下午3:00:02
 */
@Controller
@RequestMapping("/workflow/todo/")
public class TodoController extends AdminBaseController {

    @Autowired
    private WorkflowUtil workflowUtil;
    @Autowired
    private FDDUtils utils;
    @Autowired
    private LoanModule loanModule;

    @SuppressWarnings("unchecked")
    private void setSignImgInfo(Map company) throws Exception {
        // 判断系统是否配置开启云章
        QueryItem queryConfig = new QueryItem(Where.eq("nid", "use_cloudsign"));
        SysSystemConfig config = this.getOneByEntity(queryConfig, SCModule.SYSTEM, SCFunction.SYS_CONFIG, SysSystemConfig.class);
        if (config.getStatus() == AccConstants.STATUS_OPEN) {
            QueryItem queryDoc = new QueryItem(Where.eq("id", company.get("doc_id")));
            SysDocument doc = this.getOneByEntity(queryDoc, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
            if (doc != null) {
                company.put("sign_img_name", doc.getFileName());
                company.put("file_path", doc.getFilePath());
            }
        }
    }

    private List<Map> getDocument(String ids) throws Exception {
        QueryItem queryItem = QueryItem.builder().field("id as did,file_path as url").where(Where.in("id", ids)).build();
        return this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT);
    }

    /**
     * 法人资产列表
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    private List<Map> getCompanyLegalProperty(Long id) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("id,company_id companyId,property_desc propertyDesc,currency,amount,remark,file_id fileId");
        queryItem.setWhere(Where.eq("company_id", id));
        List<Map> list = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_LEGAL_PROPERTY);
        for (Map item : list) {
            String fileId = MapUtils.getString(item, "fileId");
            if (StringUtils.isNotBlank(fileId)) {
                //TODO 暂时支持一个
                item.put("fileId", getDocument(fileId).get(0));
            }
        }
        return list;
    }

    /**
     * 股东列表
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    private List<Map> getCompanyShareholder(Long id) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("id,company_id companyId,shareholder_type shareholderType,shareholder_name shareholderName, legal_relation legalRelation,shareholder_card_type shareholderCardType,card_no cardNo,currency,share_amount shareAmount,share_rate shareRate,share_way shareWay,inplace_rate inplaceRate, remark, file_id fileId");
        queryItem.setWhere(Where.eq("company_id", id));
        List<Map> list = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_SHAREHOLDER);
        for (Map item : list) {
            String fileId = MapUtils.getString(item, "fileId");
            if (StringUtils.isNotBlank(fileId)) {
                //TODO 暂时支持一个
                item.put("fileId", getDocument(fileId).get(0));
            }
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    private Map createCompanyView(Object id) throws Exception {

        // 授信客户信息
//        QueryItem item = new QueryItem();
//        item.setWhere(Where.eq("company_id", id));
//        OrgUser user = this.getOneByEntity(item, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
        Long companyId = Long.parseLong(id.toString());
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        q = QueryItem.builder().where("company_id", id).build();
        Map companyDetail = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY_DETAIL);
        if (companyDetail != null) {
            companyDetail.remove("id");
            companyDetail.put("manage_feature_type", DictUtils.getDictLabel(companyDetail.get("manage_feature_type"), "manage_feature_type"));
            companyDetail.put("company_life_type", DictUtils.getDictLabel(companyDetail.get("company_life_type"), "company_life_type"));
            companyDetail.put("manage_status", DictUtils.getDictLabel(companyDetail.get("manage_status"), "manage_status"));
            companyDetail.put("blacklist_type", DictUtils.getDictLabel(companyDetail.get("blacklist_type"), "blacklist_type"));
            companyDetail.put("legal_sex", DictUtils.getDictLabel(companyDetail.get("legal_sex"), "sex"));
            companyDetail.put("legal_degree", DictUtils.getDictLabel(companyDetail.get("legal_degree"), "legal_degree"));
            companyDetail.put("legal_birthday", DateUtil.dateFormat(companyDetail.get("legal_birthday")));
            companyDetail.put("legal_card_expire", DateUtil.dateFormat(companyDetail.get("legal_card_expire")));

            company.putAll(companyDetail);

            company.put("shareholders", dataConvert(getCompanyShareholder(companyId), "shareholderType:shareholder_type"));
            company.put("properties", getCompanyLegalProperty(companyId));
            //财产信息 股东信息
        }

        boolean fddOpen = utils.fadadaOpen();
        if (!fddOpen) {
            // 印章信息
            this.setSignImgInfo(company);
        }
        QueryItem queryItem = new QueryItem();
        Map<String, Object> account = BaseInfoUtils.getCompAccountMap(id);
        if (account != null) {
            if (account.get("account") != null) {
                company.put("open_bank", account.get("open_bank"));
                company.put("open_bank_account", account.get("account"));
                company.put("open_full_name", account.get("open_full_name"));//账户名
            }
        } else {
            company.put("open_bank", null);
            company.put("open_bank_account", null);
            company.put("open_full_name", null);//账户名
        }

        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("id", company.get("saler_id")));
        query.setWhere(Where.eq("type", AccountTypeEnum.SALER.getIndex()));
        OrgUser s = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
        if (s != null) company.put("saler_name", s.getRealName());

        //上下游企业
        queryItem = new QueryItem();
        queryItem.setFields("core_company_id,chain_position");
        queryItem.setWhere(Where.eq("check_status", CheckStatus.CHECK_PASS.getIndex()));
        queryItem.setWhere(Where.eq("company_id", id));
        List coreCompanyList = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
        if (coreCompanyList != null && coreCompanyList.size() > 0) {
            this.idToName(coreCompanyList, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "core_company_id:company_name");
            dataConvert(coreCompanyList, "chain_position");
            company.put("core_company_list", coreCompanyList);
        }
        if (company.get("company_create_time") != null) {
            company.put("company_create_time", DateUtil.dateFormat(company.get("company_create_time")));
        }
        //实名认证审批情况
        if (company.get("proc_inst_ids") != null && StringUtils.isNotBlank(company.get("proc_inst_ids").toString())) {
            List<Map> checkList = getFlowByIds(company.get("proc_inst_ids").toString());
            if (checkList != null) {
//                for(Map<String,Object> entry:checkList){
//                    dataConvert(entry,null, "create_time");
//                }
                dataConvert(checkList, null, "create_time");
            }
            company.put("checkList", checkList);
        }
        company.put("company_id", id);
        company.put("source", "todo");
        company.put("fdd_open", fddOpen);
        dataConvert(company, "legal_card_type:cred_type,contact_card_type:cred_type,financial_card_type:cred_type,business_lic_type,company_type,company_category,company_scale,is_stock:common_status");
        getViewMenu(company);
        return company;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> createLimitView(Object id, String cond3, String procName) throws Exception {
        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("id", id));
        Map limit = this.getOneByMap(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        limit.put("companyName", BaseInfoUtils.getCompanyName(MapUtils.getLong(limit, "company_id")));
        limit.put("looped", DictUtils.getDictLabel(limit.get("looped").toString(), "looped"));
//		limit.put("amount", amount);
        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("company_id", limit.get("company_id")));
        queryItem.setWhere(Where.notEq("business_type_id", 0));
        List<Map> companyLimits = this.getListByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        String[] tmp = cond3.split(":");
        int size = tmp.length;
        int index = 0;
        BigDecimal addAmount = BigDecimal.ZERO;
        if (size == 4) {
            for (Map companyLimit : companyLimits) {
                if (procName.contains("额度变更")) {
                    String[] t = null;
                    if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_RECEIVE) {
                        t = tmp[0].split(",");
                        companyLimit.put("name", "应收账款");
                    } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_B2B) {
                        t = tmp[1].split(",");
                        companyLimit.put("name", "b2b平台类");
                    } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
                        t = tmp[2].split(",");
                        companyLimit.put("name", "仓单");
                    } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_AGPUR) {
                        t = tmp[3].split(",");
                        companyLimit.put("name", "代采");
                    }
                    boolean b = t[0].equals("1");
                    companyLimit.put("changeType", b ? "增加" : "减少");
                    if(t[1].equals("null")){
                        t[1] =  "0";
                    }
                    companyLimit.put("value", t[1]);
                    companyLimit.put("total", b ? new BigDecimal(companyLimit.get("credit_limit").toString()).add(new BigDecimal(t[1]))
                            : new BigDecimal(companyLimit.get("credit_limit").toString()));
                    addAmount = addAmount.add(new BigDecimal(companyLimit.get("credit_limit").toString()));
                } else {
                    if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_RECEIVE) {
                        companyLimit.put("name", "应收账款");
                    } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_B2B) {
                        companyLimit.put("name", "b2b平台类");
                    } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
                        companyLimit.put("name", "仓单");
                    } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_AGPUR) {
                        companyLimit.put("name", "代采");
                    }
                    companyLimit.put("credit_limit", tmp[index]);
                    addAmount = addAmount.add(new BigDecimal(tmp[index]));
                }
                index ++;
            }
        }
        limit.put("changeList", companyLimits);
        limit.put("startTime", DateUtil.dateFormat(limit.get("start_time")));
        limit.put("endTime", DateUtil.dateFormat(limit.get("end_time")));
        query = QueryItem.builder().where("company_id", limit.get("company_id")).where("grade_status", GradeStatus.VALID.getIndex()).build();
        CusGradeInfo cusGradeInfo = this.getOneByEntity(query, SCModule.CUSTOMER, SCFunction.CUS_GRADE_INFO, CusGradeInfo.class);
        if(cusGradeInfo != null) {
            limit.put("totalPoint", cusGradeInfo.getTotalPoint());
            limit.put("gradeDate", cusGradeInfo.getGradeDate());
            limit.put("riskLimit", cusGradeInfo.getRiskLimit());
        }
        Integer status = Integer.valueOf(limit.get("check_status").toString());
        limit.put("status", status == ScConstants.LIMIT_PASS ? "审批通过" : (status == ScConstants.LIMIT_CHECKING ? "审批中" : "驳回"));
        Company company = this.getById(limit.get("company_id").toString(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        limit.put("companyType", DictUtils.getDictLabel(company.getCompanyRoleType(), "company_role_type"));
        // 审核进度
        List<Map> flows = CommonLoanUtil.getFlowList(id.toString(), "limit_edit");
        List<Map> flows1 = CommonLoanUtil.getFlowList(id.toString(), "limit_add");
        if(flows != null){
            flows.addAll(flows1);
            limit.put("flowList", flows);
        }else {
            limit.put("flowList", flows1);
        }
        limit.put("credit_limit", addAmount);
        limit.put("unused_limit", addAmount);
        if (procName.contains("额度变更")) {
            limit.put("changeType", "change");
            limit.put("req_type", "额度增加");
        } else {
            limit.put("type", "add");
            limit.put("req_type", "申请额度");
        }
        if (limit.get("create_uid") != null) {
            // 客户经理
            Map creater = this.getById(limit.get("create_uid").toString(), SCModule.SYSTEM, SCFunction.SYS_ADMIN);
            if (creater != null) {
                limit.put("creater", creater.get("real_name"));
                limit.put("creater_dept", creater.get("dept_name"));
            }
        }
        return limit;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> createTempLimitApplyView(Object id) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map deptLimit = this.getOneByMap(q, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT);
        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("dept_id", deptLimit.get("dept_id")));
        queryItem.setWhere(Where.eq("status", AccConstants.FLOW_STATUS_APRVING));
        Map applyRecord = this.getOneByMap(queryItem, SCModule.INSIDELIMIT, SCFunction.APPLY_RECORD);
        deptLimit.put("dept_name", deptLimit.get("dept_name"));
        deptLimit.put("apply_amount", applyRecord.get("apply_limit"));
        deptLimit.put("cur_limit", deptLimit.get("temp_limit"));
        deptLimit.put("credit_limit", deptLimit.get("credit_limit"));
        deptLimit.put("create_time", DateUtil.dateFormat(applyRecord.get("create_time")));
        deptLimit.put("reason", applyRecord.get("reason"));
        Map<String, Object> formData = Maps.newHashMap();
        QueryItem qitem = new QueryItem(Where.eq("buss_num", deptLimit.get("pledge_contract_no")));
        qitem.setWhere(Where.in("flow_status", AccConstants.FLOW_STATUS_APRVING + "," + AccConstants.FLOW_STATUS_NOREND));
        List<Map> flowInst = this.getListByMap(qitem, SCModule.FLOW, SCFunction.FLOW_PROC_INST);
        // 审核进度
        if (flowInst != null && !flowInst.isEmpty()) {
            QueryItem query = new QueryItem();
            query.setWhere(Where.eq("proc_inst_id", flowInst.get(0).get("id")));
            List<Map> flows = this.getListByMap(query, SCModule.FLOW, SCFunction.FLOW_COMMENT);
            for (Map<String, Object> entry : flows) {
                dataConvert(entry, null, "create_time");
            }
            formData.put("flowList", flows);
        }
        Map<String, Object> contract = Maps.newHashMap();
        contract.put("deptLimit", deptLimit);
        formData.put("form_data", contract);
        return formData;
    }

    /**
     * 客户审查侧滑
     *
     * @param id
     * @param flowInstId
     * @return
     * @throws Exception
     * @author likf
     */
    private Map createCommInvestApplyView(Object id, Long flowInstId) throws Exception {
        Map<String, Object> result = companyController.getViewData(Long.parseLong(id.toString()));
        TodoUtils.getCheckList(result, flowInstId);
        return result;
    }

    private Pattern p = Pattern.compile("flowInstId=(\\d+)");

    /**
     * 删除flowInstId
     *
     * @param str
     * @return
     */
    private String removeFlowInstId(String str) {
        Matcher matcher = p.matcher(str);
        if (matcher.find()) {
            return matcher.replaceFirst("flowInstId=");
        }
        return str;
    }

    @Autowired
    private CompanyController companyController;

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "view/{type}", method = RequestMethod.GET)
    public ModelAndView view(HttpServletRequest request, Long id, @PathVariable("type") int pageType) throws Exception {

        FlowProcInst inst = this.getById(id, SCModule.FLOW, SCFunction.FLOW_PROC_INST, FlowProcInst.class);
        String type = inst.getProcDefKey();
        FlowAdapter flowAdapter = AdapterManager.getFlowAdapter(type);
        Map<String, Object> result = null;
        String viewName = null;
        Object objId = inst.getCond1();
        String bussType = null;
        if (SCFlow.FLOW_SHIMING.equals(type)) {
            bussType = BUSS_TYPE_SHIMING;
            viewName = "system/companyDetail";
            result = createCompanyView(objId);
        } else if (SCFlow.FLOW_LIMIT_ADD.equals(type)) {
            bussType = BUSS_LIMIT_ADD;
            viewName = "credit/limitinfo";
            result = createLimitView(objId, inst.getCond3(), inst.getProcName());
        } else if (SCFlow.FLOW_TEMP_LIMIT_APPLY.equals(type)) {
            bussType = BUSS_TYPE_LIMIT_APPLY;
            viewName = "workflow/tempLimitApply";
            result = createTempLimitApplyView(objId);
        } else if (SCFlow.FLOW_LIMIT_EDIT.equals(type)) {
            bussType = BUSS_LIMIT_EDIT;
            viewName = "credit/limitinfo";
            result = createLimitView(objId, inst.getCond3(), inst.getProcName());
        } else if (SCFlow.FLOW_JIEDAI.equals(type)) {
            viewName = "redirect:/credit/protocol/" + inst.getBusinessType() + "?id=" + inst.getLoanId() + "&flowInstId=" + inst.getId();
        } else if (SCFlow.FLOW_QINGKUAN.equals(type)) {
            LoanAdapter loanAdapter = AdapterManager.getLoanAdapter(inst.getBusinessType());
            result = loanAdapter.createQingkuanView(inst.getLoanId(), id);

            bussType = String.valueOf(result.get("bussType"));
            viewName = String.valueOf(result.get("viewName"));
        } else if (SCFlow.FLOW_COMM_GRADE_APPLY.equals(type)) {
            viewName = "workflow/companyGradeApply";
            GradeModule gradeModule = (GradeModule) SpringContextHolder.getBean("gradeModule");
            result = gradeModule.createCommGradeApplyView(objId, id);
        } else if (SCFlow.FLOW_COMM_INVEST_APPLY.equals(type)) {
            viewName = "workflow/companyInvestApply";
            result = createCommInvestApplyView(objId, id);
        } else if (SCFlow.FLOW_COMM_AFT_CHECK.equals(type)) {
            viewName = "redirect:/loan/after/check/view?id=" + objId + "&flowInstId=" + inst.getId();
        } else if (SCFlow.FLOW_COMM_AFT_FVCLSIFY.equals(type)) {
            viewName = "redirect:/aft/clsifyInfo/view?id=" + objId + "&flowInstId=" + inst.getId();
        } else if (flowAdapter != null) {
            result = flowAdapter.todoView(inst, pageType);
            bussType = (String) result.remove("bussType");
            viewName = (String) result.remove("viewName");
        }

        if (viewName.startsWith("redirect:")) {
            if (pageType != 0) {//不显示审批按钮
                viewName = removeFlowInstId(viewName);
            }
            return createSuccessModelAndView(viewName, null);
        }

        if (bussType == null) {
            bussType = ScConstants.BUSS_TYPE_COMMON;
        }
        if (pageType == 0) {
            result.put("submit_url1", "workflow/todo/passView/" + bussType);
            result.put("submit_title1", "通过");
            result.put("submit_btn_text1", "通过");
            result.put("reject_url", "workflow/todo/rejectView/" + bussType);
            result.put("reject_title", "驳回");

            result.put("flowInstId", id);
        } else {
            result.remove("submit_url1");
            result.remove("reject_url");
            result.remove("submit_url");
        }

        result.put("id", id);
        result.put("flowInstStatus", inst.getCurTaskName());
        result.put("source", "todo");

        return createSuccessModelAndView(viewName, JsonUtils.object2JsonString(result));
    }

    /**
     * 增加额度
     */
    private static final String BUSS_LIMIT_ADD = "limit_add";
    /**
     * 修改额度
     */
    private static final String BUSS_LIMIT_EDIT = "limit_edit";

    /**
     * 实名认证业务
     */
    private static final String BUSS_TYPE_SHIMING = "realname";
    /**
     * 借贷审批
     */
    private static final String BUSS_TYPE_LEND = "lend";

    /**
     * 出款审批
     */
    private static final String BUSS_TYPE_REQUEST_MONEY = "requestMoney";

    /**
     * 临时额度申请
     */
    private static final String BUSS_TYPE_LIMIT_APPLY = "limitapply";

    /**
     * 实名认证审核弹出页
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "passView/{type}", method = RequestMethod.GET)
    public ModelAndView passView(Long id, @PathVariable("type") String type, String end) throws Exception {
        Map<String, Object> data = Maps.newHashMap();
        data.put("id", id);
        FlowProcInst procInst = this.getById(id, SCModule.FLOW, SCFunction.FLOW_PROC_INST, FlowProcInst.class,
                "id,proc_def_key,proc_name,cond1,cond2,flow_status,company_id");
        data.put("companyId", procInst.getCompanyId());
        List<FormField> formFieldList = null;
//        String view = "common/edit";
        //实名认证不需要选择业务员，在企业详情里编辑业务员
//        if (BUSS_TYPE_SHIMING.equals(type)) {
//            formFieldList = buidFormField();
//    		List depts = TreeUtils.getDeptOptions();
//    		Map<String,Object> deptTree = new HashMap<String,Object>();
//    		deptTree.put("department_list", depts);
//    		data.put("service_type", deptTree);
//    		deptTree.put("getlist_url", "loan/contract/getuser");
//    		data.put("departmentData", depts);
//    		view = "company/add";
//        }else if(BUSS_TYPE_LEND.equals(type)&&"1".equals(end)){
//            formFieldList = buidSalerField();
//        } else {//if (BUSS_TYPE_PLEDGE.equals(type) || BUSS_TYPE_TRANSFER.equals(type)|| BUSS_TYPE_LEND.equals(type)|| BUSS_TYPE_REQUEST_MONEY.equals(type)) {
//            formFieldList = Lists.newArrayList();
//            formFieldList.add(FormField.builder().name("msg").text("审批意见").type("textarea").verify("required").build());
//            formFieldList.add(FormField.builder().name("docId").text("添加附件").type("upload").build());
        String view = "workflow/approveView";
//        }

        Map<String, Object> pageData = PageUtil.createFormPageStructure("workflow/todo/approve/" + type + "?pass=true",
                formFieldList,
                data);
        return createSuccessModelAndView(view, JsonUtils.object2JsonString(pageData));
    }

    @RequestMapping(value = "rejectView/{type}", method = RequestMethod.GET)
    public ModelAndView rejectView(Long id, @PathVariable("type") String type) throws Exception {
        Map<String, Object> data = Maps.newHashMap();
        data.put("id", id);
        data.put("pass", false);
        List<FormField> formFieldList = Lists.newArrayList();
        formFieldList.add(FormField.builder().name("msg").text("驳回原因").type("textarea").verify("required").build());

        Map<String, Object> pageData = PageUtil.createFormPageStructure("workflow/todo/approve/" + type,
                formFieldList,
                data);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(pageData));
    }

    /**
     * 审批通过/驳回
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "approve/{type}", method = RequestMethod.POST)
    public DyResponse approve(Long id, String docId, Long salerId, Integer chainPosition, @PathVariable("type") String type,
                              boolean pass, String msg) throws Exception {

        FlowProcInst procInst = this.getById(id, SCModule.FLOW, SCFunction.FLOW_PROC_INST, FlowProcInst.class,
                "id,proc_def_key,proc_name,cond1,cond2,flow_status");
        //校验是否在黑名单 禁止内黑名单  客户在预警类黑名单中,不允许继续操作，如是提示类黑名单 客户在预警类黑名单中,是否继续操作?
//		if(procInst.getCompanyId()!=null){
//    		Map company=this.getById(procInst.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY);
//    		if(company!=null){
//    			Integer blacklist=MapUtils.getInteger(company,"blacklist_type");
//    			if(blacklist!=null&&blacklist==BlacklistTypeEnum.FORBIDDEN.getIndex()){
//    				return createErrorJsonResonse("客户在禁止类黑名单中,不允许操作");
//    			}
//    		}
//    	}

        FlowAdapter adapter = AdapterManager.getFlowAdapter(procInst.getProcDefKey());
        if (pass && adapter != null) {
            String errorMsg = adapter.checkSubmit(procInst);
            if (errorMsg != null) {
                return createErrorJsonResonse(errorMsg);
            }
        }
        procInst = workflowUtil.submit(id, (pass ? StringUtils.isNoneBlank(msg) ? msg : "审批通过" : msg), pass, docId);
        return createSuccessJsonResonse(null, "审批完成");
    }

    /**
     * 待复核页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "list/{type}", method = RequestMethod.GET)
    public ModelAndView list(@PathVariable("type") int type, String defKey) throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "cond2", "proc_name", "cur_task_name", "create_uname", "create_time"});
        tableHeader.setTexts(new String[]{"ID", "客户名称", "审批流程名称", "任务名称", "发起人", "发起时间"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "datetime"});
        tableHeader.setFilters(new String[]{"", "input", "input", "", "input", "multi_date"});
        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"search", "key"});
        search.setTexts(new String[]{"审批流程名称", "流程key"});
        search.setTypes(new String[]{"text", "hidden"});
        String dataUrl = "workflow/todo/listData/" + type;
        if (StringUtils.isNotBlank(defKey)) {
            dataUrl = "workflow/todo/listData/" + type + "?defKey=" + defKey;
        }
        PageStructure data = PageUtil.createTablePageStructure(dataUrl,
                "workflow/todo/view/" + type,
                "id",
                tableHeader,
                tool,
                search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取数据:待审核
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings({"rawtypes"})
    @ResponseBody
    @RequestMapping(value = "listData/{type}", method = RequestMethod.POST)
    public DyResponse listData(Integer page, Integer limit, String search, @PathVariable("type") int type,
                               String cond2, String proc_name, String create_uname, String create_time, String defKey) throws Exception {

        QueryItem queryItem = TodoUtils.buildTodoQeurySC(type);
//        queryItem.setWhere(Where.in("role_id", user.getRole()));
        queryItem.setOrders("id desc");
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,cond2,proc_name,cur_task_name,create_uname,create_time");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("proc_name", search));
        }
        if (StringUtils.isNotBlank(cond2)) {
            queryItem.setWhere(Where.likeAll("cond2", cond2));
        }
        if (StringUtils.isNotBlank(proc_name)) {
            queryItem.setWhere(Where.likeAll("proc_name", proc_name));
        }
        if (StringUtils.isNotBlank(create_uname)) {
            queryItem.setWhere(Where.likeAll("create_uname", create_uname));
        }
        if (StringUtils.isNotBlank(create_time)) {
            queryItem.setWhere(this.addDateWhereCondition(null, "create_time", create_time));
        }

        if (StringUtils.isNotBlank(defKey)) {
            queryItem.setWhere(Where.eq("proc_def_key", defKey));
        }

        Page<Map> insts = this.getPageByMap(queryItem, SCModule.FLOW, SCFunction.FLOW_PROC_INST);
//        this.idToName(insts.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name");
        return createSuccessJsonResonse(insts);
    }

    /**
     * 附件
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "companyDocument")
    public ModelAndView documentView(Long id) throws Exception {
        FlowProcInst inst = this.getById(id, SCModule.FLOW, SCFunction.FLOW_PROC_INST, FlowProcInst.class);
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", inst.getCond1()));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

        QueryItem queryItem = new QueryItem();
        // 附件信息
        queryItem = new QueryItem(Where.eq("company_id", inst.getCond1()));
        List<Map> documents = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT);
        this.idToName(documents, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, "premise_material_id:name as material_name");
        company.put("documents", dataConvert(documents, null, "create_time"));
        company.put("source", "todo");
        company.put("company_id", inst.getCond1());
        company.put("id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyDocument", JsonUtils.object2JsonString(company));

    }

    /**
     * 融资
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "companyLoan")
    public ModelAndView loanView(Long id) throws Exception {
        FlowProcInst inst = this.getById(id, SCModule.FLOW, SCFunction.FLOW_PROC_INST, FlowProcInst.class);
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", inst.getCond1()));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        QueryItem queryItem = new QueryItem();
        // 附件信息
        queryItem = new QueryItem(Where.eq("company_id", inst.getCond1()));
        Map<String, Object> statCredit = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.STAT_CREDIT);
        company.put("credit", statCredit);
        queryItem = new QueryItem(Where.eq("company_id", inst.getCond1()));
        Map<String, Object> statBill = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.STAT_RECEIVE_BILL);
        company.put("stat_bill", statBill);
        company.put("source", "todo");
        company.put("company_id", inst.getCond1());
        company.put("id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyLoan", JsonUtils.object2JsonString(company));

    }

    /**
     * 额度
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "companyLimit")
    public ModelAndView limitView(Long id) throws Exception {
        FlowProcInst inst = this.getById(id, SCModule.FLOW, SCFunction.FLOW_PROC_INST, FlowProcInst.class);
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", inst.getCond1()));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        // 授信企业-额度信息
        this.getLimitInfo(company);
        company.put("source", "todo");
        company.put("company_id", inst.getCond1());
        company.put("id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyLimit", JsonUtils.object2JsonString(company));
    }

    /**
     * @param company
     * @return void
     * lipengpeng
     * @throws Exception
     * @Title: getLimitInfo
     * @Description: 获取额度记录信息
     */
    @SuppressWarnings("unchecked")
    private void getLimitInfo(Map company) throws Exception {
        QueryItem queryLimit = new QueryItem(Where.eq("company_id", company.get("id")));
        queryLimit.setWhere(Where.eq("check_status", ScConstants.LIMIT_PASS));
        List<Map> limits = this.getListByMap(queryLimit, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        for (Map limit : limits) {
            limit.put("limit_type", this.getById(limit.get("business_type_id").toString(), SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class).getName());
            limit.put("create_time", DateUtil.dateFormat(limit.get("create_time")));
            OrgUser user = this.getById(limit.get("create_uid").toString(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
            limit.put("creater", user == null ? "" : user.getRealName());
            limit.put("dept_name", user == null ? "" : user.getDeptName());
        }
        company.put("limits", limits);
    }

    /**
     * 贷前评估
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "evaluateView")
    public ModelAndView evaluateView(Long id) throws Exception {
        FlowProcInst inst = this.getById(id, SCModule.FLOW, SCFunction.FLOW_PROC_INST, FlowProcInst.class);
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", inst.getCond1()));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

        QueryItem queryItem = new QueryItem();
        queryItem = new QueryItem(Where.eq("company_id", inst.getCond1()));
        Map evaluate = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_EVALUATE);
        if (evaluate != null) {
            company.putAll(evaluate);
        }
        company.put("source", "todo");
        company.put("company_id", inst.getCond1());
        company.put("id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyEvaluate", JsonUtils.object2JsonString(company));

    }

    /**
     * 实名审批查进程
     *
     * @throws Exception
     */
    private List<Map> getFlowByIds(String instIds) throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.in("proc_inst_id", instIds));
        item.setOrders("create_time desc");
        List<Map> commentList = this.getListByMap(item, SCModule.FLOW, SCFunction.FLOW_COMMENT);
        return commentList;
    }

}
