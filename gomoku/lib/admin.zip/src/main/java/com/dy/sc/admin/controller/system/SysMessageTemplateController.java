
/**
 * Copyright cuiwm
 */
package com.dy.sc.admin.controller.system;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.SysMessageTemplate;

/**
 * 提醒配置
 * @author cuiwm
 */
@Controller
@RequestMapping(value = "sys/messageTemplate")
public class SysMessageTemplateController extends AdminBaseController {
	
	@Override
	protected DateFormatType getDateFormatType() {
		return DateFormatType.DATETIME;
	}
	
	/**
     * 构建列表结构:提醒配置
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","title","sms_status","email_status","msg_status","contents","sms_contents"});
		tableHeader.setTexts(new String[]{"ID","模版标题","短信状态:status","邮件状态:status","站内信状态:status","模板内容","短信内容"});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"title"});
		search.setTexts(new String[]{"模版标题"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("sys/messageTemplate/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 获取列表数据:提醒配置
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("listData")
	public DyResponse getListData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,title,contents,sms_contents,sms_status,email_status,msg_status,create_time");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("title", search));
		}
		// 其他过滤条件
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, Module.SYSTEM, Function.MESSAGE_TEMPLATE);
 //		this.idToName(pagem.getItems(), Module.SYSTEM, Function.SYS_ADMIN, "user_id:real_name,username"); // 关联转换
 //		dataConvert(pagem); // 数据转换
		
		return createSuccessJsonResonse(pagem);
	}

	/**
	 * 到添加界面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="toAdd")
	public ModelAndView toAdd() throws Exception {
		
		List<FormField> formFieldList = buidFormField();
		
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/messageTemplate/save", formFieldList);
		
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	private List<FormField> buidFormField() {
		List<FormField> formFieldList = new ArrayList<>();
		formFieldList.add(FormField.builder().name("title").text("模版标题").verify("required").build());
		formFieldList.add(FormField.builder().name("smsStatus").text("短信状态").type("select").options("status").verify("required").build());
		formFieldList.add(FormField.builder().name("emailStatus").text("邮件状态").type("select").options("status").verify("required").build());
		formFieldList.add(FormField.builder().name("msgStatus").text("站内信状态").type("select").options("status").verify("required").build());
		formFieldList.add(FormField.builder().name("contents").text("模板内容").type("textarea").verify("required").build());
		formFieldList.add(FormField.builder().name("smsContents").text("短信内容").type("textarea").verify("required").build());
		
		return formFieldList;
	}

	/**
	 * 保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="save")
	public DyResponse save(SysMessageTemplate sysMessageTemplate) throws Exception {
		if(!check(sysMessageTemplate))return createErrorJsonResonse("缺失必填项");
		this.insert(Module.SYSTEM, Function.MESSAGE_TEMPLATE, sysMessageTemplate);
		return createSuccessJsonResonse(null,"添加成功");
	}
	
	/**
	 * 校验输入
	 * @param sysMessageTemplate
	 * @return
	 */
	private boolean check(SysMessageTemplate sysMessageTemplate){
		if(StringUtils.isBlank(sysMessageTemplate.getTitle()))return false;
		if(StringUtils.isBlank(sysMessageTemplate.getContents()))return false;
		if(StringUtils.isBlank(sysMessageTemplate.getSmsContents()))return false;
		if(sysMessageTemplate.getSmsStatus() == null)return false;
		if(sysMessageTemplate.getEmailStatus() == null)return false;
		if(sysMessageTemplate.getMsgStatus() == null)return false;
		return true;
	}
	
	/**
	 * 到编辑页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="toEdit")
	public ModelAndView toEdit(Long id) throws Exception {

		List<FormField> formFieldList = buidFormField();
		
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		SysMessageTemplate sysMessageTemplate = this.getOneByEntity(queryItem , Module.SYSTEM, Function.MESSAGE_TEMPLATE, SysMessageTemplate.class);
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/messageTemplate/update", formFieldList,sysMessageTemplate);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update")
	public DyResponse update(SysMessageTemplate sysMessageTemplate) throws Exception {
		if(!check(sysMessageTemplate))return createErrorJsonResonse("缺失必填项");
		this.update(Module.SYSTEM, Function.MESSAGE_TEMPLATE, sysMessageTemplate);
		
		return createSuccessJsonResonse(null,"修改成功");
	}
	
	/**
	 * 删除
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete")
	public DyResponse delete(Long id) throws Exception {
		this.deleteById(id, Module.SYSTEM, Function.MESSAGE_TEMPLATE);
		return createSuccessJsonResonse(null,"删除成功");
	}
	

}