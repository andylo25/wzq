package com.dy.sc.admin.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.httpinvoker.HttpInvokerRequestExecutor;

import com.dy.core.httpinvoker.client.DyHttpInvokerProxyFactoryBean;
import com.dy.core.httpinvoker.client.KryoHttpComponentsInvokerRequestExecutor;
import com.dy.core.service.BaseService;
import com.dy.core.service.CompanyService;
import com.dy.core.service.CreditService;
import com.dy.core.service.ReportService;
import com.dy.core.service.SystemService;
import com.dy.sc.service.money.MoneyService;
import com.dy.sc.service.money.ScBussService;

@Configuration
public class SpringInvokerConf {
	
	@Value("${SERVER_URL}")
	private String SERVER_URL;
	
	@Bean("httpInvokerRequestExecutor")
	public HttpInvokerRequestExecutor getKryoHttpComponentsInvokerRequestExecutor(){
		KryoHttpComponentsInvokerRequestExecutor requestExecutor = new KryoHttpComponentsInvokerRequestExecutor();
		requestExecutor.setConnectTimeout(5000);
		requestExecutor.setReadTimeout(60000);
		return requestExecutor;
	}
	
	@Bean("baseService")
	public DyHttpInvokerProxyFactoryBean getBaseService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
		factoryBean.setHttpInvokerRequestExecutor(executor);
		factoryBean.setServiceUrl(SERVER_URL+"/BaseService");
		factoryBean.setServiceInterface(BaseService.class);
		return factoryBean;
	}
	@Bean("systemService")
	public DyHttpInvokerProxyFactoryBean getSystemService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
		factoryBean.setHttpInvokerRequestExecutor(executor);
		factoryBean.setServiceUrl(SERVER_URL+"/SystemService");
		factoryBean.setServiceInterface(SystemService.class);
		return factoryBean;
	}
//	@Bean("workFlowService")
//	public DyHttpInvokerProxyFactoryBean getWorkFlowService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
//		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
//		factoryBean.setHttpInvokerRequestExecutor(executor);
//		factoryBean.setServiceUrl(SERVER_URL+"/WorkFlowService");
//		factoryBean.setServiceInterface(WorkFlowService.class);
//		return factoryBean;
//	}
//	@Bean("bussService")
//	public DyHttpInvokerProxyFactoryBean getBussService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
//		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
//		factoryBean.setHttpInvokerRequestExecutor(executor);
//		factoryBean.setServiceUrl(SERVER_URL+"/BussService");
//		factoryBean.setServiceInterface(BussService.class);
//		return factoryBean;
//	}
	@Bean("moneyService")
	public DyHttpInvokerProxyFactoryBean getMoneyService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
		factoryBean.setHttpInvokerRequestExecutor(executor);
		factoryBean.setServiceUrl(SERVER_URL+"/MoneyService");
		factoryBean.setServiceInterface(MoneyService.class);
		return factoryBean;
	}
	@Bean("companyService")
	public DyHttpInvokerProxyFactoryBean getCompanyService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
		factoryBean.setHttpInvokerRequestExecutor(executor);
		factoryBean.setServiceUrl(SERVER_URL+"/CompanyService");
		factoryBean.setServiceInterface(CompanyService.class);
		return factoryBean;
	}
//	@Bean("capitalService")
//	public DyHttpInvokerProxyFactoryBean getCapitalService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
//		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
//		factoryBean.setHttpInvokerRequestExecutor(executor);
//		factoryBean.setServiceUrl(SERVER_URL+"/CapitalService");
//		factoryBean.setServiceInterface(CapitalService.class);
//		return factoryBean;
//	}
	@Bean("reportService")
	public DyHttpInvokerProxyFactoryBean getReportService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
		factoryBean.setHttpInvokerRequestExecutor(executor);
		factoryBean.setServiceUrl(SERVER_URL+"/ReportService");
		factoryBean.setServiceInterface(ReportService.class);
		return factoryBean;
	}
	@Bean("creditService")
	public DyHttpInvokerProxyFactoryBean getCreditService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
		factoryBean.setHttpInvokerRequestExecutor(executor);
		factoryBean.setServiceUrl(SERVER_URL+"/CreditService");
		factoryBean.setServiceInterface(CreditService.class);
		return factoryBean;
	}
	@Bean("scBussService")
	public DyHttpInvokerProxyFactoryBean getScBussService(@Qualifier("httpInvokerRequestExecutor")HttpInvokerRequestExecutor executor){
		DyHttpInvokerProxyFactoryBean factoryBean = new DyHttpInvokerProxyFactoryBean();
		factoryBean.setHttpInvokerRequestExecutor(executor);
		factoryBean.setServiceUrl(SERVER_URL+"/ScBussService");
		factoryBean.setServiceInterface(ScBussService.class);
		return factoryBean;
	}
	
}
