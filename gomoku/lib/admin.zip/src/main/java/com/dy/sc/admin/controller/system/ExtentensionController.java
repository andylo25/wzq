package com.dy.sc.admin.controller.system;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.dml.DmlItem;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.NameValue;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.EmailUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.sms.SmsUtil;
import com.dy.ia.entity.common.*;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/sys")
public class ExtentensionController extends AdminBaseController {
    @Autowired
    private SmsUtil smsUtil;
    @Autowired
    private EmailUtil emailUtil;

    /**
     * 短信发送记录页面结构
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/sms/sendlog")
    public ModelAndView smsSendLog() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "member_name", "username", "phone", "type", "status", "contents", "create_time"});
        tableHeader.setTexts(new String[]{"ID", "公司名称", "登录名", "手机号码", "类型", "状态", "内容", "添加时间"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());
        Search search = new Search();
        search.setNames(new String[]{"member_name"});
        search.setTexts(new String[]{"公司名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("sys/sms/sendlogData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取短信发送记录
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("/sms/sendlogData")
    public DyResponse smsSendLogData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.like("member_name", "%" + search + "%"));
        }
        queryItem.setOrders("create_time desc");
        Page<Map> rlt = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SMSLOG);
        List<Map> items = rlt.getItems();

        for (Map item : items) {
            Integer stat = Integer.parseInt(item.get("status").toString());
            if (stat == AccConstants.SEND_WILL_SEND) {
                item.put("status", "发送成功");
            } else if (stat == AccConstants.SEND_FAILURE) {
                item.put("status", "发送失败");
            } else if (stat == AccConstants.SEND_SUCCESS) {
                item.put("status", "发送成功");
            } else {
                item.put("status", "发送中");
            }
        }
        this.idToName(items, SCModule.SYSTEM, SCFunction.SYS_USER, "member_id#company_id:username");
        return createSuccessJsonResonse(dataConvert(rlt, "type", "create_time"));
    }

    /**
     * 重新发送短信
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/sms/send")
    public DyResponse sendSms(String id) throws Exception {
        if (StringUtils.isBlank(id)) {
            return createErrorJsonResonse(getMessage("sms.send.error"));
        }
        String[] arrId = id.split(",");
        DyResponse response = null;
        for (String id1 : arrId) {
            QueryItem queryItem = new QueryItem();
            queryItem.setWhere(Where.eq("id", id1));
            SysSmsLog smsLog = getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SMSLOG, SysSmsLog.class);
            Long smsPortId = smsUtil.send(smsLog.getPhone().toString(), smsLog.getContents(), smsLog.getType(), SmsUtil.SEND_REPEAT, smsLog.getMemberId(), smsLog.getMemberName());

            if (smsPortId == null) {
                response = createErrorJsonResonse(getMessage("sms.send.error"));
            } else {
                DmlItem dmlItem = new DmlItem();
                dmlItem.setId(id1);
                dmlItem.setParams(Collections.singletonList(new NameValue("sms_port_id", smsPortId)));
                update(SCModule.SYSTEM, SCFunction.SMSLOG, dmlItem);
                response = createSuccessJsonResonse(getMessage("sms.send.success"));
            }
        }
        return response;
    }

    /**
     * 短信配置页面结构
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/sms/config")
    public ModelAndView smsConfig() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "name", "status", "content"});
        tableHeader.setTexts(new String[]{"ID", "模板名称", "状态", "短信内容"});
        tableHeader.setTypes(new String[]{"int", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());
        Search search = new Search();
        search.setNames(new String[]{"name"});
        search.setTexts(new String[]{"模板名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("sys/sms/configData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取短信配置
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/sms/configData")
    public DyResponse smsConfigData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.like("name", "%" + search + "%"));
        }
        queryItem.setOrders("id");

        return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_SMSTPL), "status"));
    }

    /**
     * 编辑短信配置页面
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/sms/editconfig")
    public ModelAndView editSmsConfigPage(Long id) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();

        formFieldList.add(FormField.builder().name("name").text("模板名称")
                .verify("required").build());
        List<Option> opt = new ArrayList<Option>();
        opt.add(new Option(0, "关闭"));
        opt.add(new Option(1, "开启"));
        formFieldList.add(FormField.builder().name("status").type("radio").text("状态")
                .options(opt).verify("required").build());
        formFieldList.add(FormField.builder().type("textarea").name("content").text("短信模板").build());

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        SysSmsTemplate formdata = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_SMSTPL, SysSmsTemplate.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("sys/sms/edit", formFieldList, formdata);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 编辑短信配置
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/sms/edit")
    public DyResponse editSmsConfig(SysSmsTemplate template) throws Exception {
        this.update(SCModule.SYSTEM, SCFunction.SYS_SMSTPL, template);
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 短信接口界面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/sms/configinterface")
    public ModelAndView smsConfigInterface() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "name", "port_server", "account", "sign_name", "send_url", "remark", "status", "count"});
        tableHeader.setTexts(new String[]{"ID", "短信配置名", "短信服务商", "配置账号", "签名", "接口地址", "备注", "状态", "已发条数"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", "", "int"});

        Tool tool = new Tool();
        tool.setList(buildTools());
        Search search = new Search();
        search.setNames(new String[]{"name"});
        search.setTexts(new String[]{"菜单名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("sys/sms/configinterfaceData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取短信配置接口
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/sms/configinterfaceData")
    public DyResponse smsConfigInterfaceData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.like("name", "%" + search + "%"));
        }
        queryItem.setOrders("id");

        return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_SMSPORT), "status"));
    }

    /**
     * 增加短信接口配置界面
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/sms/addsmsserver")
    public ModelAndView addSmsInterfaceConfigPage(SmsConfig config) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        formFieldList.add(FormField.builder().name("name").text("短信配置名称").verify("required").build());
        formFieldList.add(FormField.builder().name("portServer").text("短信服务商").verify("required").build());
        formFieldList.add(FormField.builder().name("account").text("配置账号").verify("required").build());
        formFieldList.add(FormField.builder().name("password").type("pwd").text("配置密码").verify("required").build());
        formFieldList.add(FormField.builder().name("sendUrl").text("接口地址").verify("required").build());
        formFieldList.add(FormField.builder().name("signName").text("签名").verify("required").build());
        formFieldList.add(FormField.builder().name("remark").text("备注").verify("required").build());
        List<Option> opt = new ArrayList<Option>();
        opt.add(new Option(0, "关闭"));
        opt.add(new Option(1, "开启"));
        formFieldList.add(FormField.builder().name("status").text("状态").type("radio")
                .options(opt).build());

        Map<String, Object> data = PageUtil.createFormPageStructure("sys/sms/addsmsser/", formFieldList);

        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    /**
     * 增加短信接口配置
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/sms/addsmsser")
    public DyResponse addSmsInterfaceConfig(SmsConfig config) throws Exception {
        this.insert(SCModule.SYSTEM, SCFunction.SYS_SMSPORT, config);
        return createSuccessJsonResonse(null, "增加短信接口成功");
    }

    /**
     * 编辑短信接口配置界面
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/sms/editsmsserver")
    public ModelAndView editSmsInterfaceConfigPage(Long id) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();

        formFieldList.add(FormField.builder().name("name").text("短信配置名称").verify("required").build());
        formFieldList.add(FormField.builder().name("portServer").text("短信服务商").build());
        formFieldList.add(FormField.builder().name("account").text("配置账号").verify("required").build());
        formFieldList.add(FormField.builder().name("password").type("pwd").text("配置密码").verify("required").build());
        formFieldList.add(FormField.builder().name("sendUrl").text("接口地址").verify("required").build());
        formFieldList.add(FormField.builder().name("signName").text("签名").verify("required").build());
        formFieldList.add(FormField.builder().name("remark").text("备注").build());
        List<Option> opt = new ArrayList<Option>();
        opt.add(new Option(0, "关闭"));
        opt.add(new Option(1, "开启"));
        formFieldList.add(FormField.builder().name("status").text("状态").type("radio")
                .options(opt).build());

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        SmsConfig formdata = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_SMSPORT, SmsConfig.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("sys/sms/editsmsser", formFieldList, formdata);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 编辑短信接口配置
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/sms/editsmsser")
    public DyResponse editSmsInterfaceConfig(SmsConfig config) throws Exception {
        this.update(SCModule.SYSTEM, SCFunction.SYS_SMSPORT, config);
        return createSuccessJsonResonse(null, "修改短信接口成功");
    }

    /**
     * 删除短信服务商
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/sms/delsmsserver")
    public DyResponse delSmsServer(Long id) throws Exception {
        this.deleteById(id, SCModule.SYSTEM, SCFunction.SYS_SMSPORT);
        return createSuccessJsonResonse(null, "删除成功");
    }

    /**
     * 邮件发送记录界面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/mail/sendlog")
    public ModelAndView mailSendLog() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "member_name", "member_email", "title", "create_time", "send_email", "status", "send_time"});
        tableHeader.setTexts(new String[]{"ID", "用户名", "接收邮箱", "标题", "添加时间", "发送邮箱", "状态", "发送时间"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "int", "", "", "int"});

        Tool tool = new Tool();
        tool.setList(buildTools());
        Search search = new Search();
        search.setNames(new String[]{"member_name"});
        search.setTexts(new String[]{"用户名"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("sys/mail/sendlogData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取邮件发送记录
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/mail/sendlogData")
    public DyResponse mailSendLogData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.like("member_name", "%" + search + "%"));
        }
        queryItem.setOrders("id desc");
        Page<Map> rlt = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.EMAILLOG);
        List<Map> items = rlt.getItems();

        for (Map item : items) {
            Integer stat = Integer.parseInt(item.get("status").toString());
            if (stat == AccConstants.SEND_WILL_SEND) {
                item.put("status", "发送成功");
            } else if (stat == AccConstants.SEND_FAILURE) {
                item.put("status", "发送失败");
            } else if (stat == AccConstants.SEND_SUCCESS) {
                item.put("status", "发送成功");
            } else {
                item.put("status", "发送中");
            }
        }
        return createSuccessJsonResonse(dataConvert(rlt, "type", "create_time,send_time"));
    }

    /**
     * 重新发送邮件弹出
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/mail/send")
    public DyResponse sendMailPage(String id) throws Exception {
        if (StringUtils.isBlank(id)) {
            return createErrorJsonResonse(getMessage("email.send.error"));
        }
        String[] arrId = id.split(",");
        DyResponse response = null;
        for (String id1 : arrId) {
            QueryItem queryItem = new QueryItem();
            queryItem.setWhere(new Where("id", id1));
            SysEmailLog emailLog = getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.EMAILLOG, SysEmailLog.class);
            if (emailLog == null) return createSuccessJsonResonse(null);
            if (emailUtil.send(emailLog.getSendEmail(), new String[]{emailLog.getMemberEmail()}, emailLog.getTitle(), emailLog.getContents(), EmailUtil.SEND_REPEAT)) {
                DmlItem dmlItem = new DmlItem();
                dmlItem.setId(id1);
                dmlItem.setParams(Collections.singletonList(new NameValue("status", 1)));
                update(SCModule.SYSTEM, SCFunction.EMAILLOG, dmlItem);
                response = createSuccessJsonResonse(getMessage("email.send.success"));
            } else {
                response = createErrorJsonResonse(getMessage("email.send.error"));
            }
        }
        return response;
    }

    /**
     * 查看邮件
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/mail/check")
    public String checkEmail(Long id) throws Exception {
        DyResponse response = new DyResponse();
        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        SysEmailLog formdata = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.EMAILLOG, SysEmailLog.class);
        response.setData(formdata.getContents());

        return formdata.getContents();
    }

    /**
     * 邮件配置接口界面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/mail/configinterface")
    public ModelAndView mailConfiInterface() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "title", "email_smtp", "email_port", "email_account", "email_nickname", "status"});
        tableHeader.setTexts(new String[]{"ID", "配置名称", "邮件服务器", "邮件端口", "发送邮箱", "发送者昵称", "状态"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());
        Search search = new Search();
        search.setNames(new String[]{"title"});
        search.setTexts(new String[]{"配置名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("sys/mail/configinterfaceData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取邮件配置接口
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/mail/configinterfaceData")
    public DyResponse mailConfiInterfaceData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.like("title", "%" + search + "%"));
        }
        queryItem.setOrders("id");

        return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_EMAILPORT), "status"));
    }

    /**
     * 增加短信接口配置界面
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/mail/addconfig")
    public ModelAndView addConfigPage() throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        formFieldList.add(FormField.builder().name("title").text("配置名称").verify("required").build());
        formFieldList.add(FormField.builder().name("emailNickname").text("发送者昵称").verify("required").build());
        formFieldList.add(FormField.builder().name("emailAccount").text("发送邮箱").verify("required").build());
        formFieldList.add(FormField.builder().name("emailPassword").type("pwd").text("邮箱密码").verify("required").build());
        formFieldList.add(FormField.builder().name("emailSmtp").text("邮件服务器").verify("required").build());
        formFieldList.add(FormField.builder().name("emailPort").text("邮箱端口").verify("required").build());

        List<Option> opt = new ArrayList<Option>();
        opt.add(new Option(0, "关闭"));
        opt.add(new Option(1, "开启"));
        formFieldList.add(FormField.builder().name("status").text("状态").type("radio")
                .options(opt).build());

        Map<String, Object> data = PageUtil.createFormPageStructure("sys/mail/addconf", formFieldList);

        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    /**
     * 增加短信接口配置
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/mail/addconf")
    public DyResponse addConfig(SysEmailPort emailPort) throws Exception {
        this.insert(SCModule.SYSTEM, SCFunction.SYS_EMAILPORT, emailPort);
        return createSuccessJsonResonse(null, "增加短信接口成功");
    }

    /**
     * 编辑短信接口配置界面
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/mail/editconfig")
    public ModelAndView editMailConfigPage(Long id) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        formFieldList.add(FormField.builder().name("title").text("配置名称").verify("required").build());
        formFieldList.add(FormField.builder().name("emailNickname").text("发送者昵称").verify("required").build());
        formFieldList.add(FormField.builder().name("emailAccount").text("发送邮箱").verify("required").build());
        formFieldList.add(FormField.builder().name("emailPassword").type("pwd").text("邮箱密码").verify("required").build());
        formFieldList.add(FormField.builder().name("emailSmtp").text("邮件服务器").verify("required").build());
        formFieldList.add(FormField.builder().name("emailPort").text("邮箱端口").verify("required").build());
        List<Option> opt = new ArrayList<Option>();
        opt.add(new Option(0, "关闭"));
        opt.add(new Option(1, "开启"));
        formFieldList.add(FormField.builder().name("status").text("状态").type("radio")
                .options(opt).build());

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        SysEmailPort formdata = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_EMAILPORT, SysEmailPort.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("sys/mail/edit", formFieldList, formdata);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 编辑短信接口配置
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/mail/edit")
    public DyResponse editMailConfig(SysEmailPort emailPort) throws Exception {
        this.update(SCModule.SYSTEM, SCFunction.SYS_EMAILPORT, emailPort);
        return createSuccessJsonResonse(null, "修改短信接口成功");
    }

    /**
     * 删除邮件配置
     *
     * @param
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/mail/delconfig")
    public DyResponse delMailConfig(Long id) throws Exception {
        this.deleteById(id, SCModule.SYSTEM, SCFunction.SYS_EMAILPORT);
        return createSuccessJsonResonse(null, "删除成功");
    }
}