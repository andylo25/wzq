package com.dy.sc.admin.controller.system;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.system.SysSign;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Map;

/**
 * 云章渠道配置
 *
 * @author lipengpeng@diyou.cn
 * @version v1.0
 *          <pre>
 *          修改人                修改时间        版本        修改内容
 *          ---------------------------------------------------------
 *          lipengpeng
 *          </pre>
 * @ClassName: SysSignController
 * 注释说明
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @date 2017年7月31日 下午1:48:18
 */
@Controller
@RequestMapping("/system/sign")
public class SysSignController extends AdminBaseController {

    /**
     * 云章信息
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "list")
    public ModelAndView signList() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "name", "url", "app_key", "secrept", "status"});
        tableHeader.setTexts(new String[]{"ID", "渠道名称", "api地址", "appkey", "秘钥", "状态"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());
        Search search = new Search();
        search.setNames(new String[]{"name"});
        search.setTexts(new String[]{"功能名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("system/sign/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取系统设置数据
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "listData")
    public DyResponse signListData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("name", search));
        }
        queryItem.setOrders("create_time desc");
        Page<Map> rlt = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_SIGN);
        return createSuccessJsonResonse(dataConvert(rlt, "status", ""));
    }

    /**
     * 编辑页面
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "edit")
    public ModelAndView edit(Long id) throws Exception {
        List<FormField> formFieldList = Lists.newArrayList();

        formFieldList.add(FormField.builder().name("name").text("功能名称").verify("required").build());
        formFieldList.add(FormField.builder().name("url").text("api地址").verify("required").build());
        formFieldList.add(FormField.builder().name("appKey").text("appkey").verify("required").build());
        formFieldList.add(FormField.builder().name("secrept").text("秘钥").verify("required").build());
        formFieldList.add(FormField.builder().name("status").text("状态").options("status").type("radio").verify("required").build());

        SysSign sign = this.getById(id, SCModule.SYSTEM, SCFunction.SYS_SIGN, SysSign.class);

        Map<String, Object> data = PageUtil.createFormPageStructure("system/sign/update", formFieldList, sign);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public DyResponse update(SysSign sign) throws Exception {
        this.update(SCModule.SYSTEM, SCFunction.SYS_SIGN, sign);
        return createSuccessJsonResonse(null, "修改成功");
    }
}