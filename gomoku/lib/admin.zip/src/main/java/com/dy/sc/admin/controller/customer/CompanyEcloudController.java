/*
 * Copyright(c) 2017 diyou.com All rights reserved.
 * distributed with this file and available online at
 * http://www.diyou.com/
 */
package com.dy.sc.admin.controller.customer;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.Company;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Maps;

/**
 * 银行账户信息
 * @version 1.0
 * @author 
 */
@Controller
@RequestMapping("/system/ecloud")
public class CompanyEcloudController extends AdminBaseController {
    
    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        
        tableHeader.setNames(new String[]{"id", "company_name","company_role_type","url_","serial_number","creater","create_time"});
        tableHeader.setTexts(new String[]{"ID","企业名称","企业类型","印章图片","证书编号","创建人","创建时间"});
        tableHeader.setTypes(new String[]{"int","","","action","","","datetime"});
        tableHeader.setOptionTypes(new String[]{"","","company_role_type","","","",""});
        
        Tool tool = new Tool();
        tool.setList(buildTools());
        
        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("system/ecloud/listData", "id", tableHeader,tool,search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 列表数据
     * @return
     * @throws Exception
     */
    @SuppressWarnings({"rawtypes" })
    @ResponseBody
    @RequestMapping(value="/listData",method=RequestMethod.POST)
    public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if(StringUtils.isNotBlank(search)){
            queryItem.setWhere(Where.likeAll("name", search));
        }
        queryItem.setOrders("create_time desc");
        Page<Map> pageData=getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        for(Map item:pageData.getItems()){
            item.put("action", "url");
        }
        this.idToName(pageData.getItems(), SCModule.SYSTEM,SCFunction.SYS_ADMIN, "create_uid:real_name as creater");
        this.idToName(pageData.getItems(), SCModule.SYSTEM,SCFunction.SYS_DOCUMENT, "doc_id:file_path as url_");
        return createSuccessJsonResonse(pageData);
    }

    /**
     * 编辑更新页面
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/edit")
    public ModelAndView edit(Long id) throws Exception {
        Map<String,Object> formData=null;
        if(id!=null){
            Company company=BaseInfoUtils.getCompany(id);
            formData=new DataConvertUtil(company,false).convert(Map.class);
            formData.put("companyId", company.getId());
        }else{
            formData=Maps.newHashMap();
        }
        List<FormField> formFieldList = null;
        formData.put("company_role_type", DictUtils.getOptionsInt("company_role_type"));
        
//        if(company.getDocId()!=null){
//            QueryItem queryItem=QueryItem.builder().field("id as did,file_path as url").where("id", company.getDocId()).build();
//            Map doc=this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT);
//            formData.put("import_file", doc);
//        }
        Map<String, Object> data = PageUtil.createFormPageStructure("system/ecloud/update", formFieldList,formData);        
        return createSuccessModelAndView("system/companyEcloudAdd", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 更新
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/update",method=RequestMethod.POST)
    public DyResponse update(Company company) throws Exception {
        //校验
        Map<String,Object> companyMap=Maps.newHashMap();
        companyMap.put("id", company.getId());
        companyMap.put("doc_id", company.getDocId());
        this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, companyMap);
        return createSuccessJsonResonse(null,"修改成功");
    }
    
    /**
     * 删除
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/delete",method=RequestMethod.POST)
    public DyResponse delete(Long id) throws Exception {
        //至少保留一个账号
        Company company=this.getById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY,Company.class);
        if(company!=null){
            //this.deleteById(id,SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        }
        return createSuccessJsonResonse(null,"删除成功");
    }
}
