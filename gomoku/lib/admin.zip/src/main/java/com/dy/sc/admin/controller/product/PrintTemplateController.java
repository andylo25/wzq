package com.dy.sc.admin.controller.product;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.*;
import com.dy.ia.entity.common.SysDocument;
import com.dy.ia.entity.enumeration.UploadValidation;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.TemplateType;
import com.dy.sc.entity.product.ProdTemplate;
import com.google.common.collect.Maps;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * @author likaijun@diyou.cn
 * @version v1.0
 *          <pre>
 *          修改人                修改时间        版本        修改内容
 *          ---------------------------------------------------------
 *          likaijun
 *          </pre>
 * @ClassName: ProductController.java
 * 产品模块 Controller
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @date 2017年7月4日上午10:38:20
 */
@Controller
@RequestMapping("/prod/printTemplate/")
public class PrintTemplateController extends AdminBaseController {

    /**
     * 业务类型列表
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"name", "businessType", "attach_url"});
        tableHeader.setTexts(new String[]{"合同名称", "所属类型", "下载地址"});
        tableHeader.setTypes(new String[]{"", "", ""});

        tableHeader.setOptionTypes(new String[]{"", "", ""});
        tableHeader.setFilters(new String[]{"input", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"合同名称"});
        search.setTypes(new String[]{"text"});

        PageStructure data = PageUtil.createTablePageStructure("prod/printTemplate/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取业务类型数据
     *
     * @param page
     * @param limit
     * @param search
     * @param name   业务名称
     * @return
     * @throws Exception
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse printTemplateListData(Integer page, Integer limit, String search,
                                            String name) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields(" id, name, business_type_id, attach_url");
        queryItem.setWhere(Where.eq("prod_template_type", TemplateType.PRINT.getIndex()));
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("name", search));
        }
        if (StringUtils.isNotBlank(name)) {
            queryItem.setWhere(Where.likeAll("name", name));
        }
        queryItem.setOrders(" create_time desc");
        Page recordPage = this.getPageByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
        List<Map> data = recordPage.getItems();
        this.idToName(data, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, "business_type_id:name as businessType");
        return createSuccessJsonResonse(recordPage);
    }

    /**
     * 界面上的下拉、单选、字典值
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("rawtypes")
    private Map<String, Object> getFromData() throws Exception {
        Map<String, Object> formdata = Maps.newHashMap();
        List<Map> businessTypes = getBusinessTypes();
        //业务类型
        formdata.put("businessTypes", businessTypes);
        //状态
        formdata.put("printFormats", DictUtils.getOptionsInt("print_format"));
        return formdata;
    }

    /**
     * 添加产品
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "add")
    public ModelAndView add() throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        Map<String, Object> formdata = getFromData();
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/printTemplate/save", formFieldList, formdata);
        return createSuccessModelAndView("product/editPrintTemplate", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存新增业务类型
     *
     * @param businessType
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "save")
    public DyResponse save(ProdTemplate template, String import_file, String import_name, HttpServletRequest request) throws Exception {
        if (StringUtils.isNotBlank(import_file) && StringUtils.isNotBlank(import_name)) {
            SysDocument document = new SysDocument();
            document.setFileName(import_name);
            document.setFilePath(import_file);
            int ind = import_name.indexOf('.');
            if (ind > 0) {
                document.setType(import_name.substring(ind));
            }
            document.setFileSize(0l);
            document.setDocType(UploadValidation.product_printTemplate.getDocType());
            document.setCreateUname(getUser().getRealName());
            document.setClientType(Converter.boolToInt(RequestUtil.isAdmin()));
            this.insert(SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, document);
            template.setAttachId(document.getId());
            template.setAttachUrl(import_file);
        }
        template.setProdTemplateType(TemplateType.PRINT.getIndex());
        template.setContent(request.getParameter("content"));
        this.insert(SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, template);
        return createSuccessJsonResonse(null, "添加成功！");
    }

    /**
     * 添加产品
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "edit")
    public ModelAndView edite(Long id) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        Map<String, Object> formdata = getFromData();
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("id", id));
        ProdTemplate template = this.getOneByEntity(item, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, ProdTemplate.class);

        Map<String, Object> templateMap = (Map<String, Object>) new DataConvertUtil(template, false).convert();
        formdata.putAll(templateMap);
        formdata.put("id", template.getId());
        if (template.getAttachId() != null) {
            Map<String, Object> file = this.getById(template.getAttachId(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT);
            formdata.put("import_file", file.get("file_path"));
            formdata.put("import_name", file.get("file_name"));
        }
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/printTemplate/update", formFieldList, formdata);
        return createSuccessModelAndView("product/editPrintTemplate", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存新增业务类型
     *
     * @param businessType
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update")
    public DyResponse update(ProdTemplate template, String import_file, String import_name, HttpServletRequest request) throws Exception {
        if (StringUtils.isNotBlank(import_file) && StringUtils.isNotBlank(import_name)) {
            QueryItem item = new QueryItem();
            item.getWhere().add(Where.eq("id", template.getAttachId()));
            SysDocument document = this.getOneByEntity(item, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
            document.setFileName(import_name);
            document.setFilePath(import_file);
            int ind = import_name.indexOf('.');
            if (ind > 0) {
                document.setType(import_name.substring(ind));
            }
            document.setFileSize(0l);
            document.setDocType(UploadValidation.product_printTemplate.getDocType());
            this.update(SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, document);
            template.setAttachUrl(import_file);
        }
        template.setContent(request.getParameter("content"));
        this.update(SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, template);
        return createSuccessJsonResonse(null, "更新成功！");
    }

    @ResponseBody
    @RequestMapping(value = "delete")
    public DyResponse delete(Long id) throws Exception {
        Map<String, Object> printTemplate = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
        if (printTemplate.get("attach_id") != null) {
            this.deleteById(Long.parseLong(printTemplate.get("attach_id").toString()), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT);
        }
        this.deleteById(id, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
        return createSuccessJsonResonse(null, "删除成功！");
    }

    /**
     * 业务类型下拉
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("rawtypes")
    private List<Map> getBusinessTypes() throws Exception {
        QueryItem item = new QueryItem();
        item.setFields(" id, name, code ");
        List<Map> businessTypes = this.getListByMap(item, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        return businessTypes;
    }

}