package com.dy.sc.admin.controller.content;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DyStringUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.PropertiesUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.content.CtArticles;

/**
 * 文章管理
 * @author Administrator
 *
 */
@Controller
@RequestMapping("content/article")
public class CtArticleController extends AdminBaseController {
	/**
	 * 文章管理页面结构渲染
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="list")
	public ModelAndView getCtArticlesPageInfo() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "title", "author", "category_id", "status", "create_time:datetime","sort_index"});
		tableHeader.setTexts(new String[]{"ID", "标题", "作者", "分类栏目:art_page", "是否发布:common_status", "时间","排序"});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"title"});
		search.setTexts(new String[]{"标题"});
		search.setTypes(new String[]{"text"});
		
		PageStructure data = PageUtil.createTablePageStructure("content/article/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 文章管理列表数据检索
	 * @param current_page
	 * @param areas
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="listData")
	public DyResponse getCtArticlesPageData(Integer current_page, String author, String title, Integer category_id, Integer status) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(current_page == null ? 1 : current_page);
		queryItem.setFields("id,author,title,category_id,status,create_time,sort_index");
		//queryItem.setOrders("id");
		queryItem.setOrders("create_time desc");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.CONTENT, SCFunction.ARTICLES);
		
		return createSuccessJsonResonse(pagem);
	}
	
	/**
	 * 增加文章
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="addfields")
	public ModelAndView createCtArticle() throws Exception {
		
		Map<String, Object> data = PageUtil.createFormPageStructure("content/article/addsubmit", 
				getArticleEditPage(),Collections.singletonMap("author", getUser().getRealName()));
		
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 添加保存文章
	 * @return 
	 * @throws Exception 
	 */
	@ResponseBody
	@RequestMapping(value="addsubmit", method=RequestMethod.POST)
	public DyResponse addSubmit(CtArticles ctArticles) throws Exception {
		
		//非空校验
		String errorMsg = this.validateNull(ctArticles);
		if(StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
		//内容校验
		if(!StringUtils.isNotEmpty(ctArticles.getContents())) return createErrorJsonResonse("文章内容不能为空");		
		
		List<String> srcList = DyStringUtils.getImageSrc(ctArticles.getContents());
		if (srcList != null && srcList.size() > 0 && StringUtils.isNotBlank(srcList.get(0))) {
			ctArticles.setThumbs(srcList.get(0).replaceAll(PropertiesUtil.getImageHost(), ""));
		}
		DyResponse response = this.insert(SCModule.CONTENT, SCFunction.ARTICLES, ctArticles);
		if(response.isOK()){
			return createSuccessJsonResonse(null,"添加成功");
		}
		return response;
	}
	
	/**
	 * 编辑文章
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="edit")
	public ModelAndView editCtArticle(Long id) throws Exception {
		
		List<FormField> formFieldList = getArticleEditPage();
		
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		CtArticles ctArticles = this.getOneByEntity(queryItem , SCModule.CONTENT, SCFunction.ARTICLES, CtArticles.class);
		Map<String, Object> data = PageUtil.createFormPageStructure("content/article/editsubmit", formFieldList,ctArticles);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 编辑保存文章
	 */
	@ResponseBody
	@RequestMapping(value="editsubmit", method=RequestMethod.POST)
	public DyResponse editSubmit(CtArticles ctArticles) throws Exception {
		//非空校验
		String errorMsg = this.validateNull(ctArticles);
		if(StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
		//内容校验
		if(!StringUtils.isNotEmpty(ctArticles.getContents())) return createErrorJsonResonse("文章内容不能为空");		
		
		List<String> srcList = DyStringUtils.getImageSrc(ctArticles.getContents());
		if (srcList != null && srcList.size() > 0 && StringUtils.isNotBlank(srcList.get(0))) {
			ctArticles.setThumbs(srcList.get(0).replaceAll(PropertiesUtil.getImageHost(), ""));
		}
		DyResponse response = this.update(SCModule.CONTENT, SCFunction.ARTICLES, ctArticles);
		if(response.isOK()){
			return createSuccessJsonResonse(null,"修改成功");
		}
		return response;
	}
	
	/**
	 * 删除文章
	 */
	@ResponseBody
	@RequestMapping(value="DelSubmit", method=RequestMethod.POST)
	public DyResponse delSubmit(Long delid) throws Exception {
		this.deleteById(delid, SCModule.CONTENT, SCFunction.ARTICLES);
		return createSuccessJsonResonse(null,"删除成功");
	}
	
	/**
	 * 新增/编辑非空校验
	 * @param map
	 * @return
	 */
	private String validateNull(CtArticles articles) {
		return this.validateNull(
				articles,
				new String[]{"title", "author", "status", "categoryId", "sortIndex", "contents"},
				new String[]{"标题", "作者", "状态", "分类栏目", "排序", "内容"});
	}
	
	/**
	 * 文件管理(新增/编辑页面结构)
	 * @return
	 */
	private List<FormField> getArticleEditPage() {
		List<FormField> formFieldList = new ArrayList<>();
		formFieldList.add(FormField.builder().name("title").text("标题").verify("required").build());
		formFieldList.add(FormField.builder().name("summary").text("描述").verify("required").build());
		formFieldList.add(FormField.builder().name("author").text("作者").verify("required").build());
		formFieldList.add(FormField.builder().name("status").text("是否发布").verify("required").type("radio").options("common_status").build());
		formFieldList.add(FormField.builder().name("categoryId").text("分类栏目").verify("required").type("select").options("art_page").build());
		formFieldList.add(FormField.builder().name("sortIndex").text("排序").verify("required").build());
		formFieldList.add(FormField.builder().name("contents").text("内容").type("editor").build());
		
		return formFieldList;	
	}
}