/*
 * Copyright(c) 2017 diyou.com All rights reserved.
 * distributed with this file and available online at
 * http://www.diyou.com/
 */
package com.dy.sc.admin.controller.account;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.AccountUseType;
import com.dy.sc.entity.enumeration.CompanyRoleType;
import com.google.common.collect.Lists;

/**
 * 银行账户信息
 * @version 1.0
 * @author 
 */
@Controller
@RequestMapping("/account/accAccount")
public class AccAccountController extends AdminBaseController {
    
    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        
        tableHeader.setNames(new String[]{"id", "company_name","business_lic_type","business_lic_no","company_role_type","account_use_type","open_bank","account","acc_balance","saler","saler_dept"});
        tableHeader.setTexts(new String[]{"ID","公司名称","证件类型","证件号码","企业类型","账户类型", "开户行","账号","账户余额","客户经理","所属部门"});
        tableHeader.setTypes(new String[]{"int","","","","","","","","number","",""});
        tableHeader.setOptionTypes(new String[]{"","","business_lic_type","","company_role_type","account_use_type","","","","",""});
        
        Tool tool = new Tool();
        tool.setList(buildTools());
        
        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("account/accAccount/listData", "id", tableHeader,tool,search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 列表数据
     * @return
     * @throws Exception
     */
    @SuppressWarnings({"rawtypes" })
    @ResponseBody
    @RequestMapping(value="/listData",method=RequestMethod.POST)
    public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");

        QueryItem companyQuery=QueryItem.builder().field("id").where(Where.in("company_role_type", new Integer[]{CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex(),
        		CompanyRoleType.COMPANY_CORE.getIndex(),CompanyRoleType.COMPANY_CREDIT.getIndex()
        }))//.page(queryItem.getPage()).limit(queryItem.getLimit())
        		.build();
		if (StringUtils.isNotBlank(search)) {
			companyQuery.setWhere(Where.likeAll("company_name", search));
		}
        List<Map> idMapList=this.getListByMap(companyQuery, SCModule.SYSTEM,SCFunction.SYS_COMPANY);
        List idList=Lists.newArrayList();
        for(Map item:idMapList){
        	idList.add(item.get("id"));
        }
        if(idList.size()>0)
        	queryItem.setWhere(Where.in("company_id",idList));
        queryItem.setOrders("create_time desc");
        Page<Map> pageData=getPageByMap(queryItem, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT);
        this.idToName(pageData.getItems(), SCModule.SYSTEM,SCFunction.SYS_COMPANY, "company_id:saler_id,company_name,business_lic_type,company_role_type,business_lic_no");
        this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "saler_id:real_name as saler,dept_name as saler_dept");
        return createSuccessJsonResonse(pageData);
    }
    
    /**
     * 编辑新增页面
     * @return
     * @throws Exception
     */
//    @RequestMapping(value="/add",method=RequestMethod.GET)
//    public ModelAndView add() throws Exception {        
//        List<FormField> formFieldList = buidFormField(null);        
//        Map<String, Object> data = PageUtil.createFormPageStructure("account/accAccount/save", formFieldList);
//        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
//    }

    private List<FormField> buidFormField(Long id,Integer companyRoleType) {
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("companyName").text("企业名称").type("span").build());
        formFieldList.add(FormField.builder().name("companyRoleType").text("企业类型").type("span").build());
        formFieldList.add(FormField.builder().name("accountUseTypeName").text("账号类型").type("span").build());
        formFieldList.add(FormField.builder().name("openBank").text("开户行").type("input").build());
        formFieldList.add(FormField.builder().name("account").text("账号").type("input").build());
        return formFieldList;
    }
    
//    /**
//     * 保存
//     * @return
//     * @throws Exception
//     */
//    @ResponseBody
//    @RequestMapping(value="/save",method=RequestMethod.POST)
//    public DyResponse save(AccAccount accAccount) throws Exception {
//        //不能添加多个账号
//        
//        this.insert(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, accAccount);
//        return createSuccessJsonResonse(null,"添加成功");
//    }
    
    /**
     * 编辑更新页面
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/edit")
    public ModelAndView edit(Long id) throws Exception {
        AccAccount account=this.getById(id, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT,AccAccount.class);
        QueryItem queryItem=QueryItem.builder().field("company_name companyName,company_role_type company_role_type").where("id", account.getCompanyId()).build();
        Map<String,Object> formData=this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        formData.put("id", account.getId());
        formData.put("companyId", account.getCompanyId());
        formData.put("openBank", account.getOpenBank());
        formData.put("account", account.getAccount());
        Integer companyRoleType=MapUtils.getInteger(formData, "company_role_type");
        Integer accountUseType=null;
        if(companyRoleType==CompanyRoleType.COMPANY_CORE.getIndex()){
            accountUseType=AccountUseType.REPAY_ACCOUNT.getIndex();
        }else{
            accountUseType=AccountUseType.SETTLE_ACCOUNT.getIndex();
        }
        formData.put("accountUseType", accountUseType);
        formData.put("accountUseTypeName", DictUtils.getDictLabel(accountUseType, "account_use_type"));
        formData.put("companyRoleType", DictUtils.getDictLabel(companyRoleType, "company_role_type"));
        
        List<FormField> formFieldList = buidFormField(id,companyRoleType);      
        Map<String, Object> data = PageUtil.createFormPageStructure("account/accAccount/update", formFieldList,formData);        
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 更新
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/update",method=RequestMethod.POST)
    public DyResponse update(AccAccount accAccount) throws Exception {
        //校验
        this.update(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, accAccount);
        return createSuccessJsonResonse(null,"修改成功");
    }
    
    /**
     * 删除
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/delete",method=RequestMethod.POST)
    public DyResponse delete(Long id) throws Exception {
        //至少保留一个账号
        AccAccount accAccount=this.getById(id, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT,AccAccount.class);
        if(accAccount!=null){
            //this.deleteById(id,SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT);
        }
        return createSuccessJsonResonse(null,"删除成功");
    }
}
