
/**
 * Copyright cuiwm
 */
package com.dy.sc.admin.controller.loan;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.*;
import com.dy.ia.entity.common.SysDocument;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.bussmodule.utils.CommonLoanUtil;
import com.dy.sc.entity.agpur.AgpurSpa;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.ProdBusinessTypeEnum;
import com.dy.sc.entity.enumeration.SignStatusEnum;
import com.dy.sc.entity.loan.LoanDebitRecord;
import com.dy.sc.entity.loan.LoanProtocol;
import com.dy.sc.entity.loan.LoanRequest;
import com.dy.sc.entity.product.ProdBusinessType;
import com.dy.sc.entity.product.ProdProductInfo;
import com.dy.sc.entity.system.SysSignConfig;
import com.dy.sc.entity.warehouse.WarehousePledge;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 合同协议生成信息
 *
 * @author cuiwm
 */
@Controller
@RequestMapping(value = "loan/protocol")
public class LoanProtocolController extends AdminBaseController {
    @Autowired
    private FDDUtils utils;
    @Value("${MAIN_URL}")
    private String mainUrl;

    @Override
    protected DateFormatType getDateFormatType() {
        return DateFormatType.DATETIME;
    }

    @Autowired
    private CommonBussUtil bussUtil;

    /**
     * 构建列表结构:合同协议生成信息
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list/{type}")
    public ModelAndView list(@PathVariable("type") Integer type) throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "file_name", "loan_contract_no", "company_name", "sign_time_back:datetime", "product_name", "sign_status_back", "type"});
        tableHeader.setTexts(new String[]{"ID", "协议名称", "信贷合同号", "企业名称:credit_com", "签章时间", "产品名称:sc_product", "状态:sign_status", "操作"});
        tableHeader.setFilters(new String[]{"", "", "input", "select", "", "select", "select", ""});
        tableHeader.setTypes(new String[]{"", "", "", "", "", "", "", "action"});
        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"loan_contract_no"});
        search.setTexts(new String[]{"模板内容"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("loan/protocol/listData/" + type, "id", tableHeader, tool, search);

        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取列表数据:合同协议生成信息
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("listData/{type}")
    public DyResponse getListData(Integer page, Integer limit, String search, Long product_name, Long company_name, String loan_contract_no,
                                  Integer sign_status_back, @PathVariable("type") Integer type) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,loan_id,company_id,business_type,protocol_type,last_did,create_time,sign_time_back,loan_contract_no,company_id,product_id,sign_status_back");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("loan_id", search));
        }
        if (StringUtils.isNotBlank(loan_contract_no)) {
            queryItem.setWhere(Where.likeAll("loan_contract_no", loan_contract_no));
        }
        if (product_name != null) {
            queryItem.setWhere(Where.in("product_id", bussUtil.getProductIds(product_name)));
        }
        if (company_name != null) {
            queryItem.setWhere(Where.eq("company_id", company_name));
        }
        if (sign_status_back != null) {
            queryItem.setWhere(Where.eq("sign_status_back", sign_status_back));
        }
        // 其他过滤条件
        if (type != 99) {
            queryItem.getWhere().add(Where.eq("business_type", type));
        }
        queryItem.setOrders("sign_status_back asc,create_time desc");
        Page<Map> pagem = getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_PROTOCOL);
        this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, "last_did:file_path as url,file_name"); // 关联转换
        this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
        this.idToName(pagem.getItems(), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "product_id:name as product_name");
        this.dataConvert(pagem.getItems(), "", "sign_time_back");
        for (Map item : pagem.getItems()) {
            Integer s1 = Integer.parseInt(item.get("sign_status_back").toString());
            if (s1 == ScConstants.PROTOCOL_STATUS_UNSIGNED || s1 == ScConstants.PROTOCOL_STATUS_FAILURE) {
                item.put("type", "重新签署");
                String loanContractNo = "";
                if (item.get("loan_contract_no") == null) {
                    LoanDebitRecord record = CommonLoanUtil.getDebitByLoanId(item.get("loan_id"), item.get("business_type"), "loan_contract_no");
                    if (record != null) {
                        loanContractNo = record.getLoanContractNo();
                    }
                } else {
                    loanContractNo = item.get("loan_contract_no").toString();
                }
                item.put("loan_contract_no", loanContractNo);
                item.put("url_", "loan/protocol/reSign");
                item.put("action", "confirm");
            } else if (s1 == ScConstants.PROTOCOL_STATUS_SIGNED || s1 == ScConstants.PROTOCOL_STATUS_SUCCESS) {
                SysDocument document = this.getById(item.get("last_did").toString(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
                item.put("type", "查看");
                item.put("url_", document.getFilePath());
                item.put("action", "url");
            }
        }
        return createSuccessJsonResonse(pagem);
    }

    @RequestMapping("reSign")
    @ResponseBody
    public DyResponse reSign(Long id) throws Exception {
        String rlt = utils.doSignBackground(id);
        if ("success".equals(rlt)) {
            return createSuccessJsonResonse(null, "重新签署成功");
        } else {
            return createErrorJsonResonse("重新签署失败");
        }

    }

    @RequestMapping("notify/{businessType}")
    @ResponseBody
    public DyResponse signNotify(Long id, Integer protocolType, String result_code, String downloan_url, String viewpdf_url,
                                 @PathVariable("businessType") Integer businessType, Long protocolId) throws Exception {
        DyResponse response = new DyResponse();
        response.setStatus(200);
        notifySync(id, protocolType, result_code, downloan_url, viewpdf_url, businessType, protocolId);
        return response;
    }

    @RequestMapping("tmp/{businessType}")
    public ModelAndView tmpPage(Long id, Integer protocolType, String result_code, String download_url, String viewpdf_url, @PathVariable("businessType") Integer businessType, Long protocolId) throws Exception {
        DyResponse response = new DyResponse();
        response.setStatus(200);
        notifySync(id, protocolType, result_code, download_url, viewpdf_url, businessType, protocolId);
        return new ModelAndView("loan/tmp");
    }

    public void notifySync(Long id, Integer protocolType, String result_code, String downloan_url, String viewpdf_url, Integer businessType, Long protocolId) throws Exception {
        utils.notifySync(id, protocolType, result_code, downloan_url, viewpdf_url, businessType, protocolId);
    }

    /**
     * 到添加界面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toAdd")
    public ModelAndView toAdd() throws Exception {

        List<FormField> formFieldList = buidFormField();

        Map<String, Object> data = PageUtil.createFormPageStructure("loan/protocol/save", formFieldList);

        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    private List<FormField> buidFormField() {
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("loanId").text("融资合同id").verify("required").build());
//		formFieldList.add(FormField.builder().name("detailId").text("转让ID/信贷ID").verify("required").build());
        formFieldList.add(FormField.builder().name("protocolType").text("协议类型").type("select").options("protocol_type").verify("required").build());

        return formFieldList;
    }

    /**
     * 保存
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "save")
    public DyResponse save(LoanProtocol loanProtocol) throws Exception {
//		createPdfContract(loanProtocol.getLoanId(), loanProtocol.getProtocolType(),ScConstants.CONTRACT_TYPE_RECEIVE);

        return createSuccessJsonResonse(null, "添加成功");
    }


    /**
     * 删除
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "delete")
    public DyResponse delete(Long id) throws Exception {
        DyResponse dyResponse = this.deleteById(id, SCModule.LOAN, SCFunction.LOAN_PROTOCOL);
        if (dyResponse.isOK()) {
            return createSuccessJsonResonse(null, "删除成功");
        } else {
            return dyResponse;
        }
    }

    @RequestMapping("system/list")
    public ModelAndView listSystem() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "type", "url", "key", "name", "update_time"});
        tableHeader.setTexts(new String[]{"ID", "接口类型", "api地址", "key", "最后修改人", "最后修改时间"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());
        Search search = new Search();
        search.setNames(new String[]{"type"});
        search.setTexts(new String[]{"接口类型"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("loan/protocol/system/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    @ResponseBody
    @RequestMapping("system/listData")
    public DyResponse getSystemListData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("type", search));
        }
        queryItem.setOrders("create_time desc");
        Page<Map> rlt = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_SIGN_CONFIG);
        this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "update_uid:real_name as name");
        return createSuccessJsonResonse(dataConvert(rlt, "status", "update_time"));
    }

    /**
     * 新增页面
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "system/add")
    public ModelAndView add() throws Exception {
        List<FormField> formFieldList = Lists.newArrayList();

        formFieldList.add(FormField.builder().name("type").text("接口类型").verify("required").build());
        formFieldList.add(FormField.builder().name("url").text("api地址").verify("required").build());
        formFieldList.add(FormField.builder().name("key").text("key").verify("required").build());

        Map<String, Object> data = PageUtil.createFormPageStructure("loan/protocol/system/addData", formFieldList);
        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    /**
     * 新增
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "system/addData", method = RequestMethod.POST)
    public DyResponse save(SysSignConfig sign) throws Exception {
        this.insert(SCModule.SYSTEM, SCFunction.SYS_SIGN_CONFIG, sign);
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 编辑页面
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "system/edit")
    public ModelAndView edit(Long id) throws Exception {
        List<FormField> formFieldList = Lists.newArrayList();

        formFieldList.add(FormField.builder().name("type").text("接口类型").verify("required").build());
        formFieldList.add(FormField.builder().name("url").text("api地址").verify("required").build());
        formFieldList.add(FormField.builder().name("key").text("appkey").verify("required").build());

        SysSignConfig sign = this.getById(id, SCModule.SYSTEM, SCFunction.SYS_SIGN_CONFIG, SysSignConfig.class);

        Map<String, Object> data = PageUtil.createFormPageStructure("loan/protocol/system/update", formFieldList, sign);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "system/update", method = RequestMethod.POST)
    public DyResponse update(SysSignConfig sign) throws Exception {
        this.update(SCModule.SYSTEM, SCFunction.SYS_SIGN_CONFIG, sign);
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 删除
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "system/delete", method = RequestMethod.POST)
    public DyResponse deleteSystem(Long id) throws Exception {
        if (id != null) {
            this.deleteById(id, SCModule.SYSTEM, SCFunction.SYS_SIGN_CONFIG);
        }
        return createSuccessJsonResonse(null, "删除成功");
    }

    @RequestMapping("list1")
    public ModelAndView list1() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"loan_contract_no", "buss_no", "business_type_id", "product_name", "file_name", "sign_node", "sign_type1", "sign_status", "real_name", "create_time", "type1", "type"});
        tableHeader.setTexts(new String[]{"信贷合同号", "业务编号", "业务类型", "产品名称:sc_product", "合同名称", "签署节点", "签署方式:sign_type_1", "签署状态:sign_status", "创建人", "创建时间", "操作", "操作"});
//		tableHeader.setFilters(new String[]{"", "", "input", "select", "", "select", "select", "", "", ""});
        tableHeader.setTypes(new String[]{"", "", "", "", "", "", "", "", "", "", "action1", "action"});
        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"loan_contract_no"});
        search.setTexts(new String[]{"信贷合同号"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("loan/protocol/listData1", "id", tableHeader, tool, search);

        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取列表数据:合同协议生成信息
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("listData1")
    public DyResponse getListData1(Integer page, Integer limit, String search, Long product_name, Long company_name, String loan_contract_no,
                                   Integer sign_status_back) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,loan_id,product_id,company_id,paper_id,sign_status,sign_node,sign_type1,create_uid,sign_target,business_type,protocol_type,last_did,create_time,sign_time,loan_contract_no,company_id,product_id");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("loan_contract_no", search));
        }
        if (StringUtils.isNotBlank(loan_contract_no)) {
            queryItem.setWhere(Where.likeAll("loan_contract_no", loan_contract_no));
        }
        if (product_name != null) {
            queryItem.setWhere(Where.in("product_id", bussUtil.getProductIds(product_name)));
        }
        if (company_name != null) {
            queryItem.setWhere(Where.eq("company_id", company_name));
        }
        if (sign_status_back != null) {
            queryItem.setWhere(Where.eq("sign_status", sign_status_back));
        }
        queryItem.setWhere(Where.le("business_type", ScConstants.CONTRACT_TYPE_AGPUR));
        queryItem.setOrders("sign_status asc,create_time desc");
        Page<Map> pagem = getPageByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_PROTOCOL);
        this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, "last_did:file_path as url,file_name"); // 关联转换
        this.idToName(pagem.getItems(), SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, "business_type:name as business_type_id");
        this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name");
        this.idToName(pagem.getItems(), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "product_id:name as product_name");
        this.dataConvert(pagem.getItems(), "", "sign_time,create_time");
        for (Map item : pagem.getItems()) {
            if(item.get("product_id") == null)continue;
            ProdProductInfo productInfo = this.getById(item.get("product_id").toString(), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
            Integer businessType = productInfo.getBusinessTypeId();
            Long loanId = Long.valueOf(item.get("loan_id").toString());
            if(businessType == ProdBusinessTypeEnum.RECEIVE_BILL.getIndex()){
                LoanRequest request = this.getById(loanId, SCModule.LOAN, SCFunction.LOAN_REQUEST, LoanRequest.class);
                if(request == null) continue;
                item.put("buss_no", request.getPledgeContractNo());
            }else if(businessType == ProdBusinessTypeEnum.B2B.getIndex()){
                LoanDebitRecord record = this.getById(loanId, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, LoanDebitRecord.class);
                LoanRequest request = this.getById(record.getLoanId(), SCModule.LOAN, SCFunction.LOAN_REQUEST, LoanRequest.class);
                if(record == null) continue;
                item.put("buss_no", request.getPledgeContractNo());
            }else if(businessType == ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex()){
                WarehousePledge pledge = this.getById(loanId, SCModule.WAREHOUSE, SCFunction.WAREHOUSE_PLEDGE, WarehousePledge.class);
                if(pledge == null) continue;
                item.put("buss_no", pledge.getPledgeNo());
            }else if(businessType == ProdBusinessTypeEnum.AGENTPUR.getIndex()){
                AgpurSpa spa = this.getById(loanId, SCModule.AGPUR, SCFunction.SPA, AgpurSpa.class);
                if(spa == null) continue;
                item.put("buss_no", spa.getPledgeNo());
            }
            if (item.get("sign_node") != null) {
                item.put("sign_node", bussUtil.getSignNodeName(Integer.valueOf(item.get("sign_node").toString()), Integer.valueOf(item.get("business_type").toString())));
            }
            if (item.get("sign_type1") != null) {
                if (Integer.parseInt(item.get("sign_type1").toString()) == 1) {
//					item.put("type", "查看电子协议");
//					SysDocument document = this.getById(item.get("last_did").toString(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
//					item.put("url_", document.getFilePath());
//					item.put("action", "url");
                } else {
                    item.put("type", "查看纸质合同附件");
                    if (item.get("paper_id") != null) {
                        SysDocument document = this.getById(item.get("paper_id").toString(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
                        item.put("url_", document.getFilePath());
                        item.put("action", "url");
                    }
                }
                item.put("type1", "查看");
                SysDocument document = this.getById(item.get("last_did").toString(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
                item.put("url1_", document.getFilePath());
                item.put("action1", "url1");
            }
        }
        return createSuccessJsonResonse(pagem);
    }

    @RequestMapping(value = "uploadPaperProtocol")
    public ModelAndView uploadPaperProtocol(Long id) throws Exception {
        Map<String, Object> formData = Maps.newHashMap();
        Map<String, Object> formStruct = Maps.newHashMap();
        LoanProtocol protocol = this.getById(id, SCModule.LOAN, SCFunction.LOAN_PROTOCOL, LoanProtocol.class);
        List<Map> pros = Lists.newArrayList();

        Map map = Maps.newHashMap();
        map.put("id", protocol.getId());
        map.put("fileName", this.getById(protocol.getLastDid(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class).getFileName());
        map.put("signType1", DictUtils.getDictLabel(protocol.getSignType1(), "sign_type_1"));
        map.put("signStatus", DictUtils.getDictLabel(protocol.getSignStatusBack(), "sign_status"));
        if (protocol.getPaperId() != null) {
            Map file = Maps.newHashMap();
            SysDocument document = this.getById(protocol.getPaperId(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
            file.put("name", document.getFileName());
            file.put("format", document.getType());
            file.put("time", DateUtil.dateFormat(document.getCreateTime()));
            file.put("url", document.getFilePath());
            file.put("did", document.getId());
            map.put("import_file", file);
        }
        pros.add(map);

        formData.put("data", pros);
        Map<String, Object> rlt = new HashMap<String, Object>();
        rlt.put("form_data", formData);
        rlt.put("form_struct", formStruct);
        rlt.put("submit_url", "loan/protocol/upload/" + id);// 提交
        return createSuccessModelAndView("loan/uploadProtocol", JsonUtils.object2JsonString(rlt));
    }

    @ResponseBody
    @RequestMapping(value = "upload/{id}", method = RequestMethod.POST)
    public DyResponse upload(@PathVariable("id") Long id, String params) throws Exception {
        LoanProtocol pro = this.getById(id, SCModule.LOAN, SCFunction.LOAN_PROTOCOL, LoanProtocol.class);
        if (ScConstants.SIGN_TYPE_ELEC == pro.getSignType1()) {
            return createErrorJsonResonse("电子签署不能上传附件");
        }
        if (StringUtils.isBlank(params)) {
            return createErrorJsonResonse("请上传附件");
        }
        String[] p = params.split(",");
        for (String str : p) {
            String[] ids = str.split(":");
            Long protocolId = Long.valueOf(ids[0]);
            Long docId = Long.valueOf(ids[1]);
            LoanProtocol protocol = this.getById(protocolId, SCModule.LOAN, SCFunction.LOAN_PROTOCOL, LoanProtocol.class);
            protocol.setSignStatusBack(SignStatusEnum.SIGNED.getIndex());
            protocol.setPaperId(docId);
            this.update(SCModule.LOAN, SCFunction.LOAN_PROTOCOL, protocol);
        }
        return createSuccessJsonResonse(null, "上传成功");
    }

    @ResponseBody
    @RequestMapping(value = "delPaperProtocol", method = RequestMethod.POST)
    public DyResponse del(Long id) throws Exception {
        LoanProtocol protocol = this.getById(id, SCModule.LOAN, SCFunction.LOAN_PROTOCOL, LoanProtocol.class);
        if (protocol.getPaperId() == null) {
            return createErrorJsonResonse("没有附件无法删除");
        } else {
            protocol.setPaperId(null);
            protocol.setSignStatusBack(SignStatusEnum.UNSIGNED.getIndex());
            this.update(SCModule.LOAN, SCFunction.LOAN_PROTOCOL, protocol, true);
            return createSuccessJsonResonse(null, "删除成功");
        }
    }
}