package com.dy.sc.admin.controller;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.cz.IPSeeker;
import com.dy.core.dao.dml.DmlItem;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.NameValue;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DyHttpClient;
import com.dy.core.utils.IpUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PropertiesUtil;
import com.dy.core.utils.SecurityUtil;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.Role;
import com.dy.ia.entity.common.SysAdminLoginLog;
import com.dy.ia.entity.common.SysDocument;
import com.dy.ia.entity.enumeration.UploadValidation;
import com.dy.sc.entity.constant.AdminConstants;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Controller
public class CommonController extends AdminBaseController {
	
	protected Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
	
	@RequestMapping("/")
	public ModelAndView index(HttpServletRequest request,HttpServletResponse response) throws Exception {
		OrgUser user = getAdminUser();
		if(user == null) 
			return createSuccessModelAndView("redirect:system/public/login", null);
		
		// 防止后退后还能进入主页
		response.addHeader("Cache-Control", "no-store, no-cache, must-revalidate, post-check");
		Map<String,String> data = new HashMap<String,String>();
		data.put("username", user.getUsername());
		data.put("role", user.getRoleName());
		data.put("realName", user.getRealName());
		return createSuccessModelAndView("index/index", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 登陆校验
	 * @param username
	 * @param password
	 * @param valicode
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/common/index/checkLogin")
	public DyResponse verifyLogin(String username, String password, String valicode) throws Exception {
		
		//非空校验
		String errorMsg = validateNull(new Object[]{username, password, valicode}, new String[3], new String[]{"用户名", "密码", "验证码"});
		if(StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
		
		//验证码校验
		this.checkVerifyCode(valicode);
		
		//用户名、密码校验	
		QueryItem queryItem = new QueryItem(new Where("username", username));
		//queryItem.setWhere(Where.eq("type", 1));
//		queryItem.setFields("id,role,username,real_name as realName,role_name as roleName,password,phone,email,status,lastlogin_time as lastloginTime,dept_id as deptId,dept_name as deptName,superior_depart");
		OrgUser user = this.getOneByEntity(queryItem, Module.SYSTEM, Function.SYS_ADMIN, OrgUser.class);
		if(user == null ){
			return createErrorJsonResonse(this.getMessage("system.userNamePasswordError"));
		}
		//判断管理员状态
		if(user.getStatus().toString().equalsIgnoreCase("0")){
			return createErrorJsonResonse(this.getMessage("system.errorStatus"));
		}
		String encryptPassword = "";
		if(user != null) encryptPassword = SecurityUtil.md5(SecurityUtil.sha1(password));
		if(user == null || !encryptPassword.equals(user.getPassword()))
			return createErrorJsonResonse(this.getMessage("system.userNamePasswordError"));

		//把用户信息加入session
		this.setSessionAtrribute(Constant.SESSION_USER, user);
		
		//session加入权限，可以访问的路径
		Set<String> roles = Sets.newHashSet();
		QueryItem query = new QueryItem(Where.in("id", user.getRole()));
		query.setFields("auth");
		List<Role> roleList = this.getListByEntity(query , Module.SYSTEM, Function.SYS_ROLE, Role.class);
		for(Role role : roleList){
			if(role!=null&&StringUtils.isNotBlank(role.getAuth())){
				roles.addAll(Arrays.asList(role.getAuth().split(",")));
			}
		}
		QueryItem q = new QueryItem(Where.notIn("id", roles));
		q.setFields("id,url");
		List<Map> menus = this.getListByMap(q , Module.SYSTEM, Function.SYS_MENU);
				
		List<String> unauth = Lists.newArrayList();
		for(Map menu : menus){
			if(menu.get("url")!=null&&StringUtils.isNotBlank(menu.get("url").toString())){
				if(!unauth.contains(menu.get("url").toString())){
					unauth.add((String) menu.get("url"));
				}
			}
		}
		
		//有权限的url不过虑
		QueryItem authsQuery = new QueryItem(Where.in("id", roles));
		authsQuery.setFields("id,url");
		List<Map> auths = this.getListByMap(authsQuery , Module.SYSTEM, Function.SYS_MENU);
		List<String> authLst = Lists.newArrayList();
		for(Map menu : auths){
			if(menu.get("url")!=null&&StringUtils.isNotBlank(menu.get("url").toString())){
				if(!authLst.contains(menu.get("url").toString())){
					authLst.add((String) menu.get("url"));
				}
			}
		}
		//有权限的url从不允许访问里排除
		for(String url:authLst){
			if(unauth.contains(url)){
				unauth.remove(url);
			}
		}
		this.setSessionAtrribute(AdminConstants.USER_RIGHT_NO, unauth);
		this.setSessionAtrribute(AdminConstants.USER_RIGHT_IDS, roles);
		
		
		//加入Shiro身份验证
		Subject subject = SecurityUtils.getSubject(); 
	    UsernamePasswordToken token = new UsernamePasswordToken(username, password); 
	    try { 
	        subject.login(token); 
	    } catch (AuthenticationException e) {
	    	logger.error("shiro 登录异常",e);
	    }
	    
	    //更新登信息
		List<NameValue> params = new ArrayList<NameValue>();
		params.add(new NameValue("lastlogin_ip", this.getRemoteIp()));
		params.add(new NameValue("lastlogin_time", DateUtil.getCurrentTime()));
		params.add(NameValue.setExpression("count", "count + 1"));
		
		DmlItem dmlItem = new DmlItem();
	    dmlItem.setId(user.getId());
		dmlItem.setParams(params);
		this.update(Module.SYSTEM, Function.SYS_ADMIN, dmlItem);
		
		String ip = this.getRemoteIp();
		SysAdminLoginLog loginLog = new SysAdminLoginLog();
		loginLog.setAdminId(user.getId());
		loginLog.setAdminName(user.getUsername());
		loginLog.setAddTime(DateUtil.getCurrentTime());
		loginLog.setAddIp(IpUtil.ipStrToLong(ip));
		loginLog.setAddDate(new Date());
		loginLog.setAddr(IPSeeker.getInstance().getAddress(ip));
		loginLog.setStatus(1);
		this.insert(Module.SYSTEM, Function.SYS_LOGINLOG, loginLog);
	    
		return createSuccessJsonResonse(null,"登录成功");
	}
	
	/**
	 * 文件上传
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="common/fileupload/{module}/{function}", method=RequestMethod.POST)
	public DyResponse fileUpload(MultipartFile upload, @PathVariable("module")String module, @PathVariable("function")String function) throws Exception {
		DyResponse response = new DyResponse();
		String fileName = upload.getOriginalFilename();
		InputStream stream = upload.getInputStream();
		try {
			
			//上传内容校验
			String errorMsg = validateUploadContent(module, function, fileName, upload.getSize());;
			if(StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
			
			response = DyHttpClient.doImageUpload(module, function, fileName, stream);
			if(response != null && response.getStatus() == DyResponse.OK) {
				Map<String, Object> map = (Map<String, Object>) response.getData();
				String fileUrl = map.get("fileurl").toString();
				Map<String, Object> fileData=Maps.newHashMap();
				fileData.put("file_url", fileUrl);
				fileData.put("url", PropertiesUtil.getImageHost() + fileUrl);
				fileData.put("code", response.getStatus());
				fileData.put("size", upload.getSize());
				fileData.put("time", DateUtil.dateFormat(new Date()));
				fileData.put("name", fileName.substring(0, fileName.lastIndexOf(".")));
				fileData.put("format", fileName.substring(fileName.lastIndexOf("."), fileName.length()));
				map.put("Filedata", fileData);				
				response.setData(map);
				
				if(!"ueditor".equals(module)){
					// 保存文档表
					SysDocument document = new SysDocument();
					document.setFileName(fileName);
					document.setFilePath((String) fileData.get("url"));
					int ind = fileName.indexOf('.');
					if(ind > 0){
						document.setType(fileName.substring(ind));
					}
					document.setFileSize(upload.getSize());
					document.setRemarks(module + "_" + function);
					UploadValidation uploadValidation = UploadValidation.valueOf(module + "_" + function);
					document.setCreateUname(getUser().getRealName());
					document.setDocType(uploadValidation.getDocType());
					document.setCreateUname(getUser().getRealName());
					this.insert(SCModule.SYSTEM,SCFunction.SYS_DOCUMENT, document);
					map.put("did",document.getId());
				}else{
					map.put("upload", PropertiesUtil.getImageHost() + fileUrl);
				}
			}
		} catch (Exception e) {
			logger.error("File upload error:", e);
			response.setStatus(DyResponse.ERROR);
			response.setDescription(e.getMessage());
		}
		
		return response;
	}

	/**
	 * 上传内容校验
	 * @param module 模块名
	 * @param function 功能点
	 * @param fileName 上传文件名
	 * @param fileSize 上传文件大小
	 * @return
	 */
	private String validateUploadContent(String module, String function, String fileName, long fileSize) {
		if(StringUtils.isEmpty(fileName) || fileSize <= 0) return null;
		
		//根据moudle_function获取验证规则
		UploadValidation uploadValidation = null;
		try {
			uploadValidation = UploadValidation.valueOf(module + "_" + function);
			
			//文件类型验证
			String fileType = fileName.substring(fileName.lastIndexOf("."));
			if(!uploadValidation.getFileType().contains(fileType)) {
				return getMessage("validate.upload.wrongtype", new String[]{uploadValidation.getFileType().replace(".", "")});
			}
			
			//文件大小验证
			if(uploadValidation.getFileSize() < fileSize) {
				return getMessage("validate.upload.wrongsize", new Long[]{(uploadValidation.getFileSize()/1024/1024)});
			}
		} catch (Exception e) {
		}
		
		return null;
	}
	
	/**
	 * 获取文件地址
	 * @return
	 * @throws Exception 
	 */
	@ResponseBody
	@RequestMapping(value="common/document")
	public DyResponse getDocUrl(String did) throws Exception {
		if(StringUtils.isNotBlank(did)){
			QueryItem queryItem = new QueryItem(Where.in("id", did));
			queryItem.setFields("id,file_path,file_name,remarks");
			List<Map> list = this.getListByMap(queryItem, Module.SYSTEM,Function.SYS_DOCUMENT);
			return createSuccessJsonResonse(list);
		}
		return createErrorJsonResonse("请求参数为空");
	}
	
	/**
	 * 附件页面
	 * @return
	 * @throws Exception 
	 */
	@ResponseBody
	@RequestMapping(value="common/documentView")
	public ModelAndView documentView(String did) throws Exception {
		if(StringUtils.isNotBlank(did)){
			QueryItem queryItem = new QueryItem(Where.in("id", did));
			queryItem.setFields("id,file_path,file_name,remarks");
			List<Map> list = this.getListByMap(queryItem, Module.SYSTEM,Function.SYS_DOCUMENT);
			return createSuccessModelAndView("", list);
		}
		return createErrorModelAndView("请求参数为空");
	}
	
	/**
	 * 前端测试，生产关闭
	 * @param request
	 * @param page
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/templates/{page}")
	public ModelAndView toPage(HttpServletRequest request,@PathVariable("page") String page) throws Exception {
		return createSuccessModelAndView(page,null);
	}
	
	/**
	 * 测试调用
	 * @param request
	 * @param page
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/test/{action}")
	@ResponseBody
	public DyResponse test(HttpServletRequest request,@PathVariable("action") String action) throws Exception {
		
		if(action.equals("pdf")){
			// 生成pdf
//			createPdfContract(loan, loanId, protocolType);
		}
		
		return createSuccessJsonResonse(null);
	}
	
	@RequestMapping(value="/common/domain", method=RequestMethod.GET)
	public ModelAndView toDomainAuthorize() {
		ModelAndView modelAndView = createSuccessModelAndView("error",null);
		modelAndView.addObject("error", "域名授权过期或无效");
		return modelAndView;
	}

	@RequestMapping(value="/common/test", method=RequestMethod.GET)
	@ResponseBody
    public DyResponse test() {
        String active=System.getProperty("spring.profiles.active");
        return createSuccessJsonResonse("结果:"+active, "ok");
    }
	
	@RequestMapping(value="/common/noaccess", method=RequestMethod.GET)
	public ModelAndView accessError() {
		ModelAndView modelAndView = createSuccessModelAndView("error",null);
		modelAndView.addObject("error", "您无权访问该资源");
		return modelAndView;
	}
}