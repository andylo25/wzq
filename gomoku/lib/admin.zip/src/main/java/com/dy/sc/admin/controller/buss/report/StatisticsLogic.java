package com.dy.sc.admin.controller.buss.report;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.dy.core.controller.BaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.utils.DateUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Component
public class StatisticsLogic {
	
	static final int action_1 = 1; // 应回
	static final int action_2 = 2; // 实回
	static final int action_3 = 3; // 逾期待回
	static final int action_4 = 4; // 逾期已回
	
	/**
	 * 统计当月业务员信贷信息
	 * @param id
	 * @param baseController
	 * @return
	 * @throws Exception 
	 */
	public Map<String,Object> statisCustCurMonth(Date start,Date end,Long id ,BaseController baseController) throws Exception{
		Map<String, Object> map = Maps.newHashMap();
		// 新增客户
		Map<String, Object> cust = getCust(start, end, id,ScConstants.REP_TYPE_SALER, baseController);
		map.putAll(cust);
		
		// 新增贷款
		Map<String, Object> create = getCreate(start, end, id,ScConstants.REP_TYPE_SALER, baseController);
		map.putAll(create);
		
		// 应回
		Map<String, Object> repay = getRepay(start, end, id,action_1,ScConstants.REP_TYPE_SALER, baseController);
		map.put("toback_count",repay.get("loan_count"));
		map.put("toback_amount",repay.get("loan_amount"));
		
		// 实回
		repay = getRepay(start, end, id,action_2,ScConstants.REP_TYPE_SALER, baseController);
		map.put("repay_count",repay.get("loan_count"));
		map.put("repay_amount",repay.get("loan_amount"));
		
		// 逾期待回
		repay = getRepay(start, end, id,action_3,ScConstants.REP_TYPE_SALER, baseController);
		map.put("overdue_no_count",repay.get("loan_count"));
		map.put("overdue_no_amount",repay.get("loan_amount"));
		
		// 逾期已回
		repay = getRepay(start, end, id,action_4,ScConstants.REP_TYPE_SALER, baseController);
		map.put("overdue_yes_count",repay.get("loan_count"));
		map.put("overdue_yes_amount",repay.get("loan_amount"));
		
		return map;
	}

	private Map<String, Object> getRepay(Date start, Date end, Long id,int type,int catogary, BaseController baseController) throws Exception {
		QueryItem queryItem = new QueryItem(Where.gt("principal", 0));
		getQuery(id, catogary, baseController, queryItem);
		switch (type) {
		case action_1:
			queryItem.setWhere(Where.between("repay_time", DateUtil.convert(start),DateUtil.convert(end)));
			break;
		case action_2:
			queryItem.setWhere(Where.between("repay_time_yes", DateUtil.convert(start),DateUtil.convert(end)));
			break;
		case action_3:
			queryItem.setWhere(Where.lt("repay_time", DateUtil.getDateTime(new Date(),-1)));
			queryItem.setWhere(Where.isNull("repay_time_yes"));
			break;
		case action_4:
			queryItem.setWhere(Where.between("repay_time_yes", DateUtil.convert(start),DateUtil.convert(end)));
			queryItem.setWhere(Where.expression("repay_time_yes > repay_time", false));
			break;

		default:
			break;
		}
		queryItem.setFields("count(id) as loan_count,sum(principal) as loan_amount");
		
		return baseController.getOneByMap(queryItem, SCModule.FUND,SCFunction.FUND_LOAN_REPAYPERIOD);
	}

	private Map<String, Object> getCust(Date start, Date end, Long id,int catogary, BaseController baseController) throws Exception {
		QueryItem queryItem = new QueryItem(Where.between("pass_time", DateUtil.convert(start),DateUtil.convert(end)));
		getQuery(id, catogary, baseController, queryItem);
		queryItem.setFields("count(id) as cust_count");
		return baseController.getOneByMap(queryItem, SCModule.SYSTEM,SCFunction.SYS_COMPANY);
	}

	private Map<String, Object> getCreate(Date start, Date end, Long id,int catogary, BaseController baseController)
			throws Exception {
		QueryItem queryItem = new QueryItem(Where.between("create_time", DateUtil.convert(start),DateUtil.convert(end)));
		getQuery(id, catogary, baseController, queryItem);
		queryItem.setFields("count(id) as loan_count,sum(principal_total) as loan_amount,sum(transfer_total) as pay_amount");
		
		return baseController.getOneByMap(queryItem, SCModule.FUND,SCFunction.FUND_LOAN_REPAY);
	}

	private void getQuery(Long id, int catogary, BaseController baseController, QueryItem queryItem) throws Exception {
		if(catogary == ScConstants.REP_TYPE_DEPT){
			queryItem.setWhere(Where.in("saler_id", getSalesId(id, baseController)));
		}else if(catogary == ScConstants.REP_TYPE_SALER){
			queryItem.setWhere(Where.eq("saler_id", id));
		}
	}

	/**
	 * 统计当月部门信贷信息
	 * @param deptId
	 * @param baseController
	 * @return
	 * @throws Exception 
	 */
	public Map<String,Object> statisDeptCurMonth(Date start,Date end,Long deptId,BaseController baseController) throws Exception {
		Map<String, Object> map = Maps.newHashMap();
		// 新增客户
		Map<String, Object> cust = getCust(start, end, deptId, ScConstants.REP_TYPE_DEPT, baseController);
		map.putAll(cust);
		
		// 新增贷款
		Map<String, Object> create = getCreate(start, end, deptId, ScConstants.REP_TYPE_DEPT, baseController);
		map.putAll(create);
		
		// 应回
		Map<String, Object> repay = getRepay(start, end, deptId,action_1, ScConstants.REP_TYPE_DEPT, baseController);
		map.put("toback_count",repay.get("loan_count"));
		map.put("toback_amount",repay.get("loan_amount"));
		
		// 实回
		repay = getRepay(start, end, deptId,action_2, ScConstants.REP_TYPE_DEPT, baseController);
		map.put("repay_count",repay.get("loan_count"));
		map.put("repay_amount",repay.get("loan_amount"));
		
		// 逾期待回
		repay = getRepay(start, end, deptId,action_3, ScConstants.REP_TYPE_DEPT, baseController);
		map.put("overdue_no_count",repay.get("loan_count"));
		map.put("overdue_no_amount",repay.get("loan_amount"));
		
		// 逾期已回
		repay = getRepay(start, end, deptId,action_4, ScConstants.REP_TYPE_DEPT, baseController);
		map.put("overdue_yes_count",repay.get("loan_count"));
		map.put("overdue_yes_amount",repay.get("loan_amount"));
		
		return map;
		
	}

	/**
	 * 统计当月平台信贷信息
	 * @param baseController
	 * @return
	 * @throws Exception 
	 */
	public Map<String,Object> statisPlatCurMonth(Date start,Date end,BaseController baseController) throws Exception {
		Map<String, Object> map = Maps.newHashMap();
		// 新增客户
		Map<String, Object> cust = getCust(start, end, null,ScConstants.REP_TYPE_PLAT, baseController);
		map.putAll(cust);
		
		// 新增贷款
		Map<String, Object> create = getCreate(start, end, null,ScConstants.REP_TYPE_PLAT, baseController);
		map.putAll(create);
		
		// 应回
		Map<String, Object> repay = getRepay(start, end, null,action_1,ScConstants.REP_TYPE_PLAT, baseController);
		map.put("toback_count",repay.get("loan_count"));
		map.put("toback_amount",repay.get("loan_amount"));
		
		// 实回
		repay = getRepay(start, end, null,action_2,ScConstants.REP_TYPE_PLAT, baseController);
		map.put("repay_count",repay.get("loan_count"));
		map.put("repay_amount",repay.get("loan_amount"));
		
		// 逾期待回
		repay = getRepay(start, end, null,action_3,ScConstants.REP_TYPE_PLAT, baseController);
		map.put("overdue_no_count",repay.get("loan_count"));
		map.put("overdue_no_amount",repay.get("loan_amount"));
		
		// 逾期已回
		repay = getRepay(start, end, null,action_4,ScConstants.REP_TYPE_PLAT, baseController);
		map.put("overdue_yes_count",repay.get("loan_count"));
		map.put("overdue_yes_amount",repay.get("loan_amount"));
		
		return map;
	}
	
	/**
	 * 获取部门下属的业务员
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	private List<String> getSalesId(Long deptId,BaseController baseController) throws Exception {
		QueryItem queryItem = new QueryItem(Where.eq("dept_id",deptId));
		queryItem.setFields("id");
		List<Map> salers = (List<Map>) baseController.getListByMap(queryItem,SCModule.SYSTEM, SCFunction.SYS_ADMIN);
		
		List<String> ids = Lists.newArrayList();
		if(salers != null){
			for(Map s:salers){
				ids.add(s.get("id").toString());
			}
		}
		return ids;
	}
	
}
