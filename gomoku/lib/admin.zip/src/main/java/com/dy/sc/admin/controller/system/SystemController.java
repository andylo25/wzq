package com.dy.sc.admin.controller.system;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.dy.core.cache.SysCache;
import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.Condition;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.NameValue;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.common.SpringContextHolder;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.Role;
import com.dy.ia.entity.common.SysMenu;
import com.dy.ia.entity.enumeration.ReceiveBillStatusEnum;
import com.dy.sc.admin.controller.warehouse.WarehouseInspectController;
import com.dy.sc.admin.controller.warehouse.WarehouseReceiptController;
import com.dy.sc.bussmodule.utils.TodoUtils;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.AccountCheckResult;
import com.dy.sc.entity.enumeration.ArticleStatus;
import com.dy.sc.entity.enumeration.DelFlag;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/system")
public class SystemController extends AdminBaseController {
	
	@Autowired
	private SysCache sysCache;
	
	@Autowired
	private WarehouseReceiptController warehouseReceiptController;
	@Autowired
	private WarehouseInspectController warehouseInspectController;
	
	/**
	 * 首页(登陆：index 未登陆：login)
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/toIndex")
	public ModelAndView toIndex(HttpServletRequest request) throws Exception {
		//判断用户是否已经登陆过
		OrgUser user = (OrgUser)this.getSessionAttribute(Constant.SESSION_USER);
		if( user == null ) 
			return createSuccessModelAndView("system/public/login", null);
		
		return createSuccessModelAndView("system/index/index", JsonUtils.object2JsonString(user));
	}
	
	/**
	 * 进入首页
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/index/index")
	public ModelAndView index() throws Exception {
		Map<String,Object> data = Maps.newHashMap();
		Map<String,Object> formData = Maps.newHashMap();
		data.put("form_data", formData);
		// 获取本月授信情况
		getToDoList(formData);
		getMessageList(formData);
		
		formData.put("innerArticles", getArticleList("内部公告"));
		formData.put("companyArticles", getArticleList("公司制度"));
		
		return createSuccessModelAndView("common/index", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 
	 * 待办任务
	 * @param data
	 * @throws Exception
	 * @author likf
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void getToDoList(Map<String,Object> data) throws Exception{
	    OrgUser user=this.getAdminUser();
	    
	    QueryItem queryItem=new QueryItem();
	    queryItem.setFields("proc_def_id,max(create_time) as create_time,count(1) as cnt");
	    //TODO 多角色匹配有漏洞
	    
	    List and=new ArrayList();
	    NameValue nameValue=new NameValue("role_id", user.getRole()+",",Condition.LIKE_ALL , true);
	    and.add(nameValue);
	    nameValue=new NameValue("user_id", user.getId(),Condition.EQ , true);
	    and.add(nameValue);
		queryItem.setWhere(Where.setAndList(and));
//	    queryItem.setWhere("role_id", user.getRole()));
	    queryItem.setWhere(Where.eq("flow_status", AccConstants.FLOW_STATUS_APRVING));
	    //queryItem.setLimit(5);
	    queryItem.setGroup("proc_def_id");
	    List<Map> datas=this.getListByMap(queryItem, SCModule.FLOW, SCFunction.FLOW_PROC_INST);
	    this.idToName(datas, SCModule.FLOW, SCFunction.FLOW_PROC_DEF, "proc_def_id:proc_name as title,proc_key as key_name");
	    data.put("todos", datas);
	    int count=0;
        for(Map item:datas){
            count+=Integer.parseInt(item.get("cnt").toString());
        }
	    data.put("todos_count", count);
	}
	
	/**
	 * 
	 * 预警通知
	 * @param data
	 * @throws Exception
	 * @author likf
	 */
	@SuppressWarnings("unchecked")
    private void getMessageList(Map<String,Object> data) throws Exception{
        OrgUser user=this.getAdminUser();
        
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("count(1) as cnt");
        queryItem.setWhere(Where.eq("saler_uid", getUserId()));
        queryItem.setWhere(Where.between("bill_end_time",DateUtil.getCurrentTime(), DateUtil.addDay(DateUtil.getCurrentTime(), 7)));//到期日7天内的应收账款；调用账款状态为：已转让
        queryItem.setWhere(Where.eq("receive_bill_status", ReceiveBillStatusEnum.TRANSFERED.getIndex()));
        Map count1=this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_RECEIVE_BILL);
        
        queryItem = new QueryItem();
        queryItem.setFields("count(1) as cnt");
        queryItem.setWhere(Where.eq("saler_uid", getUserId()));
        queryItem.setWhere(Where.between("last_pay_time",DateUtil.getCurrentTime(),DateUtil.addDay(DateUtil.getCurrentTime(), 15)));//最迟付款日15内的应收账款
        queryItem.setWhere(Where.eq("receive_bill_status", ReceiveBillStatusEnum.TRANSFERED.getIndex()));
        Map count2=this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_RECEIVE_BILL);
        
        queryItem = new QueryItem();
        queryItem.setFields("count(1) as cnt");
        queryItem.setWhere(Where.eq("saler_uid", getUserId()));
        queryItem.setWhere(Where.le("last_pay_time", DateUtil.getCurrentTime()));//应收账款状态为：已转让， 且当前日期大于最迟付款日的 应收账款
        queryItem.setWhere(Where.eq("receive_bill_status", ReceiveBillStatusEnum.TRANSFERED.getIndex()));
        Map count3=this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_RECEIVE_BILL);

        List<Map> datas=Lists.newArrayList();
        Map item=Maps.newHashMap();
        item.put("title", "应收账款到期提醒");
        item.put("cnt", count1.get("cnt"));
        item.put("idx", 1);
        item.put("id", 10139);//菜单id
        datas.add(item);
        item=Maps.newHashMap();
        item.put("title", "应收账款催收提醒");
        item.put("cnt", count2.get("cnt"));
        item.put("idx", 2);
        item.put("id", 10141);//菜单id
        datas.add(item);
        item=Maps.newHashMap();
        item.put("title", "应收账款逾期预警");
        item.put("cnt", count3.get("cnt"));
        item.put("idx", 3);
        item.put("id", 10143);//菜单id
        datas.add(item);
        data.put("alerts", datas);
        int count=0;
        for(Map item1:datas){
            count+=Integer.parseInt(item1.get("cnt").toString());
        }
        data.put("alerts_count", count);
    }
	
	private String getArticleTypeIds(String articleType) throws Exception{
	    QueryItem queryItem=new QueryItem();
        queryItem.setFields("id");
        queryItem.setWhere(Where.eq("article_type", articleType));
        List<Map> ids=this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE);
        StringBuffer announceIds=new StringBuffer();
        if(ids!=null&&ids.size()>0){
            for(int i=0;i<ids.size();i++){
                announceIds.append(ids.get(i).get("id"));
                if(i!=ids.size()-1){
                    announceIds.append(",");
                }
            }
        }
        return announceIds.toString();
	}
	
	private List<Map> getArticleList(String articleType) throws Exception{
        OrgUser user=this.getAdminUser();
        
        QueryItem queryItem=new QueryItem();
        queryItem.setFields("id,name, create_time");
        queryItem.setWhere(Where.in("article_type_id", getArticleTypeIds(articleType)));
        queryItem.setWhere(Where.eq("article_status", ArticleStatus.RELEASE.getIndex()));
        queryItem.setWhere(Where.eq("del_flag",DelFlag.NOT_DELETE.getIndex()));
        queryItem.setLimit(8);
        queryItem.setOrders("on_top desc,id desc");
        return this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ARTICLE);
    }
	
	/**
	 * 账户金额变动情况 点击切换日周月
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/credit/view")
	public Map<String,Object> creditView(int type) throws Exception {
		Map<String,Object> data = Maps.newHashMap();
		Map<String,Object> formData = Maps.newHashMap();
		data.put("form_data", formData);

		
		return data;
	}
	
	
	
	
	/**
	 * 充值弹窗
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/index/torecharge")
	public ModelAndView toRecharge(Long id) throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		formFieldList.add(FormField.builder().name("id").value(id).type("hidden").build());
		formFieldList.add(FormField.builder().name("rechargeAmount").text("充值金额").remarks("元").verify("required").build());
		
		Map<String, Object> data = PageUtil.createFormPageStructure("capital/recharge/platRecharge", formFieldList);
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 初始加载页
	 * @return
	 */
	@RequestMapping("/index/main")
	public ModelAndView indexMain() {
		return createSuccessModelAndView("index/main",null);
	}
	
	/**
	 * 获取菜单树结构
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/menu/list")
	public ModelAndView getMenuList() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "name","url","icon","pid","status"});
		tableHeader.setTexts(new String[]{"ID", "菜单名称","菜单URL","图标","父ID","状态"});
		tableHeader.setTypes(new String[]{"int","", "","","",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
//		tool.setTexts(new String[]{"添加","编辑","删除"});
//		tool.setTitles(new String[]{"添加","编辑","删除"});
//		tool.setTypes(new String[]{"add","edit","del"});
//		tool.setUrls(new String[]{"system/menu/add","system/menu/edit","system/menu/delete"});
		
		Search search = new Search();
		search.setNames(new String[]{"name"});
		search.setTexts(new String[]{"菜单名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("system/menu/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取菜单树数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/menu/listData")
	public DyResponse getMenuListData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		if(StringUtils.isNotBlank(search)){
			if(search.matches("[0-9]+")){
				queryItem.setWhere(Where.eq("id", search));
				queryItem.setWhere((Where) Where.eq("pid", search).setOr(true));
			}else{
				queryItem.setWhere(Where.like("name", "%"+search+"%"));
			}
		}
		queryItem.setOrders("id,sort");
		
		return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, Module.SYSTEM, Function.SYS_MENU),"status"));
	}
	
	/**
	 * 菜单编辑新增页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/menu/add")
	public ModelAndView toAddMenu() throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		
		formFieldList.add(FormField.builder().name("name").text("菜单名称")
				.verify("required").build());
		
		formFieldList.add(FormField.builder().name("url").text("菜单URL").build());
		formFieldList.add(FormField.builder().name("pid").text("上级菜单").build());
		
		formFieldList.add(FormField.builder().name("buttonType").text("按钮类型")
				.placeholder("add添加 edit编辑 del删除 target新页面 allot分配  outexp超时说明").build());
		
		formFieldList.add(FormField.builder().name("single").text("单选多选")
				.placeholder("0、多选  1、单选 ").build());
		
		formFieldList.add(FormField.builder().name("type").text("类型")
				.placeholder("1、列表页  2、侧滑页  3、按钮").build());
		
		formFieldList.add(FormField.builder().name("click").text("侧滑按钮类型").build());
		formFieldList.add(FormField.builder().name("icon").text("图标").build());
		formFieldList.add(FormField.builder().name("sort").placeholder("只对同级菜单有效").text("排序").build());
		formFieldList.add(FormField.builder().name("conditionFlag").placeholder("自定义字符串").text("条件标识").build());
		formFieldList.add(FormField.builder().name("confirmTitle").placeholder("确认按钮的标题").text("确认按钮标题").build());
		formFieldList.add(FormField.builder().name("confirmContent").placeholder("确认按钮内容").text("确认按钮内容").build());
		
		Map<String, Object> data = PageUtil.createFormPageStructure("system/menu/save", formFieldList);
		
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 保存菜单
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/menu/save")
	public DyResponse saveMenu(SysMenu menu) throws Exception {
		if(StringUtils.isBlank(menu.getSort())){
			menu.setSort("0");
		}
		sysCache.addMenu(menu);
//		this.insert(Module.SYSTEM, Function.SYS_MENU, menu);
		return createSuccessJsonResonse(null,"增加菜单成功");
	}
	
	/**
	 * 菜单编辑更新页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/menu/edit")
	public ModelAndView toEditMenu(Long id) throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		
		formFieldList.add(FormField.builder().name("name").text("菜单名称")
				.verify("required").build());
		
		formFieldList.add(FormField.builder().name("url").text("菜单URL").build());
		formFieldList.add(FormField.builder().name("pid").text("上级菜单").build());
		
		formFieldList.add(FormField.builder().name("buttonType").text("按钮类型")
				.placeholder("add添加 edit编辑 del删除 target新页面 allot分配  outexp超时说明").build());
		
		formFieldList.add(FormField.builder().name("single").text("单选多选")
				.placeholder("0、多选  1、单选 ").build());
		
		formFieldList.add(FormField.builder().name("type").text("类型")
				.placeholder("1、列表页  2、侧滑页  3、按钮").build());
		
		formFieldList.add(FormField.builder().name("click").text("侧滑按钮类型").build());
		formFieldList.add(FormField.builder().name("icon").text("图标").build());
		formFieldList.add(FormField.builder().name("sort").placeholder("只对同级菜单有效").text("排序").build());
		formFieldList.add(FormField.builder().name("conditionFlag").placeholder("自定义字符串").text("条件标识").build());
		formFieldList.add(FormField.builder().name("confirmTitle").placeholder("确认按钮的标题").text("确认按钮标题").build());
		formFieldList.add(FormField.builder().name("confirmContent").placeholder("确认按钮内容").text("确认按钮内容").build());
//		QueryItem queryItem = new QueryItem(Where.eq("id", id));
//		queryItem.setFields("*");
//		SysMenu formdata = this.getOneByEntity(queryItem , Module.SYSTEM, Function.SYS_MENU, SysMenu.class);
		SysMenu formdata = sysCache.getMenu(id);
		Map<String, Object> data = PageUtil.createFormPageStructure("system/menu/update", formFieldList,formdata);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新菜单
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/menu/update")
	public DyResponse updateMenu(SysMenu menu) throws Exception {
//		this.update(Module.SYSTEM, Function.SYS_MENU, menu);
		sysCache.updateMenu(menu);
		return createSuccessJsonResonse(null,"修改菜单成功");
	}
	
	/**
	 * 删除菜单
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/menu/delete")
	public DyResponse deleteMenu(SysMenu menu) throws Exception {
		sysCache.deleteMenu(menu);
//		this.deleteById(menu.getId(), Module.SYSTEM, Function.SYS_MENU);
		return createSuccessJsonResonse(null,"删除菜单成功");
	}
	
	/**
	 * 获取主菜单
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/nav/top")
	public DyResponse navTop() throws Exception {
		List<Map> menuList = subMenuMap(0L);
		Page<Map> page = new Page<>();
		page.setItems(menuList);
		return createSuccessJsonResonse(page);
		
	}
	
	/**
	 * 获取侧栏菜单
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/nav/menu")
	public DyResponse navMenu(String id,String level) throws Exception {
		OrgUser user = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
		if(user == null)return createLoginJsonResonse("会话失效");
		List<Map> menuList = subMenuMap(Long.valueOf(id));
		Page<Map> page = new Page<>();
		if(menuList != null){
			for(Map menu:menuList){
				// 第二级菜单
				List<Map> subMenuList = subMenuMap((Long) (menu.get("id")));
				menu.put("child", subMenuList);
				if(subMenuList != null){
					//第三级菜单
					for(Map smenu:subMenuList){
						smenu.put("child", fourSubMenus((Long) (smenu.get("id"))));
					}
				}
			}
		}
		page.setItems(menuList);
		return createSuccessJsonResonse(page);
		
	}
	
	/**
	 * 获取待办提醒
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/nav/getPendingMenu")
	public DyResponse navPendingMenu(String id) throws Exception {
		DyResponse response = navMenu(id, "0");
		Page<Map> page = (Page<Map>) response.getData();
		List<Map> items = page.getItems();
		Map<String,Map<String,Object>> result = Maps.newHashMap();
		if(items != null){
			for(Map map:items){
				List<Map> children = (List<Map>) map.get("child");
				if(children != null){
					for(Map child:children){
						Map<String, Object> num = Maps.newHashMap();
						String num_key = (String) child.get("num_key");
						if(StringUtils.isNotBlank(num_key)){
							QueryItem queryItem = null;
							if("alt_1".equals(num_key)||"alt_2".equals(num_key)||"alt_3".equals(num_key)){
								queryItem = TodoUtils.buildAlertQeurySC(Integer.parseInt(num_key.substring(4)), getUserId());
							}else if("alt_9".equals(num_key) || "alt_10".equals(num_key) || "alt_11".equals(num_key) 
									|| "alt_12".equals(num_key)|| "alt_13".equals(num_key)){
								queryItem = TodoUtils.buildAgpurAlertQeurySC(Integer.parseInt(num_key.substring(4)), getUserId(),this);
							}else if(num_key.equals("notice")){
								queryItem = TodoUtils.buildNoticeQeurySC();
							}else if(num_key.equals("0")){
								queryItem = TodoUtils.buildTodoQeurySC(Integer.parseInt(num_key));
							}
							if(queryItem != null){
								queryItem.setFields("count(id) as num");
							}
							Map<String, Object> count = null;
							if("alt_1".equals(num_key)||"alt_2".equals(num_key)||"alt_3".equals(num_key)){
								count = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_RECEIVE_BILL);
							}else if("alt_4".equals(num_key)){//未巡库预警
							    num.put("num",new Long(warehouseInspectController.getAlertData(null, null, true,0).getTotal_items()));
							}else if("alt_5".equals(num_key)){//对账不平预警
							    num.put("num",count5AccountCheck(0));
							}else if("alt_6".equals(num_key)){//跌破警戒线预警
							    num.put("num",count6AlertPledgeRate(0));
							}else if("alt_7".equals(num_key)){//跌破最低控货价预警
							    num.put("num",count7AlertLowPrice(0));
    						}else if("alt_8".equals(num_key)){//保质期预警
    						    num.put("num",new Long(warehouseReceiptController.getAlertCollateralCount(0)));
    						}else if(num_key.equals("notice")){
								count = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.MESSAGE_LOG);
							}else if(num_key.equals("0")){
								count = this.getOneByMap(queryItem, SCModule.FLOW, SCFunction.FLOW_PROC_INST);
							}else if("alt_9".equals(num_key) || "alt_10".equals(num_key) || "alt_11".equals(num_key)){//未周转提示，采购未到货提示
								count = this.getOneByMap(queryItem, SCModule.AGPUR, SCFunction.SPA);
							}else if("alt_12".equals(num_key)){
								count = this.getOneByMap(queryItem, SCModule.AGPUR, SCFunction.ACCOUNT_CHECK);
							}else if("alt_13".equals(num_key)){
								count = this.getOneByMap(queryItem, SCModule.AGPUR, SCFunction.PRICE_RISK_LOG);
							}else if (num_key.indexOf(".")>0){
								String[] target=num_key.split("\\.");
								Object bean=SpringContextHolder.getBean(target[0]);
								String[] args=null;
								Class<?>[] argsClass=null;
								if(target.length>2){
									args=Arrays.copyOfRange(target, 2, target.length);
									argsClass=new Class<?>[target.length-2];
									for(int i=0;i<argsClass.length;i++){
										argsClass[i]=String.class;
									}
								}
								Method method=ReflectionUtils.findMethod(bean.getClass(), target[1],argsClass);
								num.put("num",ReflectionUtils.invokeMethod(method,bean,args));
							}
							
							if(count != null){
								num.put("num", (Long) count.get("num"));
							}
							result.put(child.get("id").toString(), num);
						}
					}
				}
			}
		}
		return createSuccessJsonResonse(result);
	}
	
	/**
	 * 
	 * 统计对账不平
	 * @return
	 * @throws Exception
	 * @author likf
	 */
	private Long count5AccountCheck(int type) throws Exception{
	    QueryItem queryItem=new QueryItem();
	    queryItem.setFields("count(id) as num");
	    if(type==0){
            queryItem.setWhere(Where.expression(" exists(select 1 from warehouse_pledge a where a.id=warehouse_account_check.pledge_id and a.saler_id="+getUserId()+")", false));    
        }
        queryItem.setWhere(Where.eq("account_check_result", AccountCheckResult.NO.getIndex()));
        Map<String, Object> result=this.getOneByMap(queryItem, SCModule.WAREHOUSE, SCFunction.WAREHOUSE_ACCOUNT_CHECK);
        return MapUtils.getLong(result, "num");
	}

	/**
	 * 
	 * 统计跌破警戒线 
	 * @return
	 * @throws Exception
	 * @author likf
	 */
	private Long count6AlertPledgeRate(int type) throws Exception{
        QueryItem queryItem=new QueryItem();
        queryItem.setFields("count(id) as num");
        queryItem.setWhere(Where.expression("pledge_rate_now>pledge_alert_rate", false));
        queryItem.setWhere(Where.eq("record_date", DateUtil.getCurrentDateStr()));
        if(type==0){
            queryItem.setWhere(Where.expression(" exists(select 1 from warehouse_pledge a where a.id=warehouse_alert_pledge_rate.pledge_id and a.saler_id="+getUserId()+")", false));    
        }
        queryItem.setWhere(Where.eq("del_flag", 0));
        Map<String, Object> result=this.getOneByMap(queryItem, SCModule.WAREHOUSE, SCFunction.WAREHOUSE_ALERT_PLEDGE_RATE);
        return MapUtils.getLong(result, "num");
    }
	
	/**
	 * 
	 * 统计跌破最低控货价 
	 * @return
	 * @throws Exception
	 * @author likf
	 */
	private Long count7AlertLowPrice(int type) throws Exception{
	    QueryItem queryItem=new QueryItem();
	    queryItem.setFields("count(id) as num");
	    if(type==0){
            queryItem.setWhere(Where.expression(" exists(select 1 from warehouse_pledge a where a.id=warehouse_alert_low_price.pledge_id and a.saler_id="+getUserId()+")", false));    
        }
	    Map<String, Object> result=this.getOneByMap(queryItem, SCModule.WAREHOUSE, SCFunction.WAREHOUSE_ALERT_LOW_PRICE);
	    return MapUtils.getLong(result, "num");
	}
	
	
	
	/**
     * 用户登录
     * @author 
     */
	@RequestMapping("/public/login")
    public String loginAction(){ 
		return "login";
    }
	
	@RequestMapping("/public/permissionDenied")
    public ModelAndView permissionDeniedAction(String path) throws Exception{ 
		Map<String,Object> formData=Maps.newHashMap();
		OrgUser user=getAdminUser();
		if(user!=null){
			formData.put("userName", user.getUsername());
			QueryItem qi=new QueryItem();
			qi.getWhere().add(Where.in("id", user.getRole()));
			List<Role> roles=this.getListByEntity(qi, SCModule.SYSTEM, SCFunction.SYS_ROLE, Role.class);
			if(roles!=null&&roles.size()>0){
				String roleName="";
				for(Role role:roles){
					roleName+=role.getRoleName()+"、";
				}
    			//去掉最后一个"、"
				if(StringUtils.isNotBlank(roleName)){
					roleName=roleName.substring(0, roleName.length()-1);
				}
				formData.put("roleName", roleName);
				
			}
			
		}
		formData.put("path", path);
		return createSuccessModelAndView("permissionDenied", JsonUtils.object2JsonString(formData));
    }
	
	/**
	 * 退出
	 * @return
	 */
	@RequestMapping("/public/logout")
	public ModelAndView logout() {
		//销毁session
		removeSessionAttribute(Constant.SESSION_USER);
		
		//Shiro销毁
		Subject subject = SecurityUtils.getSubject(); 
		subject.logout();
		
		return new ModelAndView("redirect:/system/public/login");
	}
	
	/**
	 * 修改session语言
	 * @param langType
	 * @return
	 */
	@RequestMapping("/changeLocale")
	public DyResponse changeLocale(String langType) {
		Locale locale = null;
        if("zh".equals(langType)) {
        	locale = new Locale("zh", "CN"); 
		} else if("en".equals(langType)) {
			locale = new Locale("en", "US"); 
		}
        if(locale != null)
        	this.setSessionAtrribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, locale);
        else
        	this.setSessionAtrribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, LocaleContextHolder.getLocale());
		
		return createSuccessJsonResonse(null);
	}
}