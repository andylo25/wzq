package com.dy.sc.admin.controller.customer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.dy.ia.entity.common.SysDocument;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.system.PremiseMaterial;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 准入材料
 * @ClassName: PremiseMaterialController.java 
 * @Description: TODO 
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author diyou@diyou.cn
 * @date 2017年7月11日下午5:17:17 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * diyou 
 * </pre>
 */	
@Controller
@RequestMapping("/sys/permitDatum/")
public class PermitDatumController extends AdminBaseController{
    
	/**
     * 列表
     * @return
     * @throws Exception
     */
	@RequestMapping("list")
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "name","licTypeName","real_name","create_time"});
		tableHeader.setTexts(new String[]{"ID","材料名称","所属类型","添加人","添加时间"});
		tableHeader.setTypes(new String[]{"int","","","","datetime"});
		tableHeader.setOptionTypes(new String[]{"","","", "",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"name"});
		search.setTexts(new String[]{"材料名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("sys/permitDatum/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 列表数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({"rawtypes" })
    @ResponseBody
	@RequestMapping("listData")
	public DyResponse listData(Integer page, Integer limit, String search, String name) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields(" id,name,business_lic_type,create_uid,create_time ");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("name", search));
		}
		if(StringUtils.isNotBlank(name)){
			queryItem.setWhere(Where.likeAll("name", search));
		}
		queryItem.setWhere(Where.eq("del_flag",0));
		queryItem.setOrders("id");
		Page<Map> pageData=getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL);
		List<Map> listData=pageData.getItems();
		if(listData!=null&&listData.size()>0){
			List<Long> businessLicTypeIds =Lists.newArrayList();
		    //dataConvert(listData, "", "create_time");
		    //this.idToName(pageData.getItems(), Module.SYSTEM, SCFunction.SYS_ARTICLE_TYPE, "article_type_id:article_type");
		    this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name");
			List<Option> types = DictUtils.getOptions("business_lic_type");
		    for(Map item:listData){
		    	String businessLicType = item.get("business_lic_type")!=null?item.get("business_lic_type").toString():null;
		    	String typeTextStr = "";
    			if(StringUtils.isNotBlank(businessLicType)){
    				String[] licTypeIds=businessLicType.split(",");
    				for(String value: licTypeIds){
    					for(Option type:types){
    						if(type.getValue().equals(value)){
    							typeTextStr+=type.getText()+"、";
    						}
    					}
    				}
    			}
    			//去掉最后一个"、"
				if(StringUtils.isNotBlank(typeTextStr)){
					typeTextStr=typeTextStr.substring(0, typeTextStr.length()-1);
				}
				item.put("licTypeName", typeTextStr);
		    }
		}
		return createSuccessJsonResonse(pageData);
	}
	
	/**
	 * 界面上的下拉、单选、字典值
	 * @return
	 * @throws Exception
	 */
	private Map<String,Object> getFromData() throws Exception{		
		Map<String,Object> formdata=Maps.newHashMap();
		//是否
		formdata.put("common_status", DictUtils.getOptions("common_status"));
		//状态
		formdata.put("business_lic_type", DictUtils.getOptions("business_lic_type"));
		return formdata;
	}
	
	/**
	 * 添加
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="add")
	public ModelAndView add() throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		Map<String,Object> formdata=getFromData();		
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/permitDatum/save", formFieldList, formdata);
		return createSuccessModelAndView("system/editPremiseMaterial", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 保存
	 * @param businessType
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="save")
	public DyResponse save(PremiseMaterial premiseMaterial,  String filename, String fileurl, @RequestParam(value = "businessLicTypes[]", required = false)String[] businessLicTypes) throws Exception {
		if(filename!=null){
			premiseMaterial.setFileName(filename);
			premiseMaterial.setFilePath(fileurl);
		}
        if(businessLicTypes==null||businessLicTypes.length<=0){
        	return createErrorJsonResonse("请至少选择一种所属类型！");
        }else{
        	premiseMaterial.setBusinessLicType(org.apache.commons.lang3.StringUtils.join(businessLicTypes,","));
		}
		this.insert(SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, premiseMaterial);
		return createSuccessJsonResonse(null,"添加成功！");
	}
	
	/**
	 * 编辑
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="edit")
	public ModelAndView edit(Long id) throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		Map<String,Object> formdata=getFromData();
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("id", id));
		PremiseMaterial premiseMaterial = this.getOneByEntity(item, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, PremiseMaterial.class);		
		Map<String,Object> pmMap=(Map<String, Object>) new DataConvertUtil(premiseMaterial,false).convert();
		formdata.putAll(pmMap);
		if(StringUtils.isNotBlank(premiseMaterial.getBusinessLicType())){
			formdata.put("businessLicTypes",premiseMaterial.getBusinessLicType().split(","));
		}else{
			formdata.put("businessLicTypes",null);
		}
		formdata.put("id", premiseMaterial.getId());
		Map<String,Object> file =Maps.newHashMap();
		file.put("name", premiseMaterial.getFileName());
		file.put("url", premiseMaterial.getFilePath());
		formdata.put("file",premiseMaterial.getFilePath());
//		formdata.put("import_name", pmMap.get("file_name"));
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/permitDatum/update", formFieldList, formdata);
		return createSuccessModelAndView("system/editPremiseMaterial", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新
	 * @param businessType
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update")
	public DyResponse update(PremiseMaterial premiseMaterial, String filename, String file, @RequestParam(value = "businessLicTypes[]", required = false)String[] businessLicTypes) throws Exception {
		if(filename!=null){
			SysDocument document = this.getById(file, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
			premiseMaterial.setFileName(document.getFileName());
			premiseMaterial.setFilePath(document.getFilePath());
		}
        if(businessLicTypes==null||businessLicTypes.length<=0){
        	return createErrorJsonResonse("请至少选择一种所属类型！");
        }else{
        	premiseMaterial.setBusinessLicType(org.apache.commons.lang3.StringUtils.join(businessLicTypes,","));
		}
		this.update(SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, premiseMaterial);
		return createSuccessJsonResonse(null,"更新成功！");
	}
    
	/**
	 * 删除
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete")
	public DyResponse delete(Long id) throws Exception {
		DyResponse dyResponse = this.deleteById(id, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL);
		if(dyResponse.isOK()){
			return createSuccessJsonResonse(null,"删除成功");
		}else{
			return dyResponse;
		}
	}
}