package com.dy.sc.admin.controller.buss;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.dy.sc.entity.product.ProdProductInfo;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.bussmodule.loan.LoanModule;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.RepayStatus;
import com.dy.sc.entity.loan.LoanDebitRecord;
import com.google.common.collect.Lists;
@Controller
@RequestMapping("/credit")
public class BussOverdueController extends AdminBaseController {
    
    /**
     * 全部还款
     */
    private static final int TYPE_ALL=1;
    /**
     * 逾期未还
     */
    private static final int TYPE_OVERDUE_NOTREPAY=2;
    /**
     * 逾期已还
     */
    private static final int TYPE_OVERDUE_PAYED=3;
    
    /**
     * 待还款明细
     */
    private static final int TYPE_NO_PAY=4;
    /**
     * 已还款明细
     */
    private static final int TYPE_PAYED=5;
    /**
     * 转坏账
     */
    private static final int TYPE_BAD_DEBT=6;
    
    @Autowired
	private LoanModule loanModule;
	/**
	 * 逾期未还
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/overdue/{type}")
	public ModelAndView list(@PathVariable("type") int type) throws Exception {
		TableHeader tableHeader = new TableHeader();
		if(type==TYPE_ALL){//全部
			tableHeader.setNames(new String[]{"id","company_name","loan_contract_no","business_type","product_name","period","amount","principal","interest","repay_time","repay_time_yes","amount_yes","status"});
			tableHeader.setTexts(new String[]{"ID", "客户名称","信贷合同编号","业务类型","产品名称","期数","应还总额","应还本金","应还利息","应还日期","实还时间","实还金额","状态"});
			tableHeader.setTypes(new String[]{"int","", "","","","","number","number","number","","","number",""});
			tableHeader.setFilters(new String[]{"","input", "input","select","select","","","","","multi_date","multi_date","","select"});
			tableHeader.setOptionTypes(new String[]{"","", "","business_type","sc_product","","","","","","","","repay_status"});
		}else if(type==TYPE_OVERDUE_NOTREPAY){
			tableHeader.setNames(new String[]{"id","company_name","loan_contract_no","business_type","product_id","period","amount","principal","interest","overdue_day","overdue_fee","repay_time"});
			tableHeader.setTexts(new String[]{"ID", "客户名称","信贷合同编号","业务类型","产品名称","期数","应还总额","应还本金","应还利息","逾期天数","逾期费用","应还日期"});
			tableHeader.setTypes(new String[]{"int","", "","","","","number","number","number","","number","","",""});
			tableHeader.setFilters(new String[]{"","input", "input","select","select","","","","","","","multi_date"});
			tableHeader.setOptionTypes(new String[]{"","", "","business_type","","","","","","","","",""});
		}else if(type==TYPE_OVERDUE_PAYED){
			tableHeader.setNames(new String[]{"id","company_name","loan_contract_no","business_type","product_id","period","amount","principal","interest","overdue_day","overdue_fee","repay_time","repay_time_yes"});
			tableHeader.setTexts(new String[]{"ID", "客户名称","信贷合同编号","业务类型","产品名称","期数","应还总额","应还本金","应还利息","逾期天数","逾期费用","应还日期","实还日期"});
			tableHeader.setTypes(new String[]{"int","", "","","","","number","number","number","","number","","","",""});
			tableHeader.setFilters(new String[]{"","input", "input","select","select","","","","","","","multi_date","multi_date"});
			tableHeader.setOptionTypes(new String[]{"","", "","business_type","","","","","","","","",""});
		}else if(type==TYPE_NO_PAY){//待还款/已还款
            tableHeader.setNames(new String[]{"id","company_name","loan_contract_no","business_type","product_id","period","amount","principal","interest","repay_time","status"});
            tableHeader.setTexts(new String[]{"ID", "客户名称","信贷合同编号","业务类型","产品名称","期数","应还总额","应还本金","应还利息","应还日期","状态"});
            tableHeader.setTypes(new String[]{"int","", "","","","","number","number","number","",""});
            tableHeader.setFilters(new String[]{"","input", "input","select","select","","","","","multi_date",""});
            tableHeader.setOptionTypes(new String[]{"","", "","business_type","","","","","","","repay_status"});
		}else if(type==TYPE_PAYED){//待还款/已还款
		    tableHeader.setNames(new String[]{"id","company_name","loan_contract_no","business_type","product_id","period","amount","principal","interest","repay_time","repay_time_yes","amount_yes","status"});
		    tableHeader.setTexts(new String[]{"ID", "客户名称","信贷合同编号","业务类型","产品名称","期数","应还总额","应还本金","应还利息","应还日期","实还时间","实还金额","状态"});
		    tableHeader.setTypes(new String[]{"int","", "","","","","number","number","number","","","number",""});
		    tableHeader.setFilters(new String[]{"","input", "input","select","select","","","","","multi_date","multi_date","",""});
		    tableHeader.setOptionTypes(new String[]{"","", "","business_type","","","","","","","","","repay_status"});
		}else if(type==TYPE_BAD_DEBT){//转坏账
		    tableHeader.setNames(new String[]{"id","company_name","loan_contract_no","business_type","product_id","period","amount","principal","interest","overdue_day","overdue_fee","repay_time","bad_debt_time"});
		    tableHeader.setTexts(new String[]{"ID", "客户名称","信贷合同编号","业务类型","产品名称","期数","应还总额","应还本金","应还利息","逾期天数","逾期费用","应还日期","转坏账时间"});
		    tableHeader.setTypes(new String[]{"int","", "","","","","number","number","number","","number","",""});
		    tableHeader.setFilters(new String[]{"","input", "input","select","select","","","","","","","multi_date","multi_date"});
		    tableHeader.setOptionTypes(new String[]{"","", "","business_type","","","","","","","","",""});
		}
		Tool tool = new Tool();
		tool.setList(buildTools());	
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"信贷编号"});
		search.setTypes(new String[]{"text"});
		
		PageStructure data = PageUtil.createTablePageStructure("credit/overdue/overdueData/"+type,"credit/recovering/recoverPeriodView","id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 逾期未还 数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping("/overdue/overdueData/{type}")
	public DyResponse listData(Integer page,Integer limit,String search,
			String loan_contract_no,String company_license,String company_name,Long business_type,Long product_id,Integer status,String repay_time,String repay_time_yes,
			String bad_debt_time,String loan_repay_type,String product_name,String expire_time,String next_repay_time,@PathVariable("type") int type) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("loan_contract_no", search));
		}
		if(org.apache.commons.lang3.StringUtils.isNotBlank(product_name)){
			ProdProductInfo productInfo = this.getById(product_name, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
			QueryItem query = new QueryItem(Where.eq("root_version", productInfo.getRootVersion()));
			List<ProdProductInfo> productInfos = this.getListByEntity(query, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
			List<Object> ids = Lists.newArrayList();
			for(ProdProductInfo info : productInfos){
				ids.add(info.getId());
			}
			queryItem.setWhere(Where.in("debit_id", getIdsIn(SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "product_id", ids)));
		}
		if(StringUtils.isNotBlank(loan_contract_no)){
			queryItem.setWhere(Where.likeAll("loan_contract_no", loan_contract_no));
		}
		if(StringUtils.isNotBlank(company_license)){
			queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_license", company_license)));
		}
		if(StringUtils.isNotBlank(company_name)){
			queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", company_name)));
		}
		if(business_type!=null){
			queryItem.setWhere(Where.in("debit_id",getIdsIn(SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD,"loan_id", getIdsEq(SCModule.LOAN, SCFunction.LOAN_REQUEST, "business_type", business_type))));
		}
		
		if(status!=null){
			queryItem.setWhere(Where.eq("status", status));
		}
		
		if(StringUtils.isNotBlank(repay_time_yes)){
			queryItem.setWhere(this.addDateWhereCondition(null, "repay_time_yes",repay_time_yes));
		}
		if(StringUtils.isNotBlank(repay_time)){
			queryItem.setWhere(this.addDateWhereCondition(null, "repay_time",repay_time));
		}
		if(StringUtils.isNotBlank(bad_debt_time)){
			queryItem.setWhere(this.addDateWhereCondition(null, "bad_debt_time",bad_debt_time));
		}

		if(StringUtils.isNotBlank(loan_repay_type)){
			queryItem.setWhere(Where.eq("loan_repay_type", loan_repay_type));
		}
		if(type==TYPE_OVERDUE_NOTREPAY){
            queryItem.setWhere(Where.lt("repay_time", DateUtil.getCurrentDateLong()));// 应还日期<当前日期
			//queryItem.setWhere(Where.eq("overdue_fee", 0));
			queryItem.setWhere(Where.eq("status", RepayStatus.NO.getIndex()));
			queryItem.setOrders("repay_time asc");
		}else if(type==TYPE_OVERDUE_PAYED){
		    queryItem.setWhere(Where.gt("overdue_fee", 0));//产生逾期费用  逾期已还
		    queryItem.setWhere(Where.eq("status", RepayStatus.YES.getIndex()));
			queryItem.setOrders("id desc");
		}else if(type==TYPE_NO_PAY){
		    //未还款
		    queryItem.setWhere(Where.eq("status", RepayStatus.NO.getIndex()));
		    queryItem.setOrders("repay_time asc");
		}else if(type==TYPE_PAYED){//已还款
		    //未还款
		    queryItem.setWhere(Where.eq("status", RepayStatus.YES.getIndex()));
		    queryItem.setOrders("repay_time_yes desc");
		}else if(type==TYPE_BAD_DEBT){//坏账
		    //未还款
		    queryItem.setWhere(Where.eq("status", RepayStatus.BAD_DEBT.getIndex()));
		    queryItem.setOrders("id desc");
		}else{
			//用状态排序会报错
			queryItem.setOrders("status asc,repay_time asc");
		}
		Page recordPage=this.getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
	    List<Map> data=recordPage.getItems();
	    if(data!=null&& data.size()>0){
			this.idToName(data, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:status as debit_status,product_id,business_type,loan_id,company_id,sales_uid,contract_start_time,contract_end_time,loan_amount,loan_apr,overdue_rate_type,overdue_rate_value");
			this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name,company_license");
			this.idToName(data, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "product_id:name as product_name");
			Iterator ite = data.iterator();
			while (ite.hasNext()){
				Map repay = (Map)ite.next();
                Integer debitStatus = MapUtils.getInteger(repay, "debit_status");
                if (debitStatus == null || AccConstants.CREDIT_RECORD_STATUS_NO_ACCEPT == debitStatus) {
					ite.remove();
				}
			}
	    	for (Map item : data) {
	    		    //已还款逾期 
	    			Integer days=null;
	    		    if(item.get("status").equals(RepayStatus.YES.getIndex())&&item.get("overdue_fee")!=null&&NumberUtils.greaterThanZero(new BigDecimal(item.get("overdue_fee").toString()))){
	    		    	days=DateUtil.daysBetween(DateUtil.dateParse(Long.parseLong(item.get("repay_time").toString())),DateUtil.dateParse(Long.parseLong(item.get("repay_time_yes").toString())));
	    		    	 //未还款逾期
	    		    }else if((item.get("status").equals(RepayStatus.NO.getIndex())||item.get("status").equals(RepayStatus.BAD_DEBT.getIndex()))
	    		            &&DateUtil.getCurrentTime()> Long.parseLong(item.get("repay_time").toString())){
	    		    	days=DateUtil.daysBetween(DateUtil.dateParse(Long.parseLong(item.get("repay_time").toString())),DateUtil.getCurrentDate());
	    		    	if(days>0&&item.get("overdue_rate_value")!=null){
//	    		    		BigDecimal overdueFee= RepayUtil.calcOverdueRate(item, days);
//	    		    		if(NumberUtils.greaterThanZero(overdueFee))
//	    		    			item.put("overdue_fee",overdueFee);
	    		    	}
	    		    }
	    			if(days!=null&&days>0){
	    				item.put("overdue_day",days+"天");
	    			}
//	    			dataConvert(item,"status:repay_status");
                    if(item.get("repay_time_yes")!=null)
                        item.put("repay_time_yes", DateUtil.dateFormat(Long.parseLong(item.get("repay_time_yes").toString())));
                    if(item.get("bad_debt_time")!=null)
                        item.put("bad_debt_time", DateUtil.dateFormat(Long.parseLong(item.get("bad_debt_time").toString())));
                    
	    			item.put("repay_time", DateUtil.dateFormat(Long.parseLong(item.get("repay_time").toString())));
	 		}
	    }
		return createSuccessJsonResonse(recordPage);
	}
	
	/**
	 * 根据recordId查出repay
	 * @throws Exception 
	 */
	private Map<String,Object> getRepayByid(String debit_id) throws Exception{
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("debit_id", debit_id));
		Map<String,Object> repay = this.getOneByMap(item, SCModule.FUND, SCFunction.FUND_LOAN_REPAY);
		return repay;
	}
	/**
	 * 逾期未还
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/overdue/repay")
	public ModelAndView getOverdueRepay() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "loan_contract_no","company_license","company_name","loan_amount","transfer_total","loan_apr","loan_repay_type","interest_yes","amount_yes","expire_time","next_repay_time","overdue_day","sales_name"});
		tableHeader.setTexts(new String[]{"ID", "信贷合同编号","用户名","企业名称","实际授信金额","实际放款金额","利率","还款方式","还款利息","还款本息","应还日期","实际还款日期","逾期天数","业务员"});
		tableHeader.setTypes(new String[]{"int","", "","","","","","","","","","","",""});	
		tableHeader.setOptionTypes(new String[]{"","", "","","","","","repay_type","","","","","",""});
		tableHeader.setFilters(new String[]{"","input", "input","input","","","","select","","","","multi_date","","input"});
		
		Tool tool = new Tool();
		tool.setList(buildTools());	
		
		Search search = new Search();
		search.setNames(new String[]{"loan_contract_no"});
		search.setTexts(new String[]{"信贷编号"});
		search.setTypes(new String[]{"text"});
		
		PageStructure data = PageUtil.createTablePageStructure("credit/overdue/repayData","credit/recovering/recoverview","id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}

	/**
	 * 根据回款日期获取回款记录
	 * 
	 * @param value  回款时间段
	 * @param pageNo 第几页
	 * @param limit  页数
	 * @return
	 * @throws Exception
	 */
	private List<Object> getIdsFromRepay(String value,Integer pageNo,Integer limit) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(pageNo);
		queryItem.setLimit(limit); 
		queryItem.setFields("debit_id");
		if(StringUtils.isNotBlank(value))
			queryItem.setWhere(this.addDateWhereCondition(null, "repay_time_yes", value));
		queryItem.setWhere(Where.expression("next_repay_time>expire_time",false));
		List<Map> ents = this.getListByMap(queryItem, SCModule.FUND,SCFunction.FUND_LOAN_REPAY);
		List<Object> ids = Lists.newArrayList();
		if(ents != null){
			for(Map s:ents){
				ids.add(s.get("debit_id").toString());
			}
		}
		return ids;
	}
	
	/**
	 * 获取所有信贷记录数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping("/overdue/repayData")
	public DyResponse getOverdueRepayData(Integer page,Integer limit,String search,String loan_contract_no,String company_license,String company_name
			,String loan_repay_type,String sales_name,String next_repay_time) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		//List<Where> whereList = new ArrayList<Where>();
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("loan_contract_no", loan_contract_no));
		}
		if(StringUtils.isNotBlank(loan_contract_no)){
			queryItem.setWhere(Where.like("loan_contract_no", "%"+loan_contract_no+"%"));
		}
		if(StringUtils.isNotBlank(company_license)){
			queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_license", company_license)));
		}
		if(StringUtils.isNotBlank(company_name)){
			queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", company_name)));
		}
		if(StringUtils.isNotBlank(sales_name)){
			queryItem.setWhere(Where.in("sales_uid", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_ADMIN, "real_name", sales_name)));
		}
		if(StringUtils.isNotBlank(loan_repay_type)){
			queryItem.setWhere(Where.eq("loan_repay_type", loan_repay_type));
		}
		//if(StringUtils.isNotBlank(next_repay_time)){
			queryItem.setWhere(Where.in("id", this.getIdsFromRepay(next_repay_time, page == null ? 1 : page, limit == null ? 20 : limit)));
		//}
		//queryItem.setWhere(Where.lt("contract_end_time", DateUtil.getCurrentTime()));
		queryItem.setWhere(Where.eq("status", "6"));
		queryItem.setOrders("id desc");
		Page recordPage=this.getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
	    List<Map> data=recordPage.getItems();
	    if(data!=null&& data.size()>0){
	    	 for (Map map : data) {
//	    			String compayId = map.get("company_id").toString();
//	    			Map<String,Object> company = getCompanyById(compayId);	 			
	    			String debit_id = map.get("id").toString();
	    			Map<String,Object> repay = getRepayByid(debit_id); 			
//	    			String userId=map.get("sales_uid").toString();
//	    			Map<String,Object> user = getUserByid(userId);  			
//	    			map.put("company_license", company.get("company_license"));
//	    			map.put("company_name", company.get("company_name"));    
//	    			map.put("sales_name",user.get("real_name"));
	    			map.put("amount_total", repay.get("amount_total"));
	    			map.put("transfer_total", repay.get("transfer_total"));
	    			map.put("interest_yes", repay.get("interest_yes"));
	    			map.put("amount_yes", repay.get("amount_yes"));
	    			map.put("expire_time", DateUtil.dateFormat(repay.get("expire_time")));    
	    			map.put("next_repay_time", repay.get("next_repay_time"));    			
	    			int days=DateUtil.daysBetween(DateUtil.dateParse(Long.valueOf(repay.get("expire_time").toString())),DateUtil.dateParse(Long.parseLong(repay.get("next_repay_time").toString())));	    			
	    			map.put("overdue_day",days+"天");  
	 		}
	    	this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_ADMIN, "sales_uid:real_name as sales_name");
	        this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name,company_license");
	    }
	    recordPage=(Page) dataConvert(recordPage,null,"next_repay_time");
		return createSuccessJsonResonse(recordPage);
	}
	
	@RequestMapping(value="/recovering/recoverPeriodView")
    public ModelAndView recoverPeriodView(Long id) throws Exception { 
	    Map data=this.getById(id, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
//        return recoverViewData(Long.parseLong(data.get("debit_id").toString()));
	    LoanDebitRecord record=this.getById(Long.parseLong(data.get("debit_id").toString()), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD,LoanDebitRecord.class);
	    //转坏账、提前还款、回款中、已还款、逾期中（没用到）
	    if(AccConstants.CREDIT_RECORD_ADVANCE_REPAY==record.getStatus().intValue()
	    		||AccConstants.CREDIT_RECORD_STATUS_REQUEST_BADDEBT==record.getStatus().intValue()
	    		||AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT==record.getStatus().intValue()
	    		||AccConstants.CREDIT_RECORD_STATUS_REPAY==record.getStatus().intValue()){
	    	return new ModelAndView("redirect:/credit/recovering/recoverview?id="+data.get("debit_id").toString());
	    }else{//否则没有【还款信息】tab只有【信贷信息】
	    	return new ModelAndView("redirect:/credit/allrecord/view?id="+data.get("debit_id").toString());
	    }
    }
	
}