package com.dy.sc.admin.config;

import java.util.Map;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.dy.core.adapter.AdapterManager;
import com.dy.core.adapter.FlowAdapter;
import com.dy.core.adapter.LoanAdapter;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.entity.constant.CommonConstant;

@Component
public class StartupListener implements ApplicationListener<ApplicationReadyEvent> {

    public void onApplicationEvent(ApplicationReadyEvent event) {
    	
        initModule();
        
        // 扩展点加载
        initAdapter(event);
    }

	private void initAdapter(ApplicationReadyEvent event) {
    	Map<String, FlowAdapter> flowAdapters = event.getApplicationContext().getBeansOfType(FlowAdapter.class);
    	if(flowAdapters != null){
    		for(FlowAdapter adapter:flowAdapters.values()){
    			AdapterManager.instance().addFlowAdapter(adapter);
    		}
    	}
    	Map<String, LoanAdapter> loadAdapters = event.getApplicationContext().getBeansOfType(LoanAdapter.class);
    	if(loadAdapters != null){
    		for(LoanAdapter adapter:loadAdapters.values()){
    			AdapterManager.instance().addLoanAdapter(adapter);
    		}
    	}
	}

	private void initModule() {
		//供应链菜单先独立开来 查询表sys_menu_supplychain;
        Function.SYS_MENU="menu_supplychain";
        
        //指向供应链数据库
        Module.ACCOUNT="sc_"+Module.ACCOUNT;
        Module.BUSINESS="sc_"+Module.BUSINESS;
        Module.CREDIT="sc_"+Module.CREDIT;
        Module.FLOW="sc_"+Module.FLOW;
        Module.LOAN="sc_"+Module.LOAN;
        Module.MEMBER="sc_"+Module.MEMBER;
        Module.REPORT="sc_"+Module.REPORT;
        Module.SYSTEM="sc_"+Module.SYSTEM;
        
        //common jar中system模块
        CommonConstant.MODULE_SYSTEM="sc_"+CommonConstant.MODULE_SYSTEM;
        CommonConstant.MODULE_BUSINESS="sc_fund";
	}

}
