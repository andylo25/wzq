package com.dy.sc.admin.controller.insidelimit;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.trust.enumeration.TrustActionEnum;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.encrypt.MessageEncryptUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.OrgUser;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.google.common.collect.Maps;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping("insidelimit/platlimit")
public class PlatController extends AdminBaseController {

    @Autowired
    private MessageEncryptUtil messageEncryptUtil;
    @Value("${ia.notifyUrl}")
    private String iaNotifyUrl;
    @Value("${ia.apiUrl}")
    private String iaServiceUrl;

    /**
     * 构建界面结构
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "open_bank", "open_name", "account", "acc_balance", "status"});
        tableHeader.setTexts(new String[]{"ID", "开户行", "开户名", "账号", "账户余额", "状态"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"open_bank"});
        search.setTexts(new String[]{"开户行"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("insidelimit/platlimit/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取数据
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse listData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,open_bank,open_name,account,acc_balance,status");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("open_bank", search));
        }
        queryItem.setWhere(Where.eq("account_type", AccConstants.ACCOUNT_TYPE_MASTER));
        queryItem.setOrders("id");

        return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT), "status"));
    }

    private List<FormField> buidFormField() {
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("openBank").text("开户行").verify("required").build());
        formFieldList.add(FormField.builder().name("openName").text("开户名").verify("required").build());

        formFieldList.add(FormField.builder().name("account").text("账号").verify("required").build());

        List<FormOption> options = new ArrayList<>();
        options.add(new FormOption("是", "1"));
        options.add(new FormOption("否", "0"));
        formFieldList.add(FormField.builder().name("status").text("是否开启").type("radio").options(options).build());
        return formFieldList;
    }

    /**
     * 编辑更新页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toEdit")
    public ModelAndView toEdit(Long id) throws Exception {

        List<FormField> formFieldList = buidFormField();

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        queryItem.setFields("id,open_bank as openBank,open_name as openName,account,status");
        AccAccount account = this.getOneByEntity(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("insidelimit/platlimit/update", formFieldList, account);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update")
    public DyResponse update(AccAccount accAccount) throws Exception {
//		if(!check(accAccount))return createErrorJsonResonse("缺失必填项");
        accAccount.setOpenFullName(accAccount.getOpenBank() + "-" + accAccount.getOpenName());
        this.update(Module.ACCOUNT, Function.ACC_ACCOUNT, accAccount);

        accAccount = this.getById(accAccount.getId(), Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        OrgUser user = new OrgUser();
        user.setId(accAccount.getUserId());
        user.setRealName(accAccount.getOpenName());
        this.update(Module.SYSTEM, Function.SYS_ADMIN, user);
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 更新余额
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "updateBalance")
    public DyResponse updateBalance(AccAccount accAccount) throws Exception {
        String trn_id = UUID.randomUUID().toString();

        AccAccount account = getAccAccount();

        Map<String, String> data = Maps.newHashMap();
        data.put("trn_id", trn_id);
        data.put("action", "qcard");
        data.put("account", account.getAccount());
        data.put("notify_url", iaNotifyUrl);

//        createTrustLog(user.getId(),null , trn_id, TYPE_QCARD, JsonUtils.object2JsonString(data), this.getRemoteIp(), null, null, account.getId(),1);

        String result = messageEncryptUtil.post(String.format(iaServiceUrl, TrustActionEnum.ACTION_QCARD.getIndex()), data);
        Map resultMap = JsonUtils.json2Map(result);
        if (DyResponse.OK != MapUtils.getInteger(resultMap, "status")) {
            return createErrorJsonResonse(resultMap.get("description"));
        } else {
            String balance = (String) ((Map) ((Map) ((Map) resultMap.get("data")).get("bussMap")).get("cardInfo")).get("SelfBalance");
            //更新余额表
            Map<String, Object> updateObj = Maps.newHashMap();
            updateObj.put("id", account.getId());
            updateObj.put("acc_balance", balance);
            updateObj.put("update_time", DateUtil.getCurrentTime());
            this.update(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, updateObj);

            return createSuccessJsonResonse("更新成功");
        }
    }

    private AccAccount getAccAccount() throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("id", ScConstants.PLAT_ACCOUNT_ID));
        return this.getOneByEntity(queryItem, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);
    }

    /**
     * 充值
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toRecharge")
    public ModelAndView toRecharge(Long id) throws Exception {

        List<FormField> formFieldList = buidFormField();

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        queryItem.setFields("id,open_bank as openBank,open_name as openName,account,status");
        AccAccount account = this.getOneByEntity(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("insidelimit/platlimit/update", formFieldList, account);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "recharge")
    public DyResponse recharge(AccAccount accAccount) throws Exception {
//		if(!check(accAccount))return createErrorJsonResonse("缺失必填项");
        accAccount.setOpenFullName(accAccount.getOpenBank() + "-" + accAccount.getOpenName());
        this.update(Module.ACCOUNT, Function.ACC_ACCOUNT, accAccount);

        accAccount = this.getById(accAccount.getId(), Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        OrgUser user = new OrgUser();
        user.setId(accAccount.getUserId());
        user.setRealName(accAccount.getOpenName());
        this.update(Module.SYSTEM, Function.SYS_ADMIN, user);
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 转账
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toTransfer")
    public ModelAndView toTransfer(Long id) throws Exception {

        List<FormField> formFieldList = buidFormField();

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        queryItem.setFields("id,open_bank as openBank,open_name as openName,account,status");
        AccAccount account = this.getOneByEntity(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("insidelimit/platlimit/update", formFieldList, account);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 转账
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "transfer")
    public DyResponse transfer(AccAccount accAccount) throws Exception {
//		if(!check(accAccount))return createErrorJsonResonse("缺失必填项");
        accAccount.setOpenFullName(accAccount.getOpenBank() + "-" + accAccount.getOpenName());
        this.update(Module.ACCOUNT, Function.ACC_ACCOUNT, accAccount);

        accAccount = this.getById(accAccount.getId(), Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        OrgUser user = new OrgUser();
        user.setId(accAccount.getUserId());
        user.setRealName(accAccount.getOpenName());
        this.update(Module.SYSTEM, Function.SYS_ADMIN, user);
        return createSuccessJsonResonse(null, "修改成功");
    }
}