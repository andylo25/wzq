package com.dy.sc.admin.controller.product;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.SysDict;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.TemplateType;
import com.dy.sc.entity.product.ProdBusinessType;
import com.dy.sc.entity.product.ProdProductInfo;
import com.dy.sc.entity.product.ProdTemplate;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * @author likaijun@diyou.cn
 * @version v1.0
 *          <pre>
 *                   修改人                修改时间        版本        修改内容
 *                   ---------------------------------------------------------
 *                   likaijun
 *                   </pre>
 * @ClassName: ProductController.java
 * 产品模块 Controller
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @date 2017年7月4日上午10:38:20
 */
@Controller
@RequestMapping("/prod/businessTemplate/")
public class BusinessTemplateController extends AdminBaseController {

    @Autowired
    CommonBussUtil commonBussUtil;

    /**
     * 根据id获取业务类型
     *
     * @param businessTypeId
     * @return
     * @throws Exception
     */
    private Map<String, Object> getBusinessTypeById(Long businessTypeId) throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("id", businessTypeId));
        item.setFields(" id, name, code ");
        Map<String, Object> businessType = this.getOneByMap(item, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        return businessType;
    }


    /**
     * 业务类型下拉
     *
     * @return
     * @throws Exception
     */
    private List<Map> getBusinessTypes() throws Exception {
        QueryItem item = new QueryItem();
        item.setFields(" id, name, code ");
        List<Map> businessTypes = this.getListByMap(item, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        return businessTypes;
    }

    /**
     * 业务类型列表
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list/{type}")
    public ModelAndView list(@PathVariable("type") Integer type) throws Exception {
        TableHeader tableHeader = new TableHeader();
        if(type == 99) {
            tableHeader.setNames(new String[]{"businessType", "product_name", "name", "sign_node", "create_uid", "dept_name", "create_time"});
            tableHeader.setTexts(new String[]{"所属类型", "产品名称", "合同名称", "签署节点", "创建人", "所属部门", "创建时间"});
            tableHeader.setTypes(new String[]{"", "", "", "", "", "", "datetime"});

            tableHeader.setOptionTypes(new String[]{"", "", "", "", "", "", ""});
            tableHeader.setFilters(new String[]{"input", "", "", "", "", "", ""});
        }else{
            tableHeader.setNames(new String[]{"name", "create_uid", "dept_name", "create_time"});
            tableHeader.setTexts(new String[]{"合同名称", "创建人", "所属部门", "创建时间"});
            tableHeader.setTypes(new String[]{"", "", "", "datetime"});

            tableHeader.setOptionTypes(new String[]{"", "", "", ""});
            tableHeader.setFilters(new String[]{"", "", "", ""});
        }
        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"name"});
        search.setTexts(new String[]{"合同名称"});
        search.setTypes(new String[]{"text"});

        PageStructure data = PageUtil.createTablePageStructure("prod/businessTemplate/listData?type=" + type, "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取业务类型数据
     *
     * @param page
     * @param limit
     * @param search
     * @param name   业务名称
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse listData(Integer page, Integer limit, String search, String name, Integer type) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields(" id, name, business_type_id, create_time, update_time, create_uid, product_id, sign_node");
        if (type == 1) {
            queryItem.setWhere(Where.eq("prod_template_type", TemplateType.COMMON.getIndex()));
        } else {
            queryItem.setWhere(Where.eq("prod_template_type", TemplateType.BUSINESS.getIndex()));
        }
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("name", search));
        }
        if (StringUtils.isNotBlank(name)) {
            queryItem.setWhere(Where.likeAll("name", name));
        }
        queryItem.setOrders(" create_time desc");
        Page recordPage = this.getPageByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
        List<Map> data = recordPage.getItems();
        if (data != null && data.size() > 0) {
            this.idToName(data, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, "business_type_id:name as businessType");
            this.idToName(data, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "product_id:name as product_name");
            this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name as create_uid,dept_name");
            for (Map protocol : data) {
                if (protocol.get("sign_node") != null) {
                    protocol.put("sign_node", commonBussUtil.getSignNodeName(Integer.valueOf(protocol.get("sign_node").toString()), Integer.valueOf(protocol.get("business_type_id").toString())));
                }
            }
        }
        return createSuccessJsonResonse(recordPage);
    }

    /**
     * 业务类型界面值绑定
     *
     * @return
     * @throws Exception
     */
    private List<FormField> buidField() throws Exception {
        List<FormField> formFieldList = new ArrayList<>();
        List businessTypeList = Lists.newArrayList();
        List<Map> types = getBusinessTypes();
        for (Map item : types) {
            businessTypeList.add(new FormOption(item.get("name").toString(), item.get("id")));
        }
        formFieldList.add(FormField.builder().name("name").text("合同名称").verify("required").build());
        formFieldList.add(FormField.builder().name("businessTypeId").text("业务类型").type("select").options(businessTypeList).verify("required").build());
        formFieldList.add(FormField.builder().name("content").text("模板内容").type("ueditor").verify("required").build());
        formFieldList.add(FormField.builder().name("detail").type("texturl").text("编辑说明").build());
        return formFieldList;
    }

    /**
     * 添加业务类型
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "add")
    public ModelAndView add() throws Exception {
        List<FormField> formFieldList = buidField();
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/businessTemplate/save", formFieldList);
        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存新增业务类型
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "save")
    public DyResponse save(ProdTemplate template, HttpServletRequest request) throws Exception {
        template.setProdTemplateType(TemplateType.BUSINESS.getIndex());
        template.setContent(request.getParameter("content"));
        this.insert(SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, template);
        return createSuccessJsonResonse(null, "添加成功！");
    }

    /**
     * 编辑业务类型
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "edit")
    public ModelAndView edit(Long id) throws Exception {
        List<FormField> formFieldList = Lists.newArrayList();
        ProdTemplate template = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, ProdTemplate.class);
        ProdProductInfo product = this.getById(template.getProductId(), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
        formFieldList.add(FormField.builder().name("name").text("合同名称").verify("required").build());
        formFieldList.add(FormField.builder().name("businessType2").br("br").text("业务类型").type("span").build());
        formFieldList.add(FormField.builder().name("productName").br("br").text("产品名称").type("span").build());
        formFieldList.add(FormField.builder().name("signNode2").text("签署节点").type("span").br("br").build());
        formFieldList.add(FormField.builder().name("signTarget1").text("签署对象").type("span").br("br").build());
        formFieldList.add(FormField.builder().name("signType1").text("签署类型").type("select").verify("required").options("sign_type_1").br("br").build());
        formFieldList.add(FormField.builder().name("signDesc").text("签署描述").type("input").br("br").build());
        formFieldList.add(FormField.builder().name("content").text("模板内容").br("br").type("ueditor").verify("required").build());
        formFieldList.add(FormField.builder().name("content").text("业务字段").br("br").type("texturl").build());
        Map<String, Object> formStruct = Maps.newHashMap();
        formStruct.put("name", template.getName());
        formStruct.put("productName", product.getName());
        String stepKey = "buss_step_" + product.getBusinessTypeId();
        QueryItem queryItem = new QueryItem(Where.eq("value", template.getSignNode()));
        queryItem.setWhere(Where.eq("type", stepKey));
        SysDict dict = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_DICT, SysDict.class);
        formStruct.put("signNode2", dict.getLabel());
        String[] target = template.getSignTarget().split(",");
        String tar = "";
        for (String t : target) {
            tar += DictUtils.getDictLabel(t, "sign_target") + ",";
        }
        formStruct.put("signTarget1", tar.length() > 0 ? tar.substring(0, tar.length() - 1) : "");
        formStruct.put("signType1", template.getSignType1());
        formStruct.put("content", template.getContent());
        formStruct.put("signDesc", template.getSignDesc());
        formStruct.put("businessType2", this.getById(product.getBusinessTypeId(), SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class).getName());
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/businessTemplate/update?id=" + id, formFieldList, formStruct);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新合同模板
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update")
    public DyResponse update(ProdTemplate template, HttpServletRequest request) throws Exception {
        template.setContent(request.getParameter("content"));
        this.update(SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, template);
        return createSuccessJsonResonse(null, "更新成功");
    }

    /**
     * 编辑公共类型
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "editCommon")
    public ModelAndView editCommon(Long id) throws Exception {
        List<FormField> formFieldList = Lists.newArrayList();
        ProdTemplate template = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, ProdTemplate.class);
        formFieldList.add(FormField.builder().name("name").text("合同名称").verify("required").build());
        formFieldList.add(FormField.builder().name("signType1").text("签署类型").type("select").verify("required").options("sign_type_1").br("br").build());
        formFieldList.add(FormField.builder().name("content").text("模板内容").br("br").type("ueditor").verify("required").build());
        formFieldList.add(FormField.builder().name("content").text("业务字段").br("br").type("texturl").build());
        Map<String, Object> formStruct = Maps.newHashMap();
        formStruct.put("name", template.getName());
        formStruct.put("content", template.getContent());
        formStruct.put("signType1", template.getSignType1());
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/businessTemplate/updateCommon/" + id, formFieldList, template);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新公共合同模板
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "updateCommon/{id}")
    public DyResponse updateCommon(@PathVariable("id") Long id, ProdTemplate template, HttpServletRequest request) throws Exception {
        template.setId(id);
        template.setContent(request.getParameter("content"));
        this.update(SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, template);
        return createSuccessJsonResonse(null, "更新成功");
    }

    /**
     * 删除合同模板
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "del")
    public DyResponse del(Long id) throws Exception {
        if (id != null) {
            this.deleteById(id, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
        } else {
            return createErrorJsonResonse("删除失败");
        }
        return createSuccessJsonResonse(null, "删除成功");
    }

}