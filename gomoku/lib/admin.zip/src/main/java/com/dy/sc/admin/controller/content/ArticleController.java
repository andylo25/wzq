package com.dy.sc.admin.controller.content;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.OrgUser;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.ArticleStatus;
import com.dy.sc.entity.enumeration.CommonStatus;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.system.Article;
import com.dy.sc.entity.system.ArticleType;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * 公告管理
 * @ClassName: ArticleController 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年7月3日 上午11:56:53 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Controller
@RequestMapping("/sys/article/")
public class ArticleController extends AdminBaseController{

    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="list/{type}",method=RequestMethod.GET)
    public ModelAndView list(@PathVariable("type")int type) throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "name","article_type","real_name","article_status","on_top","create_time"});
		tableHeader.setTexts(new String[]{"ID", "公告标题","分类名称","发布人","状态","是否置顶","发布日期"});
		tableHeader.setTypes(new String[]{"int","","", "","","",""});
		tableHeader.setOptionTypes(new String[]{"","","", "","","common_status",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"name"});
		search.setTexts(new String[]{"公告标题"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("sys/article/listData/"+type,"sys/article/view", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 
     * 列表数据
     * @param page
     * @param limit
     * @param search
     * @param type 0-公告管理 1-新闻公告
     * @return
     * @throws Exception
     * @author likf
     */
	@SuppressWarnings({"rawtypes" })
    @ResponseBody
	@RequestMapping(value="listData/{type}",method=RequestMethod.POST)
	public DyResponse listData(Integer page,Integer limit,String search,@PathVariable("type")int type) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,name,article_type_id,create_uid,article_status,on_top,create_time");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("name", search));
		}
		//新闻公告不显示草稿
		if(type==1){
		    queryItem.setWhere(Where.eq("article_status", ArticleStatus.RELEASE.getIndex()));
		}
		queryItem.setWhere(Where.eq("del_flag",0));
		queryItem.setOrders("on_top desc,id desc");
		Page<Map> pageData=getPageByMap(queryItem, Module.SYSTEM, SCFunction.SYS_ARTICLE);
		List<Map> listData=pageData.getItems();
		if(listData!=null&&listData.size()>0){
		    dataConvert(listData, "article_status", "create_time");
		    this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE, "article_type_id:article_type");
		    this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name");
		}
		return createSuccessJsonResonse(pageData);
	}
	
	/**
	 * 编辑新增页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="add",method=RequestMethod.GET)
	public ModelAndView add() throws Exception {
		
		List<FormField> formFieldList = buidFormField();
		
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/article/save", formFieldList);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	private List getArticleTypeList(){
	    QueryItem queryItem=new QueryItem();
	    queryItem.setFields("id,article_type");
	    queryItem.setWhere(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
	    List result=Lists.newArrayList();
	    try {
            List<Map> list=this.getListByMap(queryItem, Module.SYSTEM, SCFunction.SYS_ARTICLE_TYPE);
            for(Map item:list){
                result.add(new FormOption(item.get("article_type").toString(), item.get("id")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
	}

	@SuppressWarnings("unchecked")
    private List<FormField> buidFormField() {
		List<FormField> formFieldList = new ArrayList<>();
		formFieldList.add(FormField.builder().name("name").text("公告标题").verify("required").clasz("input-size-big").build());
		formFieldList.add(FormField.builder().name("content").text("公告内容").type("ueditor").verify("required").build());
		formFieldList.add(FormField.builder().name("articleTypeId").text("类型名称").type("select").options(getArticleTypeList()).verify("required").build());
		
		formFieldList.add(FormField.builder().name("articleStatus").text("状态").type("radio").options(DictUtils.getOptionsInt("article_status")).verify("required").build());
		List options=Lists.newArrayList();
		Map optionItem=Maps.newHashMap();
		optionItem.put("text", "是否置顶");
		optionItem.put("value", 1);
		//optionItem.put("name", "onTop");
		options.add(optionItem);
		
		formFieldList.add(FormField.builder().name("onTop").text("是否置顶").type("checkbox").options(options).build());
		return formFieldList;
	}
	
	/**
	 * 保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="save",method=RequestMethod.POST)
	public DyResponse save(HttpServletRequest request) throws Exception {
	    Article article=new Article();
	    article.setArticleStatus(Integer.parseInt(request.getParameter("articleStatus").toString()));
	    article.setArticleTypeId(Long.parseLong(request.getParameter("articleTypeId").toString()));
	    article.setContent(request.getParameter("content"));
	    article.setName(request.getParameter("name"));
	    String onTopString=request.getParameter("onTop[]");
        if(StringUtils.isNoneBlank(onTopString)){
            article.setOnTop(Integer.parseInt(onTopString));
        }
		this.insert(Module.SYSTEM, SCFunction.SYS_ARTICLE, article);
		return createSuccessJsonResonse(null,"添加成功");
	}
	
	/**
	 * 编辑更新页面
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
    @RequestMapping(value="edit")
	public ModelAndView edit(Long id) throws Exception {

		List<FormField> formFieldList = buidFormField();
		
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("id,name,content,article_type_id as articleTypeId,article_status articleStatus,on_top onTop");
		Map entity = this.getOneByMap(queryItem , Module.SYSTEM, SCFunction.SYS_ARTICLE);
		Integer onTop=Integer.parseInt(entity.get("onTop").toString());
		if(onTop==CommonStatus.TRUE.getIndex()){
		    entity.put("onTop",new Integer[]{onTop});
		}
		
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/article/update", formFieldList,entity);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	private OrgUser getUser(Object userId) throws Exception{
	    if(userId!=null){
	        QueryItem queryItem=new QueryItem();
	        queryItem.setFields("real_name as realName");
	        queryItem.setWhere(Where.eq("id", userId));
	        return this.getOneByEntity(queryItem, SCModule.SYSTEM,SCFunction.SYS_ADMIN,OrgUser.class);
	    }
	    return null;
	}
	
	private String getArticleType(Object articleTypeId) throws Exception{
	    if(articleTypeId!=null){
	        QueryItem queryItem=new QueryItem();
	        queryItem.setFields("article_type");
	        queryItem.setWhere(Where.eq("id", articleTypeId));
	        Map articleType=this.getOneByMap(queryItem, SCModule.SYSTEM,SCFunction.SYS_ARTICLE_TYPE);
	        return (String) articleType.get("article_type");
	    }
	    return null;
	}
	
    @RequestMapping(value="view")
    public ModelAndView view(Long id) throws Exception {

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        queryItem.setFields("id,name,content,article_type_id as articleTypeId,article_status articleStatus,on_top onTop,create_uid,create_time");
        Map entity = this.getOneByMap(queryItem , SCModule.SYSTEM, SCFunction.SYS_ARTICLE);
        OrgUser user=getUser(entity.get("create_uid"));
        if(user!=null)
            entity.put("create_uid", user.getRealName());
        entity.put("article_type", getArticleType(entity.get("articleTypeId")));
        Map<String, Object> result = Maps.newHashMap();
        result.put("form_data", entity);
        return createSuccessModelAndView("system/article/view", JsonUtils.object2JsonString(result));
    }
	
	/**
	 * 更新
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update",method=RequestMethod.POST)
	public DyResponse update(HttpServletRequest request) throws Exception {
	    Long id=Long.parseLong(request.getParameter("id").toString());
	    if(id!=null){
	        Article article=new Article();
	        article.setId(id);
	        article.setArticleStatus(Integer.parseInt(request.getParameter("articleStatus").toString()));
	        article.setArticleTypeId(Long.parseLong(request.getParameter("articleTypeId").toString()));
	        article.setContent(request.getParameter("content"));
	        article.setName(request.getParameter("name"));
	        String onTopString=request.getParameter("onTop[]");
	        if(StringUtils.isNoneBlank(onTopString)){
	            article.setOnTop(Integer.parseInt(onTopString));
	        }else{
	            article.setOnTop(CommonStatus.FALSE.getIndex());
	        }
	        this.update(Module.SYSTEM, SCFunction.SYS_ARTICLE, article);
	    }
		return createSuccessJsonResonse(null,"修改成功");
	}
	
	/**
	 * 删除
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete",method=RequestMethod.POST)
	public DyResponse delete(Long id) throws Exception {
	    Article article=this.getById(id, Module.SYSTEM, SCFunction.SYS_ARTICLE,Article.class);
	    if(article!=null&& !(ArticleStatus.RELEASE.getIndex()==article.getArticleStatus().intValue())){
	        this.deleteById(id, Module.SYSTEM, SCFunction.SYS_ARTICLE);
	    }else if(article!=null){
	        Map<String,Object> data=Maps.newHashMap();
	        data.put("del_flag", AccConstants.DELETE_FLAG);
	        data.put("id", id);
	        this.update(Module.SYSTEM, SCFunction.SYS_ARTICLE, data);
	    }
		return createSuccessJsonResonse(null,"删除成功");
	}
    
}