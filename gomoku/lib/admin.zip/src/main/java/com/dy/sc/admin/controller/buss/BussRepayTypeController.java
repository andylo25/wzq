package com.dy.sc.admin.controller.buss;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/loan")
public class BussRepayTypeController extends AdminBaseController {
	
	/**
	 * 获取借款类型
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/repaytype/list")
	public ModelAndView getRepayTypeList() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "name","status","contents"});
		tableHeader.setTexts(new String[]{"ID", "名称","状态","内容"});
		tableHeader.setTypes(new String[]{"int","", "",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());

		PageStructure data = PageUtil.createTablePageStructure("loan/repayType/listData", "id", tableHeader,tool,null);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取借款类型数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/repayType/listData")
	public DyResponse getRepayTypeListData(Integer page,Integer limit) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		queryItem.setOrders("id");	
		return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_REPAYTYPE),"status:status"));
	}
	
	/**
	 * 编辑更新页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/repaytype/toEdit")
	public ModelAndView toEdit(Long id) throws Exception {
		List<FormField> formFieldList = buidFormField();	
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("id,name,contents,status");
		Map<String, Object> repayTypeMap = this.getOneByMap(queryItem , SCModule.FUND, SCFunction.FUND_REPAYTYPE);
		Map<String, Object> data = PageUtil.createFormPageStructure("loan/repayType/update", formFieldList,repayTypeMap);	
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	private List<FormField> buidFormField() {
		List<FormField> formFieldList = new ArrayList<>();		
		formFieldList.add(FormField.builder().name("name").text("还款方式").verify("required").build());
		
		formFieldList.add(FormField.builder().name("contents").text("内容").type("textarea").verify("required").build());	
		
	
		
		List<FormOption> options = new ArrayList<>();
		options.add(new FormOption("是", "1"));
		options.add(new FormOption("否", "0"));
		formFieldList.add(FormField.builder().name("status").text("是否开启").type("radio").options(options).build());
		return formFieldList;
	}
	/**
	 * 编辑保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/repayType/update")
	public DyResponse updateRepayType(HttpServletRequest request) throws Exception {
		Map<String, Object> paramMap = Maps.newHashMap();
		paramMap.put("contents", request.getParameter("contents"));
		paramMap.put("name", request.getParameter("name"));
		paramMap.put("status", request.getParameter("status"));
		paramMap.put("id", request.getParameter("id"));
		this.update(SCModule.FUND, SCFunction.FUND_REPAYTYPE,paramMap);
		return createSuccessJsonResonse(null,"修改成功");
	}
}