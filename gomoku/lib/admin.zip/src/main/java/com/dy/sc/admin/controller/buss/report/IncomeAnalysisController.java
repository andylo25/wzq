package com.dy.sc.admin.controller.buss.report;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.RowLink;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.service.ReportService;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.ThreadUtils;
import com.dy.core.utils.excel.ExportExcel;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.Role;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * @ClassName: IncomeAnalysisController 
 * 收入统计
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author cuiwenming@diyou.cn
 * @date 2017年8月3日 上午10:41:17
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * cuiwm 
 * </pre>
 */	
@Controller
@RequestMapping("loan/analysis")
public class IncomeAnalysisController extends AdminBaseController {
	
	@Autowired
	ReportService reportService;
	
	/**
	 * 收入统计全部
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="income/all")
	public ModelAndView all() throws Exception {
		
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","rep_date","total_income","income_mom:percent"});
		tableHeader.setTexts(new String[]{"ID","月份","总收入总额","环比"});
		
		List<RowLink> rowLink=Lists.newArrayList();
		rowLink.add(new RowLink("查看明细","loan/analysis/income/detail"));
		rowLink.add(new RowLink("按资方","loan/analysis/income/category/3"));
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"月份"});
		search.setTypes(new String[]{"date"});
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/income/allData", "rep_date", tableHeader,tool,search);
		data.setRowLink(rowLink);
		data.setRowLinkTitle("统计明细");
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:收入统计全部
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="income/allData")
	public DyResponse allData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,rep_date,total_income,income_mom,create_time");
		queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("rep_date", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_INCOME);
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}
	
	/**
	 * 收入明细
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="income/detail")
	public ModelAndView detail(String id) throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","create_time:datetime","company_name","txn_type","amount_in","remark"});
		tableHeader.setTexts(new String[]{"ID","交易时间","企业名称","交易类型:cap_detail_type","收入","备注"});
		
		Tool tool = new Tool();
		tool.setUrl("loan/analysis/income/99/exportExcel");
		tool.setText("导出");
		tool.setType("commonbatchdownload");
		
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/income/detailData?id="+id, "id", tableHeader,tool,null);
		return createSuccessModelAndView("common/table_single_open", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:收入明细
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="income/detailData")
	public DyResponse detailData(Integer page,Integer limit,String id,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,company_id,create_time,txn_type,amount_in,remark");

		Date start = DateUtil.dateParse(id+"01");
		Date end = DateUtil.addSecond(DateUtil.addMonth(start, 1),-1);
		queryItem.setWhere(Where.between("create_time", DateUtil.convert(start), DateUtil.convert(end)));
		queryItem.setWhere(Where.in("txn_type", new Integer[]{AccConstants.CAP_DETAIL_TYPE_SDLX,AccConstants.CAP_DETAIL_TYPE_SQYQF,AccConstants.CAP_DETAIL_TYPE_SDFWF}));
		
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("rep_date", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_DETAIL);
		
		this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}
	
	/**
	 * 生成上月月报
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("income/insert")
	public DyResponse insert() throws Exception {
		
		ThreadUtils.doSync(()->{
			try {
				reportService.createLastMonthIncomeReport(DateUtil.dateShortFormat(DateUtil.addMonth(new Date(), -1)).substring(0, 6),false);
			} catch (Exception e) {
			}
			return null;
		});
		return createSuccessJsonResonse(null,"正在生成，1分钟后刷新查看结果");
	}
	
	/**
	 * 生成上月月报
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("income/update")
	public DyResponse update() throws Exception {
		ThreadUtils.doSync(()->{
			try {
				reportService.createLastMonthIncomeReport(DateUtil.dateShortFormat(DateUtil.addMonth(new Date(), -1)).substring(0, 6),false);
			} catch (Exception e) {
			}
			return null;
		});
		return createSuccessJsonResonse(null,"正在生成，1分钟后刷新查看结果");
	}
	
	/**
	 * 导出excel
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="income/{type}/exportExcel")
	public String exportExcel(HttpServletResponse response,@PathVariable("type") int type,String id) throws Exception{
		String title = "";
		ExportExcel excel = null;
		List<Map> items = null;
		QueryItem queryItem = new QueryItem(Where.in("id", id));
		if(type == 99){// 明细信息
			title = "收入明细记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID","交易时间","企业名称","交易类型","收入","备注"});
			excel.setFieldNames(new String[]{"id","create_time","company_name","txn_type","amount_in","remark"});
			queryItem.setFields("id,company_id,create_time,txn_type,amount_in,remark");
			Page<Map> pagem = getPageByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_DETAIL);
			items = pagem.getItems();
			this.idToName(items, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
			dataConvert(items, "txn_type:cap_detail_type","create_time");
		}else {
			if(type == ScConstants.REP_TYPE_PLAT){
				queryItem = new QueryItem(Where.in("rep_date", id));
				queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
				title = "收入统计记录_"+DateUtil.getCurrentTimeStr();
				excel = new ExportExcel(title, new String[]{"ID","月份","总收入总额","环比(%)"});
				excel.setFieldNames(new String[]{"id","rep_date","total_income","income_mom"});
			}else if(type == ScConstants.REP_TYPE_CAPITAL){
				title = "按资方统计记录_"+DateUtil.getCurrentTimeStr();
				excel = new ExportExcel(title, new String[]{"资方","交易类型","收入总额","占比(%)","环比(%)"});
				excel.setFieldNames(new String[]{"company_name","txn_type","total_income","income_prop","income_mom"});
			}
			queryItem.setFields("id,rep_date,relation_id,txn_type,total_income,income_prop,income_mom,create_time");
			items = (List<Map>) dataConvert(getListByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_INCOME),"txn_type:cap_detail_type");
			
			if(type == ScConstants.REP_TYPE_CAPITAL){
				this.idToName(items, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "relation_id:company_name");
			}
		}
		
		excel.setDataList(items);
		excel.write(response, title+".xlsx");
		
		return null;
	}
	
	/**
	 * 按资方
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="income/category/{type}")
	public ModelAndView category(String id,@PathVariable("type") Integer type) throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"company_name","txn_type","total_income","income_prop:percent","income_mom:percent"});
		tableHeader.setTexts(new String[]{"资方","交易类型:cap_detail_type","收入总额","占比","环比"});

		Tool tool = new Tool();
		tool.setUrl("loan/analysis/income/"+type+"/exportExcel");
		tool.setText("导出");
		tool.setType("commonbatchdownload");
		
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/income/categoryData/"+type+"?id="+id, "id", tableHeader,tool,null);
		return createSuccessModelAndView("common/table_single_open", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:按资方
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="income/categoryData/{type}")
	public DyResponse categoryData(Integer page,Integer limit,String id,@PathVariable("type") Integer type,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,rep_date,relation_id,txn_type,total_income,income_prop,income_mom,create_time");
		queryItem.setWhere(Where.eq("rec_category", type));
		queryItem.setWhere(Where.eq("rep_date", id));
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("rep_date", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, Module.REPORT, SCFunction.MONTH_LOAN_INCOME);
		this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "relation_id:company_name");
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}
	
	
	
	
}