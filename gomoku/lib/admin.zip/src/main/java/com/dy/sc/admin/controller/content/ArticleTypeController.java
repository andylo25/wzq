package com.dy.sc.admin.controller.content;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.ArticleStatus;
import com.dy.sc.entity.enumeration.CommonStatus;
import com.dy.sc.entity.system.Article;
import com.dy.sc.entity.system.ArticleType;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
/**
 * 公告类型
 * @ClassName: ArticleTypeController.java 
 * @Description: TODO 
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author diyou@diyou.cn
 * @date 2017年7月13日下午3:52:51 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * diyou 
 * </pre>
 */	
@Controller
@RequestMapping("/sys/articleType/")
public class ArticleTypeController extends AdminBaseController{

    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "article_type"});
		tableHeader.setTexts(new String[]{"ID", "分类名称"});
		tableHeader.setTypes(new String[]{"int",""});
		tableHeader.setOptionTypes(new String[]{"",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"分类名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("sys/articleType/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 列表数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({"rawtypes" })
    @ResponseBody
	@RequestMapping(value="listData",method=RequestMethod.POST)
	public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,article_type");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("article_type", search));
		}
		queryItem.setWhere(Where.eq("del_flag",0));
		queryItem.setOrders("id");
		Page<Map> pageData=getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE);
		return createSuccessJsonResonse(pageData);
	}
	
	/**
	 * 编辑新增页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="add",method=RequestMethod.GET)
	public ModelAndView add() throws Exception {		
		List<FormField> formFieldList = buidFormField(null);		
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/articleType/save", formFieldList);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	private List getArticleTypeList(Long id){
	    QueryItem queryItem=new QueryItem();
	    queryItem.setFields("id,article_type");
	    List result=Lists.newArrayList();
	    //编辑时排除当前项和当前项的子项
	    if(id!=null){
	    	queryItem.setWhere(Where.notEq("id", id));
	    	queryItem.setWhere(Where.notEq("pid", id));
	    }
	    try {
            List<Map> list=this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE);
            for(Map item:list){
                result.add(new FormOption(item.get("article_type").toString(), item.get("id")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
	}

	@SuppressWarnings("unchecked")
    private List<FormField> buidFormField(Long id) {
		List<FormField> formFieldList = new ArrayList<>();		
		//formFieldList.add(FormField.builder().name("pid").text("上级分类").type("select").options(getArticleTypeList(id)).build());
		formFieldList.add(FormField.builder().name("articleType").text("分类名称").verify("required").build());
		return formFieldList;
	}
	
	/**
	 * 保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="save",method=RequestMethod.POST)
	public DyResponse save(ArticleType articleType) throws Exception {
		this.insert(SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE, articleType);
		return createSuccessJsonResonse(null,"添加成功");
	}
	
	/**
	 * 编辑更新页面
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
    @RequestMapping(value="edit")
	public ModelAndView edit(Long id) throws Exception {
		List<FormField> formFieldList = buidFormField(id);		
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("id,pid,article_type as articleType");
		Map entity = this.getOneByMap(queryItem , SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE);		
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/articleType/update", formFieldList,entity);		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update",method=RequestMethod.POST)
	public DyResponse update(ArticleType articleType) throws Exception {
		if(articleType.getPid()==null){
			articleType.setPid(0l);
		}
	    this.update(SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE, articleType);
		return createSuccessJsonResonse(null,"修改成功");
	}
	
	/**
	 * 删除
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete",method=RequestMethod.POST)
	public DyResponse delete(Long id) throws Exception {
		QueryItem queryItem = new QueryItem(Where.eq("pid", id));
		queryItem.setFields("id,del_flag");
		queryItem.getWhere().add(Where.eq("del_flag",0));
		List<Map> items=this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE);
		//存在子项置为删除
	    if(CollectionUtils.isNotEmpty(items)){
	    	for(Map item:items){
		        item.put("del_flag", AccConstants.DELETE_FLAG);
		        this.update(SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE, item);
	    	}
	    }
        Map<String,Object> data=Maps.newHashMap();
        data.put("del_flag", AccConstants.DELETE_FLAG);
        data.put("id", id);
        this.update(SCModule.SYSTEM, SCFunction.SYS_ARTICLE_TYPE, data);
		return createSuccessJsonResonse(null,"删除成功");
	}
    
}