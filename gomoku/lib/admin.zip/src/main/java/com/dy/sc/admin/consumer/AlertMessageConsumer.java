package com.dy.sc.admin.consumer;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.Email;
import com.dy.core.enumeration.SmsType;
import com.dy.core.event.DyConsumer;
import com.dy.core.event.DyEvent;
import com.dy.core.exception.DyServiceException;
import com.dy.core.service.BaseService;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.EmailUtil;
import com.dy.core.utils.sms.SmsUtil;
import com.dy.ia.entity.common.SysMessageLog;
import com.dy.sc.entity.constant.SCFlow;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.EmailType;
import com.dy.sc.entity.enumeration.MessageType;
import com.dy.sc.entity.enumeration.ReceiverType;
import com.dy.sc.entity.enumeration.TriggerTime;
import com.dy.sc.entity.loan.LoanDebitRecord;
import com.dy.sc.entity.loan.LoanReceiveBill;
import com.dy.sc.entity.loan.LoanRequest;
import com.dy.sc.entity.loan.LoanTransfer;
import com.dy.sc.entity.schedule.ScheTriggerInfo;
import com.google.common.collect.Maps;

/**
 * 
 * 消息提醒
 * @ClassName: AlertMessageConsumer 
 * Copyright (c) 2017
 * 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年8月6日 下午3:57:07 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * 
 * </pre>
 */
@Component
public class AlertMessageConsumer implements DyConsumer{

	@Autowired
	BaseService baseService;
	
	@Override
	public Integer apply() {
		return ScConstants.EVENT_TYPE_3;
	}

	@Override
	public void consume(DyEvent event) throws Exception {
	    Integer triggerTime=event.getSubType();
	    
	    QueryItem queryItem=new QueryItem(SCModule.SCHEDULE,SCFunction.SCHE_SEND_MSG);
	    queryItem.setFields("id,trigger_time,trigger_point,trigger_name");
	    queryItem.setWhere(Where.eq("trigger_time", triggerTime));
	    queryItem.setWhere(Where.eq("status", 1));
	    Map sendMsgMap=baseService.getOne(queryItem);
	    
	    String[] params=(String[]) event.getData();
	    if(!sendMsgMap.isEmpty()){
	        queryItem=new QueryItem(SCModule.SCHEDULE,SCFunction.SCHE_TRIGGER_INFO);
	        queryItem.setWhere(Where.eq("send_msg_id", sendMsgMap.get("id")));
	        List<ScheTriggerInfo> triggers=baseService.getList(queryItem, ScheTriggerInfo.class);
	        for(ScheTriggerInfo trigger:triggers){
	            String[] sendTypes=trigger.getSendType().split(","); //电话 邮箱 站内信
	            
	            Integer tempTriggerTime=MapUtils.getInteger(sendMsgMap,"trigger_time");
	            String title = "";
//	            if(tempTriggerTime>=5)
//	                title=DictUtils.getDictLabel(tempTriggerTime, "trigger_time_c");
//	            else{
//	                title=DictUtils.getDictLabel(sendMsgMap.get("trigger_point"), "trigger_point");
//	            }
				if(sendMsgMap.get("trigger_name") != null) {
					title = sendMsgMap.get("trigger_name").toString();
				}else{
					if(tempTriggerTime>=5)
						title=DictUtils.getDictLabel(tempTriggerTime, "trigger_time_c");
					else{
						title=DictUtils.getDictLabel(sendMsgMap.get("trigger_point"), "trigger_point");
					}
				}
	            //creditName:授信企业名称coreName:核心企业名称contractNo:信贷合同号creditNo:应收账款凭证编号
	            Map<String, String> commonParam=Maps.newHashMap();
	            //cond1,procDefKey,companyName,procName
	            //业务通知
	            if(triggerTime==TriggerTime.AUDIT_REJECT.getIndex()){
	               String cond1=params[0];
	               String procDefKey=params[1];
	               Map<String,Object> contract=getProcContact(procDefKey, cond1, trigger.getReceiverType());
	               String sendContent=trigger.getSendContent();
	               //#contractName#为#contractNo#的#contractName#申请已被驳回，驳回原因：#reason#，驳回人：#rejectUser#，驳回时间#rejectTime#
	               Map<String, String> templateParam=Maps.newHashMap();
	               templateParam.put("#contractName#", params[4]);
	               templateParam.put("#contractNo#", params[5]);
	               templateParam.put("#reason#", params[6]);
	               templateParam.put("#rejectUser#", params[7]);
	               templateParam.put("#rejectTime#", params[8]);
	               if(templateParam != null && templateParam.size() > 0) {
	                    for(String code : templateParam.keySet()) {
	                        sendContent = sendContent.replaceAll(code, templateParam.get(code));
	                    }
	                }
//	             send(sendTypes, contract, title, sendContent);
	                Long userId=null;
	                Long companyId=null;
	                if(contract.get("user_id")!=null)
	                    userId=Long.parseLong(contract.get("user_id").toString());
	                if(contract.get("company_id")!=null){
	                    companyId=Long.parseLong(contract.get("company_id").toString());
	                }
	                title=params[9];
	                Long instId=Long.parseLong(params[10]);
	                sendNotice(cond1,procDefKey,title, sendContent, userId, companyId,MapUtils.getString(contract, "name"),instId);
	              //loanId,companyId,salerId,LoanContractNo,CompanyName
	            }else if(triggerTime==TriggerTime.CREDIT_REJECT.getIndex()||triggerTime==TriggerTime.REALNAME_REJECT.getIndex()){
	               String cond1=params[0];
	               String procDefKey=params[1];
	               Map<String,Object> contract=getProcContact(procDefKey, cond1, trigger.getReceiverType());
		            if(triggerTime==TriggerTime.CREDIT_REJECT.getIndex()){
			            commonParam.put("#creditName#", params[2]);
			            commonParam.put("#coreName#", params[4]);
			            commonParam.put("#contractNo#", params[5]);
			            commonParam.put("#creditNo#", params[6]);
		            }else{
			            commonParam.put("#creditName#", params[2]);
			            commonParam.put("#coreName#","");
			            commonParam.put("#contractNo#","");
			            commonParam.put("#creditNo#","");
		            }
	               send(sendTypes, contract, title, replaceSendContent(commonParam,trigger.getSendContent()));
	            }else if(triggerTime==TriggerTime.PAY_SUCCESS.getIndex()){
	                Map<String,Object> contract=getContact(Long.parseLong(params[0]), params[1], params[2], trigger.getReceiverType());
		            commonParam.put("#creditName#", params[4]);
		            commonParam.put("#coreName#", params[5]);
		            commonParam.put("#contractNo#", params[3]);
		            commonParam.put("#creditNo#", params[6]);
	                send(sendTypes, contract, title, replaceSendContent(commonParam,trigger.getSendContent()));
	              //loanId,companyId,salerId,LoanContractNo,CompanyName,message 
	            }else if(triggerTime==TriggerTime.PAY_FAILURE.getIndex()){
		            commonParam.put("#creditName#", params[4]);
		            commonParam.put("#coreName#", params[6]);
		            commonParam.put("#contractNo#", params[3]);
		            commonParam.put("#creditNo#", params[7]);
	                Map<String,Object> contract=getContact(Long.parseLong(params[0]), params[1], params[2], trigger.getReceiverType());
	                send(sendTypes, contract, title, replaceSendContent(commonParam,trigger.getSendContent()));
	                //loanId,companyId,SalerId,LoanContractNo,companyName,amount
	            }else if(triggerTime==TriggerTime.REPAY_SUCCESS.getIndex()){
		            commonParam.put("#creditName#", params[4]);
		            commonParam.put("#coreName#", params[6]);
		            commonParam.put("#contractNo#", params[3]);
		            commonParam.put("#creditNo#", params[7]);
	                Map<String,Object> contract=getContact(Long.parseLong(params[0]), params[1], params[2], trigger.getReceiverType());
	                send(sendTypes, contract, title, replaceSendContent(commonParam,trigger.getSendContent()));
	            }else if(triggerTime==TriggerTime.RELATION_REJECT.getIndex()){
		            commonParam.put("#creditName#", params[2]);
		            commonParam.put("#coreName#", params[4]);
		            commonParam.put("#contractNo#","");
		            commonParam.put("#creditNo#","");
	                Map<String,Object> contract=getRelationContact(Long.parseLong(params[0]), trigger.getReceiverType());
	                send(sendTypes, contract, title, replaceSendContent(commonParam,trigger.getSendContent()));
	            }    
	        }
	        
	    }
	}
	//授信企业名称，核心企业名称，应收账款凭证编号，信贷合同号
	private String replaceSendContent(Map<String, String> templateParam,String sendContent){
		if(StringUtils.isNotBlank(sendContent)){
	        if(templateParam != null && templateParam.keySet().size() > 0) {
	            for(String code : templateParam.keySet()) {
	                sendContent = sendContent.replaceAll(code, templateParam.get(code));
	            }
	        }
		}
        return sendContent;
	}
	private Map<String,Object> getRelationContact(Long relationId,Integer receiverType) throws DyServiceException{
        Object companyId=null;
        Object salerId=null;
        Map<String,Object> relation=getRelation(relationId);
	    if(receiverType==ReceiverType.CREDIT_COMPANY.getIndex()){
            companyId=relation.get("company_id");
        }else if(receiverType==ReceiverType.CORE_COMPANY.getIndex()){
            companyId=relation.get("core_company_id");
        }else if(receiverType==ReceiverType.SALER.getIndex()){
            salerId=getCompanySalerId(Long.parseLong(relation.get("company_id").toString()));
        }
	    return getContactInfo(companyId, salerId);
	}
	
	private Map<String,Object> getContact(Long loanId,Object companyId,Object salerId,Integer receiverType) throws DyServiceException{
	    if(receiverType==ReceiverType.CREDIT_COMPANY.getIndex()){
            //companyId=transfer.getCompanyId();
	        salerId=null;
        }else if(receiverType==ReceiverType.CORE_COMPANY.getIndex()){
        	//核心企业
        	LoanReceiveBill bill = getReceiverBillByLoanId(loanId);
        	if (bill!= null) {
        		companyId=bill.getBuyerId();
        	}
        }else if(receiverType==ReceiverType.SALER.getIndex()){
            //salerId=getLoanRequestSaler(transfer.getLoanId());
            companyId=null;
        }
	    return getContactInfo(companyId, salerId);
	}
	
	@Autowired
	private SmsUtil smsUtil;
	@Autowired
	private EmailUtil emailUtil;
	
	//0 短信 1-邮件 2-站内信
	private void send(String[] sendTypes,Map<String,Object> contract,String title,String content) throws DyServiceException{
	    for(String sendType:sendTypes){
	        if(sendType.equals("1")){
	            Long userId=null;
	            if(contract.get("user_id")!=null){
	                userId=Long.parseLong(contract.get("user_id").toString());
	            }else if(contract.get("company_id")!=null){
                    userId=Long.parseLong(contract.get("company_id").toString());
                }
	            String.valueOf(contract.get("user_id"));
	            if(contract.get("phone")!=null)
	                smsUtil.send(contract.get("phone").toString(), content, SmsType.ALERT.getIndex(), SmsUtil.SEND_IMMEDIATE, userId, contract.get("name").toString());
	        }else if(sendType.equals("2")){
                //TODO 邮件发送人
	            if(contract.get("email")!=null){
	                Email email = new Email();
	                email.setSubject(title);
	                email.setContent(content);
	                //email.setFrom("admin@diyou.com");
	                email.setTo( new String[]{contract.get("email").toString()});
	                email.setType(EmailType.MESSAGE_ALERT.getIndex());
	                if(contract.get("user_id")!=null){
	                    email.setMemberId(Long.parseLong(contract.get("user_id").toString()));
	                }else if(contract.get("company_id")!=null){
	                    email.setCompanyId(Long.parseLong(contract.get("company_id").toString()));
	                }
	                email.setMemberName((String)contract.get("name"));
	                emailUtil.send(email, EmailUtil.SEND_IMMEDIATE);
	            }
	         }else if(sendType.equalsIgnoreCase("3")){
	            Long userId=null;
	            Long companyId=null;
	            if(contract.get("user_id")!=null)
	                userId=Long.parseLong(contract.get("user_id").toString());
	            if(contract.get("company_id")!=null){
	                companyId=Long.parseLong(contract.get("company_id").toString());
	            }
	            sendSiteMessage(title, content, userId,companyId,MapUtils.getString(contract, "name"));
	        }
	    }
	}
	//业务通知
	private void sendNotice(String cond1,String procDefKey,String title,String content,Long memberId,Long companyId,String name,Long flowInstId) throws DyServiceException{
	    SysMessageLog log=new SysMessageLog();
	    log.setCompanyId(companyId);
	    log.setContents(content);
	    log.setMemberId(memberId);
	    log.setName(name);
	    log.setReadStatus(0);
	    log.setStatus(0);
	    log.setTitle(title);
	    log.setMessageType(MessageType.NOTICE.getIndex());
	    log.setBusinessId(Long.parseLong(cond1));
	    log.setProcDefKey(procDefKey);
	    log.setFlowInstId(flowInstId);
	    baseService.insert(SCModule.SYSTEM,SCFunction.MESSAGE_LOG, log);
	}
	
	private void sendSiteMessage(String title,String content,Long memberId,Long companyId,String name) throws DyServiceException{
	    SysMessageLog log=new SysMessageLog();
	    log.setCompanyId(companyId);
	    log.setName(name);
	    log.setContents(content);
	    log.setMemberId(memberId);
	    log.setReadStatus(0);
	    log.setStatus(0);
	    log.setTitle(title);
	    baseService.insert(SCModule.SYSTEM,SCFunction.MESSAGE_LOG, log);
	}
	
	private Map<String, Object> getCompany(Object id) throws DyServiceException{
	    QueryItem queryItem=new QueryItem(SCModule.SYSTEM,SCFunction.SYS_COMPANY);
	    queryItem.setFields("id as company_id,company_name as name,contact_phone_number as phone,contact_email as email");
	    queryItem.setWhere(Where.eq("id", id));
	    return baseService.getOne(queryItem);
	}
	
	private Map<String, Object> getAdmin(Object id) throws DyServiceException{
	    QueryItem queryItem=new QueryItem(SCModule.SYSTEM,SCFunction.SYS_ADMIN);
	    queryItem.setFields("id as user_id,real_name as name,phone,email");
	    queryItem.setWhere(Where.eq("id", id));
	    return baseService.getOne(queryItem);
	}
	
	private Object getLoanRequestSaler(Long loanId) throws DyServiceException{
        QueryItem queryItem=new QueryItem(SCModule.LOAN,SCFunction.LOAN_REQUEST);
        queryItem.setFields("manager_id");
        queryItem.setWhere(Where.eq("id", loanId));
        return baseService.getOne(queryItem).get("manager_id");
    }
	
	private Map<String, Object> getRelation(Long id) throws DyServiceException{
        QueryItem queryItem=new QueryItem(SCModule.SYSTEM,SCFunction.SYS_COMPANY_RELATION);
        queryItem.setFields("company_id,core_comapny_id");
        queryItem.setWhere(Where.eq("id", id));
        return baseService.getOne(queryItem);
    }
	
	private Object getCompanySalerId(Long companyId) throws DyServiceException{
        QueryItem queryItem=new QueryItem(SCModule.SYSTEM,SCFunction.SYS_COMPANY);
        queryItem.setFields("saler_id");
        queryItem.setWhere(Where.eq("id", companyId));
        return baseService.getOne(queryItem).get("saler_id");
    }
    private Map<String, Object> getContactInfo(Object companyId,Object salerId) throws DyServiceException{
        if(companyId!=null){
            return getCompany(companyId);
        }
        if(salerId!=null){
            return getAdmin(salerId);
        }
        return null;
    }
    
    private Map<String, Object> getContractTransfer(Long id,Integer receiverType) throws DyServiceException{
        Object companyId=null;
        Object salerId=null;
        LoanTransfer transfer=baseService.getOneById(id, SCModule.LOAN,SCFunction.LOAN_TRANSFER, LoanTransfer.class);
        
        if(receiverType==ReceiverType.CREDIT_COMPANY.getIndex()){
            companyId=transfer.getCompanyId();
        }else if(receiverType==ReceiverType.CORE_COMPANY.getIndex()){
            companyId=transfer.getBuyerId();
        }else if(receiverType==ReceiverType.SALER.getIndex()){
            salerId=getLoanRequestSaler(transfer.getLoanId());
        }
        return getContactInfo(companyId, salerId);
    }
    
    private LoanReceiveBill getReceiverBillById(Long id) throws DyServiceException{
        return baseService.getOneById(id, SCModule.LOAN,SCFunction.LOAN_RECEIVE_BILL, LoanReceiveBill.class);
    }
    
    private LoanReceiveBill getReceiverBillByLoanId(Long loanId) throws DyServiceException{
        QueryItem queryItem=new QueryItem(SCModule.LOAN,SCFunction.LOAN_RECEIVE_BILL);
        queryItem.setWhere(Where.eq("loan_id", loanId));
        List<LoanReceiveBill> bills = baseService.getList(queryItem,LoanReceiveBill.class); 
        return bills != null && bills.size() > 0 ? bills.get(0) : null;
    }
    
    private Map<String, Object> getContractReceiverBill(LoanReceiveBill receiveBill,Integer receiverType) throws DyServiceException{
        Object companyId=null;
        Object salerId=null;
        if(receiverType==ReceiverType.CREDIT_COMPANY.getIndex()){
            companyId=receiveBill.getCompanyId();
        }else if(receiverType==ReceiverType.CORE_COMPANY.getIndex()){
            companyId=receiveBill.getBuyerId();
        }else if(receiverType==ReceiverType.SALER.getIndex()){
            salerId=getLoanRequestSaler(receiveBill.getLoanId());
        }
        return getContactInfo(companyId, salerId);
    }
    
    private Map<String, Object> getContractDebit(Long id,Integer receiverType) throws DyServiceException{
        Object companyId=null;
        Object salerId=null;
        LoanDebitRecord receiveBill=baseService.getOneById(id, SCModule.LOAN,SCFunction.LOAN_DEBIT_RECORD, LoanDebitRecord.class);
        if(receiverType==ReceiverType.CREDIT_COMPANY.getIndex()){
            companyId=receiveBill.getCompanyId();
        }else if(receiverType==ReceiverType.CORE_COMPANY.getIndex()){
        	//核心企业
        	LoanReceiveBill bill = getReceiverBillByLoanId(receiveBill.getLoanId());
        	if (bill!= null) {
        		companyId=bill.getBuyerId();
        	}
        }else if(receiverType==ReceiverType.SALER.getIndex()){
            salerId=getLoanRequestSaler(receiveBill.getLoanId());
        }
        return getContactInfo(companyId, salerId);
    }
    
    private Map<String, Object> getContractRequest(Long id,Integer receiverType) throws DyServiceException{
        Object companyId=null;
        Object salerId=null;
        LoanRequest request=baseService.getOneById(id, SCModule.LOAN,SCFunction.LOAN_REQUEST, LoanRequest.class);
        if(receiverType==ReceiverType.CREDIT_COMPANY.getIndex()){
            companyId=request.getCompanyId();
        }else if(receiverType==ReceiverType.CORE_COMPANY.getIndex()){
            //核心企业
        	LoanReceiveBill bill = getReceiverBillByLoanId(request.getId());
        	if (bill!= null) {
        		companyId=bill.getBuyerId();
        	}
        }else if(receiverType==ReceiverType.SALER.getIndex()){
            salerId=request.getManagerId();
        }
        return getContactInfo(companyId, salerId);
    }
	
    /**
     * 
     * 获取联系方式 (id,phone,email)
     * @param procDefKey
     * @param cond1
     * @param receiverType
     * @return
     * @throws DyServiceException
     * @author likf
     */
	private Map<String, Object> getProcContact(String procDefKey,String cond1,Integer receiverType) throws DyServiceException{
	    Long id=Long.parseLong(cond1);
	    Map<String,Object> result=null;
        
	    switch (procDefKey) {
	        //出质转让id
	        case SCFlow.FLOW_CHUZHI:
	            result=getContractTransfer(id, receiverType);
	            break;
	         //应收账款id
	        case SCFlow.FLOW_HUAIZHANG:
	            result=getContractReceiverBill(getReceiverBillById(id), receiverType);
	            break;
	        //借贷合同id
	        case SCFlow.FLOW_JIEDAI:
	            result=getContractDebit(id, receiverType);
	            break;
	        //借贷合同id
	        case SCFlow.FLOW_QINGKUAN:
	            result=getContractDebit(id, receiverType);
	            break;
	        //企业id
	        case SCFlow.FLOW_SHIMING:
	            result = getContactInfo(id,null);
	            break;
	        //质押合同id
	        case SCFlow.FLOW_ZHIYA:
	            result=getContractRequest(id, receiverType);
	            break;
	        //应收账款id
	        case SCFlow.FLOW_ZHUIZHANG:
	            result=getContractReceiverBill(getReceiverBillById(id), receiverType);
	            break;

            default:
                break;
        }
        return result;
	}

	

}
