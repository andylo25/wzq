package com.dy.sc.admin.controller.buss.report;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.RowLink;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.service.ReportService;
import com.dy.core.utils.Constant;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.ListUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.ThreadUtils;
import com.dy.core.utils.excel.ExportExcel;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.Role;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * @ClassName: NewBussAnalysisController 
 * 新增业务统计
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author cuiwenming@diyou.cn
 * @date 2017年8月3日 上午10:41:17
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * cuiwm 
 * </pre>
 */	
@Controller
@RequestMapping("loan/analysis")
public class NewBussAnalysisController extends AdminBaseController {
	
	@Autowired
	ReportService reportService;
	
	/**
	 * 新增业务统计全部
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="newbuss/all/{tab}")
	public ModelAndView newBussAll(@PathVariable("tab") int tab) throws Exception {
		
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","rep_date","loan_count","total_amount","total_pay","toback_count","toback_amount"});
		tableHeader.setTexts(new String[]{"ID","月份","新增件数","放贷总额（元）","拨款总额（元）","月末在贷件数","月末待回总额"});
		
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"月份"});
		search.setTypes(new String[]{"date"});
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/newbuss/allData/"+tab, "rep_date", tableHeader,tool,search);
		
		List<RowLink> rowLink=Lists.newArrayList();
		if(tab == 0){
			rowLink.add(new RowLink("新增明细","loan/analysis/newbuss/detail"));
			rowLink.add(new RowLink("按业务类型","loan/analysis/newbuss/category/4"));
			rowLink.add(new RowLink("按部门","loan/analysis/newbuss/category/5"));
			rowLink.add(new RowLink("按客户经理","loan/analysis/newbuss/category/6"));
			rowLink.add(new RowLink("按资方","loan/analysis/newbuss/category/3"));
			
			data.setRowLink(rowLink);
			data.setRowLinkTitle("统计明细");
		}
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:新增业务统计全部
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="newbuss/allData/{tab}")
	public DyResponse newBussAllData(Integer page,Integer limit,String search,@PathVariable("tab") int tab) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,rep_date,relation_id,loan_count,total_amount,total_pay,toback_count,toback_amount");
		if(tab == 0){
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
		}else if(tab == 1){
			// 我的部门
			OrgUser user = getAdminUser();
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_DEPT_ALL));
			queryItem.setWhere(Where.eq("relation_id", user.getDeptId()));
		}else if(tab == 2){
			// 我的业务
			OrgUser user = getAdminUser();
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_SALER_ALL));
			queryItem.setWhere(Where.eq("relation_id", user.getId()));
		}
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("rep_date", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_MONEY);
		
		return createSuccessJsonResonse(dataConvert(pagem));
		
	}
	
	/**
	 * 新增明细
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="newbuss/detail")
	public ModelAndView newbussDetail(String id) throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","create_time:datetime","loan_contract_no","company_id","business_type","product_id","principal_total","capital_id","transfer_total","interest_total","fee_total","sales_uid","dept_id"});
		tableHeader.setTexts(new String[]{"ID","进件时间","信贷合同号","客户名称:credit_com","业务类型:business_type","产品名称:product_list","贷款金额","资方:capital_com","实际拨款金额","利息","服务费","客户经理:manager","所属部门:sc_dept"});
		
		Tool tool = new Tool();
		tool.setUrl("loan/analysis/newbuss/99/exportExcel?id=" + id);
		tool.setText("导出");
		tool.setType("commonbatchdownload");

		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"信贷合同号"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/newbuss/detailData?id="+id, "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single_open", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:新增明细
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="newbuss/detailData")
	public DyResponse newbussDetailData(Integer page,String id,Integer limit,String search) throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,debit_id,create_time,loan_contract_no,company_id,principal_total,transfer_total,interest_total,fee_total");
		Date start = DateUtil.dateParse(id+"01");
		Date end = DateUtil.addSecond(DateUtil.addMonth(start, 1),-1);
		queryItem.setWhere(Where.between("create_time", DateUtil.convert(start), DateUtil.convert(end)));
		
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("loan_contract_no", search));
		}
		
		queryItem.setOrders(" create_time desc");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAY);
		
		this.idToName(pagem.getItems(), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:business_type,product_id,capital_id,sales_uid");
		this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "sales_uid:dept_id");
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}
	
	/**
	 * 生成上月月报
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("newbuss/insert")
	public DyResponse newbussInsert() throws Exception {
		
		ThreadUtils.doSync(()->{
			try {
				reportService.createLoanMoneyReport(DateUtil.dateShortFormat(DateUtil.addMonth(new Date(), -1)).substring(0, 6),false);
			} catch (Exception e) {
			}
			return null;
		});
		return createSuccessJsonResonse(null,"正在生成，1分钟后刷新查看结果");
	}
	
	/**
	 * 更新上月月报
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("newbuss/update")
	public DyResponse update() throws Exception {
		ThreadUtils.doSync(()->{
			try {
				reportService.createLoanMoneyReport(DateUtil.dateShortFormat(DateUtil.addMonth(new Date(), -1)).substring(0, 6),true);
			} catch (Exception e) {
			}
			return null;
		});
		return createSuccessJsonResonse(null,"正在生成，1分钟后刷新查看结果");
	}
	
	/**
	 * 导出excel
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="newbuss/{type}/exportExcel")
	public String exportExcel(HttpServletResponse response,@PathVariable("type") int type,String id) throws Exception{
		String title = "";
		ExportExcel excel = null;
		List<Map> items = null;
		// Where.in("id", id)
		QueryItem queryItem = new QueryItem();
		if(type == 99) {//分类统计
			title = "新增明细记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID","进件时间","信贷合同号","客户名称","业务类型","产品名称","贷款金额","资方","实际拨款金额","利息","服务费","客户经理","所属部门"});
			excel.setFieldNames(new String[]{"id","success_time","loan_contract_no","company_id","business_type","product_id","principal_total","capital_id","transfer_total","interest_total","fee_total","sales_uid","dept_id"});
			Date start = DateUtil.dateParse(id+"01");
			Date end = DateUtil.addSecond(DateUtil.addMonth(start, 1),-1);
			queryItem.setWhere(Where.between("create_time", DateUtil.convert(start), DateUtil.convert(end)));
			queryItem.setFields("id,debit_id,success_time,loan_contract_no,company_id,principal_total,transfer_total,interest_total,fee_total");
			items = getListByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAY);
			
			this.idToName(items, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:business_type,product_id,capital_id,sales_uid");
			this.idToName(items, SCModule.SYSTEM, SCFunction.SYS_ADMIN, "sales_uid:dept_id");
			dataConvert(items,"company_id:credit_com,business_type,product_id:product_list,capital_id:capital_com,sales_uid:manager,dept_id:sc_dept","success_time");
		}else{
			String status = "";
			queryItem = new QueryItem(Where.eq("rec_category", type));
			if(type == ScConstants.REP_TYPE_PLAT){//总统计
				queryItem = new QueryItem(Where.in("rep_date", id));
				queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
				title = "新增业务统计记录_"+DateUtil.getCurrentTimeStr();
				excel = new ExportExcel(title, new String[]{"ID","月份","新增件数","放贷总额（元）","拨款总额（元）","月末在贷件数","月末待回总额"});
				excel.setFieldNames(new String[]{"id","rep_date","loan_count","total_amount","total_pay","toback_count","toback_amount"});
			}else if(type == ScConstants.REP_TYPE_PROD){
				title = "按业务类型统计记录_"+DateUtil.getCurrentTimeStr();
				excel = new ExportExcel(title, new String[]{"业务类型","产品名称","新增件数","占比(%)","环比(%)","放贷总额（元）","占比(%)","环比(%)","拨款总额（元）","占比(%)","环比(%)"});
				excel.setFieldNames(new String[]{"buss_type","prod_id","loan_count","count_prop","count_mom","total_amount","loan_prop","loan_mom","total_pay","pay_prop","pay_mom"});
			}else if(type == ScConstants.REP_TYPE_DEPT){
				title = "按部门统计记录_"+DateUtil.getCurrentTimeStr();
				excel = new ExportExcel(title, new String[]{"部门名称","业务类型","产品名称","新增件数","占比(%)","环比(%)","放贷总额（元）","占比(%)","环比(%)","拨款总额（元）","占比(%)","环比(%)"});
				excel.setFieldNames(new String[]{"relation_id","buss_type","prod_id","loan_count","count_prop","count_mom:percent","total_amount","loan_prop:percent","loan_mom:percent","total_pay","pay_prop:percent","pay_mom:percent"});
				status = "relation_id:sc_dept,";
			}else if(type == ScConstants.REP_TYPE_SALER){
				title = "按客户经理统计记录_"+DateUtil.getCurrentTimeStr();
				excel = new ExportExcel(title, new String[]{"部门名称","客户经理:manager","业务类型","产品名称","新增件数","占比(%)","环比(%)","放贷总额（元）","占比(%)","环比(%)","拨款总额（元）","占比(%)","环比(%)"});
				excel.setFieldNames(new String[]{"dept_id","relation_id","buss_type","prod_id","loan_count","count_prop","count_mom","total_amount","loan_prop","loan_mom","total_pay","pay_prop","pay_mom"});
				status = "dept_id:sc_dept,";
			}else if(type == ScConstants.REP_TYPE_CAPITAL){
				title = "按资方统计记录_"+DateUtil.getCurrentTimeStr();
				excel = new ExportExcel(title, new String[]{"放款方","新增件数","占比(%)","环比(%)","放贷总额（元）","占比(%)","环比(%)","拨款总额（元）","占比(%)","环比(%)"});
				excel.setFieldNames(new String[]{"relation_id","loan_count","count_prop","count_mom","total_amount","loan_prop","loan_mom","total_pay","pay_prop","pay_mom"});
				status = "relation_id:capital_com,";
			}
			
			queryItem.setFields("id,rep_date,relation_id,buss_type,prod_id,loan_count,total_amount,total_pay,count_prop,count_mom,loan_prop,loan_mom,pay_prop,pay_mom");
			items = (List<Map>) dataConvert(getListByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_MONEY),status+"buss_type:business_type,prod_id:product_list");
		}
		
//		queryItem.setOrders("id desc");
		excel.setDataList(items);
		excel.write(response, title+".xlsx");
		
		return null;
	}
	
	/**
	 * 按业务类型
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="newbuss/category/{type}")
	public ModelAndView newbussType(String id,@PathVariable("type") Integer type) throws Exception {
		TableHeader tableHeader = new TableHeader();
		if(type == ScConstants.REP_TYPE_PROD){
			tableHeader.setNames(new String[]{"buss_type","prod_name","loan_count","count_prop:percent","count_mom:percent","total_amount","loan_prop:percent","loan_mom:percent","total_pay","pay_prop:percent","pay_mom:percent"});
			tableHeader.setTexts(new String[]{"业务类型:business_type","产品名称","新增件数","占比","环比","放贷总额（元）","占比","环比","拨款总额（元）","占比","环比"});
		}else if(type == ScConstants.REP_TYPE_DEPT){
			tableHeader.setNames(new String[]{"relation_id","buss_type","prod_name","loan_count","count_prop:percent","count_mom:percent","total_amount","loan_prop:percent","loan_mom:percent","total_pay","pay_prop:percent","pay_mom:percent"});
			tableHeader.setTexts(new String[]{"部门名称:sc_dept","业务类型:business_type","产品名称","新增件数","占比","环比","放贷总额（元）","占比","环比","拨款总额（元）","占比","环比"});
		}else if(type == ScConstants.REP_TYPE_SALER){
			tableHeader.setNames(new String[]{"dept_id","relation_id","buss_type","prod_name","loan_count","count_prop:percent","count_mom:percent","total_amount","loan_prop:percent","loan_mom:percent","total_pay","pay_prop:percent","pay_mom:percent"});
			tableHeader.setTexts(new String[]{"部门名称:sc_dept","客户经理:manager","业务类型:business_type","产品名称","新增件数","占比","环比","放贷总额（元）","占比","环比","拨款总额（元）","占比","环比"});
		}else if(type == ScConstants.REP_TYPE_CAPITAL){
			tableHeader.setNames(new String[]{"relation_id","loan_count","count_prop:percent","count_mom:percent","total_amount","loan_prop:percent","loan_mom:percent","total_pay","pay_prop:percent","pay_mom:percent"});
			tableHeader.setTexts(new String[]{"放款方:capital_com","新增件数","占比","环比","放贷总额（元）","占比","环比","拨款总额（元）","占比","环比"});
		}
		
		Tool tool = new Tool();
		tool.setUrl("loan/analysis/newbuss/"+type+"/exportExcel");
		tool.setText("导出");
		tool.setType("commonbatchdownload");
		
		PageStructure data = PageUtil.createTablePageStructure("loan/analysis/newbuss/categoryData/"+type+"?id="+id, "id", tableHeader,tool,null);
		String view = "common/table_single_open";
		if(type == ScConstants.REP_TYPE_PROD){
			view = "loan/report/prod";
		}else if(type == ScConstants.REP_TYPE_SALER){
			view = "loan/report/prod";
		}else if(type == ScConstants.REP_TYPE_DEPT){
			view = "loan/report/prod";
		}
		return createSuccessModelAndView(view, JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:按业务类型
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="newbuss/categoryData/{type}")
	public DyResponse categoryData(Integer page,String id,@PathVariable("type") Integer type,Integer limit,String search) throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,rep_date,relation_id,buss_type,prod_id,loan_count,total_amount,total_pay,count_prop,count_mom,loan_prop,loan_mom,pay_prop,pay_mom");

		queryItem.setWhere(Where.eq("rec_category", type));
		queryItem.setWhere(Where.eq("rep_date", id));
		
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("rep_date", search));
		}
		
		queryItem.setOrders("id");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_MONEY);
		
		if(type == ScConstants.REP_TYPE_SALER){
			this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "relation_id:dept_id");
		}
		
		if(type == ScConstants.REP_TYPE_PROD){
			buildBussType(pagem,"buss_type","prod_id");
		}else if(type == ScConstants.REP_TYPE_SALER){
			buildBussType(pagem,"dept_id","relation_id");
		}else if(type == ScConstants.REP_TYPE_DEPT){
			buildBussType(pagem,"relation_id","buss_type");
		}
		
		return createSuccessJsonResonse(dataConvert(pagem));
	}

	private void buildBussType(Page<Map> pagem,String pkey,String heji) throws Exception {
		this.idToName(pagem.getItems(), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "prod_id:name as prod_name");
		
		//TODO:bug按照产品名称合并后，部门名称只能取一个，这样按部门统计就有问题了，得扩展这个方法
		// 合并相同产品名称
		pagem.setItems(ListUtils.mathMerge(pagem.getItems(), "relation_id,buss_typ,prod_name", "loan_count,total_amount,total_pay,count_prop,count_mom,loan_prop,loan_mom,pay_prop,pay_mom"));
		
		// 合计
		List<Map> items = Lists.newArrayList();
		Map<String,List<Map>> buss = Maps.newTreeMap();
		
		for(Map map:pagem.getItems()){
			String relation_id = map.get(pkey).toString();
			if(relation_id != null){
				List<Map> prods = buss.get(relation_id);
				if(prods == null){
					prods = Lists.newArrayList();
					buss.put(relation_id, prods);
				}
				prods.add(map);
			}
		}
		
		for(Entry<String, List<Map>> entry:buss.entrySet()){
			Map<String, Object> item = Maps.newHashMap();
			List<Map> prods = entry.getValue();
			item.put(pkey, entry.getKey());
			item.put(heji, "合计");
			BigDecimal loan_count = BigDecimal.ZERO;
			BigDecimal total_amount = BigDecimal.ZERO;
			BigDecimal total_pay = BigDecimal.ZERO;
			
			for(Map prod:prods){
				loan_count = NumberUtils.add(new BigDecimal(prod.get("loan_count").toString()),loan_count);
				total_amount = NumberUtils.add(new BigDecimal(prod.get("total_amount").toString()),total_amount);
				total_pay = NumberUtils.add(new BigDecimal(prod.get("total_pay").toString()),total_pay);
			}
			
			item.put("loan_count", loan_count.intValue());
			item.put("total_amount", total_amount);
			item.put("total_pay", total_pay);
			item.put("info", prods);
			items.add(item);
		}
		
		pagem.setItems(items);
	}
	
	
	
	
}