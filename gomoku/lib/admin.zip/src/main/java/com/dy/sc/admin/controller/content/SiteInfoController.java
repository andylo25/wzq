package com.dy.sc.admin.controller.content;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.bussmodule.utils.CommonLoanUtil;
import com.dy.sc.entity.common.SystemInfo;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Maps;

/**
 * 网站信息管理
 */
@Controller
@RequestMapping("content/side")
public class SiteInfoController extends AdminBaseController {
	/**
	 * 列表
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="list")
	public ModelAndView getPageInfo() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "site_name", "description", "company_name"});
		tableHeader.setTexts(new String[]{"ID", "网站名称", "平台名称", "公司名称"});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		PageStructure data = PageUtil.createTablePageStructure("content/side/listData", "id", tableHeader, tool, null);
		
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 列表数据
	 * @return
	 */
	@SuppressWarnings({"rawtypes"})
	@ResponseBody
	@RequestMapping(value="listData")
	public DyResponse getPageData (Integer page, Integer limit) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setWhere(Where.eq("style_type", 0));
		Page<Map> rlt = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.BASE_CONFIG);
		return createSuccessJsonResonse(rlt);
	}
	
	/**
	 * 编辑网站信息
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(Long id) throws Exception {

		SystemInfo systemInfo = this.getById(id, SCModule.SYSTEM, SCFunction.BASE_CONFIG, SystemInfo.class);
		
		List<FormField> formFieldList = new ArrayList<>();
		formFieldList.add(FormField.builder().name("keywords").text("网站seo").verify("required").build());
//		formFieldList.add(FormField.builder().name("title").text("网站标题").verify("required").build());
		formFieldList.add(FormField.builder().name("siteName").text("网站名称").verify("required").build());
		formFieldList.add(FormField.builder().name("siteIco").text("网站图标").type("upload").build());
		formFieldList.add(FormField.builder().name("serviceTel").text("网站电话").verify("required").build());
		formFieldList.add(FormField.builder().name("siteLogo").text("logo").type("upload").build());
		formFieldList.add(FormField.builder().name("description").text("平台名称").verify("required").build());
		formFieldList.add(FormField.builder().name("siteLicenseNumber").text("备案信息").verify("required").build());
		formFieldList.add(FormField.builder().name("siteCopyright").text("版权").verify("required").build());
		formFieldList.add(FormField.builder().name("companyName").text("公司名称").verify("required").build());
		
		Map<String, Object> data = PageUtil.createFormPageStructure("content/side/edit", formFieldList, systemInfo);
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}

	/**
	 * 保存网站信息
	 * 
	 * @param businessType
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@ResponseBody
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public DyResponse save(SystemInfo systemInfo) throws Exception {
		
		if (StringUtils.isBlank(systemInfo.getSiteIco()) || StringUtils.isBlank(systemInfo.getSiteLogo())) {
			return createErrorJsonResonse("请上传图片!");
		}
		
		Map data = Maps.newHashMap();
		
		Map ico = CommonLoanUtil.getDocument(systemInfo.getSiteIco());
		if (ico != null) {
			data.put("site_ico", ico.get("file_path"));
		}
		
		Map logo = CommonLoanUtil.getDocument(systemInfo.getSiteLogo());
		if (logo != null) {
			data.put("site_logo", logo.get("file_path"));
		}
		
		data.put("id", systemInfo.getId());
		data.put("keywords", systemInfo.getKeywords());
		data.put("title", systemInfo.getTitle());
		data.put("site_name", systemInfo.getSiteName());
		data.put("service_tel", systemInfo.getServiceTel());
		data.put("description", systemInfo.getDescription());
		data.put("site_license_number", systemInfo.getSiteLicenseNumber());
		data.put("site_copyright", systemInfo.getSiteCopyright());
		data.put("company_name", systemInfo.getCompanyName());
		
		this.update(SCModule.SYSTEM, SCFunction.BASE_CONFIG, data);
		return createSuccessJsonResonse(null,"修改网站信息成功");
	}
}