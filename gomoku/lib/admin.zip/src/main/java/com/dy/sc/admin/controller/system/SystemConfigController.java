package com.dy.sc.admin.controller.system;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.cache.SysCache;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.SysSystemConfig;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Lists;

@Controller
@RequestMapping("/system/config")
public class SystemConfigController extends AdminBaseController {
	
	@Autowired
	private SysCache sysCache;
	
	/**
	 * 系统设置信息
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="list")
	public ModelAndView configList() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","nid", "name","status"});
		tableHeader.setTexts(new String[]{"ID","映射键", "功能名称", "状态"});
		
		Tool tool = new Tool();
		tool.setList(buildTools());	
		Search search = new Search();
		search.setNames(new String[]{"name"});
		search.setTexts(new String[]{"功能名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("system/config/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取系统设置数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="listData")
	public DyResponse configListData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("name", search));
		}
//		queryItem.setWhere(Where.eq("nid", "use_cloudsign"));
		queryItem.setOrders("create_time desc");
		Page<Map> rlt = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_CONFIG);
		return createSuccessJsonResonse(dataConvert(rlt,"status",""));
	}
	
	/**
	 * 编辑页面
	 * @return
	 * @throws Exception
	 */
    @RequestMapping(value="edit")
	public ModelAndView edit(Long id) throws Exception {
		List<FormField> formFieldList = Lists.newArrayList();
		SysSystemConfig config = this.getById(id, SCModule.SYSTEM, SCFunction.SYS_CONFIG, SysSystemConfig.class);
		
		formFieldList.add(FormField.builder().name("name").text("功能名称").verify("required").build());
		formFieldList.add(FormField.builder().name("nid").text("映射键").type("span").build());
		if(config.getType() == 1){
			formFieldList.add(FormField.builder().name("value").text("参数值").type("textarea").build());
		}else{
			formFieldList.add(FormField.builder().name("value").text("参数值").build());
		}
		formFieldList.add(FormField.builder().name("status").text("状态").options("status").type("radio").verify("required").build());

		
		Map<String, Object> data = PageUtil.createFormPageStructure("system/config/update", formFieldList, config);
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update",method=RequestMethod.POST)
	public DyResponse update(SysSystemConfig config) throws Exception {
		sysCache.updateConf(config);
//	    this.update(SCModule.SYSTEM, SCFunction.SYS_CONFIG, config);
		return createSuccessJsonResonse(null,"修改成功");
	}
}