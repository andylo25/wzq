package com.dy.sc.admin.controller.insidelimit;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

@Controller
@RequestMapping("/insidelimit/changelog")
public class InsideLimitChangeLogController extends AdminBaseController {

    /**
     * 内部额度变动记录
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView deptDetail() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "create_time", "dept_name", "action_type", "credit_limit", "temp_limit", "remark"});
        tableHeader.setTexts(new String[]{"ID", "时间", "部门名称", "类型", "授信限额", "临时额度", "摘要"});
        tableHeader.setTypes(new String[]{"", "datetime", "", "", "", "", ""});
        tableHeader.setOptionTypes(new String[]{"", "", "", "inner_cre_chag_type", "", "", ""});
        tableHeader.setFilters(new String[]{"", "multi_date", "select", "select", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"account_name"});
        search.setTexts(new String[]{"部门名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("insidelimit/changelog/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取数据:内部额度变动记录
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse deptDetailData(Integer page, Integer limit, String search, String create_time, String user_id, String action_type) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        if (StringUtils.isNotBlank(action_type)) {
            queryItem.setWhere(Where.eq("action_type", action_type));
        }
        if (StringUtils.isNotBlank(user_id)) {
            queryItem.setWhere(Where.eq("dept_id", user_id));
        }
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("account_name", search));
        }
        if (StringUtils.isNotBlank(create_time)) {
            queryItem.setWhere(this.addDateWhereCondition(null, "create_time", create_time));
        }
        queryItem.setFields("id,dept_id,action_type,credit_limit,temp_limit,remark,create_time");
        queryItem.setOrders("id desc");
        Page<Map> rlt = getPageByMap(queryItem, SCModule.INSIDELIMIT, SCFunction.CHANGE_LOG);
        this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_DEPT, "dept_id:dept_name");
        return createSuccessJsonResonse(dataConvert(rlt));
    }
}