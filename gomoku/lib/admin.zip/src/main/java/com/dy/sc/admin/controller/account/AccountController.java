package com.dy.sc.admin.controller.account;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.common.OrgUser;
import com.dy.sc.bussmodule.utils.TrustApiUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/account/plat")
public class AccountController extends AdminBaseController {

    @Autowired
    private TrustApiUtil trustApiUtil;

    /**
     * 构建界面结构
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView platList() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "open_bank", "open_name", "account", "acc_balance", "soa_url", "status"});
        tableHeader.setTexts(new String[]{"ID", "开户行", "开户名", "账号", "账户余额", "接口地址", "状态"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"open_bank"});
        search.setTexts(new String[]{"开户行"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("account/plat/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取数据
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse getListData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,open_bank,open_name,account,soa_url,acc_balance,status");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.like("open_bank", "%" + search + "%"));
        }
        queryItem.setWhere(Where.eq("account_type", AccConstants.ACCOUNT_TYPE_MASTER));
        queryItem.setOrders("id");

        return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT), "status"));
    }

    /**
     * 编辑新增页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toAdd")
    public ModelAndView toAdd() throws Exception {

        List<FormField> formFieldList = buidFormField();

        Map<String, Object> data = PageUtil.createFormPageStructure("account/plat/save", formFieldList);

        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    private List<FormField> buidFormField() {
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("openBank").text("开户行").verify("required").build());
        formFieldList.add(FormField.builder().name("openName").text("开户名").verify("required").build());

        formFieldList.add(FormField.builder().name("account").text("账号").verify("required").build());

        List<FormOption> options = new ArrayList<>();
        options.add(new FormOption("是", "1"));
        options.add(new FormOption("否", "0"));
        formFieldList.add(FormField.builder().name("status").text("是否开启").type("radio").options(options).build());
        return formFieldList;
    }

    /**
     * 保存
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "save")
    public DyResponse saveAccount(AccAccount account) throws Exception {
        account.setAccBalance(BigDecimal.ZERO);
        account.setAccountType(AccConstants.ACCOUNT_TYPE_MASTER);
        account.setOpenFullName(account.getOpenBank() + "-" + account.getOpenName());
        this.insert(Module.ACCOUNT, Function.ACC_ACCOUNT, account);
        return createSuccessJsonResonse(null, "添加成功");
    }

    /**
     * 编辑更新页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toEdit")
    public ModelAndView toEdit(Long id) throws Exception {

        List<FormField> formFieldList = buidFormField();

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        queryItem.setFields("id,open_bank as openBank,open_name as openName,account,soa_url as soaUrl,status");
        AccAccount account = this.getOneByEntity(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("account/plat/update", formFieldList, account);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update")
    public DyResponse update(AccAccount accAccount) throws Exception {
        accAccount.setOpenFullName(accAccount.getOpenBank() + "-" + accAccount.getOpenName());
        this.update(Module.ACCOUNT, Function.ACC_ACCOUNT, accAccount);

        accAccount = this.getById(accAccount.getId(), Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        OrgUser user = new OrgUser();
        user.setId(accAccount.getUserId());
        user.setRealName(accAccount.getOpenName());
        this.update(Module.SYSTEM, Function.SYS_ADMIN, user);
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 删除
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "delete")
    public DyResponse delete(Long id) throws Exception {
        if (id != AccConstants.PLAT_ACCOUNT_ID) {
            this.deleteById(id, Module.ACCOUNT, Function.ACC_ACCOUNT);
        }
        return createSuccessJsonResonse(null, "删除成功");
    }

    /**
     * 构建界面结构：客户账户
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("custList")
    public ModelAndView custList() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "username", "real_name", "open_full_name", "account"});
        tableHeader.setTexts(new String[]{"ID", "用户名", "企业名称", "开户行", "账号"});
        tableHeader.setFilters(new String[]{"", "", "input", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"account"});
        search.setTexts(new String[]{"账号"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("account/plat/custListData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取数据:客户账户
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("custListData")
    public DyResponse getCustListData(Integer page, Integer limit, String search, String real_name, String username) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,open_full_name,account,user_id,acc_balance");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("account", search));
        }
        List<Where> whereList = Lists.newArrayList();
        if (StringUtils.isNotBlank(username)) {
            whereList.add(Where.in("user_id", getIdsLike(Module.SYSTEM, Function.SYS_ADMIN, "username", username)));
        }
        if (StringUtils.isNotBlank(real_name)) {
            whereList.add(Where.in("user_id", getIdsLike(Module.SYSTEM, Function.SYS_ADMIN, "real_name", real_name)));
        }
        queryItem.setWhere(Where.setAndList(whereList));
        queryItem.setWhere(Where.eq("account_type", AccConstants.ACCOUNT_TYPE_CHILD));
        queryItem.setOrders("id");
        Page<Map> page2 = getPageByMap(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT);
        this.idToName(page2.getItems(), Module.SYSTEM, Function.SYS_ADMIN, "user_id:username,real_name");
        return createSuccessJsonResonse(page2);
    }

    /**
     * 编辑更新页面:客户账户
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toCustEdit")
    public ModelAndView toCustEdit(Long id) throws Exception {

        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("openName").text("企业名称").type("span").build());

        formFieldList.add(FormField.builder().name("openFullName").text("开户行").type("span").build());

        formFieldList.add(FormField.builder().name("account").text("账号").verify("required").build());

        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        queryItem.setFields("id,open_full_name as openFullName,account,user_id as userId");
        AccAccount account = this.getOneByEntity(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);

        queryItem = new QueryItem(Where.eq("id", account.getUserId()));
        queryItem.setFields("real_name");
        Map<String, Object> map = this.getOneByMap(queryItem, Module.SYSTEM, Function.SYS_ADMIN);
        if (map != null)
            account.setOpenName((String) map.get("real_name"));
        Map<String, Object> data = PageUtil.createFormPageStructure("account/plat/update", formFieldList, account);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新:客户账户
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "custUpdate")
    public DyResponse custUpdate(AccAccount accAccount) throws Exception {
        AccAccount accAccountt = new AccAccount();
        accAccount.setId(accAccount.getId());
        accAccountt.setAccount(accAccount.getAccount());
        this.update(Module.ACCOUNT, Function.ACC_ACCOUNT, accAccountt);
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 同步余额
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "sysncBalance")
    public DyResponse sysncBalance(Long id) throws Exception {
        AccAccount accAccount = this.getById(id, Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        trustApiUtil.qcard(accAccount.getCompanyId());
        return createSuccessJsonResonse(null, "更新成功");
    }

    @ResponseBody
    @RequestMapping(value = "accountExist")
    public DyResponse accountExist(Long id) throws Exception {
        AccAccount accAccount = this.getById(id, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);
        Company company = this.getById(accAccount.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        if (StringUtils.isBlank(company.getLegalPhoneNumber()) || StringUtils.isBlank(company.getLegalCardNo())
                || StringUtils.isBlank(company.getLegalCardType()) || StringUtils.isBlank(company.getLegalName())) {
            return createErrorJsonResonse("法人信息不完整，请先完善法人信息！");
        }
        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("id", id));
        AccAccount account = this.getOneByEntity(queryItem, Module.ACCOUNT, Function.ACC_ACCOUNT, AccAccount.class);
        Boolean accountStatus = null;
        Map<String, Object> data = Maps.newHashMap();
        if (account == null || StringUtils.isEmpty(account.getAccount())) {
            accountStatus = false;
            data.put("accountStatus", accountStatus);
            return createSuccessJsonResonse(data, null);
        } else {
            accountStatus = true;
            data.put("accountStatus", accountStatus);
            return createSuccessJsonResonse(data, "该企业已开户");
        }

    }
}