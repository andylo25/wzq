package com.dy.sc.admin.controller.credit;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.Company;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;

@Controller
@RequestMapping("/credit/log")
public class CreLimitLogController extends AdminBaseController {
	
	/**
	 * 授信额度操作记录
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="list")
	public ModelAndView logList() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "company_name","type_name","credit_limit","creater_name","dept_name","create_time","action_type","trade_amount","balance_amount"});
		tableHeader.setTexts(new String[]{"ID", "企业名称", "额度类型", "额度总额", "操作人", "操作部门", "操作日期", "操作类型", "交易金额", "操作后剩余可用额度"});
		tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", "", "", ""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());	
		Search search = new Search();
		search.setNames(new String[]{"company_name"});
		search.setTexts(new String[]{"企业名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("credit/log/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 操作记录数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="listData")
	public DyResponse logListData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		if(StringUtils.isNotBlank(search)){
			QueryItem query = new QueryItem(Where.likeAll("company_name", search));
			List<Company> companies = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
			List<Long> ids = new ArrayList();
			for(Company company : companies){
				ids.add(company.getId());
			}
			queryItem.setWhere(Where.in("company_id", ids));
		}
		queryItem.setOrders("create_time desc");
		Page<Map> rlt = getPageByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_LIMIT_LOG);
		this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
		this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name as creater_name,dept_name");
		this.idToName(rlt.getItems(), SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, "business_type_id:name as type_name");
		return createSuccessJsonResonse(dataConvert(rlt,"limit_type,action_type","create_time"));
	}
}