package com.dy.sc.admin.controller.insidelimit;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.*;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.FlowProcInst;
import com.dy.ia.entity.common.OrgUser;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.insidelimit.InsideLimitApplyRecord;
import com.dy.sc.entity.insidelimit.InsideLimitChangeLog;
import com.dy.sc.entity.insidelimit.InsideLimitDept;
import com.dy.sc.entity.system.Department;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.math.BigDecimal;
import java.util.*;
import java.util.Map.Entry;


@Controller
@RequestMapping("/insidelimit/deptlimit")
public class InsideLimitDeptController extends AdminBaseController {

    /**
     * 构建界面结构
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView platList() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "dept_name", "credit_limit", "temp_limit", "avail_limit", "tobe_recovered", "monthLoan", "pay_limit"});
        tableHeader.setTexts(new String[]{"ID", "部门名称", "授信限额", "临时额度", "可用授信额度", "待回授信金额", "本月已放授信额度", "总已放授信额度"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"accountName"});
        search.setTexts(new String[]{"部门名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("insidelimit/deptlimit/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取数据
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse getListData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,dept_id,credit_limit,temp_limit,avail_limit,tobe_recovered,pay_limit");
        queryItem.setWhere(Where.eq("acc_type", AccConstants.REC_TYPE_DEPT));
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("account_name", search));
        }
        queryItem.setOrders("id");
        Page<Map> pagem = getPageByMap(queryItem, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT);
        this.idToName(pagem.getItems(), SCModule.SYSTEM, SCFunction.SYS_DEPT, "dept_id:dept_name");

        // 本月已放
        Set<String> ids = Sets.newHashSet();
        for (int i = 0; i < pagem.getItems().size(); i++) {
            Map map = pagem.getItems().get(i);
            ids.add(map.get("dept_id").toString());
        }
        queryItem = new QueryItem();
        List<Integer> ls = Lists.newArrayList();
        ls.add(AccConstants.CREDIT_RECORD_STATUS_TO_REPAYMENT);
        ls.add(AccConstants.CREDIT_RECORD_STATUS_REPAY);
        ls.add(AccConstants.CREDIT_RECORD_ADVANCE_REPAY);
        queryItem.setWhere(Where.in("status", ls));
        queryItem.setWhere(this.addAndWhereCondition(null, "create_time", DateUtil.getMonthFirstDay(DateUtil.getTxnDate()), DateUtil.getCurrentDate()));
        queryItem.setFields("sales_uid,sum(loan_amount) as monthLoan");
        queryItem.setGroup("sales_uid");
        List<Map> maps = this.getListByMap(queryItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);

        if (maps != null) {
            Map merg = Maps.newHashMap();
            for (Map map : maps) {
                OrgUser user = this.getById(map.get("sales_uid").toString(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
                map.put("dept_id", user.getDeptId());
                if (merg.get(map.get("dept_id").toString()) == null) {
                    merg.put(map.get("dept_id").toString(), new BigDecimal(map.get("monthLoan").toString()));
                } else {
                    merg.put(map.get("dept_id").toString(), new BigDecimal(map.get("monthLoan").toString()).add(new BigDecimal(merg.get(map.get("dept_id").toString()).toString())));
                }
            }
            for (Map item : pagem.getItems()) {
                item.put("monthLoan", BigDecimal.ZERO);
                for (Object key : merg.keySet()) {
                    if (key.toString().equals(item.get("dept_id").toString())) {
                        item.put("monthLoan", merg.get(key));
                        break;
                    }
                }
            }
        }

        return createSuccessJsonResonse(pagem);
    }

    private InsideLimitChangeLog buildLimitLog(InsideLimitDept limitInfo, BigDecimal allotLimit, int actionType) {
        InsideLimitChangeLog limitLog = new InsideLimitChangeLog();
        limitLog.setAccountName(limitInfo.getAccountName());
        limitLog.setDeptId(limitInfo.getDeptId());
        limitLog.setActionType(actionType);
        limitInfo.setAvailLimit(limitInfo.getAvailLimit());
        limitLog.setCreditLimit(limitInfo.getCreditLimit());
        limitLog.setTempLimit(limitInfo.getTempLimit());
        switch (actionType) {
            case AccConstants.CRE_INNER_ACTION_TYPE_ALLOT:
                limitLog.setRemark("平台进行额度分配，授信限额增加" + allotLimit);
                break;
            case AccConstants.CRE_INNER_ACTION_TYPE_ADDTEMP:
                limitLog.setRemark("平台添加临时额度，临时额度增加" + allotLimit);
                break;
            case AccConstants.CRE_INNER_ACTION_TYPE_CLEAR:
                limitLog.setRemark("平台进行额度归集，授信限额和临时额度归0");
                break;
            case AccConstants.CRE_INNER_ACTION_TYPE_REDUCE:
                limitLog.setRemark("平台进行修整，授信限额减少" + allotLimit);
                break;
            default:
                break;
        }
        return limitLog;
    }

    /**
     * 分配限额页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toAllot")
    public ModelAndView toAllot(Long id) throws Exception {

        QueryItem queryItem = new QueryItem(Where.eq("acc_type", AccConstants.REC_TYPE_DEPT));
        List<InsideLimitDept> creLimitInfos = this.getListByEntity(queryItem, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("totalAvali").text("可授信金额").type("span").build());

        Map<String, Object> formData = new HashMap<>();
        if (creLimitInfos != null) {
            for (InsideLimitDept limitInfo : creLimitInfos) {
                formFieldList.add(FormField.builder().name("allotLimit_" + limitInfo.getId())
                        .text(limitInfo.getAccountName()).build());
                formData.put("allotLimit_" + limitInfo.getId(), limitInfo.getCreditLimit());
            }
        }
        formData.put("avali", getAvaliBalance(true));
        formData.put("totalAvali", getAvaliBalance(false));
        Map<String, Object> data = PageUtil.createFormPageStructure("insidelimit/deptlimit/allot", formFieldList, formData);

        return createSuccessModelAndView("insidelimit/deptlimit/allot", JsonUtils.object2JsonString(data));
    }


    /**
     * 分配限额
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "allot")
    public DyResponse allot() throws Exception {
        // 部门授信限额增加，可用授信增加
        Map<String, Object> map = RequestUtil.getRequestMap(getRequest());
        List<String> ids = Lists.newArrayList();
        BigDecimal sumUse = BigDecimal.ZERO;
        for (Entry<String, Object> entry : map.entrySet()) {
            if (entry.getKey().startsWith("allotLimit_")) {
                BigDecimal allotLimit = new BigDecimal((String) entry.getValue());
                if (NumberUtils.greaterThanZero(allotLimit)) {
                    ids.add(entry.getKey().substring(11));
                    sumUse = NumberUtils.add(sumUse, allotLimit);
                }
            }
        }
        if (NumberUtils.greaterThan(sumUse, getAvaliBalance(true))) {
            return createErrorJsonResonse("平台可用授信不足，请先添加平台授信");
        }
        QueryItem queryItem = new QueryItem(Where.in("id", StringUtils.join(ids, ",")));
        List<InsideLimitDept> creLimitInfos = this.getListByEntity(queryItem, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
        if (creLimitInfos != null) {
            for (InsideLimitDept limitInfo : creLimitInfos) {
                BigDecimal allotLimit = new BigDecimal((String) map.get("allotLimit_" + limitInfo.getId()));
                if (NumberUtils.greaterThanZero(allotLimit)) {
                    limitInfo.setCreditLimit(NumberUtils.add(limitInfo.getCreditLimit(), allotLimit));
                    limitInfo.setAvailLimit(NumberUtils.add(limitInfo.getAvailLimit(), allotLimit));

                    this.update(SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, limitInfo);

                    // 插入内部流转记录
                    InsideLimitChangeLog limitLog = buildLimitLog(limitInfo, allotLimit, AccConstants.CRE_INNER_ACTION_TYPE_ALLOT);
                    this.insert(SCModule.INSIDELIMIT, SCFunction.CHANGE_LOG, limitLog);
                }
            }
        }

        return createSuccessJsonResonse(null, "分配成功");
    }

    /**
     * 申请临时额度弹窗
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toApplyTempLimit")
    public ModelAndView toApplyTempLimit(Long id) throws Exception {
        InsideLimitDept creLimitInfo = this.getById(id, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("totalAvali").text("可授信金额").type("span").build());
        formFieldList.add(FormField.builder().name("accountName").text("账户名称").type("span").build());

        formFieldList.add(FormField.builder().name("addtempLimit").text("新增临时额度").verify("required").build());
        formFieldList.add(FormField.builder().name("msg").text("申请理由").verify("required").build());

        Map<String, Object> formData = new HashMap<>();
        formData.put("totalAvali", getAvaliBalance(true) + " 元");
        formData.put("accountName", creLimitInfo.getAccountName());
        formData.put("id", id);
        Map<String, Object> data = PageUtil.createFormPageStructure("insidelimit/deptlimit/applyTempLimit", formFieldList, formData);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取余额
     *
     * @param isContainUsed 是否减去已分配的
     * @return
     * @throws Exception
     */
    private BigDecimal getAvaliBalance(boolean isSubUsed) throws Exception {
        QueryItem queryItem = new QueryItem(Where.eq("id", AccConstants.PLAT_ACCOUNT_ID));
        queryItem.setFields("id,acc_balance as accBalance");
        AccAccount account = this.getOneByEntity(queryItem, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);

        if (isSubUsed) {
            queryItem = new QueryItem(Where.eq("acc_type", AccConstants.REC_TYPE_DEPT));
            queryItem.setFields("sum(credit_limit+temp_limit) as useLimit");
            Map<String, Object> limit = this.getOneByMap(queryItem, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT);
            if (limit == null) {
                return account.getAccBalance();
            }
            return NumberUtils.sub(account.getAccBalance(), new BigDecimal(limit.get("useLimit").toString()));
        }
        return account.getAccBalance();
    }

    /**
     * 申请临时额度
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "applyTempLimit")
    public DyResponse applyTempLimit(Long id, @RequestParam("addtempLimit") BigDecimal addtempLimit, @RequestParam("msg") String msg) throws Exception {
        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        InsideLimitDept creditLimit = this.getOneByEntity(queryItem, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);

        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("dept_id", creditLimit.getDeptId()));
        query.setWhere(Where.eq("status", 0));
        InsideLimitApplyRecord applyRecord1 = this.getOneByEntity(query, SCModule.INSIDELIMIT, SCFunction.APPLY_RECORD, InsideLimitApplyRecord.class);
        if (applyRecord1 != null) {
            return this.createErrorJsonResonse("您已有申请审核中，请勿重复申请");
        }

        String flowNum = GenNumUtil.genNum("SQLE");
        Department department = this.getById(creditLimit.getDeptId(), SCModule.SYSTEM, SCFunction.SYS_DEPT, Department.class);
        FlowProcInst procInst = workFlowUtil.startFlowPub(AccConstants.FLOW_DEF_SQLE, flowNum, msg, null, id.toString(), department.getDeptName());

        InsideLimitApplyRecord applyRecord = new InsideLimitApplyRecord();
        applyRecord.setApplyLimit(addtempLimit);
        applyRecord.setAvailLimit(creditLimit.getAvailLimit());
        applyRecord.setCreditLimit(creditLimit.getCreditLimit());
        applyRecord.setDeptName(creditLimit.getAccountName());
        applyRecord.setDeptName(department.getDeptName());
        applyRecord.setDeptId(department.getId());
        applyRecord.setFlowNum(flowNum);
        applyRecord.setReason(msg);
        applyRecord.setStatus(AccConstants.FLOW_STATUS_APRVING);
        applyRecord.setTempLimit(creditLimit.getTempLimit());
        applyRecord.setProcInstId(procInst.getId());
        this.insert(SCModule.INSIDELIMIT, SCFunction.APPLY_RECORD, applyRecord);

        return createSuccessJsonResonse(null, "申请提交成功");
    }

    /**
     * 额度扣减页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toReduce")
    public ModelAndView toReduce(Long id) throws Exception {

        InsideLimitDept creLimitInfo = this.getById(id, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
        List<FormField> formFieldList = new ArrayList<>();
        String remarks = "（授信限额" + creLimitInfo.getCreditLimit().longValue() + "元，可用授信" + creLimitInfo.getAvailLimit().longValue() + "元）";
        formFieldList.add(FormField.builder().name("accountName").text("子账户").type("span").remarks(remarks).build());

        formFieldList.add(FormField.builder().name("reduceLimit").text("扣减额度").verify("required").build());

        Map<String, Object> data = PageUtil.createFormPageStructure("insidelimit/deptlimit/reduce", formFieldList, creLimitInfo);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 额度扣减
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "reduce")
    public DyResponse reduce(InsideLimitDept limitInfo, @Param("reduceLimit") BigDecimal reduceLimit) throws Exception {
        if (!NumberUtils.greaterThanZero(reduceLimit)) {
            return createErrorJsonResonse("输入额度必须大于0");
        }
        if (NumberUtils.greaterThan(reduceLimit, limitInfo.getAvailLimit())) {
            return createErrorJsonResonse("扣减的额度大于可用额度，不能进行扣减操作");
        }

        // 部门授信限额减少，可用授信减少
        limitInfo.setCreditLimit(NumberUtils.sub(limitInfo.getCreditLimit(), reduceLimit));
        limitInfo.setAvailLimit(NumberUtils.sub(limitInfo.getAvailLimit(), reduceLimit));

        this.update(SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, limitInfo);

        InsideLimitChangeLog limitLog = buildLimitLog(limitInfo, reduceLimit, AccConstants.CRE_INNER_ACTION_TYPE_REDUCE);
        this.insert(SCModule.INSIDELIMIT, SCFunction.CHANGE_LOG, limitLog);
        return createSuccessJsonResonse(null, "扣减成功");
    }

    /**
     * 额度归集
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "clear")
    public DyResponse clear() throws Exception {

        QueryItem queryItem = new QueryItem(Where.eq("acc_type", AccConstants.REC_TYPE_DEPT));
        List<InsideLimitDept> creLimitInfos = this.getListByEntity(queryItem, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
        if (creLimitInfos != null) {
            for (InsideLimitDept limitInfo : creLimitInfos) {
                // 部门授信限额归0，可用授信0,部门临时额度归0
                limitInfo = this.getById(limitInfo.getId(), SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
                limitInfo.setCreditLimit(BigDecimal.ZERO);
                limitInfo.setAvailLimit(BigDecimal.ZERO);
                limitInfo.setTempLimit(BigDecimal.ZERO);

                this.update(SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, limitInfo);

                // 插入内部流转记录
                InsideLimitChangeLog limitLog = buildLimitLog(limitInfo, null, AccConstants.CRE_INNER_ACTION_TYPE_CLEAR);
                this.insert(SCModule.INSIDELIMIT, SCFunction.CHANGE_LOG, limitLog);
            }
        }

        return createSuccessJsonResonse(null, "归集成功");
    }

    /**
     * 部门设置
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "toSetDept")
    public ModelAndView toSetDept() throws Exception {

        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("reduceLimit").text("扣减额度").verify("required").build());

        QueryItem queryItem = new QueryItem();
        Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex());
        List<Map> departments = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DEPT);

        Map<String, Object> formData = Maps.newHashMap();
        Map<String, Object> position = Maps.newHashMap();
        formData.put("department_list", departments);
        formData.put("form_data", position);

        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
        query.setFields("id,dept_id");
        List<InsideLimitDept> limits = this.getListByEntity(query, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
        String ids = "";
        for (InsideLimitDept limit : limits) {
            ids += limit.getDeptId() + ",";
        }
        position.put("position", ids.length() < 1 ? "" : ids.substring(0, ids.length() - 1));
        formData.put("submit_url", "insidelimit/deptlimit/setDept");
        return createSuccessModelAndView("insidelimit/deptlimit/add", JsonUtils.object2JsonString(formData));
    }

    /**
     * 部门设置
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "setDept")
    public DyResponse setDept(String positionNameStr, String position) throws Exception {
        String[] positions = StringUtils.isBlank(position) ? new String[1] : position.split(",");
        List<String> arrayList = new ArrayList<String>(Arrays.asList(positions));

        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
        query.setFields("id,dept_id");
        List<InsideLimitDept> limits = this.getListByEntity(query, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
        for (InsideLimitDept limit : limits) {
            if (!arrayList.contains(limit.getDeptId().toString())) {
                this.deleteById(limit.getId(), SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT);
            }
        }

        if (positions != null) {
            for (String pos : positions) {
                if (pos == null) continue;
                QueryItem queryItem = new QueryItem();
                queryItem.setWhere(Where.eq("dept_id", pos));
                InsideLimitDept dept = this.getOneByEntity(queryItem, SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, InsideLimitDept.class);
                if (dept != null) {
                    continue;
                }

                InsideLimitDept deptLimit = new InsideLimitDept();
                Department department = this.getById(pos, SCModule.SYSTEM, SCFunction.SYS_DEPT, Department.class);
                deptLimit.setDeptId(department.getId());
                deptLimit.setDeptName(department.getDeptName());
                deptLimit.setAccountName(department.getDeptName());
                deptLimit.setTotalBackLimit(BigDecimal.ZERO);
                deptLimit.setCreditLimit(BigDecimal.ZERO);
                deptLimit.setTempLimit(BigDecimal.ZERO);
                deptLimit.setAvailLimit(BigDecimal.ZERO);
                deptLimit.setPayLimit(BigDecimal.ZERO);
                deptLimit.setTobeRecovered(BigDecimal.ZERO);
                deptLimit.setAccType(AccConstants.REC_TYPE_DEPT);

                this.insert(SCModule.INSIDELIMIT, SCFunction.LIMIT_DEPT, deptLimit);
            }
        }
        return createSuccessJsonResonse(null, "设置成功");
    }
}