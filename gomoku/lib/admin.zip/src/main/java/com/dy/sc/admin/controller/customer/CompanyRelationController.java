package com.dy.sc.admin.controller.customer;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Lists;


/**
 * 关联管理
 * @ClassName: CompanyRelationController.java 
 * @Description: TODO 
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author diyou@diyou.cn
 * @date 2017年7月17日下午2:11:00 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * diyou 
 * </pre>
 */	
@Controller
@RequestMapping("/sys/companyRelation/")
public class CompanyRelationController extends AdminBaseController{

    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{ "companyName","coreName","chain_position","check_status","create_time"});
		tableHeader.setTexts(new String[]{ "授信企业名称", "核心企业名称", "所属位置", "状态", "添加时间"});
		tableHeader.setTypes(new String[]{"","","","","datetime"});
		tableHeader.setOptionTypes(new String[]{"","","chain_position","company_relation_status",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"授信企业"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("sys/companyRelation/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 列表数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({"rawtypes" })
    @ResponseBody
	@RequestMapping(value="listData",method=RequestMethod.POST)
	public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,company_id,core_company_id,chain_position,check_status,check_reason,create_time");
		//企业名称查询
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.in("company_id",getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", search)));
		}
		queryItem.setWhere(Where.eq("del_flag",0));
		queryItem.setOrders("create_time desc");
		Page<Map> pageData=getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
		List<Map> data=pageData.getItems();
	    if(data!=null&& data.size()>0){
	    	this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name as companyName");
	    	this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "core_company_id:company_name as coreName");
	    }
		return createSuccessJsonResonse(pageData);
	}
	

    
}