package com.dy.sc.admin.controller.product;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.product.ProdBusinessType;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author diyou@diyou.cn
 * @version v1.0
 *          <pre>
 *          修改人                修改时间        版本        修改内容
 *          ---------------------------------------------------------
 *          diyou
 *          </pre>
 * @ClassName: ProductController.java
 * @Description: TODO
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @date 2017年7月10日上午11:33:30
 */
@Controller
@RequestMapping("/prod/businessType/")
public class BusinessTypeController extends AdminBaseController {


    /**
     * 业务类型列表
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"name", "code", "limit_name"});
        tableHeader.setTexts(new String[]{"业务名称", "业务编码", "额度名称"});
        tableHeader.setTypes(new String[]{"", "", ""});

        tableHeader.setOptionTypes(new String[]{"", "", ""});
        tableHeader.setFilters(new String[]{"input", "input", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"业务名称"});
        search.setTypes(new String[]{"text"});

        PageStructure data = PageUtil.createTablePageStructure("prod/businessType/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取业务类型数据
     *
     * @param page
     * @param limit
     * @param search
     * @param name   业务名称
     * @param code   业务编码
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse listData(Integer page, Integer limit, String search,
                               String name, String code) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields(" id, name, code, limit_name ");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("name", search));
        }
        if (StringUtils.isNotBlank(name)) {
            queryItem.setWhere(Where.likeAll("name", name));
        }
        if (StringUtils.isNotBlank(code)) {
            queryItem.setWhere(Where.eq("code", code));
        }
        queryItem.setOrders("code asc");
        Page recordPage = this.getPageByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        return createSuccessJsonResonse(recordPage);
    }

    /**
     * 添加业务类型
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "add")
    public ModelAndView add() throws Exception {
        List<FormField> formFieldList = buidField();
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/businessType/save", formFieldList);
        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    /**
     * 业务类型界面值绑定
     *
     * @return
     */
    private List<FormField> buidField() {
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("name").text("业务名称").verify("required").build());
        formFieldList.add(FormField.builder().name("code").text("业务编码").verify("required").build());
        formFieldList.add(FormField.builder().name("limitName").text("额度名称").verify("required").build());
        return formFieldList;
    }


    /**
     * 保存新增业务类型
     *
     * @param businessType
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "save")
    public DyResponse save(ProdBusinessType businessType) throws Exception {
        this.insert(SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, businessType);
        return createSuccessJsonResonse(null, "添加成功！");
    }

    /**
     * 编辑业务类型
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "edit")
    public ModelAndView edit(Long id) throws Exception {
        List<FormField> formFieldList = buidField();
        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        ProdBusinessType entity = this.getOneByEntity(queryItem, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class);
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/businessType/update", formFieldList, entity);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新业务类型
     *
     * @param businessType
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update")
    public DyResponse update(ProdBusinessType businessType) throws Exception {
        this.update(SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, businessType);
        return createSuccessJsonResonse(null, "更新成功！");
    }
}