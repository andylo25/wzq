package com.dy.sc.admin.controller.workflow;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.FlowProcDef;
import com.dy.ia.entity.common.Role;
import com.dy.ia.entity.custom.flow.RoleData;
import com.dy.ia.entity.custom.flow.TaskNode;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.FlowProcType;
import com.dy.sc.entity.enumeration.FlowTypeEnum;
import com.google.common.collect.Lists;

@Controller
@RequestMapping("/workflow/proc")
public class ProcDefController extends AdminBaseController{

	/**
     * 构建界面结构
     * @return
     * @throws Exception
     */
    @RequestMapping("list/{type}")
    public ModelAndView platList(@PathVariable("type") int type) throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "proc_name","proc_type","flow_proc_type","update_time","real_name"});
		tableHeader.setTexts(new String[]{"ID", "审批流程名称","流程类别","审批方式","最近更新时间","更新人"});
		tableHeader.setTypes(new String[]{"int","","","","datetime",""});
		tableHeader.setOptionTypes(new String[]{"","","proc_type","flow_proc_type","",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"流程名称"});
        search.setTypes(new String[]{"text"});
		
		PageStructure data = PageUtil.createTablePageStructure("workflow/proc/listData/"+type, "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 获取数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("listData/{type}")
	public DyResponse getListData(Integer page,Integer limit,String search,@PathVariable("type") int type) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,proc_name,proc_type,flow_proc_type,update_time,update_uid");
		queryItem.setOrders("id");
		if(StringUtils.isNoneBlank(search)){
		    queryItem.setWhere(Where.likeAll("proc_name", search));
		}
		if(FlowTypeEnum.FLOW_COMMON.getIndex()==type){
		    queryItem.setWhere(Where.eq("proc_type", type));//公共类
		}else{
            queryItem.setWhere(Where.notEq("proc_type", FlowTypeEnum.FLOW_COMMON.getIndex()));//应收账款类
        }
		Page pageData=getPageByMap(queryItem, Module.FLOW, SCFunction.FLOW_PROC_DEF);
		this.idToName(pageData.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "update_uid:real_name");
		
		return createSuccessJsonResonse(pageData);
	}
	
    private List<FormField> buidFormField() {
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("procName").text("名称").verify("required").build());
        formFieldList.add(FormField.builder().name("flowProcType").text("审批方式").type("radio").options(DictUtils.getOptionsInt("flow_proc_type")).verify("required").build());
        return formFieldList;
    }
	
	/**
     * 流程定义配置
     * @return
     * @throws Exception
     */
    @RequestMapping("edit/{type}")
    public ModelAndView edit(Long id,@PathVariable("type") int type) throws Exception {
        FlowProcDef procDef = this.getById(id, Module.FLOW, SCFunction.FLOW_PROC_DEF, FlowProcDef.class);
        List<FormField> formFieldList = buidFormField();
        Map<String, Object> data = PageUtil.createFormPageStructure("workflow/proc/update", formFieldList,procDef);
        
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 更新
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="update",method=RequestMethod.POST)
    public DyResponse update(FlowProcDef procDef) throws Exception {
    	//不允许自动审批的流程key数组
    	String[] unableAutoKeys=new String[]{"comm_smrz"};
        if(procDef.getId()!=null){
        	if(FlowProcType.AUTO.getIndex()==procDef.getFlowProcType()){
        		//是不允许自动审批的流程
        		if(Arrays.asList(unableAutoKeys).contains(procDef.getProcKey())){
        			return createErrorJsonResonse("此流程不能进行系统自动审核!");
        		}
        	}
            this.update(SCModule.FLOW, SCFunction.FLOW_PROC_DEF, procDef);
        }
        return createSuccessJsonResonse(null,"修改成功");
    }
	
    /**
     * 流程定义配置
     * @return
     * @throws Exception
     */
    @RequestMapping("conf/{type}")
    public ModelAndView conf(Long id,@PathVariable("type") int type) throws Exception {
    	
    	FlowProcDef procDef = this.getById(id, Module.FLOW, SCFunction.FLOW_PROC_DEF, FlowProcDef.class);
    	if(procDef == null)return null;
    	List<TaskNode> formStruct = new ArrayList<>();
    	TaskNode start = JsonUtils.fromJson(procDef.getTaskStart(), TaskNode.class);
    	formStruct.add(start);
    	List<TaskNode> mid = Lists.newArrayList();
    	if(StringUtils.isNotBlank(procDef.getTaskInfo())){
    		mid = JsonUtils.jsonToList(procDef.getTaskInfo(), TaskNode[].class);
    	}
    	formStruct.addAll(mid);
    	TaskNode end = JsonUtils.fromJson(procDef.getTaskEnd(), TaskNode.class);
    	formStruct.add(end);
		
		StringBuilder result = new StringBuilder(JsonUtils.object2JsonString(formStruct));
		result.append(",formStruct=").append(JsonUtils.object2JsonString(formStruct));
		
		Map<String,RoleData> roleData = new HashMap<>();
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("id,role_name as roleName");
		List<Role> roles = this.getListByEntity(queryItem , Module.SYSTEM, SCFunction.SYS_ROLE, Role.class);
		for(Role role:roles){
			roleData.put(role.getId().toString(), new RoleData(role.getId().toString(),role.getRoleName()));
		}
		
		List<Map<String,Object>> memberData = new ArrayList<>();
		Map<String,Object> member = new HashMap<>();
		member.put("id", "1");
		member.put("pid", "0");
		member.put("name", "帝友总部");
		member.put("cname", "帝友总部");
		Map<String,Object> child = new HashMap<>();
		child.put("1", roleData.values());
		member.put("child", child);
		memberData.add(member);
		result.append(",memberData=").append(JsonUtils.object2JsonString(memberData));
		
		Map<String,Object> departmentData = new HashMap<>();
		Map<String,String> department = new HashMap<>();
		department.put("id", "1");
		department.put("pid", "0");
		department.put("name", "帝友总部");
		departmentData.put("1", department);
		result.append(",departmentData=").append(JsonUtils.object2JsonString(departmentData));
		
		result.append(",roleData=").append(JsonUtils.object2JsonString(roleData));
		result.append(",defId=").append(id);
		result.append(",url=").append("'workflow/proc/flow_save'");
		return createSuccessModelAndView("system/flowConf", result);
    }
    
    /**
     * 流程定义配置
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("flow_save")
    public DyResponse flowSave(@RequestParam("node_list") String nodeLists,@RequestParam("id") String id) throws Exception {
    	List<TaskNode> nodeList = JsonUtils.jsonToList(nodeLists, TaskNode[].class);
    	FlowProcDef procDef = this.getById(id, Module.FLOW, SCFunction.FLOW_PROC_DEF, FlowProcDef.class);
    	List<TaskNode> newNodes = new ArrayList<>(nodeList.subList(1, nodeList.size()-1));
    	for(int i=0;i<newNodes.size();i++){
    		newNodes.get(i).setNode_id(String.valueOf(i));
    	}
    	if(newNodes.isEmpty()){
            procDef.setTaskInfo("");
        }else{
            procDef.setTaskInfo(JsonUtils.object2JsonString(newNodes));
        }
    	
    	TaskNode end = nodeList.get(nodeList.size()-1);
    	if(end != null){
    		end.setNode_id("99"); // 最后节点id固定为99
    	}
    	procDef.setTaskEnd(JsonUtils.object2JsonString(end));
    	
    	this.update(SCModule.FLOW, SCFunction.FLOW_PROC_DEF, procDef);
    	
    	return createSuccessJsonResonse(null,"配置成功");
    }
    

}