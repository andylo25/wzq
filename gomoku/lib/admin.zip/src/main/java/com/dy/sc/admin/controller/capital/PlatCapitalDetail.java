package com.dy.sc.admin.controller.capital;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.dy.sc.entity.product.ProdProductInfo;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.excel.ExportExcel;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;

/**
 * 平台资金记录
 * @author cuiwm
 *
 */
@Controller
@RequestMapping("/platcap/detail")
public class PlatCapitalDetail extends AdminBaseController{

	/**
     * 构建界面结构:平台收入支出记录
     * @return
     * @throws Exception
     */
    @RequestMapping("{dir}/list")
    public ModelAndView list(@PathVariable("dir") int dir) throws Exception {
    	TableHeader tableHeader = new TableHeader();
		if(AccConstants.TXN_DIR_IN == dir){
			tableHeader.setNames(new String[]{"id", "create_time","amount_yes","principal_yes","interest_yes","overdue_fee","loan_contract_no","company_name","sales_uid","dept_name"});
			tableHeader.setTexts(new String[]{"ID", "还款时间","还款总额","还款本金","还款利息","逾期费用","信贷合同号","客户名称","客户经理:manager","所属部门"});
			tableHeader.setTypes(new String[]{"","datetime","number","number","number","number","","","",""});
			tableHeader.setFilters(new String[]{"","multi_date","","","","","input","input","select",""});
		}else if(AccConstants.TXN_DIR_OUT == dir){
			tableHeader.setNames(new String[]{"id", "create_time:datetime","capital_id","payee_name","loan_contract_no","principal_total:number","transfer_total:number","business_type","product_name","sales_uid","dept_name"});
			tableHeader.setTexts(new String[]{"ID", "出账时间","放款方","收款方","借贷合同号","借贷金额","实际出账金额","业务类型","产品名称","客户经理","所属部门"});
			tableHeader.setFilters(new String[]{"","multi_date", "select","input","input","","","","select","select",""});
			tableHeader.setOptionTypes(new String[]{"","","capital_com","","","","","business_type","sc_product","manager",""});
		}
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"企业名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("platcap/detail/"+dir+"/listData", "", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 获取数据:平台收入支出记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("{dir}/listData")
	public DyResponse listData(@PathVariable("dir") int dir,Integer page,Integer limit,String search,String create_time,String company_name,String product_name ,String capital_id,String loan_contract_no,String business_type,String sales_uid) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		
		
		if(StringUtils.isNotBlank(create_time)){
			queryItem.setWhere(this.addDateWhereCondition(null, "create_time",create_time));
		}
		
		if(StringUtils.isNoneBlank(capital_id)){
            queryItem.setWhere(Where.in("debit_id", getIdsEq(SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "capital_id", capital_id)));
        }
		if(StringUtils.isNotBlank(company_name)){
			queryItem.setWhere(Where.likeAll("payee_name", company_name));
		}
		if(StringUtils.isNotBlank(search)){
		    queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", search)));
		}
		if(StringUtils.isNotBlank(sales_uid)){
			queryItem.setWhere(Where.in("debit_id", getIdsEq(SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "sales_uid", sales_uid)));
		}
		if(StringUtils.isNotBlank(loan_contract_no)){
		    queryItem.setWhere(Where.in("debit_id", getIdsLike(SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "loan_contract_no", loan_contract_no)));
		}
		if(org.apache.commons.lang3.StringUtils.isNotBlank(product_name)){
			ProdProductInfo productInfo = this.getById(product_name, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
			QueryItem query = new QueryItem(Where.eq("root_version", productInfo.getRootVersion()));
			List<ProdProductInfo> productInfos = this.getListByEntity(query, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
			List<Object> ids = Lists.newArrayList();
			for(ProdProductInfo info : productInfos){
				ids.add(info.getId());
			}
			queryItem.setWhere(Where.in("debit_id", getIdsIn(SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "product_id", ids)));
		}
		queryItem.setOrders("id desc");
		Page<Map> page2 =null;
		if(AccConstants.TXN_DIR_IN == dir){
			page2 = getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD_LOG);
			this.idToName(page2.getItems(), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:sales_uid");
			this.idToName(page2.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "saler_id:dept_name");
			this.idToName(page2.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");

		}else if(AccConstants.TXN_DIR_OUT == dir){
			page2 = getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAY);
			this.idToName(page2.getItems(), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, "debit_id:sales_uid,capital_id,product_id,business_type");
			this.idToName(page2.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "sales_uid:dept_name");
//			this.idToName(page2.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
		}
		
		return createSuccessJsonResonse(page2);
	}
	
	/**
	 * 导出excel
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="{dir}/exportExcel")
	public String exportExcel(HttpServletResponse response,@PathVariable("dir") int dir,String id) throws Exception{
		String title = "";
		ExportExcel excel = null;
		if(dir == AccConstants.TXN_DIR_IN){//收入
			title = "平台收入记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID", "交易日期时间","流水号","企业名称","对方账号","平台账号","交易类型","收入金额"});
		}else if(dir == AccConstants.TXN_DIR_OUT){//支出
			title = "平台支出记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID", "交易日期时间","流水号","企业名称","对方账号","平台账号","交易类型","支出金额"});
		}
		excel.setFieldNames(new String[]{"id", "create_time","flow_num","otherName","other_account","account","txn_type","deal_amount"});
		
		QueryItem queryItem = new QueryItem(Where.in("id", id));
		queryItem.setFields("id,flow_num,company_id,other_company_id,account,txn_type,deal_amount,other_account");
		queryItem.setOrders("id desc");
		List<Map> items = (List<Map>) dataConvert(getListByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_DETAIL),"txn_type:cap_detail_type","create_time");
		this.idToName(items, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "other_company_id:company_name as otherName");
		excel.setDataList(items);
		excel.write(response, title+".xlsx");
		
		return null;
	}
	
}
