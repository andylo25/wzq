package com.dy.sc.admin.controller.product;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.TemplateType;
import com.dy.sc.entity.loan.LoanProtocol;
import com.dy.sc.entity.product.ProdTemplate;
import com.google.common.collect.Lists;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;


/**
 * @author likaijun@diyou.cn
 * @version v1.0
 *          <pre>
 *          修改人                修改时间        版本        修改内容
 *          ---------------------------------------------------------
 *          likaijun
 *          </pre>
 * @ClassName: ProductController.java
 * 产品模块 Controller
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @date 2017年7月4日上午10:38:20
 */
@Controller
@RequestMapping("/prod/productTemplate/")
public class ProductTemplateController extends AdminBaseController {

    /**
     * 业务类型列表
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"name", "businessType", "productName", "create_time", "update_time"});
        tableHeader.setTexts(new String[]{"合同名称", "所属类型", "产品名称", "添加时间", "更新时间"});
        tableHeader.setTypes(new String[]{"", "", "", "datetime", "datetime"});

        tableHeader.setOptionTypes(new String[]{"", "", "", "", ""});
        tableHeader.setFilters(new String[]{"input", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"合同名称"});
        search.setTypes(new String[]{"text"});

        PageStructure data = PageUtil.createTablePageStructure("prod/productTemplate/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取业务类型数据
     *
     * @param page
     * @param limit
     * @param search
     * @param name   业务名称
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse listData(Integer page, Integer limit, String search,
                               String name) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields(" id, name, business_type_id, product_id, create_time, update_time ");
        queryItem.setWhere(Where.eq("prod_template_type", TemplateType.PRODUCT.getIndex()));
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("name", search));
        }
        if (StringUtils.isNotBlank(name)) {
            queryItem.setWhere(Where.likeAll("name", name));
        }
        queryItem.setWhere(Where.eq("del_flag", 0));
        queryItem.setOrders(" create_time desc");
        Page recordPage = this.getPageByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
        List<Map> data = recordPage.getItems();
        if (data != null && data.size() > 0) {
            this.idToName(data, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, "business_type_id:name as businessType");
            this.idToName(data, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "product_id:name as productName");
        }
        return createSuccessJsonResonse(recordPage);
    }

    /**
     * 编辑业务类型
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "edit")
    public ModelAndView edit(Long id) throws Exception {
        List<FormField> formFieldList = Lists.newArrayList();
        formFieldList.add(FormField.builder().name("name").text("合同名称").verify("required").build());
        formFieldList.add(FormField.builder().name("businessType").text("业务类型").type("span").build());
        formFieldList.add(FormField.builder().name("productName").text("产品名称").type("span").build());
        formFieldList.add(FormField.builder().name("content").text("模板内容").type("ueditor").verify("required").build());
        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        queryItem.setFields(" id, name, business_type_id, product_id, content ");
        Map entity = this.getOneByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
        Map product = this.getById(Long.parseLong(entity.get("product_id").toString()), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO);
        Map businessType = this.getBusinessTypeById(Long.parseLong(entity.get("business_type_id").toString()));
        entity.put("productName", product.get("name"));
        entity.put("businessType", businessType.get("name"));
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/productTemplate/update", formFieldList, entity);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新业务类型
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update")
    public DyResponse update(ProdTemplate template, HttpServletRequest request) throws Exception {
        template.setContent(request.getParameter("content"));
        //template.setCode(code);
        this.update(SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, template);
        return createSuccessJsonResonse(null, "更新成功！");
    }

    /**
     * 根据id获取业务类型
     *
     * @param businessTypeId
     * @return
     * @throws Exception
     */
    private Map<String, Object> getBusinessTypeById(Long businessTypeId) throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("id", businessTypeId));
        item.setFields(" id, name, code ");
        Map<String, Object> businessType = this.getOneByMap(item, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        return businessType;
    }

    @ResponseBody
    @RequestMapping(value = "del")
    public DyResponse del(Long id) throws Exception {
        if (id != null) {
            QueryItem queryItem = new QueryItem(Where.eq("template_id", id));
            queryItem.setFields("id");
            List<LoanProtocol> protocols = this.getListByEntity(queryItem, SCModule.LOAN, SCFunction.LOAN_PROTOCOL, LoanProtocol.class);
            if (protocols.size() > 0) {
                return createErrorJsonResonse("模板使用中，无法删除");
            } else {
                this.deleteById(id, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
            }
        } else {
            return createErrorJsonResonse("删除失败");
        }
        return createSuccessJsonResonse(null, "删除成功");
    }

}