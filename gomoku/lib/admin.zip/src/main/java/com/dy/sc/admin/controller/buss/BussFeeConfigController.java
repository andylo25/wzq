package com.dy.sc.admin.controller.buss;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.RequestUtil;
import com.dy.core.utils.serializer.SerializerUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;

@Controller
@RequestMapping("/loan")
public class BussFeeConfigController extends AdminBaseController {
	private String configs = "deduct_fee_way,deduct_target_member";
	
	/**
	 * 获取费用列表
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/feeconfig/list")
	public ModelAndView getFeeConfigList() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "name","status","deduct_target_member","operate_type","deduct_fee_way"});
		tableHeader.setTexts(new String[]{"ID", "名称","状态","扣除对象","操作类型","扣费方式"});
		tableHeader.setTypes(new String[]{"int","", "","","",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());

		PageStructure data = PageUtil.createTablePageStructure("loan/feeconfig/listData", "id", tableHeader,tool,null);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取费用数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/feeconfig/listData")
	public DyResponse getFeeConfigListData(Integer page,Integer limit) throws Exception {
		
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		queryItem.setOrders("id");	
		Page pages = getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_FEECONFIG);
		
		List<Map<String, Object>> newData = new ArrayList<Map<String,Object>>();
		SerializerUtil serializerUtil = new SerializerUtil();
		for(Map<String, Object> map : (List<Map<String, Object>>)pages.getItems()) {
			Map configMap = (Map)serializerUtil.unserialize(map.get("configs").toString().getBytes());
			map.put("deduct_target_member", configMap.get("deduct_target_member"));//扣除对象
			map.put("deduct_fee_way", configMap.get("deduct_fee_way"));//扣费方式		
			newData.add(map);
		}
		pages.setItems(newData);
		return createSuccessJsonResonse(dataConvert(pages,"status:status,deduct_fee_way:deduct_fee_way,operate_type:operate_type"));
	}
	
	/**
	 * 编辑更新页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/feeconfig/toEdit")
	public ModelAndView toEdit(Long id) throws Exception {
		//状态转换
		//map = (Map)this.dataConvert(map, "operate_type:getOperateType,deduct_target_member_name:getDeductTargetMember,pay_target_member_name:getPayTargetMember");	
			
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("id,name,operate_type,configs,status");
		Map<String, Object> repayTypeMap = this.getOneByMap(queryItem , SCModule.FUND, SCFunction.FUND_FEECONFIG);	
		
		List<FormField> formFieldList = buidFormField(repayTypeMap.get("operate_type").toString());
		
		SerializerUtil serializerUtil = new SerializerUtil();
		Map<String, Object> configMap = (Map)serializerUtil.unserialize(repayTypeMap.get("configs").toString().getBytes());
		Object deduct_fee_way=configMap.get("deduct_fee_way");
		if(deduct_fee_way!=null){
			String[] deduct_fee_ways=deduct_fee_way.toString().split(",");
			repayTypeMap.put("deduct_fee_way", deduct_fee_ways);
		}
		
		Map<String, Object> data = PageUtil.createFormPageStructure("loan/feeconfig/update", formFieldList,repayTypeMap);	
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	private static final String LOAN_FEE_TYPE_LEND="lend_success";//借贷类型
	private static final String LOAN_FEE_TYPE_REPAY="repay_success";//逾期
	
	private List<FormField> buidFormField(String type) {
		List<FormField> formFieldList = new ArrayList<>();		
		formFieldList.add(FormField.builder().name("name").text("费用名称").verify("required").build());
		
		if(type.equals(LOAN_FEE_TYPE_LEND)){
			List<FormOption> repayTypeOption = new ArrayList<>();	
			repayTypeOption.add(new FormOption("按固定费用", "1"));
			repayTypeOption.add(new FormOption("按本金比例", "2"));
			repayTypeOption.add(new FormOption("按本息比例", "3"));
			repayTypeOption.add(new FormOption("按利息比例", "4"));
			formFieldList.add(FormField.builder().name("deduct_fee_way").text("扣费方式").type("checkbox").options(repayTypeOption).build());
		}else if(type.equals(LOAN_FEE_TYPE_REPAY)){
			formFieldList.add(FormField.builder().name("deduct_fee_way").text("扣费方式").type("input").preText("借款本金*").remarks("%*逾期天数").verify("required").build());
		}
		
		List<FormOption> options = new ArrayList<>();
		options.add(new FormOption("是", "1"));
		options.add(new FormOption("否", "0"));
		formFieldList.add(FormField.builder().name("status").text("是否开启").type("radio").options(options ).build());
		
		formFieldList.add(FormField.builder().name("operate_type").text("操作类型").type("span").build());
		
		return formFieldList;
	}
	/**
	 * 编辑保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/feeconfig/update")
	public DyResponse updateFeeConfig(HttpServletRequest request) throws Exception {
		String id=request.getParameter("id");
		//获取旧的configs
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("configs");
		Map<String, Object> map = this.getOneByMap(queryItem, SCModule.FUND, SCFunction.FUND_FEECONFIG);
				
		//请求参数
		Map<String, Object> requestMap = RequestUtil.getRequestMap(request);	
		Object value = requestMap.get("deduct_fee_way[]");
		if(value instanceof String[]) {
			String [] deduct_fee_way=(String[]) requestMap.get("deduct_fee_way[]");	
			StringBuffer sb = new StringBuffer();
			for(int i = 0; i < deduct_fee_way.length; i++){
			 sb. append(deduct_fee_way[i]+",");
			}
			String s = sb.toString();
			s=s.substring(0, s.length()-1);
			requestMap.put("deduct_fee_way", s);
			requestMap.remove("deduct_fee_way[]");
		}
		else{
			requestMap.remove("deduct_fee_way[]");
			if(value!=null)
				requestMap.put("deduct_fee_way",value);
		}
		
		//更新configs
		SerializerUtil serializerUtil = new SerializerUtil();
		Map<String, Object> configMap = (Map)serializerUtil.unserialize(map.get("configs").toString().getBytes());
		for(String config : configs.split(",")) {
			if(requestMap.get(config) == null) continue;
			configMap.put(config, requestMap.get(config));
		}
		
		String strConfigs = new String(serializerUtil.serialize(configMap));
		
		//更新
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("id", id);
		paramMap.put("configs", strConfigs);
		paramMap.put("name", requestMap.get("name"));
		paramMap.put("operate_type", requestMap.get("operate_type"));
		paramMap.put("status", requestMap.get("status"));
		DyResponse response = this.update(SCModule.FUND, SCFunction.FUND_FEECONFIG, paramMap);
		return createSuccessJsonResonse(null,"修改成功");
	}
}