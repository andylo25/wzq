package com.dy.sc.admin.controller.system;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DownloadUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;

/**
 * 资金管理
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/loganaly")
public class LogAnalyzeController extends AdminBaseController{
	
	private static Logger log = LoggerFactory.getLogger(LogAnalyzeController.class);
	
	@Value("${logging.file}")
	private String logFilePath = "/home/ap/ialog/ia-admin.log";
	
	/**
	 * 日志界面渲染
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/log/list")
	public ModelAndView getLogListPageInfo() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"file_name","size", "last_update", "app_name"});
		tableHeader.setTexts(new String[]{"文件名", "大小", "修改日期", "所属应用"});
		tableHeader.setTypes(new String[]{"", "", "", ""});
			
		Tool tool = new Tool();
		tool.setTexts(new String[]{"下载"});
		tool.setTitles(new String[]{"下载"});
		tool.setTypes(new String[]{"commondownload"});
		tool.setUrls(new String[]{"loganaly/log/down"});
	
		Search search = new Search();
		search.setNames(new String[]{"file_name"});
		search.setTexts(new String[]{"文件名"});
		search.setTypes(new String[]{"text"});
		
		PageStructure data = PageUtil.createTablePageStructure("loganaly/log/listdata", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));

	}
	/**
	 * 日志列表
	 * @param current_page
	 * @param member_name
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/log/listdata")
	public DyResponse getLogListPageData(Integer current_page,String member_name) throws Exception {
		
		Page<Map<String,Object>> data = new Page<>();
		List<Map<String,Object>> items = new ArrayList<>();
		File logDir = new File(logFilePath).getParentFile();
		if(logDir.isDirectory()){
			for(File f:logDir.listFiles()){
				Map<String,Object> map = new HashMap<>();
				map.put("id", f.getName());
				map.put("file_name", f.getName());
				map.put("size", f.length());
				map.put("last_update", new Date(f.lastModified()));
				map.put("app_name", "");
				items.add(map);
			}
		}
		data.setItems(items);
		data.setEpage(300);
		data.setPage(1);
		data.setTotal_items(items.size());
		data.setTotal_pages(1);
		return createSuccessJsonResonse(dataConvert(data,null,"last_update"));
	}
	
	/**
	 * 下载日志
	 * @author cwm
	 * @return
	 */
	@RequestMapping("/log/down")
	public void exportAccountExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam("id") String id ) throws Exception {
		File logDir = new File(logFilePath).getParentFile();
		DownloadUtils.download(id,logDir.getAbsolutePath()+"/"+id, request, response);
		
		
	}
	
}