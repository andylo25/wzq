package com.dy.sc.admin.controller.customer;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.*;
import com.dy.ia.entity.common.*;
import com.dy.ia.entity.enumeration.AccountTypeEnum;
import com.dy.ia.entity.enumeration.CompanyStatus;
import com.dy.ia.entity.enumeration.UploadValidation;
import com.dy.ia.entity.enumeration.UserStatusEnum;
import com.dy.sc.bussmodule.cus.CompanyModule;
import com.dy.sc.bussmodule.cus.Id2NameModule;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.bussmodule.utils.CommonLoanUtil;
import com.dy.sc.entity.common.FileStruct;
import com.dy.sc.entity.constant.*;
import com.dy.sc.entity.customer.CusGradeInfo;
import com.dy.sc.entity.enumeration.*;
import com.dy.sc.entity.money.MoneyRechargeRecord;
import com.dy.sc.entity.org.OrgFrontUser;
import com.dy.sc.entity.product.ProdBusinessType;
import com.dy.sc.entity.system.*;
import com.dy.sc.service.money.MoneyService;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller("userSCController")
@RequestMapping("/system/company/")
public class CompanyController extends AdminBaseController {
    @Autowired
    private MoneyService moneyService;
    @Autowired
    private FDDUtils utils;
    @Autowired
    private CompanyModule companyModule;
    @Autowired
    private Id2NameModule id2NameModule;

    /**
     * 1 所有用户
     */
    public static final int TYPE_ALL = 0;
    public static final int TYPE_PERMIT = 9;

    @Override
    protected DateFormatType getDateFormatType() {
        return DateFormatType.DATETIME;
    }

    /**
     * 当前用户修改密码
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/admin/changePassword")
    public ModelAndView changePasswd() throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();

        formFieldList.add(FormField.builder()
                .name("oldPassword")
                .type("pwd")
                .placeholder("请输入旧密码")
                .text("旧密码")
                .verify("required")
                .build());
        formFieldList.add(FormField.builder()
                .name("password")
                .type("pwd")
                .placeholder("请输入新密码")
                .text("新密码")
                .verify("required")
                .build());
        formFieldList.add(FormField.builder()
                .name("rePassword")
                .type("pwd")
                .placeholder("请输入确认密码")
                .text("再次输入新密码")
                .verify("required")
                .build());

        Map<String, Object> data = PageUtil.createFormPageStructure("org/passwd/save", formFieldList);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 当前用户保存密码
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/passwd/save")
    public DyResponse savePasswd(String oldPassword, String password, String rePassword) throws Exception {
        OrgUser OrgUser = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
        // 非空校验
        String errorMsg = validateNull(new Object[]{password, rePassword},
                new String[2],
                new String[]{"登陆密码", "确认密码"});
        if (StringUtils.isNotBlank(errorMsg)) return createErrorJsonResonse(errorMsg);

        // 新密码与确认密码是否一致
        if (!password.equals(rePassword)) return createErrorJsonResonse(this.getMessage("system.errorNewPassword"));
        if (!oldPassword.equals(OrgUser.getPassword())) {
            return createErrorJsonResonse("旧密码错误");
        }
        QueryItem queryItem = new QueryItem(Where.eq("username", OrgUser.getUsername()));
        OrgUser admin = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
        admin.setPassword(SecurityUtil.md5(SecurityUtil.sha1(password)));

        this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, admin);
        return createSuccessJsonResonse(null, "修改密码成功");
    }

    /**
     * 获取所有用户
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @RequestMapping("list/{type}")
    public ModelAndView list(@PathVariable("type") int type) throws Exception {
        TableHeader tableHeader = new TableHeader();
        if (TYPE_ALL == type) {
            tableHeader.setNames(
                    new String[]{"id", "username", "company_name", "work_area", "company_work_address",
                            "company_type", "contact_name", "contact_phone_number", "email", "company_role_type", "register_ip", "register_time", "cust_status"});
            tableHeader.setTexts(new String[]{"ID", "用户名", "公司名称", "公司所在地", "公司地址", "公司类型", "联系人", "联系人手机", "邮箱地址", "角色", "注册IP", "注册日期",
                    "状态"});
            tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", "", "", "", "", "date", ""});
            tableHeader.setFilters(new String[]{"", "input", "input", "", "", "", "", "", "", "select", "", "multi_date", "select"});
            tableHeader.setOptionTypes(new String[]{"", "", "", "", "", "company_type", "", "", "", "company_role_type", "", "", "cust_status"});
            // tableHeader.setFilters(new String[]{"","input","input","","","","select","select","","multi_date"});
        } else if (CompanyRoleType.COMPANY_CREDIT.getIndex() == type || CompanyRoleType.COMPANY_CORE.getIndex() == type) {
            tableHeader.setNames(
                    new String[]{"id", "company_name", "business_lic_type", "business_lic_no", "work_area", "contact_name",
                            "contact_phone_number", "create_time", "company_check_status", "blacklist_type", "saler_id", "saler_department"});
            tableHeader.setTexts(
                    new String[]{"ID", "公司名称", "证件类型", "证件号码", "办公所在地", "联系人", "联系人手机", "提交时间", "状态", "是否黑名单", "客户经理", "所属部门"});
            tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", "datetime", "", "", "", ""});
            tableHeader.setFilters(new String[]{"", "input", "", "input", "", "", "", "multi_date", "", "", "select", ""});
            tableHeader.setOptionTypes(new String[]{"", "", "", "", "", "", "", "", "company_check_status", "common_status", "manager", ""});
        } else if (TYPE_PERMIT == type) {
            tableHeader.setNames(
                    new String[]{"id", "username", "company_name", "business_lic_type", "business_lic_no", "work_area", "company_work_address",
                            "company_type", "contact_name", "contact_phone_number", "approve_status", "create_time"});
            tableHeader.setTexts(new String[]{"ID", "用户名", "公司名称", "证件类型", "证件号码", "公司所在地", "公司地址", "公司类型", "联系人", "联系人手机", "审核状态", "提交时间"});
            tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "", "", "", "", "", "datetime"});
            // 过滤
            tableHeader.setOptionTypes(new String[]{"", "", "", "", "", "", "", "company_type", "", "", "approve_status", ""});
        } else if (CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() == type) {
            tableHeader.setNames(
                    new String[]{"id", "company_name", "capital_side_type", "create_time", "status"});
            tableHeader.setTexts(new String[]{"ID", "企业名称", "资方类型", "创建时间", "状态"});
            tableHeader.setTypes(new String[]{"int", "", "", "datetime", ""});
            tableHeader.setOptionTypes(new String[]{"", "", "capital_side_type", "", "company_status"});

        } else if (CompanyRoleType.COMPANY_SUPERVISE.getIndex() == type) {
            tableHeader.setNames(
                    new String[]{"id", "company_name", "supervise_level", "supervise_mode", "level_affirm_date", "level_overdue_date", "cooperate", "archive_date", "create_time"});
            tableHeader.setTexts(new String[]{"ID", "公司名称", "监管公司等级", "监管模式", "等级认定日", "等级到期日", "合作状态", "建档日期", "提交时间"});
            tableHeader.setTypes(new String[]{"int", "", "", "", "date", "date", "", "date", "datetime", "", ""});
            tableHeader.setOptionTypes(new String[]{"", "", "supervise_level", "", "", "", "cooperate", "", ""});
        }
        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"公司名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data;
        if (TYPE_ALL != type) {
            data = PageUtil.createTablePageStructure("system/company/listData/" + type, "system/company/info/" + type, "id", tableHeader, tool, search);
        } else {
            data = PageUtil.createTablePageStructure("system/company/listData/" + type, "id", tableHeader, tool, search);
        }
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    private Map getUser(Object companyId) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("id as user_id,username,email,register_ip,register_time,cust_status");
        queryItem.setWhere(Where.eq("company_id", companyId));
        List<Map> list = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER);
        if (list != null && list.size() > 0) {
            return list.get(0);
        }
        return null;
    }

    private Map getCompanyMap(Object companyId) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("id", companyId));
        Company company = getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        return (Map) new DataConvertUtil(company, false).convert();
    }

    private List<Object> getIdsLike(String module, String function, String field, String col, Object cond, String type) throws Exception {
        QueryItem queryItem = new QueryItem();
        if (cond != null && "datetime".equals(type)) {
            queryItem.setWhere(this.addDateWhereCondition(null, col, cond.toString()));
        } else {
            queryItem.setWhere(Where.likeAll(col, cond));
        }
        queryItem.setPage(1);
        queryItem.setLimit(100); // 限定模糊条件100内
        if (StringUtils.isBlank(field)) {
            field = "id";
        }
        queryItem.setFields(field);
        List<Map> ents = this.getListByMap(queryItem, module, function);

        List<Object> ids = Lists.newArrayList();
        if (ents != null) {
            for (Map s : ents) {
                ids.add(s.get(field).toString());
            }
        }
        return ids;
    }

    /**
     * 获取用户数据
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("listData/{type}")
    public DyResponse listData(Integer page, Integer limit, String search, String username, String company_name,
                               String saler_id, String dept_id, String create_time, Integer company_role_type, String register_time,
                               Integer cust_status, String business_lic_type, String business_lic_no,
                               @PathVariable("type") int type) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        //所有用户
        if (type == TYPE_ALL) {
            List<Where> whereList = new ArrayList<Where>();
            queryItem.setFields("id,company_name,company_license,work_area,company_work_address,company_type,contact_name,contact_phone_number,company_role_type,create_time,saler_id,saler_department");

            if (StringUtils.isNotBlank(search)) {
                addWhereCondition(whereList, "company_name", LIKE_ALL, search);
            }
            this.addWhereCondition(whereList, "del_flag", 0);
            queryItem.setWhere(whereList);
            if (StringUtils.isNotBlank(username)) {
                queryItem.setWhere(Where.in("id", this.getIdsLike(SCModule.SYSTEM, SCFunction.SYS_USER, "company_id", "username", username, null)));
            }
            if (cust_status != null) {
                queryItem.setWhere(Where.in("id", this.getIdsLike(SCModule.SYSTEM, SCFunction.SYS_USER, "company_id", "cust_status", cust_status, null)));
            }
            if (StringUtils.isNotBlank(company_name)) {
                queryItem.setWhere(Where.likeAll("company_name", company_name));
            }
            if (company_role_type != null) {
                queryItem.setWhere(Where.eq("company_role_type", company_role_type));
            }
            if (register_time != null) {
                queryItem.setWhere(Where.in("id", this.getIdsLike(SCModule.SYSTEM, SCFunction.SYS_USER, "company_id", "register_time", register_time, "datetime")));
            }
            queryItem.setOrders("id desc");

            Page pageData = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
            List<Map> list = pageData.getItems();

            this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_USER, "id#company_id:username,email,register_ip,register_time,cust_status");
            return createSuccessJsonResonse(pageData);
        } else if (CompanyRoleType.COMPANY_SUPERVISE.getIndex() == type) {
            return listDataSupervise(queryItem, search, type, company_name, business_lic_type, business_lic_no, create_time, saler_id);
        } else {//授信企业 核心企业
            List<Where> whereList = new ArrayList<Where>();
            queryItem.setFields("id,company_name,business_lic_type,business_lic_no,company_license,work_area,company_work_address,company_type,contact_name,contact_phone_number,company_role_type,create_time,saler_id,saler_name,saler_department,capital_side_type,status,approve_status,company_check_status,blacklist_type");

            if (StringUtils.isNotBlank(search)) {
                addWhereCondition(whereList, "company_name", LIKE_ALL, search);
            }
            this.addWhereCondition(whereList, "del_flag", 0);
            if (CompanyRoleType.COMPANY_CORE.getIndex() == type) {
                this.addWhereCondition(whereList, "company_role_type", CompanyRoleType.COMPANY_CORE.getIndex());
            } else if (CompanyRoleType.COMPANY_CREDIT.getIndex() == type) {
                this.addWhereCondition(whereList, "company_role_type", CompanyRoleType.COMPANY_CREDIT.getIndex());
            } else if (TYPE_PERMIT == type) {
                this.addWhereCondition(whereList, "company_role_type", IN, CompanyRoleType.COMPANY_CREDIT.getIndex() + "," + CompanyRoleType.COMPANY_NORMAL.getIndex());
            } else if (CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() == type) {
                this.addWhereCondition(whereList, "company_role_type", CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex());
            }
            queryItem.setWhere(whereList);
            if (StringUtils.isNotBlank(company_name)) {
                queryItem.setWhere(Where.likeAll("company_name", company_name));
            }
            if (StringUtils.isNotBlank(business_lic_type)) {
                queryItem.setWhere(Where.likeAll("business_lic_type", business_lic_type));
            }
            if (StringUtils.isNotBlank(business_lic_no)) {
                queryItem.setWhere(Where.likeAll("business_lic_no", business_lic_no));
            }
            if (StringUtils.isNotBlank(create_time)) {
                queryItem.setWhere(this.addDateWhereCondition(null, "create_time", create_time));
            }
            if (saler_id != null) {
                queryItem.setWhere(Where.eq("saler_id", saler_id));
            }
            queryItem.setOrders("id desc");

            Page pageData = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
            List<Map> list = pageData.getItems();
            if (list != null && list.size() > 0) {
                for (Map item : list) {
                    item.put("blacklist_type", item.get("blacklist_type") == null ? "0" : "1");
                }
            }
            this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_USER, "id#company_id:username,email,register_ip,register_time,cust_status");
            dataConvert(list, "business_lic_type:business_lic_type");
            return createSuccessJsonResonse(pageData);
        }
    }

    /**
     * 查询监管企业
     *
     * @param queryItem
     * @param search
     * @param type
     * @param company_name
     * @param business_lic_type
     * @param business_lic_no
     * @param create_time
     * @param saler_id
     * @return
     * @throws Exception
     * @author likf
     */
    private DyResponse listDataSupervise(QueryItem queryItem, String search, int type, String company_name, String business_lic_type,
                                         String business_lic_no, String create_time, String saler_id) throws Exception {
        queryItem.setFields("id,company_name,business_lic_type,business_lic_no,company_license,work_area,company_work_address,company_type,contact_name,contact_phone_number,company_role_type,create_time,saler_id,saler_name,saler_department,capital_side_type,status");

        List<Where> whereList = Lists.newArrayList();
        if (StringUtils.isNotBlank(search)) {
            addWhereCondition(whereList, "company_name", LIKE_ALL, search);
        }
        this.addWhereCondition(whereList, "del_flag", 0);
        this.addWhereCondition(whereList, "company_role_type", CompanyRoleType.COMPANY_SUPERVISE.getIndex());
        queryItem.setWhere(whereList);
        if (StringUtils.isNotBlank(company_name)) {
            queryItem.setWhere(Where.likeAll("company_name", company_name));
        }
        if (StringUtils.isNotBlank(business_lic_type)) {
            queryItem.setWhere(Where.likeAll("business_lic_type", business_lic_type));
        }
        if (StringUtils.isNotBlank(business_lic_no)) {
            queryItem.setWhere(Where.likeAll("business_lic_no", business_lic_no));
        }
        if (StringUtils.isNotBlank(create_time)) {
            queryItem.setWhere(this.addDateWhereCondition(null, "create_time", create_time));
        }
        queryItem.setOrders("id desc");

        Page pageData = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        List<Map> list = pageData.getItems();
        this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_USER, "id#company_id:username,email,register_ip,register_time,cust_status");
        this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_COMPANY_SUPERVISE, "id#company_id:supervise_mode,supervise_level,level_affirm_date,level_overdue_date,supervise_region_type,cooperate,archive_date");
        for (Map item : list) {
            String superviseMode = MapUtils.getString(item, "supervise_mode");
            item.put("supervise_mode", translate(superviseMode, "supervise_mode"));
        }
        return createSuccessJsonResonse(dataConvert(pageData, "business_lic_type"));
    }

    private String translate(String before, String dictType) {
        if (StringUtils.isNoneBlank(before)) {
            String[] befores = before.split(",");
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < befores.length; i++) {
                sb.append(DictUtils.getDictLabel(befores[i], dictType));
                if (i != befores.length - 1) {
                    sb.append(",");
                }
            }
            return sb.toString();
        }
        return null;
    }

    /**
     * @param company
     * @return void
     * lipengpeng
     * @throws Exception
     * @Title: setSignImgInfo
     * @Description: 设置云章信息
     */
    @SuppressWarnings("unchecked")
    private void setSignImgInfo(Map company) throws Exception {
        // 判断系统是否配置开启云章
        QueryItem queryConfig = new QueryItem(Where.eq("nid", "use_cloudsign"));
        SysSystemConfig config = this.getOneByEntity(queryConfig, SCModule.SYSTEM, SCFunction.SYS_CONFIG, SysSystemConfig.class);
        if (config.getStatus() == AccConstants.STATUS_OPEN) {
            Long docId = MapUtils.getLong(company, "doc_id");
            if (docId != null) {
                QueryItem queryDoc = new QueryItem(Where.eq("id", docId));
                SysDocument doc = this.getOneByEntity(queryDoc, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
                if (doc != null) {
                    company.put("sign_img_name", doc.getFileName());
                    company.put("file_path", doc.getFilePath());
                }
            }
        }
    }

    /**
     * 授信客户企业信息
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "view/{type}")
    public ModelAndView view(Long id, @PathVariable("type") int type) throws Exception {

        if (TYPE_ALL == type) {
            return null;
        } else if (CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() == type) {
            QueryItem q = new QueryItem();
            q.setWhere(Where.eq("id", id));
            Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

            // 印章信息
            this.setSignImgInfo(company);

            Map<String, Object> account = BaseInfoUtils.getCompAccountMap(id);
            if (account != null) {
                if (account.get("account") != null) {
                    company.put("open_bank", account.get("open_bank"));
                    company.put("open_bank_account", account.get("account"));
                }
            } else {
                company.put("open_bank", null);
                company.put("open_bank_account", null);
            }
            if (company.get("company_create_time") != null) {
                company.put("company_create_time", DateUtil.dateFormat(company.get("company_create_time")));
            }
            dataConvert(company, "capital_side_type,legal_card_type:cred_type,contact_card_type:cred_type,financial_card_type:cred_type,business_lic_type,company_type,company_category,company_scale,is_stock:common_status");

            return createSuccessModelAndView("system/companyCapitalSide", JsonUtils.object2JsonString(company));
        } else {
            QueryItem q = new QueryItem();
            q.setWhere(Where.eq("id", id));
            Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
            // 印章信息
            this.setSignImgInfo(company);

            QueryItem queryItem = new QueryItem();
            Map<String, Object> account = BaseInfoUtils.getCompAccountMap(id);
            if (account != null) {
                if (account.get("account") != null) {
                    company.put("open_bank", account.get("open_bank"));
                    company.put("open_bank_account", account.get("account"));
                }
            } else {
                company.put("open_bank", null);
                company.put("open_bank_account", null);
            }

            QueryItem query = new QueryItem();
            query.setWhere(Where.eq("id", company.get("saler_id")));
            query.setWhere(Where.eq("type", AccountTypeEnum.SALER.getIndex()));
            OrgUser s = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
            if (s != null) company.put("saler_name", s.getRealName());

            //上下游企业
            queryItem = new QueryItem();
            queryItem.setFields("core_company_id,chain_position");
            queryItem.setWhere(Where.eq("check_status", CheckStatus.CHECK_PASS.getIndex()));
            queryItem.setWhere(Where.eq("company_id", id));

            if (company.get("company_create_time") != null) {
                company.put("company_create_time", DateUtil.dateFormat(company.get("company_create_time")));
            }
            dataConvert(company, "legal_card_type:cred_type,contact_card_type:cred_type,financial_card_type:cred_type,business_lic_type,company_type,company_category,company_scale,is_stock:common_status");

            // 附件信息
            queryItem = new QueryItem(Where.eq("company_id", id));
            List<Map> documents = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT);
            this.idToName(documents, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, "premise_material_id:name as material_name");
            company.put("documents", dataConvert(documents, null, "create_time"));
            company.put("source", "company");
            company.put("company_id", id);
            if (type == CompanyRoleType.COMPANY_CREDIT.getIndex()) {
                // 授信企业-额度信息
                this.getLimitInfo(company);
                // 融资情况
                queryItem = new QueryItem(Where.eq("company_id", id));
                Map<String, Object> statCredit = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.STAT_CREDIT);
                company.put("credit", statCredit == null ? Maps.newHashMap() : statCredit);
                queryItem = new QueryItem(Where.eq("company_id", id));
                Map<String, Object> statBill = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.STAT_RECEIVE_BILL);
                company.put("stat_bill", statBill);
            } else if (type == CompanyRoleType.COMPANY_CORE.getIndex()) {
                queryItem = new QueryItem(Where.eq("company_id", id));
                Map<String, Object> statBill = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.STAT_RECEIVE_BILL);
                company.put("pay_bill", statBill == null ? Maps.newHashMap() : statBill);
            }

            return createSuccessModelAndView("system/companyInfo", JsonUtils.object2JsonString(company));
        }

    }

    /**
     * @param company
     * @return void
     * lipengpeng
     * @throws Exception
     * @Title: getLimitInfo
     * @Description: 获取额度记录信息
     */
    @SuppressWarnings("unchecked")
    private void getLimitInfo(Map company) throws Exception {
        QueryItem queryLimit = new QueryItem(Where.eq("company_id", company.get("id")));
        queryLimit.setWhere(Where.eq("check_status", ScConstants.LIMIT_PASS));
        List<Map> limits = this.getListByMap(queryLimit, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        for (Map limit : limits) {
            limit.put("limit_type", this.getById(limit.get("business_type_id").toString(), SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class).getName());
            limit.put("create_time", DateUtil.dateFormat(limit.get("create_time")));
            OrgUser user = this.getById(limit.get("create_uid").toString(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
            limit.put("creater", user == null ? "" : user.getRealName());
            limit.put("dept_name", user == null ? "" : user.getDeptName());
        }
        company.put("limits", limits);
    }

    @SuppressWarnings("unchecked")
    private ModelAndView createSuperviseCompanyInfo(Long id) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

        q = new QueryItem();
        q.setWhere(Where.eq("company_id", id));
        Map companySupervise = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY_SUPERVISE);
        companySupervise.remove("id");
        company.putAll(companySupervise);

        Object userId = company.get("create_uid");
        if (userId != null) {
            Map creater = this.getById((Serializable) userId, SCModule.SYSTEM, SCFunction.SYS_ADMIN);
            if (creater != null) {
                company.put("creater", creater.get("real_name"));
                company.put("saler_department", creater.get("dept_name"));
            }
        }
        // 印章信息
        this.setSignImgInfo(company);

        if (company.get("company_create_time") != null) {
            company.put("company_create_time", DateUtil.dateFormat(company.get("company_create_time")));
        }
        if (company.get("level_affirm_date") != null) {
            company.put("level_affirm_date", DateUtil.dateFormat(company.get("level_affirm_date")));
        }
        if (company.get("level_overdue_date") != null) {
            company.put("level_overdue_date", DateUtil.dateFormat(company.get("level_overdue_date")));
        }
        if (company.get("archive_date") != null) {
            company.put("archive_date", DateUtil.dateFormat(company.get("archive_date")));
        }

        company.put("company_id", id);
        company.put("source", "company");
        dataConvert(company, "legal_card_type:cred_type,contact_card_type:cred_type,business_lic_type,company_type,company_category,supervise_mode,supervise_level,supervise_region_type,cooperate");
        getViewMenu(company);
        return createSuccessModelAndView("system/companySupervise", JsonUtils.object2JsonString(company));
    }

    @SuppressWarnings("unchecked")
    public Map getViewData(Long id) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        Integer blacklistType = MapUtils.getInteger(company, "blacklist_type");
        if (blacklistType != null) {
            company.put("blacklist_type", "是");
        } else {
            company.put("blacklist_type", "否");
        }

        Map companyDetail = getCompanyDetail(id, false);
        if (companyDetail != null) {
            companyDetail.remove("id");
            company.putAll(companyDetail);
            company.put("manage_status", DictUtils.getDictLabel(company.get("manage_status"), "manage_status"));
            company.put("manage_feature_type", DictUtils.getDictLabel(company.get("manage_feature_type"), "manage_feature_type"));
            company.put("company_life_type", DictUtils.getDictLabel(company.get("company_life_type"), "company_life_type"));
            company.put("legal_sex", DictUtils.getDictLabel(company.get("legal_sex"), "sex"));
            company.put("legal_degree", DictUtils.getDictLabel(company.get("legal_degree"), "legal_degree"));
            company.put("legal_birthday", DateUtil.dateFormat(company.get("legal_birthday")));
            company.put("legal_card_expire", DateUtil.dateFormat(company.get("legal_card_expire")));

            company.put("properties", getCompanyLegalProperty(id));
            company.put("shareholders", dataConvert(getCompanyShareholder(id), "shareholderType:shareholder_type"));

        }

        Map<String, Object> account = BaseInfoUtils.getCompAccountMap(id);
        if (account != null) {
            if (account.get("account") != null) {
                company.put("open_bank", account.get("open_bank"));
                company.put("open_bank_account", account.get("account"));
                company.put("open_full_name", account.get("open_full_name"));//账户名
                company.put("acc_balance", account.get("acc_balance"));
            }
        } else {
            company.put("open_bank", null);
            company.put("open_bank_account", null);
            company.put("open_full_name", null);
            company.put("acc_balance", null);
        }

        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("id", company.get("saler_id")));
        query.setWhere(Where.eq("type", AccountTypeEnum.SALER.getIndex()));
        OrgUser s = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
        if (s != null) company.put("saler_name", s.getRealName());

        if (company.get("company_create_time") != null) {
            company.put("company_create_time", DateUtil.dateFormat(company.get("company_create_time")));
        }
        //实名认证审批情况
        if (company.get("proc_inst_ids") != null && StringUtils.isNotBlank(company.get("proc_inst_ids").toString())) {
            List<Map> checkList = getFlowByIds(company.get("proc_inst_ids").toString());
            if (checkList != null) {
                dataConvert(checkList, null, "create_time");
            }
            company.put("checkList", checkList);
        }

        QueryItem queryItem = new QueryItem(Where.eq("company_id", id));
        List<Map> documents = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT);
        this.idToName(documents, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, "premise_material_id:name as material_name");
        company.put("documents", dataConvert(documents, "never_expire:common_status", "create_time"));


        company.put("company_id", id);
        company.put("source", "company");
        dataConvert(company, "legal_card_type:cred_type,contact_card_type:cred_type,financial_card_type:cred_type,business_lic_type,company_type,company_category,company_scale,is_stock:common_status");
        getViewMenu(company);
        return company;
    }

    /**
     * 公司信息
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "info/{type}")
    public ModelAndView info(Long id, @PathVariable("type") int type) throws Exception {
        if (TYPE_ALL == type) {
            return null;
        } else if (CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() == type) {
            QueryItem q = new QueryItem();
            q.setWhere(Where.eq("id", id));
            Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

            // 印章信息
            this.setSignImgInfo(company);

            Map<String, Object> account = BaseInfoUtils.getCompAccountMap(id);

            if (account != null) {
                if (account.get("account") != null) {
                    company.put("open_bank", account.get("open_bank"));
                    company.put("open_bank_account", account.get("account"));
                    company.put("open_full_name", account.get("open_full_name"));//账户名
                }
            } else {
                company.put("open_bank", null);
                company.put("open_bank_account", null);
                company.put("open_full_name", null);//账户名
            }
            if (company.get("company_create_time") != null) {
                company.put("company_create_time", DateUtil.dateFormat(company.get("company_create_time")));
            }
            dataConvert(company, "capital_side_type,legal_card_type:cred_type,contact_card_type:cred_type,financial_card_type:cred_type,business_lic_type,company_type,company_category,company_scale,is_stock:common_status");

            return createSuccessModelAndView("system/companyCapitalSide", JsonUtils.object2JsonString(company));
        } else if (CompanyRoleType.COMPANY_SUPERVISE.getIndex() == type) {
            return createSuperviseCompanyInfo(id);
        } else if (CompanyRoleType.COMPANY_CREDIT.getIndex() == type || CompanyRoleType.COMPANY_CORE.getIndex() == type) {
            Map company = getViewData(id);
            return createSuccessModelAndView("system/companyDetail", JsonUtils.object2JsonString(company));
        } else if (TYPE_PERMIT == type) {
            Map company = getViewData(id);
            return createSuccessModelAndView("system/companyDetail", JsonUtils.object2JsonString(company));
        }
        return null;
    }

    /**
     * 附件
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "documentView/{type}")
    public ModelAndView documentView(Long id, @PathVariable("type") int type) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        Object userId = null;
        if (MapUtils.getInteger(company, "company_role_type") == CompanyRoleType.COMPANY_SUPERVISE.getIndex()) {
            userId = company.get("create_uid");
        } else {
            userId = company.get("saler_uid");
        }

        if (userId != null) {
            Map creater = this.getById((Serializable) userId, SCModule.SYSTEM, SCFunction.SYS_ADMIN);
            if (creater != null) {
                company.put("creater", creater.get("real_name"));
                company.put("saler_department", creater.get("dept_name"));
            }
        }

        QueryItem queryItem = new QueryItem();
        // 附件信息
        queryItem = new QueryItem(Where.eq("company_id", id));
        List<Map> documents = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT);
        this.idToName(documents, SCModule.SYSTEM, SCFunction.SYS_PREMISE_MATERIAL, "premise_material_id:name as material_name");
        company.put("documents", dataConvert(documents, "never_expire:common_status", "create_time"));
        company.put("source", "company");
        company.put("company_id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyDocument", JsonUtils.object2JsonString(company));
    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "gradeView/{type}")
    public ModelAndView gradeView(Long id,@PathVariable("type")int type) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

        QueryItem queryItem = new QueryItem(Where.eq("company_id", id));
        List gradeList = this.getListByMap(queryItem, SCModule.CUSTOMER, SCFunction.CUS_GRADE_INFO);
        dataConvert(gradeList,"grade_template_id:cus_grade_template");
        company.put("gradeList", gradeList);
        company.put("source", "company");
        company.put("company_id",id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyGradeView", JsonUtils.object2JsonString(company));
    }

//    @SuppressWarnings("unchecked")
//    @ResponseBody
//    @RequestMapping(value = "partnerView/{type}")
//    public ModelAndView partnerView(Long id,@PathVariable("type")int type) throws Exception {
//        Map company = this.getById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
//
//        QueryItem query = new QueryItem(Where.eq("company_id", id));
//        List<CompanyRelation> relations = getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION, CompanyRelation.class);
//
//        QueryItem queryItem = new QueryItem(Where.eq("company_id", id));
//        List gradeList = this.getListByMap(queryItem, SCModule.CUSTOMER, SCFunction.CUS_GRADE_INFO);
//        dataConvert(gradeList,"grade_template_id:cus_grade_template");
//        company.put("gradeList", gradeList);
//        company.put("source", "company");
//        company.put("company_id",id);
//        company.put("relations", relations);
//        getViewMenu(company);
//        return createSuccessModelAndView("system/companyPartner", JsonUtils.object2JsonString(company));
//    }

    /**
     * 融资
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "loanView/{type}")
    public ModelAndView loanView(Long id, @PathVariable("type") int type) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        QueryItem queryItem = new QueryItem();
        // 附件信息
        queryItem = new QueryItem(Where.eq("company_id", id));
        Map<String, Object> statCredit = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.STAT_CREDIT);
        company.put("credit", statCredit);
        queryItem = new QueryItem(Where.eq("company_id", id));
        Map<String, Object> statBill = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.STAT_RECEIVE_BILL);
        company.put("stat_bill", statBill);
        company.put("source", "company");
        company.put("company_id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyLoan", JsonUtils.object2JsonString(company));

    }

    /**
     * 付款
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "payView/{type}")
    public ModelAndView payView(Long id, @PathVariable("type") int type) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        QueryItem queryItem = new QueryItem();
        // 附件信息
        queryItem = new QueryItem(Where.eq("company_id", id));
        Map<String, Object> statBill = this.getOneByMap(queryItem, SCModule.LOAN, SCFunction.STAT_RECEIVE_BILL);
        company.put("pay_bill", statBill == null ? Maps.newHashMap() : statBill);
        company.put("source", "company");
        company.put("company_id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyPay", JsonUtils.object2JsonString(company));

    }


    /**
     * 额度
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "limitView/{type}")
    public ModelAndView limitView(Long id, @PathVariable("type") int type) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        Map limit = createLimitView(id);
        company.put("source", "company");
        company.put("company_id", id);
        if(limit != null) {
            company.putAll(limit);
            company.put("nodata", false);
        }else{
            company.put("nodata", true);
        }
        getViewMenu(company);
        return createSuccessModelAndView("system/companyLimit", JsonUtils.object2JsonString(company));
    }

    private Map<String, Object> createLimitView(Object id) throws Exception {
        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("company_id", id));
        query.setWhere(Where.eq("business_type_id", 0));
        Map limit = this.getOneByMap(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        if(limit == null) {
            return null;
        }
        limit.put("companyName", this.getById(limit.get("company_id").toString(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class).getCompanyName());
        limit.put("looped", DictUtils.getDictLabel(limit.get("looped").toString(), "looped"));
        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("company_id", limit.get("company_id")));
        queryItem.setWhere(Where.notEq("business_type_id", 0));
        List<Map> companyLimits = this.getListByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        BigDecimal total = BigDecimal.ZERO;
        BigDecimal unused = BigDecimal.ZERO;
        for (Map companyLimit : companyLimits) {
            total = total.add(new BigDecimal(companyLimit.get("credit_limit").toString()));
            unused = unused.add(new BigDecimal(companyLimit.get("unused_limit").toString()));
            if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_RECEIVE) {
                companyLimit.put("name", "应收账款");
            } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_B2B) {
                companyLimit.put("name", "b2b平台类");
            } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
                companyLimit.put("name", "仓单");
            } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_AGPUR) {
                companyLimit.put("name", "代采");
            }
        }
        limit.put("credit_limit", total);
        limit.put("unused_limit", unused);
        limit.put("changeList", companyLimits);
        limit.put("changeType", "view");
        // 审批记录
        List<Map> flows = CommonLoanUtil.getFlowList(id.toString(), "limit_edit");
        List<Map> flows1 = CommonLoanUtil.getFlowList(id.toString(), "limit_add");
        if(flows != null){
            flows.addAll(flows1);
            limit.put("flowList", flows);
        }else {
            limit.put("flowList", flows1);
        }

        limit.put("startTime", DateUtil.dateFormat(limit.get("start_time")));
        limit.put("endTime", DateUtil.dateFormat(limit.get("end_time")));
        query = QueryItem.builder().where("company_id", limit.get("company_id")).where("grade_status", GradeStatus.VALID.getIndex()).build();
        CusGradeInfo cusGradeInfo=this.getOneByEntity(query, SCModule.CUSTOMER, SCFunction.CUS_GRADE_INFO,CusGradeInfo.class);
        if(cusGradeInfo != null) {
            limit.put("totalPoint", cusGradeInfo.getTotalPoint());
            limit.put("gradeDate", cusGradeInfo.getGradeDate());
            limit.put("riskLimit", cusGradeInfo.getRiskLimit());
        }
        Integer status = Integer.valueOf(limit.get("check_status").toString());
        limit.put("status", status == ScConstants.LIMIT_PASS ? "审批通过" : (status == ScConstants.LIMIT_CHECKING ? "审批中" : "驳回"));
        Company company = this.getById(limit.get("company_id").toString(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        limit.put("companyType", DictUtils.getDictLabel(company.getCompanyRoleType(),"company_role_type"));
        if(limit.get("create_uid") != null){
            // 客户经理
            Map creater = this.getById(limit.get("create_uid").toString(), SCModule.SYSTEM, SCFunction.SYS_ADMIN);
            if(creater!=null){
                limit.put("creater", creater.get("real_name"));
                limit.put("creater_dept", creater.get("dept_name"));
            }
        }
        return limit;
    }


    /**
     * 贷前评估
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "evaluateView/{type}")
    public ModelAndView evaluateView(Long id, @PathVariable("type") int type) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

        QueryItem queryItem = new QueryItem();
        queryItem = new QueryItem(Where.eq("company_id", id));
        Map evaluate = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_EVALUATE);
        if (evaluate != null) {
            company.putAll(evaluate);
        }
        company.put("source", "company");
        company.put("company_id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyEvaluate", JsonUtils.object2JsonString(company));

    }


    private List<Map> getCoreCompanyList() throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("company_name as text,id as value");
        queryItem.setWhere(Where.eq("company_role_type", CompanyRoleType.COMPANY_CORE.getIndex()));
        return this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
    }

    @SuppressWarnings("unchecked")
    private void createAllUserForm(List<FormField> formFieldList, boolean edit) throws Exception {
        formFieldList.add(FormField.builder().type("title").text("基本信息").build());
        if (!edit) {
            formFieldList.add(FormField.builder().name("username").text("用户名").verify("required").build());
            formFieldList.add(FormField.builder()
                    .name("password")
                    .type("pwd")
                    .text("密码")
                    .verify("required,pwdchar=[8|16]")
                    .build());
            formFieldList.add(FormField.builder()
                    .name("repassword")
                    .type("pwd")
                    .text("确认密码")
                    .verify("required,pwdchar=[8|16],equals=password")
                    .build());
        } else {
            formFieldList.add(FormField.builder().name("username").text("用户名").type("span").verify("required").build());
            formFieldList.add(FormField.builder()
                    .name("password")
                    .type("pwd")
                    .text("密码")
                    //.verify("pwdchar=[8|16]")
                    .build());
            formFieldList.add(FormField.builder()
                    .name("repassword")
                    .type("pwd")
                    .text("确认密码")
                    .verify("equals=password")
                    .build());
        }

        formFieldList.add(FormField.builder().name("companyRoleType").text("所属角色").type("radio").options(DictUtils.getOptionsInt("company_role_type")).verify("required").build());
        formFieldList.add(FormField.builder().name("companyName").text("公司名称").verify("required").build());
        List linklist = Lists.newArrayList();
        Map item = Maps.newHashMap();
        item.put("name", "pid_province");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "pid_city");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "workAreaId");
        linklist.add(item);

        formFieldList.add(FormField.builder().name("workAreaId").text("公司所在地").type("linkselect").url("/sys/area/listData").linklist(linklist).dataparams("['pid_province','pid_city','workAreaId']").build());
        formFieldList.add(FormField.builder().name("companyWorkAddress").text("公司地址").build());
        formFieldList.add(FormField.builder().name("companyType").text("公司类型").type("select").options(DictUtils.getOptionsInt("company_type")).build());
        formFieldList.add(FormField.builder().name("contactName").text("联系人姓名").verify("required").build());
        formFieldList.add(FormField.builder().name("contactPhoneNumber").text("联系人手机").verify("required,phone").build());
        formFieldList.add(FormField.builder().name("email").text("邮箱地址").verify("email").build());

        QueryItem queryItem = new QueryItem();
        List<Where> whereList = new ArrayList<Where>();
        addWhereCondition(whereList, "type", AccountTypeEnum.SALER.getIndex());
        addWhereCondition(whereList, "del_flag", 0);
        queryItem.setWhere(whereList);
        List<OrgUser> users = this.getListByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);

        List<FormOption> options = new ArrayList<>();
        for (OrgUser OrgUser : users) {
            if (OrgUser.getType() == 3) options.add(new FormOption(OrgUser.getRealName(), OrgUser.getId()));
        }
        formFieldList.add(FormField.builder()
                .name("salerId")
                .text("经办人")
                .type("userbox")
                .verify("required").br("br")
                .build());
    }

    @SuppressWarnings("unchecked")
    private void createCapitalForm(List<FormField> formFieldList) throws Exception {
        formFieldList.add(FormField.builder().type("title").text("基本信息").build());
        formFieldList.add(FormField.builder().name("companyName").text("企业名称").verify("required").build());
        formFieldList.add(FormField.builder().name("businessLicType").text("证件类型").type("select").options(DictUtils.getOptionsInt("business_lic_type")).verify("required").build());
        formFieldList.add(FormField.builder().name("businessLicNo").text("证件号码").verify("required").build());
        formFieldList.add(FormField.builder().name("businessRegNo").text("工商注册号").build());
        //TODO 检验非空
        formFieldList.add(FormField.builder().name("companyLicense").text("公司税号").build());
        formFieldList.add(FormField.builder().name("basicBank").text("基本户开户行").build());
        formFieldList.add(FormField.builder().name("basicAccount").text("基本户账号").verify("number").build());
        formFieldList.add(FormField.builder().name("basicPermitNo").text("基本户核准号").build());
        formFieldList.add(FormField.builder().name("generalBank").text("一般户开户行").build());
        formFieldList.add(FormField.builder().name("generalAccount").text("一般户账户").verify("number").build());

        formFieldList.add(FormField.builder().name("companyType").text("企业类型").type("select").options(DictUtils.getOptionsInt("company_type")).build());
        formFieldList.add(FormField.builder().name("companyCategory").text("所属行业").type("select").options(DictUtils.getOptionsInt("company_category")).build());
        formFieldList.add(FormField.builder().name("companyScale").text("企业规模").type("select").options(DictUtils.getOptionsInt("company_scale")).build());
        formFieldList.add(FormField.builder().name("isStock").text("是否上市").type("radio").options(DictUtils.getOptionsInt("common_status")).build());
        formFieldList.add(FormField.builder().name("companyCreateTime1").text("企业成立时间").type("date").build());
        formFieldList.add(FormField.builder().name("registerCapital").text("注册资本").build());

        List linklist = Lists.newArrayList();
        Map item = Maps.newHashMap();
        item.put("name", "pid_province");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "pid_city");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "workAreaId");
        linklist.add(item);

        formFieldList.add(FormField.builder().name("workAreaId").text("办公所在地").type("linkselect").url("/sys/area/listData").linklist(linklist).dataparams("['pid_province','pid_city','workAreaId']").build());

        formFieldList.add(FormField.builder().name("companyWorkAddress").text("办公地址").build());
        linklist = Lists.newArrayList();
        item = Maps.newHashMap();
        item.put("name", "pid_province1");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "pid_city1");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "companyAreaId");
        linklist.add(item);

        formFieldList.add(FormField.builder().name("companyAreaId").text("注册所在地").type("linkselect").url("/sys/area/listData").linklist(linklist).dataparams("['pid_province1','pid_city1','companyAreaId']").build());
        formFieldList.add(FormField.builder().name("companyAddress").text("注册地址").build());
        formFieldList.add(FormField.builder().name("capitalSideType").text("资方类型").type("select").verify("required").options(DictUtils.getOptions("capital_side_type")).build());
        formFieldList.add(FormField.builder().name("remark").text("备注").build());
        ;
        formFieldList.add(FormField.builder().type("title").text("人员信息").build());
        formFieldList.add(FormField.builder().name("legalName").text("法人姓名").verify("required").build());
        formFieldList.add(FormField.builder()
                .name("legalCardType")
                .type("select")
                .options("cred_type").verify("required")
                .text("法人证件类型")
                .build());
        formFieldList.add(FormField.builder().name("legalCardNo").text("法人证件号码").verify("idcard,required").build());
        formFieldList
                .add(FormField.builder().name("legalPhoneNumber").text("法人手机号码").verify("phone,required").build());
        formFieldList.add(FormField.builder().name("contactName").text("联系人姓名").build());
        formFieldList.add(
                FormField.builder().name("contactCardType").type("select").options("cred_type").text("联系人证件类型").build());
        formFieldList.add(FormField.builder().name("contactCardNo").text("联系人证件号码").verify("idcard").build());
        formFieldList
                .add(FormField.builder().name("contactPhoneNumber").text("联系人手机号码").verify("phone").build());
        formFieldList.add(FormField.builder().name("financialName").text("财务姓名").build());
        formFieldList.add(FormField.builder()
                .name("financialCardType")
                .type("select")
                .options("cred_type")
                .text("财务证件类型")
                .build());
        formFieldList
                .add(FormField.builder().name("financialCardNo").text("财务证件号码").verify("idcard").build());
        formFieldList
                .add(FormField.builder().name("financialPhoneNumber").text("财务手机号码").verify("phone").build());
        formFieldList
                .add(FormField.builder().name("fax").text("传真号码").build());
        formFieldList.add(FormField.builder().type("title").text("账户信息").build());
        formFieldList.add(FormField.builder()
                .name("openBank")
                .text("开户行")
                .type("select")
                .options("open_bank")
                .build());

        formFieldList.add(FormField.builder().name("openBankAccount").text("账号").build());
//        formFieldList.add(FormField.builder().type("title").text("印章信息").build());
//        formFieldList.add(FormField.builder().name("docId").text("印章图片").type("upload").build());
    }

    @SuppressWarnings("unchecked")
    private void createCompanyForm(List<FormField> formFieldList, List<FormField> formFieldList1, int type) throws Exception {
        formFieldList.add(FormField.builder().type("title").text("基本信息").build());
        formFieldList.add(FormField.builder()
                .name("salerId")
                .text("客户经理")
                .type("userbox")
                .verify("required").br("br")
                .build());
        formFieldList.add(FormField.builder().name("companyName").text("企业名称").verify("required").build());
        formFieldList.add(FormField.builder().name("companyEnglishName").text("企业名称（英文）").build());
        formFieldList.add(FormField.builder().name("businessLicType").text("证件类型").type("select").options(DictUtils.getOptionsInt("business_lic_type")).verify("required").build());
        formFieldList.add(FormField.builder().name("businessLicNo").type("button").remarks("一键导入").text("证件号码").verify("required").build());
        formFieldList.add(FormField.builder().name("companyType").text("客户境内外标记").type("select").options(DictUtils.getOptionsInt("company_type")).build());
        formFieldList.add(FormField.builder().name("companyCategory").text("国标行业分类").type("select").options(DictUtils.getOptionsInt("company_category")).build());
        formFieldList.add(FormField.builder().name("businessRange").text("营业范围").type("textarea").verify("required").build());
        formFieldList.add(FormField.builder().name("parentCompany").text("上级公司").build());
        formFieldList.add(FormField.builder().name("companyCreateTime1").text("企业成立时间").type("date").verify("required").build());
        formFieldList.add(FormField.builder().name("companyScale").text("经营规模").verify("required").type("select").options(DictUtils.getOptionsInt("company_scale")).build());
        formFieldList.add(FormField.builder().name("isStock").text("是否上市公司").verify("required").type("radio").options(DictUtils.getOptionsInt("common_status")).build());

        formFieldList.add(FormField.builder().name("currency").text("币种").build());
        formFieldList.add(FormField.builder().name("lastYearSaleAmount").text("上年度销售收入（万元）").verify("required").build());
        formFieldList.add(FormField.builder().name("registerCapital").text("注册资本（万元）").verify("required").build());
        formFieldList.add(FormField.builder().name("realCapital").text("实收资本（万元）").verify("required").build());
        formFieldList.add(FormField.builder().name("totalAsset").text("企业总资产（万元）").verify("required").build());
        formFieldList.add(FormField.builder().name("totalDebt").text("负债总额（万元）").verify("required").build());

        formFieldList.add(FormField.builder().name("businessRegNo").text("工商注册号").verify("required").build());
        //TODO 检验非空
        formFieldList.add(FormField.builder().name("companyLicense").text("税务登记证号").verify("required").build());

        formFieldList.add(FormField.builder().name("basicBank").text("基本户开户行").verify("required").build());
        formFieldList.add(FormField.builder().name("basicAccount").text("基本户账号").verify("required,number").build());
        formFieldList.add(FormField.builder().name("basicPermitNo").text("基本户核准号").verify("required").br("br").build());
        formFieldList.add(FormField.builder().name("generalBank").text("一般户开户行").verify("required").build());
        formFieldList.add(FormField.builder().name("generalAccount").text("一般户账户").verify("required,number").build());

        formFieldList.add(FormField.builder().name("employeeCount").text("员工人数").verify("required").build());
        formFieldList.add(FormField.builder().name("employeeCollegeCount").text("大专以上学历员工数").verify("required").build());
        formFieldList.add(FormField.builder().name("manageFeatureType").text("管理特征").type("select").options(DictUtils.getOptionsInt("manage_feature_type")).verify("required").build());
        formFieldList.add(FormField.builder().name("companyLifeType").text("企业所处生命周期阶段").type("select").options(DictUtils.getOptionsInt("company_life_type")).verify("required").build());
        formFieldList.add(FormField.builder().name("manageStatus").text("经营状况").type("select").options(DictUtils.getOptionsInt("manage_status")).verify("required").build());
        formFieldList.add(FormField.builder().name("remark").text("备注").type("textarea").build());

        formFieldList.add(FormField.builder().type("title").text("联系信息").build());
        formFieldList.add(FormField.builder().name("financialName").text("财务姓名").verify("required").build());
        formFieldList.add(FormField.builder()
                .name("financialCardType")
                .type("select").verify("required")
                .options("cred_type")
                .text("财务证件类型")
                .build());
        formFieldList.add(FormField.builder().name("financialCardNo").text("财务证件号码").verify("required,idcard").build());
        formFieldList.add(FormField.builder().name("financialPhoneNumber").text("财务手机号码").verify("required,phone").build());
        formFieldList.add(FormField.builder().name("contactName").verify("required").text("联系人姓名").build());
        formFieldList.add(FormField.builder().name("contactCardType").type("select").verify("required").options("cred_type").text("联系人证件类型").build());
        formFieldList.add(FormField.builder().name("contactCardNo").text("联系人证件号码").verify("required,idcard").build());
        formFieldList.add(FormField.builder().name("contactPhoneNumber").text("联系人手机号码").verify("required,phone").build());
        formFieldList.add(FormField.builder().name("email").text("公司邮箱").verify("email").build());
        formFieldList.add(FormField.builder().type("title").text("经营场所信息").build());
        List linklist = Lists.newArrayList();
        Map item = Maps.newHashMap();
        item.put("name", "pid_province");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "pid_city");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "workAreaId");
        linklist.add(item);
        formFieldList.add(FormField.builder().name("workAreaId").text("公司所在地").verify("required").type("linkselect").url("/sys/area/listData").linklist(linklist).dataparams("['pid_province','pid_city','workAreaId']").build());

        formFieldList.add(FormField.builder().name("companyWorkAddress").verify("required").text("公司地址").build());
        formFieldList.add(FormField.builder().name("phone").text("公司电话").build());
        formFieldList.add(FormField.builder().name("fax").text("公司传真").build());
        linklist = Lists.newArrayList();
        item = Maps.newHashMap();
        item.put("name", "pid_province1");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "pid_city1");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "companyAreaId");
        linklist.add(item);

        formFieldList.add(FormField.builder().name("companyAreaId").text("注册所在地").type("linkselect").url("/sys/area/listData").linklist(linklist).dataparams("['pid_province1','pid_city1','companyAreaId']").build());
        formFieldList.add(FormField.builder().name("companyAddress").text("注册地址").build());

        linklist = Lists.newArrayList();
        item = Maps.newHashMap();
        item.put("name", "pid_province2");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "pid_city2");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "factoryAreaId");
        linklist.add(item);
        formFieldList.add(FormField.builder().name("factoryAreaId").text("工厂所在地").type("linkselect").url("/sys/area/listData").linklist(linklist).dataparams("['pid_province2','pid_city2','factoryAreaId']").build());
        formFieldList.add(FormField.builder().name("factoryAddr").text("工厂地址").build());
        formFieldList.add(FormField.builder().name("factoryPhone").text("工厂电话").build());
        formFieldList.add(FormField.builder().name("factoryFax").text("工厂传真").build());
        formFieldList.add(FormField.builder().type("title").text("法人代表信息").build());
        formFieldList.add(FormField.builder().name("legalName").text("法人代表姓名").verify("required").build());
        formFieldList.add(FormField.builder().name("legalSex").text("性别").type("radio").options(DictUtils.getOptionsInt("sex")).build());
        formFieldList.add(FormField.builder().name("legalBirthday1").text("生日").type("date").build());
        formFieldList.add(FormField.builder()
                .name("legalCardType")
                .type("select")
                .options("cred_type").verify("required")
                .text("证件类型")
                .build());
        formFieldList.add(FormField.builder().name("legalCardNo").text("证件号码").verify("idcard,required").build());
        formFieldList.add(FormField.builder().name("legalCardExpire1").text("证件到期日").type("date").build());
        formFieldList.add(FormField.builder().name("legalCertNo").text("法人代表证字号").type("input").build());
        formFieldList.add(FormField.builder().name("legalDegree").text("学历").type("select").options(DictUtils.getOptionsInt("legal_degree")).build());
        formFieldList.add(FormField.builder().name("legalPhoneNumber").text("手机号码").verify("phone,required").build());
        formFieldList.add(FormField.builder().name("legalPhone").text("固定电话").type("input").build());
        formFieldList.add(FormField.builder().name("legalAddr").text("家庭住址").type("input").build());
        formFieldList.add(FormField.builder().name("legalZipcode").text("邮编").type("input").build());
    }

    @SuppressWarnings("unchecked")
    private void createCompanySuperviseForm(List<FormField> formFieldList) throws Exception {
        formFieldList.add(FormField.builder().type("title").text("基本信息").build());
        formFieldList.add(FormField.builder().name("companyName").text("企业名称").verify("required").build());

        formFieldList.add(FormField.builder().name("businessLicType").text("证件类型").type("select").options(DictUtils.getOptionsInt("business_lic_type")).verify("required").build());
        formFieldList.add(FormField.builder().name("businessLicNo").text("证件号码").verify("required").build());
        formFieldList.add(FormField.builder().name("superviseMode1").text("监管模式").type("checkbox").verify("required").options(DictUtils.getOptionsInt("supervise_mode")).build());
        formFieldList.add(FormField.builder().name("superviseLevel").text("监管公司等级").type("select").verify("required").options(DictUtils.getOptionsInt("supervise_level")).build());
        formFieldList.add(FormField.builder().name("superviseRegionType").text("监管区域").type("select").verify("required").options(DictUtils.getOptionsInt("supervise_region_type")).build());

        formFieldList.add(FormField.builder().name("superviseRegion").text("具体监管区域（省/市）").build());
        formFieldList.add(FormField.builder().name("superviseRate").text("巡库频率（天）").verify("required").build());
        formFieldList.add(FormField.builder().name("levelAffirmDate1").text("等级认定日").verify("required").type("date").build());
        formFieldList.add(FormField.builder().name("levelOverdueDate1").text("等级到期日").verify("required").type("date").build());
        formFieldList.add(FormField.builder().name("companyCreateTime1").text("企业成立时间").type("date").build());
        formFieldList.add(FormField.builder().name("registerCapital").text("注册资本").build());

        List linklist = Lists.newArrayList();
        Map item = Maps.newHashMap();
        item.put("name", "pid_province");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "pid_city");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "workAreaId");
        linklist.add(item);

        formFieldList.add(FormField.builder().name("workAreaId").text("办公所在地").type("linkselect").url("/sys/area/listData").linklist(linklist).dataparams("['pid_province','pid_city','workAreaId']").build());

        formFieldList.add(FormField.builder().name("companyWorkAddress").text("办公地址").build());
        linklist = Lists.newArrayList();
        item = Maps.newHashMap();
        item.put("name", "pid_province1");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "pid_city1");
        linklist.add(item);
        item = Maps.newHashMap();
        item.put("name", "companyAreaId");
        linklist.add(item);

        formFieldList.add(FormField.builder().name("companyAreaId").text("注册所在地").type("linkselect").url("/sys/area/listData").linklist(linklist).dataparams("['pid_province1','pid_city1','companyAreaId']").build());
        formFieldList.add(FormField.builder().name("companyAddress").text("注册地址").build());
        formFieldList.add(FormField.builder().name("cooperate").text("合作状态").type("select").verify("required").options(DictUtils.getOptionsInt("cooperate")).verify("required").build());
        formFieldList.add(FormField.builder().name("archiveDate1").text("建档日期").type("date").verify("required").build());
        formFieldList.add(FormField.builder().name("remark").text("备注").type("textarea").build());

        QueryItem queryItem = new QueryItem();
        List<OrgUser> users = this.getListByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
        List<FormOption> options = new ArrayList<>();
        for (OrgUser OrgUser : users) {
            if (OrgUser.getType() == 3) options.add(new FormOption(OrgUser.getRealName(), OrgUser.getId()));
        }
        formFieldList.add(FormField.builder().type("title").text("人员信息").build());
        formFieldList.add(FormField.builder().name("contactName").text("联系人姓名").build());
        formFieldList.add(
                FormField.builder().name("contactCardType").type("select").options("cred_type").text("证件类型").build());
        formFieldList.add(FormField.builder().name("contactCardNo").text("证件号码").verify("idcard").build());
        formFieldList
                .add(FormField.builder().name("contactPhoneNumber").text("手机号码").verify("phone").build());
    }

    @RequestMapping(value = "uploadMaterial")
    public ModelAndView uploadMaterial(Long id) throws Exception {
        Map<String, Object> formData = Maps.newHashMap();
        formData.put("id", id);
        formData.put("companyName", id2NameModule.getCompanyNameById(id));

        formData.put("premiseMaterials", DictUtils.getOptions("premise_material"));
        formData.put("common_status", DictUtils.getOptionsInt("common_status"));
        Map<String, Object> data = PageUtil.createFormPageStructure("system/company/addMaterial", null, formData);
        return createSuccessModelAndView("system/companyCreditAdd", JsonUtils.object2JsonString(data));
    }

    @RequestMapping(value = "addMaterial")
    @ResponseBody
    public DyResponse addMaterial(Long id, Long premiseMaterialId, Long expireDate, String licenseNo,
                                  Integer neverExpire, String files) throws Exception {
        if (StringUtils.isNotBlank(files)) {
            String[] fs = files.split(",");
            for (String fid : fs) {
                SysDocument document = this.getById(fid, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, SysDocument.class);
                CompanyCredit companyCredit = new CompanyCredit();
                companyCredit.setCompanyId(id);
                companyCredit.setPremiseMaterialId(premiseMaterialId);
                companyCredit.setFileName(document.getFileName());
                companyCredit.setFilePath(document.getFilePath());
                companyCredit.setExpireDate(expireDate);
                companyCredit.setLicenseNo(licenseNo);
                companyCredit.setNeverExpire(neverExpire);
                this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT, companyCredit);
            }
        }
        return this.createSuccessJsonResonse(null, "上传成功！");

    }

    @RequestMapping(value = "deleteMaterial")
    @ResponseBody
    public DyResponse deleteMaterial(Long id) throws Exception {
        this.deleteById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY_CREDIT);
        return this.createSuccessJsonResonse(null, "删除成功！");
    }

    /**
     * 用户新增页面
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "add/{type}")
    public ModelAndView add(@PathVariable("type") int type) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        List<FormField> formFieldList1 = null;
        String view = "common/add";
        Map<String, Object> formData = Maps.newHashMap();
        if (type == TYPE_ALL) {
            createAllUserForm(formFieldList, false);
            List depts = TreeUtils.getDeptOptions();// 所有部门
            Map<String, Object> deptTree = new HashMap<String, Object>();
            deptTree.put("department_list", depts);
            formData.put("service_type", deptTree);
            deptTree.put("getlist_url", "loan/contract/getuser");
            formData.put("departmentData", depts);
            view = "company/add";
        } else if (CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() == type) {
            createCapitalForm(formFieldList);
        } else if (CompanyRoleType.COMPANY_SUPERVISE.getIndex() == type) {
            formFieldList1 = new ArrayList<>();
            createCompanySuperviseForm(formFieldList);
        } else if (type == CompanyRoleType.COMPANY_CREDIT.getIndex() || type == CompanyRoleType.COMPANY_CORE.getIndex()) {
            formFieldList1 = new ArrayList<>();
            createCompanyForm(formFieldList, formFieldList1, type);
            formData.put("shareholder_card_type", DictUtils.getOptionsInt("shareholder_card_type"));
            formData.put("manage_feature_type", DictUtils.getOptionsInt("manage_feature_type"));
            formData.put("company_life_type", DictUtils.getOptionsInt("company_life_type"));
            formData.put("manage_status", DictUtils.getOptionsInt("manage_status"));
            formData.put("shareholder_type", DictUtils.getOptionsInt("shareholder_type"));
            formData.put("legal_degree", DictUtils.getOptionsInt("legal_degree"));
            //授信企业
            if (type == CompanyRoleType.COMPANY_CREDIT.getIndex()) {
                List chains = Lists.newArrayList();
                Map chain = Maps.newHashMap();
                chain.put("coreCompanyId", "");
                chain.put("chainPosition", "");
                chains.add(chain);
                formData.put("chains", chains);
                List optionsCompany = getCoreCompanyList();
                formData.put("coreCompanys", optionsCompany);
            }
            // 所有部门
            List depts = TreeUtils.getDeptOptions();
            Map<String, Object> deptTree = new HashMap<String, Object>();
            deptTree.put("department_list", depts);
            formData.put("service_type", deptTree);
            deptTree.put("getlist_url", "loan/contract/getuser");
            formData.put("departmentData", depts);
            view = "company/add_new";
        }

        Map<String, Object> data = PageUtil.createFormPageStructure("system/company/save/" + type, formFieldList, formData);
        if (formFieldList1 != null) {
            data.put("form_struct1", formFieldList1);
        }
        return createSuccessModelAndView(view, JsonUtils.object2JsonString(data));
    }

    /**
     * 判断用户名是否存在
     *
     * @param val 用户名
     * @return
     * @throws Exception
     * @author likf
     */
    private OrgFrontUser userIsExists(String val) throws Exception {
        QueryItem query = new QueryItem();
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "username", val);
        this.addWhereCondition(where, "del_flag", 0);
        query.setWhere(where);

        OrgFrontUser u = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
        return u;
    }

    /**
     * 判断企业名是否存在
     *
     * @param param
     * @return
     * @throws Exception
     * @author likf
     */
    private boolean isCompanyExists(String param, String companyName) throws Exception {
        Assert.hasLength(companyName, "company can not null.");
        QueryItem query = new QueryItem();
        query.setFields("count(1) as count");
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "company_name", companyName);
        this.addWhereCondition(where, "del_flag", 0);
        query.setWhere(where);

        Map<String, Object> result = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        if (result != null && result.size() > 0 && Integer.parseInt(result.get("count").toString()) > 0) {
            return true;
        }
        return false;
    }

    private void setCompanyArea(Company company) throws Exception {
        if (company.getCompanyAreaId() != null)
            company.setCompanyArea(translateArea(company.getCompanyAreaId()));
        if (company.getWorkAreaId() != null)
            company.setWorkArea(translateArea(company.getWorkAreaId()));
    }

    private String translateArea(Long areaId) throws Exception {
        if (areaId != null) {
            QueryItem queryItem = new QueryItem();
            queryItem.setFields("id,name,province,city");
            queryItem.setWhere(Where.eq("id", areaId));
            //queryItem.setOrders("privince");
            Map area = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS);

            queryItem = new QueryItem();
            queryItem.setFields("id,name");
            queryItem.setWhere(Where.in("id", area.get("province") + "," + area.get("city")));
            queryItem.setOrders("province");
            List<Map> provinceList = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS);
            String result = "";
            for (Map item : provinceList) {
                result += item.get("name");
            }
            result += MapUtils.getString(area, "name");
            return result;
        }
        return null;
    }

    /**
     * 检查证件号码是否重复
     *
     * @param id
     * @param businessLicNo
     * @return
     * @throws Exception
     * @author likf
     */
    private boolean existsBusinessLicNo(Long id, String businessLicNo, Integer type) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("count(1) cnt");
        if (id != null)
            queryItem.setWhere(Where.notEq("id", id));
        queryItem.setWhere(Where.eq("business_lic_no", businessLicNo));
        queryItem.setWhere(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
        queryItem.setWhere(Where.eq("company_role_type", type));
        Map result = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        if (MapUtils.getLong(result, "cnt") > 0) {
            return true;
        }
        return false;
    }

    /**
     * 保存用户
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "save/{type}")
    public DyResponse save(Company company, CusCompanyDetail detail, String shareholderJson, String propertyJson,
                           CompanySupervise supervise,
                           String legalCardExpire1, String legalBirthday1, String companyCreateTime1, @RequestParam(value = "import_file", required = false) String import_file,
                           OrgFrontUser orgFrontUser, String repassword, @PathVariable("type") int type, String openBankAccount, String openBank, HttpServletRequest request) throws Exception {

        OrgUser ses = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
        orgFrontUser.setUpdateAdminId(ses.getId().toString());
        Long now = System.currentTimeMillis() / 1000;
        orgFrontUser.setRegisterTime(now);
        orgFrontUser.setRegisterIp(this.getRemoteIp());
        orgFrontUser.setLastloginTime(now);
        orgFrontUser.setCreateUid(ses.getId());
        orgFrontUser.setUpdateTime(now);
        orgFrontUser.setUpdateUid(ses.getId());
        orgFrontUser.setCreateTime(now);

        // 有上传附件，保存附件
        if (StringUtils.isNotBlank(import_file)) {
            FileStruct file = JsonUtils.fromJson(import_file, FileStruct.class);
            SysDocument document = new SysDocument();
            document.setFileName(file.getName());
            document.setFilePath(file.getUrl());
            document.setType(file.getFormat());
            document.setFileSize(file.getSize());
            document.setDocType(UploadValidation.product_printTemplate.getDocType());
            document.setCreateUname(getUser().getRealName());
            document.setClientType(Converter.boolToInt(RequestUtil.isAdmin()));
            this.insert(SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, document);
            company.setDocId(document.getId());
        }

        OrgFrontUser u = this.userIsExists(company.getCompanyName());
        if (u != null && u.getDelFlag() == 0) {
            return createErrorJsonResonse("用户名已存在，不能新增，请重新输入");
        }
        if (isCompanyExists("username", company.getCompanyName())) {
            return createErrorJsonResonse("企业名称已存在，不能新增，请重新输入");
        }
        if (type == CompanyRoleType.COMPANY_CREDIT.getIndex() || type == CompanyRoleType.COMPANY_CORE.getIndex()
                || type == CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() || type == CompanyRoleType.COMPANY_SUPERVISE.getIndex()) {
            if(existsBusinessLicNo(company.getId(), company.getBusinessLicNo(), type)) {
                return createErrorJsonResonse("证件号码不能重复");
            }
            orgFrontUser.setStatus(UserStatusEnum.ACTIVE.getIndex());
            orgFrontUser.setPassword(SecurityUtil.md5(SecurityUtil.sha1(ScConstants.DEFAULT_PASSWD)));
            orgFrontUser.setUsername(company.getBusinessLicNo());
            company.setCompanyRoleType(type);
            orgFrontUser.setType(type);
        }
        if (type == TYPE_ALL) {
            company.setContactEmail(orgFrontUser.getEmail());
            orgFrontUser.setType(company.getCompanyRoleType());
        }
        //处理客户经理
        if (type != CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() && type != CompanyRoleType.COMPANY_SUPERVISE.getIndex()) {
            QueryItem query = new QueryItem();
            query.setWhere(Where.eq("id", orgFrontUser.getSalerId()));
            OrgUser saler = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
            orgFrontUser.setSalerId(company.getSalerId());
            company.setSalerName(saler.getRealName());
            company.setSalerDepartment(saler.getDeptName());
            orgFrontUser.setPassword(SecurityUtil.md5(SecurityUtil.sha1(ScConstants.DEFAULT_PASSWD)));
        }
        if (StringUtils.isBlank(orgFrontUser.getUsername())) {
            if (StringUtils.isNotBlank(company.getCompanyLicense())) {
                orgFrontUser.setUsername(company.getCompanyLicense());
            } else {
                orgFrontUser.setUsername(company.getCompanyName());
            }
        }

        orgFrontUser.setRealName(company.getCompanyName());
        if (StringUtils.isNoneBlank(repassword)) {
            orgFrontUser.setPassword(SecurityUtil.md5(SecurityUtil.sha1(repassword)));
        }

        company.setStatus(1);// 默认审核通过
        company.setPassTime(System.currentTimeMillis() / 1000);

        //处理成立时间
        if (StringUtils.isNoneBlank(companyCreateTime1)) {
            company.setCompanyCreateTime(DateUtil.convert(companyCreateTime1));
        }
        setCompanyArea(company);

        // 申请云章CA证书
        // 核心企业，授信企业和资方才需要开通
        if (type == CompanyRoleType.COMPANY_CORE.getIndex() || type == CompanyRoleType.COMPANY_CREDIT.getIndex()
                || type == CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex()) {
            utils.applyCA(company);
        }
        DyResponse companyResp = this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);

        if (CompanyRoleType.COMPANY_SUPERVISE.getIndex() == type) {
            String tempDate = request.getParameter("archiveDate1");
            if (StringUtils.isNoneBlank(tempDate)) {
                supervise.setArchiveDate(DateUtil.convert(tempDate));
            }
            tempDate = request.getParameter("levelAffirmDate1");
            if (StringUtils.isNoneBlank(tempDate)) {
                supervise.setLevelAffirmDate(DateUtil.convert(tempDate));
            }
            tempDate = request.getParameter("levelOverdueDate1");
            if (StringUtils.isNoneBlank(tempDate)) {
                supervise.setLevelOverdueDate(DateUtil.convert(tempDate));
            }
            String[] superviseMode1 = request.getParameterValues("superviseMode1");
            if (superviseMode1 == null || superviseMode1.length == 0) {
                return createErrorJsonResonse("监管模式必选");
            }
            supervise.setSuperviseMode(String.join(",", superviseMode1));
            supervise.setCompanyId(companyResp.getId());

            this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_SUPERVISE, supervise);
        } else if (CompanyRoleType.COMPANY_CREDIT.getIndex() == type || CompanyRoleType.COMPANY_CORE.getIndex() == type) {
            if (StringUtils.isNoneBlank(legalCardExpire1)) {
                detail.setLegalCardExpire(DateUtil.convert(legalCardExpire1));
            }
            if (StringUtils.isNoneBlank(legalBirthday1)) {
                detail.setLegalBirthday(DateUtil.convert(legalBirthday1));
            }
            detail.setFactoryArea(translateArea(detail.getFactoryAreaId()));
            //插入企业详情 法人 股东
            detail.setCompanyId(company.getId());
            this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_DETAIL, detail);
            List<CusCompanyShareholder> shareholders = JsonUtils.jsonToList(shareholderJson, CusCompanyShareholder[].class);

            for (CusCompanyShareholder holder : shareholders) {
                holder.setCompanyId(company.getId());
                this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_SHAREHOLDER, holder);
            }
            List<CusCompanyLegalProperty> properties = JsonUtils.jsonToList(propertyJson, CusCompanyLegalProperty[].class);
            for (CusCompanyLegalProperty item : properties) {
                item.setCompanyId(company.getId());
                this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_LEGAL_PROPERTY, item);
            }
        }
        orgFrontUser.setCompanyId(companyResp.getId());
        this.insert(SCModule.SYSTEM, SCFunction.SYS_USER, orgFrontUser);
        //账号 授信额度
        moneyService.createBankAccount(companyResp.getId(), openBankAccount, BaseInfoUtils.getPlatAccount().getId(),
                CompanyRoleType.COMPANY_CORE.getIndex() == type ? AccountUseType.REPAY_ACCOUNT.getIndex() : AccountUseType.SETTLE_ACCOUNT.getIndex());
        return createSuccessJsonResonse(null, "新增成功");
    }

    private Areas getArea(Object id) throws Exception {
        if (id != null) {
            QueryItem queryItem = new QueryItem();
            queryItem.setFields("province,city");
            queryItem.setWhere(Where.eq("id", id));
            return this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_AREAS, Areas.class);
        }
        return null;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private Map getAccount(Object companyId) throws Exception {
        if (companyId != null) {
            Map data = BaseInfoUtils.getCompAccountMap(companyId);
            data.put("openBank", Converter.toString(data.get("pid")));
            data.put("account", data.get("openBankAccount"));
            return data;
        }
        return null;
    }

    /**
     * 用户编辑更新页面
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "edit/{type}")
    public ModelAndView edit(Long id, @PathVariable("type") int type) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        List<FormField> formFieldList1 = null;
        Map<String, Object> data = null;
        data = getEditData(id, type, data, formFieldList, formFieldList1);
        return createSuccessModelAndView(data.get("view").toString(), JsonUtils.object2JsonString(data));
    }

    /**
     * 用户编辑更新页面
     *
     * @param type   用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @param source 页面来源，用于配置刷新（refresh页面全部刷新，refresh_sub只刷新侧滑页，refresh_tree刷新右边内容）
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "edit/{type}/{source}")
    public ModelAndView edit(Long id, @PathVariable("type") int type, @PathVariable("source") String source) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        List<FormField> formFieldList1 = null;
        Map<String, Object> data = null;
        data = getEditData(id, type, data, formFieldList, formFieldList1);
        data.put(source, true);
        return createSuccessModelAndView(data.get("view").toString(), JsonUtils.object2JsonString(data));
    }

    /**
     * 获取企业详情 company_detail
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    private Map getCompanyDetail(Long id, boolean useCamelFormat) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("company_id", id));
        if (useCamelFormat) {
            CusCompanyDetail entity = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_DETAIL, CusCompanyDetail.class);
            return new DataConvertUtil(entity, false).convert(Map.class);
        } else {
            return this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_DETAIL);
        }
    }

    /**
     * 股东列表
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    private List<Map> getCompanyShareholder(Long id) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("id,company_id companyId,shareholder_type shareholderType,shareholder_name shareholderName, legal_relation legalRelation,shareholder_card_type shareholderCardType,card_no cardNo,currency,share_amount shareAmount,share_rate shareRate,share_way shareWay,inplace_rate inplaceRate, remark, file_id fileId");
        queryItem.setWhere(Where.eq("company_id", id));
        List<Map> list = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_SHAREHOLDER);
        for (Map item : list) {
            String fileId = MapUtils.getString(item, "fileId");
            if (StringUtils.isNotBlank(fileId)) {
                //TODO 暂时支持一个
                item.put("fileId", getDocument(fileId).get(0).get("url"));
            }
        }
        return list;
    }

    private List<Map> getDocument(String ids) throws Exception {
        QueryItem queryItem = QueryItem.builder().field("id as did,file_path as url").where(Where.in("id", ids)).build();
        return this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT);
    }

    /**
     * 法人资产列表
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    private List<Map> getCompanyLegalProperty(Long id) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("id,company_id companyId,property_desc propertyDesc,currency,amount,remark,file_id fileId");
        queryItem.setWhere(Where.eq("company_id", id));
        List<Map> list = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_LEGAL_PROPERTY);
        for (Map item : list) {
            String fileId = MapUtils.getString(item, "fileId");
            if (StringUtils.isNotBlank(fileId)) {
                //TODO 暂时支持一个
                item.put("fileId", getDocument(fileId).get(0).get("url"));
            }
        }
        return list;
    }

    private Map<String, Object> getEditData(Long id, @PathVariable("type") int type, Map<String, Object> data,
                                            List<FormField> formFieldList, List<FormField> formFieldList1) throws Exception {
        Map<String, Object> company = getCompanyMap(id);
        String view = "common/edit";
        if (company.get("companyCreateTime") != null)
            company.put("companyCreateTime1", DateUtil.dateFormat(company.get("companyCreateTime")));
        if (type == TYPE_ALL) {
            createAllUserForm(formFieldList, true);

            company.putAll(getUser(id));
            company.put("companyRoleType_", DictUtils.getDictLabel(company.get("companyRoleType").toString(), "company_role_type"));
            Areas area = getArea(company.get("workAreaId"));
            if (area != null) {
                company.put("pid_province", area.getProvince());
                company.put("pid_city", area.getCity());
            }
            // 所有部门
            List depts = TreeUtils.getDeptOptions();
            Map<String, Object> deptTree = new HashMap<String, Object>();
            deptTree.put("department_list", depts);
            company.put("service_type", deptTree);
            if (company.get("salerId") != null) {
                QueryItem queryItem = new QueryItem(Where.eq("id", (Long) company.get("salerId")));
                OrgUser saler = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
                deptTree.put("salesman", saler.getId());
                deptTree.put("user_name", saler.getRealName());
                deptTree.put("salesman_department", saler.getDeptId());
            }
            deptTree.put("getlist_url", "loan/contract/getuser");
            company.put("departmentData", depts);
            view = "company/edit";
        } else if (CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() == type) {
            createCapitalForm(formFieldList);
            company.putAll(getUser(id));

            Areas area = getArea(company.get("workAreaId"));
            if (area != null) {
                company.put("pid_province", area.getProvince());
                company.put("pid_city", area.getCity());
            }
            area = getArea(company.get("companyAreaId"));
            if (area != null) {
                company.put("pid_province1", area.getProvince());
                company.put("pid_city1", area.getCity());
            }
            //账户
            Map account = getAccount(company.get("id"));
            if (account != null) {
                company.putAll(account);
            }
        } else if (CompanyRoleType.COMPANY_SUPERVISE.getIndex() == type) {
            formFieldList1 = new ArrayList<FormField>();
            createCompanySuperviseForm(formFieldList);
            QueryItem queryItem = new QueryItem();
            queryItem.setWhere(Where.eq("company_id", company.get("id")));
            CompanySupervise supervise = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_SUPERVISE, CompanySupervise.class);
            Map superviseMap = new DataConvertUtil(supervise, false).convert(Map.class);

            superviseMap.remove("id");

            company.putAll(superviseMap);
            String superviseMode = MapUtils.getString(superviseMap, "superviseMode");
            if (StringUtils.isNoneBlank(superviseMode)) {
                company.put("superviseMode1", ArrayUtils.stringParseInt(superviseMode.split(",")));
            }
            Long levelAffirmDate = MapUtils.getLong(superviseMap, "levelAffirmDate");
            if (levelAffirmDate != null) {
                company.put("levelAffirmDate1", DateUtil.dateFormat(levelAffirmDate));
            }
            Long levelOverdueDate = MapUtils.getLong(superviseMap, "levelOverdueDate");
            if (levelOverdueDate != null) {
                company.put("levelOverdueDate1", DateUtil.dateFormat(levelOverdueDate));
            }
            Long archiveDate = MapUtils.getLong(superviseMap, "archiveDate");
            if (archiveDate != null) {
                company.put("archiveDate1", DateUtil.dateFormat(archiveDate));
            }
            company.putAll(getUser(id));

            Areas area = getArea(company.get("workAreaId"));
            if (area != null) {
                company.put("pid_province", area.getProvince());
                company.put("pid_city", area.getCity());
            }
            area = getArea(company.get("companyAreaId"));
            if (area != null) {
                company.put("pid_province1", area.getProvince());
                company.put("pid_city1", area.getCity());
            }
            //账户
            Map account = getAccount(company.get("id"));
            if (account != null) {
                company.putAll(account);
            }
        } else if (type == CompanyRoleType.COMPANY_CREDIT.getIndex() || type == CompanyRoleType.COMPANY_CORE.getIndex()) {
            formFieldList1 = new ArrayList<FormField>();
            createCompanyForm(formFieldList, formFieldList1, type);
            Map user = getUser(id);
            if (user != null)
                company.putAll(user);
            //账户
            Map account = getAccount(company.get("id"));
            if (account != null)
                company.putAll(account);
            if (company.get("companyCreateTime") != null) {
                company.put("companyCreateTime1", DateUtil.dateFormat(company.get("companyCreateTime")));
            }
            Areas area = getArea(company.get("workAreaId"));
            if (area != null) {
                company.put("pid_province", area.getProvince());
                company.put("pid_city", area.getCity());
            }
            area = getArea(company.get("companyAreaId"));
            if (area != null) {
                company.put("pid_province1", area.getProvince());
                company.put("pid_city1", area.getCity());
            }


            //公司详情 法人 股东 
            Map companyDetail = getCompanyDetail(id, true);
            Long legalCardExpire = MapUtils.getLong(companyDetail, "legalCardExpire");
            if (legalCardExpire != null)
                companyDetail.put("legalCardExpire1", DateUtil.dateFormat(legalCardExpire));
            Long legalBirthday = MapUtils.getLong(companyDetail, "legalBirthday");
            if (legalBirthday != null)
                companyDetail.put("legalBirthday1", DateUtil.dateFormat(legalBirthday));
            if (companyDetail != null) {
                company.put("detailId", companyDetail.get("id"));
                company.putAll(companyDetail);
            }
            area = getArea(company.get("factoryAreaId"));
            if (area != null) {
                company.put("pid_province2", area.getProvince());
                company.put("pid_city2", area.getCity());
            }

            company.put("shareholders", getCompanyShareholder(id));
            company.put("properties", getCompanyLegalProperty(id));

            company.put("shareholder_card_type", DictUtils.getOptionsInt("shareholder_card_type"));
            company.put("manage_feature_type", DictUtils.getOptionsInt("manage_feature_type"));
            company.put("company_life_type", DictUtils.getOptionsInt("company_life_type"));
            company.put("manage_status", DictUtils.getOptionsInt("manage_status"));
            company.put("shareholder_type", DictUtils.getOptionsInt("shareholder_type"));
            company.put("legal_degree", DictUtils.getOptionsInt("legal_degree"));

            company.put("id", id);

            // 所有部门
            List depts = TreeUtils.getDeptOptions();
            Map<String, Object> deptTree = new HashMap<String, Object>();
            deptTree.put("department_list", depts);
            company.put("service_type", deptTree);
            if (company.get("salerId") != null) {
                QueryItem queryItem = new QueryItem(Where.eq("id", (Long) company.get("salerId")));
                OrgUser saler = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
                deptTree.put("salesman", saler.getId());
                deptTree.put("user_name", saler.getRealName());
                deptTree.put("salesman_department", saler.getDeptId());
            }
            deptTree.put("getlist_url", "loan/contract/getuser");
            company.put("departmentData", depts);
            view = "company/edit_new";
        }

        data = PageUtil.createFormPageStructure("system/company/update/" + type,
                formFieldList,
                company);
        if (formFieldList1 != null)
            data.put("form_struct1", formFieldList1);
        //data.put("refresh_sub", true);
        data.put("view", view);
        return data;
    }

    /**
     * 更新用户
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update/{type}")
    public DyResponse update(HttpServletRequest request, Company company, Long detailId, CusCompanyDetail detail,
                             String shareholderJson, String propertyJson, CompanySupervise supervise,
                             String legalCardExpire1, String legalBirthday1, String companyCreateTime1, String chains1, String openBankAccount, String openBank,
                             OrgFrontUser orgFrontUser, @PathVariable("type") int type, String import_file) throws Exception {
        OrgUser ses = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
        if (ses == null) {
            return null;
        }
        // 有上传附件，保存附件
//        if (StringUtils.isNotBlank(import_file)) {
//            FileStruct file = JsonUtils.fromJson(import_file, FileStruct.class);
//            Long did = file.getDid();
//            if (did == null) {
//                SysDocument document = new SysDocument();
//                document.setFileName(file.getName());
//                document.setFilePath(file.getUrl());
//                document.setType(file.getFormat());
//                document.setFileSize(file.getSize());
//                document.setDocType(UploadValidation.product_printTemplate.getDocType());
//                document.setCreateUname(getUser().getRealName());
//                document.setClientType(Converter.boolToInt(RequestUtil.isAdmin()));
//                this.insert(SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, document);
//                did = document.getId();
//            }
//            company.setDocId(did);
//        }

        if ((type == CompanyRoleType.COMPANY_CREDIT.getIndex() || type == CompanyRoleType.COMPANY_CORE.getIndex()
                || type == CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() || type == CompanyRoleType.COMPANY_SUPERVISE.getIndex()) && existsBusinessLicNo(company.getId(), company.getBusinessLicNo(), type)) {
            return createErrorJsonResonse("证件号码不能重复");
        }
        //处理客户经理
        if (type != CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex() && type != CompanyRoleType.COMPANY_SUPERVISE.getIndex()) {
            QueryItem query = new QueryItem();
            query.setWhere(Where.eq("id", orgFrontUser.getSalerId()));
            OrgUser saler = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
            orgFrontUser.setSalerId(saler.getId());
            company.setSalerId(saler.getId());
            company.setSalerName(saler.getRealName());
            company.setSalerDepartment(saler.getDeptName());
        }
        //处理成立时间
        if (StringUtils.isNoneBlank(companyCreateTime1)) {
            company.setCompanyCreateTime(DateUtil.convert(companyCreateTime1));
        }
        setCompanyArea(company);

        Long now = System.currentTimeMillis() / 1000;
        orgFrontUser.setUpdateTime(now);
        orgFrontUser.setUpdateUid(ses.getId());
        if (orgFrontUser.getEmail() != null) {
            company.setContactEmail(orgFrontUser.getEmail());
        }
        company.setUpdateTime(now);
        company.setUpdateUid(ses.getId());
        this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);

        if (CompanyRoleType.COMPANY_CREDIT.getIndex() == type || CompanyRoleType.COMPANY_CORE.getIndex() == type) {
            QueryItem queryItem = QueryItem.builder().where("company_id", company.getId()).build();
            Long count = this.getCount(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_DETAIL);

            if (StringUtils.isNoneBlank(legalCardExpire1)) {
                detail.setLegalCardExpire(DateUtil.convert(legalCardExpire1));
            }
            if (StringUtils.isNoneBlank(legalBirthday1)) {
                detail.setLegalBirthday(DateUtil.convert(legalBirthday1));
            }
            detail.setFactoryArea(translateArea(detail.getFactoryAreaId()));
            detail.setCompanyId(company.getId());
            if (count == 0)
                this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_DETAIL, detail);
            else {
                detail.setId(detailId);
                this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY_DETAIL, detail);
            }
            //先删除旧数据
            queryItem.setFields("id");
            List<Map> olds = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_SHAREHOLDER);
            if (olds != null && olds.size() > 0) {
                for (Map item : olds) {
                    this.deleteById(MapUtils.getLong(item, "id"), SCModule.SYSTEM, SCFunction.SYS_COMPANY_SHAREHOLDER);
                }
            }
            olds = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_LEGAL_PROPERTY);
            if (olds != null && olds.size() > 0) {
                for (Map item : olds) {
                    this.deleteById(MapUtils.getLong(item, "id"), SCModule.SYSTEM, SCFunction.SYS_COMPANY_LEGAL_PROPERTY);
                }
            }

            List<CusCompanyShareholder> shareholders = JsonUtils.jsonToList(shareholderJson, CusCompanyShareholder[].class);
            for (CusCompanyShareholder holder : shareholders) {
                holder.setCompanyId(company.getId());
                this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_SHAREHOLDER, holder);
            }
            List<CusCompanyLegalProperty> properties = JsonUtils.jsonToList(propertyJson, CusCompanyLegalProperty[].class);
            for (CusCompanyLegalProperty item : properties) {
                item.setCompanyId(company.getId());
                this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_LEGAL_PROPERTY, item);
            }
        } else if (CompanyRoleType.COMPANY_SUPERVISE.getIndex() == type) {
            String tempDate = request.getParameter("archiveDate1");
            if (StringUtils.isNoneBlank(tempDate)) {
                supervise.setArchiveDate(DateUtil.convert(tempDate));
            }
            tempDate = request.getParameter("levelAffirmDate1");
            if (StringUtils.isNoneBlank(tempDate)) {
                supervise.setLevelAffirmDate(DateUtil.convert(tempDate));
            }
            tempDate = request.getParameter("levelOverdueDate1");
            if (StringUtils.isNoneBlank(tempDate)) {
                supervise.setLevelOverdueDate(DateUtil.convert(tempDate));
            }
            String[] superviseMode1 = request.getParameterValues("superviseMode1[]");
            if (superviseMode1 == null || superviseMode1.length == 0) {
                return createErrorJsonResonse("监管模式必选");
            }
            supervise.setSuperviseMode(String.join(",", superviseMode1));
            supervise.setCompanyId(company.getId());
            QueryItem supQuery = new QueryItem();
            supQuery.setFields("id");
            supQuery.getWhere().add(Where.eq("company_id", company.getId()));
            Map sup = this.getOneByMap(supQuery, SCModule.SYSTEM, SCFunction.SYS_COMPANY_SUPERVISE);
            supervise.setId(Long.parseLong(sup.get("id").toString()));
            this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY_SUPERVISE, supervise);
        }

        QueryItem queryItem = new QueryItem(Where.eq("company_id", company.getId()));
        OrgFrontUser tempUser = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
        OrgUser frontUser = new OrgUser();
        frontUser.setId(tempUser.getId());
        if (type == TYPE_ALL) {
            if (StringUtils.isNoneBlank(orgFrontUser.getPassword()))
                frontUser.setPassword(SecurityUtil.md5(SecurityUtil.sha1(orgFrontUser.getPassword())));
        } else {
            moneyService.createBankAccount(company.getId(), openBankAccount, Long.parseLong(openBank),
                    CompanyRoleType.COMPANY_CORE.getIndex() == type ? AccountUseType.REPAY_ACCOUNT.getIndex() : AccountUseType.SETTLE_ACCOUNT.getIndex());
        }
        frontUser.setRealName(company.getCompanyName());
        frontUser.setEmail(orgFrontUser.getEmail());
        //与企业角色同
        frontUser.setType(company.getCompanyRoleType());
        this.update(SCModule.SYSTEM, SCFunction.SYS_USER, frontUser);

        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 删除用户
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "delete/{type}")
    public DyResponse delete(Long id, @PathVariable("type") int type) throws Exception {
        if (TYPE_ALL == type) {
            return null;
        } else if (CompanyRoleType.COMPANY_SUPERVISE.getIndex() == type) {
            //被监管合同使用
            QueryItem queryItem = QueryItem.builder().where("supervise_comp_id", id).where("del_flag", DelFlag.NOT_DELETE.getIndex()).build();
            long count = this.getCount(queryItem, SCModule.WAREHOUSE, SCFunction.WAREHOUSE_SUPERVISE_PROTOCOL);
            if (count > 0) {
                return createErrorJsonResonse("监管公司被关联,不能删除");
            }
        }
        this.deleteById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        return createSuccessJsonResonse(null, "删除成功");
    }

    /**
     * 冻结用户
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "frozen/{type}")
    public DyResponse frozeUser(Long id, @PathVariable("type") int type) throws Exception {
        Map<String, Object> company = Maps.newHashMap();
        company.put("id", id);
        company.put("status", CompanyStatus.FREEZE.getIndex());
        this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);

        QueryItem queryItem = new QueryItem(Where.eq("company_id", id));
        OrgFrontUser frontUser = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
        if (frontUser != null && frontUser.getCustStatus() == 1) {
            frontUser.setCustStatus(0);
            this.update(SCModule.SYSTEM, SCFunction.SYS_USER, frontUser);
            return createSuccessJsonResonse(null, "冻结成功");
        } else {
            return createErrorJsonResonse("冻结失败");
        }
    }

    /**
     * 启用用户
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "activate/{type}")
    public DyResponse activateUser(Long id, @PathVariable("type") int type) throws Exception {
        if (type == CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex()) {
            Map<String, Object> company = Maps.newHashMap();
            company.put("id", id);
            company.put("status", CompanyStatus.ACTIVE.getIndex());
            this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);
        }

        QueryItem queryItem = new QueryItem(Where.eq("company_id", id));
        OrgFrontUser frontUser = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_USER, OrgFrontUser.class);
        if (frontUser != null && frontUser.getCustStatus() == 0) {
            frontUser.setCustStatus(1);
            this.update(SCModule.SYSTEM, SCFunction.SYS_USER, frontUser);
            return createSuccessJsonResonse(null, "启用成功");
        } else {
            return createErrorJsonResonse("启用失败");
        }

    }

    /**
     * 移交授信用户页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "transfer")
    public ModelAndView toTransferUser(Long id) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        QueryItem query = new QueryItem(Where.eq("id", id));
        Company company = this.getOneByEntity(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        Map<String, Object> formData = Maps.newHashMap();
        // 所有部门
        List depts = TreeUtils.getDeptOptions();
        Map<String, Object> deptTree = new HashMap<String, Object>();
        deptTree.put("department_list", depts);
        formData.put("service_type", deptTree);
        if (company.getSalerId() != null) {
            QueryItem queryItem = new QueryItem(Where.eq("id", company.getSalerId()));
            OrgUser saler = this.getOneByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
            deptTree.put("salesman", saler.getId());
            deptTree.put("user_name", saler.getRealName());
            deptTree.put("salesman_department", saler.getDeptId());
        }
        deptTree.put("getlist_url", "loan/contract/getuser");
        formData.put("departmentData", depts);
        Map<String, Object> data = PageUtil.createFormPageStructure("system/company/transferUpdate/" + id, formFieldList, formData);

        return createSuccessModelAndView("company/transferuser", JsonUtils.object2JsonString(data));
    }

    /**
     * 移交授信用户
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "transferUpdate/{id}")
    public DyResponse transferUser(Long salerId, @PathVariable("id") int id) throws Exception {
        // 查询授信客户信息
        QueryItem q = new QueryItem(Where.eq("company_id", id));
        OrgUser user = this.getOneByEntity(q, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
        // 查询授信客户所属业务员信息
        if (salerId != null) {
            QueryItem qItem = new QueryItem(Where.eq("id", salerId));
            OrgUser saler = this.getOneByEntity(qItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
            if (user != null) {
                user.setSalerName(saler.getRealName());
                user.setSalerId(salerId);
                this.update(SCModule.SYSTEM, SCFunction.SYS_ADMIN, user);
            }

            Map<String, Object> company = Maps.newHashMap();
            company.put("id", id);
            company.put("saler_id", saler.getId());
            company.put("saler_name", saler.getUsername());
            company.put("saler_department", saler.getDeptName());
            this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);
        }

        return createSuccessJsonResonse(null, "移交授信用户成功");
    }

    /**
     * 用户密码编辑更新页面
     *
     * @param type 用户类型（1 所有用户，2 授信企业，3 核心企业，4 准入管理）
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "changepwdpage/{type}")
    public ModelAndView toChangeUserPwd(Long id, @PathVariable("type") int type) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        formFieldList.add(FormField.builder().name("password").type("pwd").text("密码").verify("required").build());
        formFieldList.add(FormField.builder().name("repassword").type("pwd").text("重复密码").verify("required").build());
        Map<String, Object> data = PageUtil.createFormPageStructure("org/OrgUser/changepwd/" + type + "/" + id,
                formFieldList,
                null);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新用户密码
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "changepwd/{type}/{id}")
    public DyResponse updateUserPwd(@PathVariable("id") Long id, String repassword, OrgFrontUser orgFrontUser,
                                    @PathVariable("type") int type) throws Exception {
        OrgUser ses = (OrgUser) this.getSessionAttribute(Constant.SESSION_USER);
        Long now = System.currentTimeMillis() / 1000;
        orgFrontUser.setUpdateTime(now);
        orgFrontUser.setUpdateUid(ses.getId());
        orgFrontUser.setId(id);
        if (!orgFrontUser.getPassword().equalsIgnoreCase(repassword)) {
            return createErrorJsonResonse("两次输入密码不一致");
        }
        orgFrontUser.setPassword(SecurityUtil.md5(SecurityUtil.sha1(orgFrontUser.getPassword())));
        //TODO 需判断用户类型 安全问题
        this.update(SCModule.SYSTEM, SCFunction.SYS_USER, orgFrontUser);

        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 实名审批查进程
     *
     * @throws Exception
     */
    private List<Map> getFlowByIds(String instIds) throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.in("proc_inst_id", instIds));
        item.setOrders("create_time desc");
        List<Map> commentList = this.getListByMap(item, SCModule.FLOW, SCFunction.FLOW_COMMENT);
        return commentList;
    }

    /**
     * 编辑贷前评估页面
     *
     * @param source 页面来源，用于配置刷新（refresh页面全部刷新，refresh_sub只刷新侧滑页，refresh_tree刷新右边内容）
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "editEvaluate/{source}")
    public ModelAndView editEvaluate(Long id, @PathVariable("source") String source) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("company_id", id));
        CompanyEvaluate ce = this.getOneByEntity(item, SCModule.SYSTEM, SCFunction.SYS_COMPANY_EVALUATE, CompanyEvaluate.class);
        if (ce == null) {
            ce = new CompanyEvaluate();
            ce.setCompanyId(id);
            this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_EVALUATE, ce);
        }
        Map<String, Object> formData = (Map<String, Object>) new DataConvertUtil(ce, false).convert();
        Map<String, Object> data = PageUtil.createFormPageStructure("system/company/updateEvaluate", formFieldList, formData);
        data.put(source, true);
        return createSuccessModelAndView("company/evaluateEdit", JsonUtils.object2JsonString(data));
    }

    /**
     * 编辑贷前评估页面
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "updateEvaluate")
    public DyResponse updateEvaluate(Long id, HttpServletRequest request) throws Exception {
        CompanyEvaluate ce = this.getById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY_EVALUATE, CompanyEvaluate.class);
        ce.setScopeInfo(request.getParameter("scopeInfo"));
        ce.setAreaRiskEvaluate(request.getParameter("areaRiskEvaluate"));
        ce.setBlacklistRecord(request.getParameter("blacklistRecord"));
        ce.setCustCooperationSituation(request.getParameter("custCooperationSituation"));
        ce.setExchangeCashAnalyze(request.getParameter("exchangeCashAnalyze"));
        ce.setFinancialBalanceEvaluate(request.getParameter("financialBalanceEvaluate"));
        ce.setIndustryBoomDegree(request.getParameter("industryBoomDegree"));
        ce.setLegalAssetsSituation(request.getParameter("legalAssetsSituation"));
        ce.setLegalCreditRecord(request.getParameter("legalCreditRecord"));
        ce.setLegalShoppingAnalyze(request.getParameter("legalShoppingAnalyze"));
        ce.setLegalSituation(request.getParameter("legalSituation"));
        ce.setLiabilitiesRecord(request.getParameter("liabilitiesRecord"));
        ce.setLitigationSituation(request.getParameter("litigationSituation"));
        ce.setSupplierCooperationSituation(request.getParameter("supplierCooperationSituation"));
        this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY_EVALUATE, ce);
        return createSuccessJsonResonse(null, "修改成功");
    }

    @RequestMapping(value = "toRechargeByCompanyId")
    public ModelAndView toRechargeByCompanyId(Long id) throws Exception {
        return toRecharge(null, id);
    }

    /**
     * 充值页面
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "toRecharge")
    public ModelAndView toRecharge(Long id, Long companyId) throws Exception {
        AccAccount account = this.getById(id, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);

        List<FormField> formFieldList = new ArrayList<FormField>();
        formFieldList.add(FormField.builder().name("companyName").text("企业名称").type("span").build());
        formFieldList.add(FormField.builder().name("companyRoleType").text("企业类型").type("span").build());
        formFieldList.add(FormField.builder().name("accountUseType").text("账户类型").type("span").build());
        formFieldList.add(FormField.builder().name("openBank").text("开户行").type("span").build());
        formFieldList.add(FormField.builder().name("balance").text("账号").type("span").build());
        formFieldList.add(FormField.builder().name("dealAmount").text("充值金额").type("input").verify("required").build());
        formFieldList.add(FormField.builder().name("rechargeDate").text("充值时间").type("date").verify("required").build());

        Company company = BaseInfoUtils.getCompany(account.getCompanyId());

        Map<String, Object> formData = Maps.newHashMap();
        formData.put("balance", account.getAccBalance());
        formData.put("openBank", account.getOpenBank());
        formData.put("accId", account.getId());
        formData.put("companyName", company.getCompanyName());
        formData.put("companyRoleType", DictUtils.getDictLabel(company.getCompanyRoleType(), "company_role_type"));

        formData.put("accountUseType", DictUtils.getDictLabel(account.getAccountUseType(), "account_use_type"));
        formData.put("companyId", account.getCompanyId());
        Map<String, Object> data = PageUtil.createFormPageStructure("system/company/charge", formFieldList, formData);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 账户充值
     *
     * @param record
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "charge")
    public @ResponseBody
    DyResponse charge(MoneyRechargeRecord record) throws Exception {
        AccAccount accAccount = this.getById(record.getAccId(), SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);
        accAccount.setAccBalance(accAccount.getAccBalance().add(record.getDealAmount()));
        this.update(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, accAccount);

        record.setCounterFee(BigDecimal.ZERO);
        record.setFlowNum(GenNumUtil.genNum("CZ"));
        record.setRealAmount(record.getDealAmount());
        record.setRecCategory(2);//记录类别：0平台，1部门，2客户
        record.setRecharStatus(1);//充值状态：0处理中，1成功，2失败，3作废
        record.setTxnType(0);//交易类型：0手动充值，1线上充值
        this.insert(SCModule.MONEY, SCFunction.MONEY_RECHARGE_RECORD, record);
        return createSuccessJsonResonse(null, "充值成功");
    }

    @ResponseBody
    @RequestMapping("options")
    public DyResponse options(Long id, String search, String username, String company_name,
                              String saler_id, String dept_id, String create_time, Integer company_role_type, String register_time,
                              Integer cust_status, String business_lic_type, String business_lic_no,
                              Integer type, Boolean checkblacklist) throws Exception {
        QueryItem queryItem = new QueryItem();

        List<Where> whereList = new ArrayList<Where>();
        queryItem.setFields("id as value,company_name as text");
        if (StringUtils.isNotBlank(search)) {
            addWhereCondition(whereList, "company_name", LIKE_ALL, search);
        }
        this.addWhereCondition(whereList, "del_flag", 0);
        if (type != null || company_role_type != null) {
            this.addWhereCondition(whereList, "company_role_type", type != null ? type : company_role_type);
        }
        queryItem.setWhere(whereList);
        if (checkblacklist != null && checkblacklist) {
            queryItem.setWhere(Where.isNull("blacklist_type"));
        }
        if (StringUtils.isNotBlank(company_name)) {
            queryItem.setWhere(Where.likeAll("company_name", company_name));
        }
        if (StringUtils.isNotBlank(business_lic_type)) {
            queryItem.setWhere(Where.likeAll("business_lic_type", business_lic_type));
        }
        if (StringUtils.isNotBlank(business_lic_no)) {
            queryItem.setWhere(Where.likeAll("business_lic_no", business_lic_no));
        }
        if (id != null) {
            queryItem.setWhere(Where.eq("id", id));
        }
        if (StringUtils.isNotBlank(create_time)) {
            queryItem.setWhere(this.addDateWhereCondition(null, "create_time", create_time));
        }
        if (saler_id != null) {
            queryItem.setWhere(Where.eq("saler_id", saler_id));
        }
        queryItem.setOrders("id desc");
        List<Map> list = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        return createSuccessJsonResonse(list);
    }

    /**
     * 企业详情json
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @ResponseBody
    @RequestMapping("detail")
    public DyResponse detail(Long id, Integer type) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setFields(
                "id,doc_id docId,blacklist_type,company_check_status companyCheckStatus,business_lic_no businessLicNo,business_lic_type businessLicType,company_scale companyScale,company_create_time as companyCreateTime,register_capital as registerCapital,company_check_status companyCheckStatus");
        queryItem.setWhere(Where.eq("id", id));
        Map<String, Object> entity = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

        //查看印章
        if (type != null && type == 1) {
            Long docId = MapUtils.getLong(entity, "docId");
            if (docId != null) {
                queryItem = QueryItem.builder().field("file_path").where("id", docId).build();
                Map doc = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DOCUMENT);
                entity.put("docId", docId);
                if (doc != null)
                    entity.put("filePath", doc.get("file_path"));
            }
        } else {
            entity.put("companyCheckStatusName", DictUtils.getDictLabel(MapUtils.getString(entity, "companyCheckStatus"), "company_check_status"));
            entity.put("businessLicTypeName", DictUtils.getDictLabel(MapUtils.getString(entity, "businessLicType"), "business_lic_type"));
            entity.put("companyScaleName", DictUtils.getDictLabel(MapUtils.getString(entity, "companyScale"), "company_scale"));
            entity.put("companyCheckStatusName", DictUtils.getDictLabel(MapUtils.getString(entity, "companyCheckStatus"), "company_check_status"));
            queryItem = QueryItem.builder().where("company_id", id).build();
            Map detail = this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_DETAIL);
            if (detail != null) {
                detail.remove("id");
                entity.putAll(detail);
            }

        }
        return createSuccessJsonResonse(entity);
    }

    /**
     * 发起审查
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @ResponseBody
    @RequestMapping("toInvest")
    public DyResponse toInvest(Long id) throws Exception {
        Company company = BaseInfoUtils.getCompany(id);

        Integer blacklistType = companyModule.getBlacklistType(company.getBusinessLicNo(), id);
        if (blacklistType != null && BlacklistTypeEnum.FORBIDDEN.getIndex() == blacklistType) {
            return createErrorJsonResonse("客户属于禁止类黑名单客户，不允许继续操作");
        }
        if (company.getCompanyCheckStatus() == CompanyCheckStatus.CHECKING.getIndex()) {
            return createErrorJsonResonse("客户已经在审核中,不能重复发起");
        }
        Map<String, Object> updateObj = Maps.newHashMap();
        updateObj.put("id", company.getId());
        updateObj.put("company_check_status", CompanyCheckStatus.CHECKING.getIndex());
        this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, updateObj);
        workFlowUtil.startFlowPub(SCFlow.FLOW_COMM_INVEST_APPLY, company.getBusinessLicNo(), "发起审查", company.getId(), company.getId().toString(), company.getCompanyName());
        return createSuccessJsonResonse(null, "发起审查成功");
    }

    /**
     * 股东信息详情
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "shareholderView", method = RequestMethod.GET)
    public ModelAndView shareholderView(Long id) throws Exception {
        Map<String, Object> entity = this.getById((Serializable) id, SCModule.SYSTEM, SCFunction.SYS_COMPANY_SHAREHOLDER);

        this.getRealnameAndDept(entity, entity.get("create_uid"));
        getDocuments(entity, MapUtils.getString(entity, "file_id"));
        entity.put("company_name", BaseInfoUtils.getCompanyName(MapUtils.getLong(entity, "company_id")));
        dataConvert(entity, "shareholder_type,shareholder_card_type");
        return createSuccessModelAndView("system/companyShareholderView", JsonUtils.object2JsonString(entity));
    }

    /**
     * 法人资产详情
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "propertyView", method = RequestMethod.GET)
    public ModelAndView propertyView(Long id) throws Exception {
        Map<String, Object> entity = this.getById((Serializable) id, SCModule.SYSTEM, SCFunction.SYS_COMPANY_LEGAL_PROPERTY);

        this.getRealnameAndDept(entity, entity.get("create_uid"));
        getDocuments(entity, MapUtils.getString(entity, "file_id"));
        return createSuccessModelAndView("system/companyPropertyView", JsonUtils.object2JsonString(entity));
    }

    /**
     * 贸易对手添加页
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "companyRelationAdd", method = RequestMethod.GET)
    public ModelAndView companyRelationAdd(Long id) throws Exception {
        Map<String, Object> formData = Maps.newHashMap();
        if (id != null) {
            QueryItem queryItem = new QueryItem();
            queryItem.setFields("id,core_company_id as coreCompanyId,chain_position as chainPosition");
            queryItem.setWhere(Where.eq("company_id", id));
            List chains = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
            if (chains == null || chains.size() == 0) {
                chains = Lists.newArrayList();
                Map<String, Object> chain = Maps.newHashMap();
                chain.put("coreCompanyId", "");
                chain.put("chainPosition", "");
                chains.add(chain);
            }
            formData.put("chains", chains);
            formData.put("companyId", id);

            List optionsCompany = getCoreCompanyList();
            formData.put("coreCompanys", optionsCompany);
        }
        Map<String, Object> data = PageUtil.createFormPageStructure("system/company/companyRelationSave", null, formData);
        return createSuccessModelAndView("system/companyRelationAdd", JsonUtils.object2JsonString(data));
    }

    /**
     * 贸易对手保存
     *
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(value = "companyRelationSave", method = RequestMethod.POST)
    @ResponseBody
    public DyResponse companyRelationSave(Long companyId, String chains1) throws Exception {
        StringBuffer companyRelationIds = new StringBuffer();
        List<CompanyRelation> chainList = null;
        if (StringUtils.isNoneBlank(chains1)) {
            chainList = JsonUtils.jsonToArrayList(chains1, CompanyRelation.class);
            //更新
            for (int i = 0; i < chainList.size(); i++) {
                if (chainList.get(i).getId() != null) {
                    companyRelationIds.append(chainList.get(i).getId());
                    this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION, chainList.get(i));
                    companyRelationIds.append(",");
                }
            }
        }
        //删除
        QueryItem queryItem = new QueryItem();
        queryItem.setFields("id");
        queryItem.setWhere(Where.eq("company_id", companyId));
        if (companyRelationIds.length() > 1)
            queryItem.setWhere(Where.notIn("id", companyRelationIds.deleteCharAt(companyRelationIds.length() - 1)));
        List<Map> relationIds = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
        for (Map id : relationIds) {
            this.deleteById(Long.parseLong(id.get("id").toString()), SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
        }
        if (chainList != null && chainList.size() > 0) {
            for (int i = 0; i < chainList.size(); i++) {
                CompanyRelation relation = chainList.get(i);
                if (relation.getId() == null) {
                    relation.setCompanyId(companyId);
                    relation.setCheckStatus(CheckStatus.CHECK_PASS.getIndex());
                    this.insert(SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION, relation);
                }
            }
        }

        return createSuccessJsonResonse(null, "添加成功");
    }

    /**
     * 贸易对手侧滑
     *
     * @param id
     * @return
     * @throws Exception
     * @author likf
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "companyRelationView")
    public ModelAndView companyRelationView(Long id) throws Exception {
        QueryItem q = new QueryItem();
        q.setWhere(Where.eq("id", id));
        Map company = this.getOneByMap(q, SCModule.SYSTEM, SCFunction.SYS_COMPANY);

        //侧滑
        QueryItem queryItem = QueryItem.builder().where("company_id", id).build();
        List coreCompanyList = this.getListByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY_RELATION);
        if (coreCompanyList != null && coreCompanyList.size() > 0) {
            this.idToName(coreCompanyList, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "core_company_id:company_name");
            dataConvert(coreCompanyList, "chain_position");
            company.put("dataList", coreCompanyList);
        }
        company.put("source", "company");
        company.put("company_id", id);
        getViewMenu(company);
        return createSuccessModelAndView("system/companyRelationView", JsonUtils.object2JsonString(company));
    }

    @RequestMapping(value = "creditreport/list", method = RequestMethod.GET)
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "company_name", "business_lic_type", "legal_card_no", "update_time", "sync_company_info"});
        tableHeader.setTexts(new String[]{"ID", "企业名称", "证件类型:business_lic_type", "证件号码", "信用报告更新时间", "是否同步客户信息:common_status"});
        tableHeader.setTypes(new String[]{"int", "", "business_lic_type", "", "datetime", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"公司名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("system/company/creditreport/listData", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    @SuppressWarnings({"rawtypes"})
    @ResponseBody
    @RequestMapping(value = "creditreport/listData", method = RequestMethod.POST)
    public DyResponse listData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,company_name,legal_card_type,legal_card_no,update_time,business_lic_type,sync_company_info");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("company_name", search));
        }
        queryItem.setWhere(Where.eq("del_flag", 0));
        queryItem.setOrders("id");
        Page<Map> pageData = getPageByMap(queryItem, Module.SYSTEM, SCFunction.SYS_COMPANY);
        return createSuccessJsonResonse(pageData);
    }

    @RequestMapping(value = "creditreport/find", method = RequestMethod.GET)
    public ModelAndView find() throws Exception {
        List<FormField> formFieldList = buidFormField();
        Map<String, Object> data = PageUtil.createFormPageStructure("system/company/creditreport/findData", formFieldList);
        return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
    }

    private List<FormField> buidFormField() {
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("companyName").text("企业名称").type("input").br("br").verify("required").build());
        formFieldList.add(FormField.builder().name("legalCardType").text("证件类型").type("select").options("cert_type").br("br").verify("required").build());
        formFieldList.add(FormField.builder().name("legalCardNo").text("证件号码").type("input").br("br").verify("required").build());
        formFieldList.add(FormField.builder().name("pId").text("是否同步更新客户信息").type("radio").options("common_status").build());
        return formFieldList;
    }

    @ResponseBody
    @RequestMapping(value = "creditreport/findData", method = RequestMethod.POST)
    public DyResponse findData(Company company) throws Exception {
        this.insert(Module.SYSTEM, SCFunction.SYS_COMPANY, company);
        TreeUtils.clearDeptCache();
        return createSuccessJsonResonse(null, "添加成功");
    }

    @RequestMapping("/ecloud/list")
    public ModelAndView getUserList() throws Exception {
        TableHeader tableHeader = new TableHeader();

        tableHeader.setNames(new String[]{"id", "company_name", "company_role_type", "file_path", "serial_number", "real_name", "create_time"});
        tableHeader.setTexts(new String[]{"ID", "企业名称", "企业类型", "印章图片", "证书编号", "创建人", "创建时间"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"company_name"});
        search.setTexts(new String[]{"企业名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = null;
        data = PageUtil.createTablePageStructure("system/company/ecloud/listData", "id", tableHeader, tool, search);

        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("/ecloud/listData")
    public DyResponse getAdminListData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        List<Where> whereList = new ArrayList<Where>();
        if (StringUtils.isNotBlank(search)) {
            addWhereCondition(whereList, "company_name", LIKE_ALL, search);
        }
        this.addWhereCondition(whereList, "company_role_type", IN, "4,5,7,8");
        this.addWhereCondition(whereList, "ca_open", EQ, AccConstants.STATUS_OPEN);
        this.addWhereCondition(whereList, "del_flag", 0);
        queryItem.setWhere(whereList);
        queryItem.setOrders("create_time desc");
        Page<Map> rlt = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_DOCUMENT, "doc_id:file_path");
        return createSuccessJsonResonse(dataConvert(rlt, "company_role_type", "create_time"));
    }

    @RequestMapping(value = "openecloud", method = RequestMethod.GET)
    public ModelAndView openEcloud() throws Exception {
        Map<String, Object> formData = Maps.newHashMap();
        Map<String, Object> formStruct = Maps.newHashMap();
        Map<String, Object> role = Maps.newHashMap();
        Map<String, Object> companyList = Maps.newHashMap();
        formData.put("pledgeContractNo", GenNumUtil.genSeq(SeqType.SEQ_ZYHT));

        formStruct.put("companyRoleType", role);
        List<Option> backFundType = DictUtils.getOptions("company_role_type");
        for (Option opt2 : backFundType) {
            role.put(opt2.getValue().toString(), opt2);
        }

        formStruct.put("companyList", companyList);
        QueryItem queryItem = new QueryItem(Where.in("company_role_type", "4,5,7,8"));
        queryItem.setWhere(Where.eq("ca_open", AccConstants.STATUS_CLOSE));
        List<Company> companies = this.getListByEntity(queryItem, SCModule.SYSTEM, Function.SYS_COMPANY, Company.class);
        for (Company opt : companies) {
            companyList.put(opt.getCompanyName().toString(), new Option(opt.getId(), opt.getCompanyName()));
        }

        Map<String, Object> rlt = new HashMap<String, Object>();
        rlt.put("form_data", formData);
        rlt.put("form_struct", formStruct);
        rlt.put("submit_url", "system/company/open");
        return createSuccessModelAndView("company/addEcloud", JsonUtils.object2JsonString(rlt));
    }

    @ResponseBody
    @RequestMapping(value = "open", method = RequestMethod.POST)
    public DyResponse open(Company company, @RequestParam("import_file") String import_file) throws Exception {
        if (StringUtils.isNotBlank(import_file)) {
            company.setDocId(Long.valueOf(this.saveDocs(import_file)));
        }
        this.update(Module.SYSTEM, SCFunction.SYS_COMPANY, company);
        utils.applyCA(company);
        return createSuccessJsonResonse(null, "添加成功");
    }

    @RequestMapping(value = "editecloud", method = RequestMethod.GET)
    public ModelAndView updatEecloud(Long id) throws Exception {
        Map<String, Object> formData = Maps.newHashMap();
        Map<String, Object> formStruct = Maps.newHashMap();
        Map<String, Object> role = Maps.newHashMap();
        Map<String, Object> companyList = Maps.newHashMap();
        formData.put("pledgeContractNo", GenNumUtil.genSeq(SeqType.SEQ_ZYHT));

        formStruct.put("companyRoleType", role);
        List<Option> backFundType = DictUtils.getOptions("company_role_type");
        for (Option opt2 : backFundType) {
            role.put(opt2.getValue().toString(), opt2);
        }

        formStruct.put("companyList", companyList);
        QueryItem queryItem = new QueryItem(Where.in("company_role_type", "4,5,7,8"));
        List<Company> companies = this.getListByEntity(queryItem, SCModule.SYSTEM, Function.SYS_COMPANY, Company.class);
        for (Company opt : companies) {
            companyList.put(opt.getCompanyName().toString(), new Option(opt.getId(), opt.getCompanyName()));
        }

        Company company = this.getById(id, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        formData.put("companyRoleType", company.getCompanyRoleType().toString());
        formData.put("id", company.getId());

        Map<String, Object> rlt = new HashMap<String, Object>();
        rlt.put("form_data", formData);
        rlt.put("form_struct", formStruct);
        rlt.put("submit_url", "system/company/updateecloudsign");
        return createSuccessModelAndView("company/addEcloud", JsonUtils.object2JsonString(rlt));
    }

    @ResponseBody
    @RequestMapping(value = "getCompanyByType", method = RequestMethod.GET)
    public DyResponse getCompanyByType(Integer type) throws Exception {
        Map<String, Object> companyList = Maps.newHashMap();
        QueryItem queryItem = new QueryItem(Where.eq("company_role_type", type));
        queryItem.setWhere(Where.eq("ca_open", AccConstants.STATUS_CLOSE));
        List<Company> companies = this.getListByEntity(queryItem, SCModule.SYSTEM, Function.SYS_COMPANY, Company.class);
        for (Company opt : companies) {
            companyList.put(opt.getCompanyName().toString(), new Option(opt.getId(), opt.getCompanyName()));
        }
        return createSuccessJsonResonse(companyList);
    }

    @ResponseBody
    @RequestMapping(value = "updateecloudsign", method = RequestMethod.POST)
    public DyResponse updatEecloudSign(Company company, @RequestParam("import_file") String import_file) throws Exception {
        company.setDocId(Long.valueOf(this.saveDocs(import_file)));
        this.update(Module.SYSTEM, SCFunction.SYS_COMPANY, company);
        return createSuccessJsonResonse(null, "修改成功");
    }
}
