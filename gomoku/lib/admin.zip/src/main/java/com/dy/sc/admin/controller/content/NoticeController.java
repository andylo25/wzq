
/**
 * Copyright cuiwm
 */
package com.dy.sc.admin.controller.content;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFlow;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.MessageType;
import com.google.common.collect.Maps;

/**
 * 站内信记录
 * @author cuiwm
 */
@Controller
@RequestMapping(value = "sys/notice/")
public class NoticeController extends AdminBaseController {
	
	@Override
	protected DateFormatType getDateFormatType() {
		return DateFormatType.DATETIME;
	}
	
	/**
     * 构建列表结构:站内信记录
     * @return
     * @throws Exception
     */
    @RequestMapping("list/{type}")
    public ModelAndView list(@PathVariable("type") int type) throws Exception {
    	String dataUrl="sys/notice/listData/"+type;
    	if(type==1){
    		dataUrl="sys/notice/listData/"+type+"?params=1&no_refresh=1";
    	}
		PageStructure data = PageUtil.createTablePageStructure(dataUrl, "id", null,null,null);
		return createSuccessModelAndView("system/noticeList", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 获取列表数据:站内信记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("listData/{type}")
	public DyResponse getListData(Integer page,Integer limit,@PathVariable("type") int type) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,flow_inst_id,business_id,proc_def_key,title,contents,status,create_time");
		// 其他过滤条件
		queryItem.getWhere().add(Where.eq("member_id", getUserId()));
		queryItem.getWhere().add(Where.eq("message_type", MessageType.NOTICE.getIndex()));
		queryItem.getWhere().add(Where.eq("read_status", type));
		queryItem.setOrders("id desc");
		
		Page<Map> pagem = getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.MESSAGE_LOG);
		if(pagem!=null&&pagem.getItems()!=null&&pagem.getItems().size()>0){
			for(Map<String,Object> item:pagem.getItems()){
				Long createTime=item.get("create_time")==null?null:Long.parseLong(item.get("create_time").toString());
				if(createTime!=null){
					item.put("date", DateUtil.dateFormat(createTime));
					//2017-08-25 11:22:34
					item.put("time", DateUtil.dateTimeFormat(createTime).substring(11, 19));	
				}
//				String procDefKey=item.get("proc_def_key")==null?"":item.get("proc_def_key").toString();
				String rightUrl="workflow/todo/view/3";
//				if (SCFlow.FLOW_ZHIYA.equals(procDefKey)) {
//		            rightUrl = "loan/contract/info";           
//		        } else if (SCFlow.FLOW_CHUZHI.equals(procDefKey)) {
//		        	rightUrl = "loan/transfer/info";		            		      
//		        } else if (SCFlow.FLOW_ZHUIZHANG.equals(procDefKey)) {		           
//		        	rightUrl = "loan/account/info";
//		        } else if (SCFlow.FLOW_HUAIZHANG.equals(procDefKey)) {
//		        	rightUrl = "loan/account/info";
//		        }
				item.put("rightUrl", rightUrl);
			}
		}
 		//this.idToName(pagem.getItems(), Module.SYSTEM, Function.SYS_ADMIN, "member_id:real_name"); // 关联转换
 //		dataConvert(pagem); // 数据转换		
		return createSuccessJsonResonse(pagem);
	}
	
	/**
	 * 已经读取
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="reader")
	public DyResponse reader(Long id) throws Exception {
		Map<String,Object> read=Maps.newHashMap();
		read.put("id", id);
		read.put("read_status",1);
		DyResponse dr=this.update(SCModule.SYSTEM, SCFunction.MESSAGE_LOG, read);
		return dr;
	}


}