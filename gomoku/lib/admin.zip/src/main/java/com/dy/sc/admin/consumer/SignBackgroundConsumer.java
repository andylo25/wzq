package com.dy.sc.admin.consumer;

import com.dy.core.event.DyConsumer;
import com.dy.core.event.DyEvent;
import com.dy.core.utils.FDDUtils;
import com.dy.sc.entity.constant.ScConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SignBackgroundConsumer implements DyConsumer{

	@Autowired
	FDDUtils fddUtils;

	@Override
	public Integer apply() {
		return ScConstants.EVENT_TYPE_6;
	}

	@Override
	public void consume(DyEvent event) throws Exception {
	    Long id = (Long)event.getData();
	    fddUtils.doSignBackground(id);
	}
}
