package com.dy.sc.admin.controller.buss.report;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.ia.entity.common.OrgUser;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * @ClassName: MonthBussAnalysisController 
 * 信贷数据看板
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author cuiwenming@diyou.cn
 * @date 2017年8月3日 上午10:41:17
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * cuiwm 
 * </pre>
 */	
@Controller
@RequestMapping("loan/analysis")
public class MonthBussAnalysisController extends AdminBaseController {
	
	@Autowired
	StatisticsLogic statisticsLogic;
	
	/**
	 * 本月业绩分析
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="buss/month")
	public ModelAndView month() throws Exception {
		
		Map<String,Object> data = Maps.newHashMap();
		Map<String,Object> form_data = Maps.newHashMap();
		OrgUser orgUser = getAdminUser();
		Date start = DateUtil.dateParse(DateUtil.getCurrentDateStr().substring(0,6)+"01");
		Date end = DateUtil.addSecond(DateUtil.addMonth(start, 1),-1);
		String month = DateUtil.getCurrentDateStr().substring(0,6);
		int maxDay = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH);
		if(hasRightForMenu("10381")){
			form_data.put("user_info", statisticsLogic.statisCustCurMonth(start,end,orgUser.getId(),this));
			form_data.put("user_trend", monthData(month, orgUser.getId(), ScConstants.REP_TYPE_SALER,maxDay));
		}
		if(hasRightForMenu("10382")){
			form_data.put("dept_info", statisticsLogic.statisDeptCurMonth(start,end,orgUser.getDeptId(),this));
			form_data.put("dept_trend", monthData(month, orgUser.getDeptId(), ScConstants.REP_TYPE_DEPT,maxDay));
		}
		if(hasRightForMenu("10383")){
			form_data.put("company_info", statisticsLogic.statisPlatCurMonth(start,end,this));
			form_data.put("company_trend", monthData(month, null, ScConstants.REP_TYPE_PLAT,maxDay));
		}
		if(hasRightForMenu("10384")){
			form_data.put("company_saler", getSalerSort(null,month));
			form_data.put("depart_saler", getSalerSort(orgUser.getDeptId(),month));
		}
		
//		form_data.put("info", list);
		
		List<String> mon = Lists.newArrayList();
		for(int i=1;i<maxDay;i++){
			mon.add(String.valueOf(i));
		}
		form_data.put("x_axis", mon);
		
		data.put("form_data", form_data );
		return createSuccessModelAndView("loan/analysis/bussmonth", JsonUtils.object2JsonString(data ));
	}
	
	private List<Map> getSalerSort(Long deptId,String month) throws Exception {
		QueryItem queryItem = new QueryItem(Where.between("rep_date", month+"01", month+"31"));
		queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_SALER));
		queryItem.setFields("relation_id, sum(amount) as credit");
		queryItem.setGroup("relation_id");
		if(deptId != null){
			queryItem.setWhere(Where.in("relation_id", getIdsEq(SCModule.SYSTEM, SCFunction.SYS_ADMIN, "dept_id", deptId)));
		}
		
		List<Map> list = this.getListByMap(queryItem, SCModule.REPORT, SCFunction.DAY_LOAN_MONEY);
		
		Collections.sort(list, new Comparator<Map>() {
			@Override
			public int compare(Map o1, Map o2) {
				return ((BigDecimal)o2.get("credit")).compareTo((BigDecimal)o1.get("credit"));
			}
			
		});
		this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_ADMIN, "relation_id:real_name as name");
		
		return list;
	}

	private List<Map> monthData(String month,Long id,int type,int maxDay) throws Exception {
		QueryItem queryItem = new QueryItem(Where.between("rep_date", month+"01", month+"31"));
		if(id != null){
			queryItem.setWhere(Where.eq("relation_id", id));
		}
		queryItem.setWhere(Where.eq("rec_category", type));
		queryItem.setFields("rep_date,relation_id, amount as credit, back_amount as back");
		queryItem.setOrders("rep_date");
		List<Map> list = this.getListByMap(queryItem, SCModule.REPORT, SCFunction.DAY_LOAN_MONEY);
		
		// 填充缺失
		for(int i=1;i<maxDay;i++){
			if(list.size() < i){
				// 后面缺失
				list.add(Maps.newHashMap());
			}else{
				// 前面缺失
				String rep_date = (String) list.get(i-1).get("rep_date");
				if (!rep_date.substring(6).equals((i<10?"0":"")+i)) {
					list.add(i-1, Maps.newHashMap());
				}
			}
		}
		
		return list;
	}
	
	/**
	 * 本年业务分析
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="buss/yearBuss")
	public ModelAndView yearBuss() throws Exception {
		Map<String,Object> data = Maps.newHashMap();
		data.put("submit_url", "loan/analysis/buss/yearBussData");
		data.put("title1", "件数情况走势图");
		data.put("title2", "金额情况走势图");
		data.put("legend1", new String[]{"新增客户", "新增件数","月末待还件数", "已还完件数"});
		data.put("col1", new String[]{"cust_count", "loan_count", "back_count","toback_count"});
		data.put("legend2", new String[]{"贷款金额(万元)", "还款金额(万元)","月末待还金额(万元)"});
		data.put("col2", new String[]{"total_amount", "back_amount","toback_amount"});
		data.put("bussTypes", DictUtils.getOptions("business_type"));
		data.put("depts", DictUtils.getOptions("sc_dept"));
		data.put("salers", DictUtils.getOptions("manager"));
//		data.put("capitals", DictUtils.getOptions("capital_com"));
//		data.put("show_cap", true);
		return createSuccessModelAndView("loan/analysis/yearbuss", JsonUtils.object2JsonString(data ));
	}
	
	/**
	 * 获取数据:本年业务分析
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="buss/yearBussData")
	public DyResponse yearBussData(String year,Long bussType,Long dept,Long saler) throws Exception {
		Map<String,Object> result = Maps.newHashMap();
		String[] mon = new String[]{"一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"};
		
		QueryItem queryItem  = new QueryItem(Where.between("rep_date", year+"01", year+"12"));
		queryItem.setFields("rep_date,sum(back_count) as back_count,sum(back_amount)/10000 as back_amount,"
				+ "sum(cust_count) as cust_count,sum(loan_count) as loan_count,sum(total_amount)/10000 as total_amount,"
				+ "sum(total_pay)/10000 as total_pay,sum(toback_count) as toback_count,sum(toback_amount)/10000 as toback_amount");
		if(bussType != null){
			// 业务类型
			queryItem.setWhere(Where.eq("buss_type", bussType));
			if(dept != null){
				// 业务类型+部门
				queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_DEPT));
				queryItem.setWhere(Where.eq("relation_id", dept));
				queryItem.setGroup("rep_date,relation_id,buss_type");
			}else if(saler != null){
				// 业务类型+客户经理
				queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_SALER));
				queryItem.setWhere(Where.eq("relation_id", saler));
				queryItem.setGroup("rep_date,relation_id,buss_type");
			}else{
				// 业务类型
				queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PROD));
				queryItem.setGroup("rep_date,buss_type");
			}
		}else if(dept != null || saler != null){
			if(dept != null){
				queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_DEPT));
				queryItem.setWhere(Where.eq("relation_id", dept));
			}else{
				queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_SALER));
				queryItem.setWhere(Where.eq("relation_id", saler));
			}
			
			queryItem.setGroup("rep_date,relation_id");
		}else{
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
			queryItem.setGroup("rep_date");
		}
		
		List<Map> list = this.getListByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_MONEY);
		dataConvert(list);
		// 填充缺失
		for(int i=1;i<mon.length;i++){
			if(list.size() < i){
				// 后面缺失
				list.add(Maps.newHashMap());
			}else{
				// 前面缺失
				String rep_date = (String) list.get(i-1).get("rep_date");
				if (!rep_date.substring(4).equals((i<10?"0":"")+i)) {
					list.add(i-1, Maps.newHashMap());
				}
			}
		}
		
		result.put("info", list);
		result.put("x_axis", mon);
		return createSuccessJsonResonse(result);
	}
	
	/**
	 * 本年回款分析
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="buss/yearBack")
	public ModelAndView yearBack() throws Exception {
		Map<String,Object> data = Maps.newHashMap();
		data.put("submit_url", "loan/analysis/buss/yearBackData");
		data.put("title1", "还款期数情况走势图");
		data.put("title2", "还款金额情况走势图");
		data.put("legend1", new String[]{"该月到期待还期数", "该月到期实还期数", "月末逾期未还期数"});
		data.put("col1", new String[]{"loan_count", "back_count", "overdue_wait_count"});
		data.put("legend2", new String[]{"该月到期应还金额(万元)", "该月到期实还金额(万元)","月末逾期未还金额(万元)"});
		data.put("col2", new String[]{"loan_amount", "back_amount","overdue_wait_amount"});
		data.put("title3", "各比例走势图");
		data.put("legend3", new String[]{"正常回款率", "逾期率"});
		data.put("col3", new String[]{"back_rate", "overdue_rate"});
		data.put("bussTypes", DictUtils.getOptions("business_type"));
		data.put("depts", DictUtils.getOptions("sc_dept"));
		data.put("salers", DictUtils.getOptions("manager"));
		return createSuccessModelAndView("loan/analysis/yearbuss", JsonUtils.object2JsonString(data ));
	}
	
	/**
	 * 获取数据:本年回款分析
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="buss/yearBackData")
	public DyResponse yearBackData(String year,Long bussType,Long dept,Long saler) throws Exception {
		Map<String,Object> result = Maps.newHashMap();
		String[] mon = new String[]{"一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"};
		
		QueryItem queryItem  = new QueryItem();
		if(bussType != null){
			// 业务类型
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PROD));
			queryItem.setWhere(Where.eq("relation_id", bussType));
		}else if(dept != null){
			// 部门
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_DEPT));
			queryItem.setWhere(Where.eq("relation_id", dept));
		}else if(saler != null){
			// 业务员
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_SALER));
			queryItem.setWhere(Where.eq("relation_id", saler));
		}else{
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
		}
		queryItem.setWhere(Where.between("rep_date", year+"01", year+"12"));
		queryItem.setFields("rep_date,loan_count,back_count,overdue_wait_count,overdue_count,loan_amount/10000 as loan_amount,back_amount/10000 as back_amount,overdue_wait_amount/10000 as overdue_wait_amount");
		List<Map> list = this.getListByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_BACK);
		if(list != null && !list.isEmpty()){
			for(Map map:list){
				BigDecimal expire = new BigDecimal(map.get("loan_count").toString());
				if(NumberUtils.greaterThanZero(expire)){
					map.put("back_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("back_count").toString()), expire),NumberUtils.ONE_HUNDRED));
					map.put("overdue_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("overdue_count").toString()), expire),NumberUtils.ONE_HUNDRED));
				}else{
					map.put("back_rate","0.00");
					map.put("overdue_rate","0.00");
				}
			}
		}
		dataConvert(list);
		// 填充缺失
		for(int i=1;i<mon.length;i++){
			if(list.size() < i){
				// 后面缺失
				list.add(Maps.newHashMap());
			}else{
				// 前面缺失
				String rep_date = (String) list.get(i-1).get("rep_date");
				if (!rep_date.substring(4).equals((i<10?"0":"")+i)) {
					list.add(i-1, Maps.newHashMap());
				}
			}
		}
		
		result.put("info", list == null ? Lists.newArrayList() : list);
		result.put("x_axis", mon);
		return createSuccessJsonResonse(result);
	}
	
	/**
	 * 本年各项比例分析
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="buss/category")
	public ModelAndView category() throws Exception {
		Map<String,Object> data = Maps.newHashMap();
		data.put("submit_url", "loan/analysis/buss/categoryData");
		data.put("company_url", "loan/searchall");
		data.put("title3", "各比例走势图");
		data.put("legend3", new String[]{"正常回款率", "逾期率","转坏账率"});
		data.put("col3", new String[]{"back_rate", "overdue_rate","bad_rate"});
		data.put("bussTypes", DictUtils.getOptions("business_type"));
		data.put("depts", DictUtils.getOptions("sc_dept"));
		data.put("salers", DictUtils.getOptions("manager"));
		return createSuccessModelAndView("loan/analysis/yearbuss", JsonUtils.object2JsonString(data ));
	}
	
	/**
	 * 获取数据:本年各项比例分析
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="buss/categoryData")
	public DyResponse categoryData(String year,Long bussType,Long dept,Long saler) throws Exception {
		Map<String,Object> result = Maps.newHashMap();
		String[] mon = new String[]{"一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"};
		
		QueryItem queryItem  = new QueryItem();
		if(bussType != null){
			// 业务类型
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PROD));
			queryItem.setWhere(Where.eq("relation_id", bussType));
		}else if(dept != null){
			// 部门
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_DEPT));
			queryItem.setWhere(Where.eq("relation_id", dept));
		}else if(saler != null){
			// 业务员
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_SALER));
			queryItem.setWhere(Where.eq("relation_id", saler));
		}else{
			queryItem.setWhere(Where.eq("rec_category", ScConstants.REP_TYPE_PLAT));
		}
		queryItem.setWhere(Where.between("rep_date", year+"01", year+"12"));
		List<Map> list = this.getListByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_BACK);
		if(list != null && !list.isEmpty()){
			for(Map map:list){
				BigDecimal expire = new BigDecimal(map.get("loan_count").toString());
				if(NumberUtils.greaterThanZero(expire)){
					map.put("back_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("back_count").toString()), expire),NumberUtils.ONE_HUNDRED));
					map.put("overdue_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("overdue_count").toString()), expire),NumberUtils.ONE_HUNDRED));
					map.put("bad_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("bad_count").toString()), expire),NumberUtils.ONE_HUNDRED));
				}else{
					map.put("back_rate","0.00");
					map.put("overdue_rate","0.00");
					map.put("bad_rate","0.00");
				}
			}
		}
		dataConvert(list);
		// 填充缺失
		for(int i=1;i<mon.length;i++){
			if(list.size() < i){
				// 后面缺失
				list.add(Maps.newHashMap());
			}else{
				// 前面缺失
				String rep_date = (String) list.get(i-1).get("rep_date");
				if (!rep_date.substring(4).equals((i<10?"0":"")+i)) {
					list.add(i-1, Maps.newHashMap());
				}
			}
		}
		result.put("info", list);
		result.put("x_axis", mon);
		return createSuccessJsonResonse(result);
	}
	
	/**
	 * 客户贷款情况分析
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="buss/custCredit")
	public ModelAndView custCredit() throws Exception {
		Map<String,Object> data = Maps.newHashMap();
		data.put("submit_url", "loan/analysis/buss/custCreditData");
		data.put("title1", "件数情况走势图");
		data.put("title2", "金额情况走势图");
		data.put("title3", "各比例走势图");
		data.put("title4", "信贷还款情况走势图");
		data.put("title5", "还款金额情况走势图");
		data.put("companys", DictUtils.getOptions("credit_com"));
		data.put("legend1", new String[]{"新增件数", "月末待还件数","已还完件数"});
		data.put("legend2", new String[]{"贷款金额(万元)","还款金额(万元)","月末待还金额(万元)"});
		data.put("legend3", new String[]{"正常还款率", "逾期率"});
		data.put("legend4", new String[]{"该月到期待还期数", "该月到期实还期数","月末逾期未还期数"});
		data.put("legend5", new String[]{"该月到期应还金额(万元)", "该月到期实还金额(万元)","月末逾期未还金额(万元)"});
		data.put("col1", new String[]{"new_count", "toback_count","back_count"});
		data.put("col2", new String[]{"total_amount","back_amount","toback_amount"});
		data.put("col3", new String[]{"back_rate", "overdue_rate"});
		data.put("col4", new String[]{"loan_count", "back_count", "overdue_wait_count"});
		data.put("col5", new String[]{"loan_amount", "back_amount","overdue_wait_amount"});
		
		return createSuccessModelAndView("loan/analysis/custbuss", JsonUtils.object2JsonString(data ));
	}
	
	/**
	 * 获取数据:客户贷款情况分析
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="buss/custCreditData")
	public DyResponse custCreditData(String year,String companyId) throws Exception {
		Map<String,Object> result = Maps.newHashMap();
		String[] mon = new String[]{"一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"};
		List<Map> list = Lists.newArrayList();
		
		if(companyId != null){
			// 还款情况
			QueryItem queryItem  = new QueryItem(Where.eq("rec_category", ScConstants.REP_TYPE_CREDIT));
			queryItem.setWhere(Where.eq("relation_id", companyId));
			queryItem.setWhere(Where.between("rep_date", year+"01", year+"12"));
			queryItem.setFields("rep_date,relation_id,loan_count,back_count,overdue_count,bad_count,overdue_wait_count,loan_amount/10000 as loan_amount,back_amount/10000 as back_amount,overdue_wait_amount/10000 as overdue_wait_amount");
			list = this.getListByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_BACK);
			
			if(list != null && !list.isEmpty()){
				for(Map map:list){
					BigDecimal expire = new BigDecimal(map.get("loan_count").toString());
					if(NumberUtils.lessThan(expire, BigDecimal.ONE)){
						expire = BigDecimal.ONE;
					}
					map.put("back_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("back_count").toString()), expire),NumberUtils.ONE_HUNDRED));
					map.put("overdue_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("overdue_count").toString()), expire),NumberUtils.ONE_HUNDRED));
					map.put("bad_rate", NumberUtils.mul(NumberUtils.div(new BigDecimal(map.get("bad_count").toString()), expire),NumberUtils.ONE_HUNDRED));
				}
				
				// 放款情况
				queryItem  = new QueryItem(Where.eq("rec_category", ScConstants.REP_TYPE_CREDIT));
				queryItem.setWhere(Where.eq("relation_id", companyId));
				queryItem.setWhere(Where.between("rep_date", year+"01", year+"12"));
				queryItem.setFields("relation_id,rep_date,loan_count as new_count,toback_count,total_amount/10000 as total_amount,toback_amount/10000 as toback_amount,total_pay/10000 as total_pay");
				List<Map> listNew = this.getListByMap(queryItem, SCModule.REPORT, SCFunction.MONTH_LOAN_MONEY);
				if(listNew != null){
					for(Map map:list){
						Map nmap = getByRepDate(listNew, MapUtils.getString(map, "rep_date"));
						if(nmap != null){
							map.putAll(nmap);
						}
					}
				}
				
				dataConvert(list);
			}
			
			
			// 填充缺失
			for(int i=1;i<mon.length;i++){
				if(list.size() < i){
					// 后面缺失
					list.add(Maps.newHashMap());
				}else{
					// 前面缺失
					String rep_date = (String) list.get(i-1).get("rep_date");
					if (!rep_date.substring(4).equals((i<10?"0":"")+i)) {
						list.add(i-1, Maps.newHashMap());
					}
				}
			}
		}
		
		result.put("info", list);
		result.put("x_axis", mon);
		return createSuccessJsonResonse(result);
	}
	
	private Map getByRepDate(List<Map> list,String repDate){
		for(Map map:list){
			if(repDate.equals(MapUtils.getString(map, "rep_date"))){
				return map;
			}
		}
		return null;
	}
	
	private Map getByRelationId(List<Map> list,Long relationId){
		for(Map map:list){
			if(relationId.equals(MapUtils.getLong(map, "relation_id"))){
				return map;
			}
		}
		return null;
	}
	
	
}