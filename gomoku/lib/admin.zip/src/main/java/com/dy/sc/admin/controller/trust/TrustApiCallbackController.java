package com.dy.sc.admin.controller.trust;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dy.core.bussmodule.IBaseBussModule;
import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.exception.DyWebException;
import com.dy.core.trust.enumeration.TrustActionEnum;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.IpUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.encrypt.MessageEncryptUtil;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.TrustLog;
import com.dy.sc.admin.bussmodule.ReciveBillModule;
import com.dy.sc.bussmodule.agpur.AgpurSpaModule;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.bussmodule.utils.TrustApiUtil;
import com.dy.sc.bussmodule.utils.workflow.WorkflowUtil;
import com.dy.sc.bussmodule.warehouse.WarehouseReceiptModule;
import com.dy.sc.entity.agpur.AgpurTakeGoods;
import com.dy.sc.entity.agpur.AgpurTakeGoodsDetail;
import com.dy.sc.entity.agpur.AgpurTakeGoodsRepay;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.ProdBusinessTypeEnum;
import com.dy.sc.entity.fund.FundLoanRepay;
import com.dy.sc.entity.fund.FundLoanRepayPeriod;
import com.dy.sc.entity.loan.LoanDebitRecord;
import com.dy.sc.entity.loan.LoanDepositLog;
import com.dy.sc.entity.money.MoneyWithdrawalsRecord;
import com.dy.sc.entity.product.ProdProductB2B;
import com.dy.sc.entity.product.ProdProductInfo;
import com.dy.sc.entity.warehouse.WarehousePledge;
import com.dy.sc.service.money.MoneyService;
import com.dy.sc.service.money.ScBussService;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/api/trust/callback")
public class TrustApiCallbackController extends AdminBaseController {

    private static Logger logger=Logger.getLogger(TrustApiCallbackController.class);
    
    @Autowired 
    private MessageEncryptUtil messageEncryptUtil;
    @Autowired
    private TrustApiUtil trustApiUtil;
    @Autowired
    CommonBussUtil commonBussUtil;
    @Autowired
    private MoneyService moneyService;
    @Autowired
    private WorkflowUtil workflowUtil;
    @Autowired
	private WarehouseReceiptModule warehouseReceiptModule;
    @Autowired
	AgpurSpaModule agpurSpaModule;
    @Autowired
    private ReciveBillModule reciveBillModule;
    @Autowired
    private ScBussService scBussService;
    @Autowired
    private IBaseBussModule bussModule;
    
    private static final int RESP_SUCCESS=0;
    
    //操作类型 0-register 1-qcard 2-pay_detail 3-transfer 4-transfer_out
    private static final Integer TYPE_REGISTER=0;
    private static final Integer TYPE_QCARD=1;
    private static final Integer TYPE_DETAIL=2;
    private static final Integer TYPE_TRANSFER=3;
    private static final Integer TYPE_TRANSFER_OUT=4;
    
    /**
     * 
     * 更新账户金额
     * @param data
     * @throws Exception
     * @author likf
     */
    private void accAccountCallback(Map data) throws Exception{
        //更新接口记录
        String trn_id=MapUtils.getString(data, "trn_id");
        Integer resp_code=MapUtils.getInteger(data, "resp_code");
        String resp_desc=MapUtils.getString(data, "resp_desc");
        
        String balance=MapUtils.getString(data, "balance");
        TrustLog trustLog=getTrustLog(trn_id, TYPE_QCARD);
        if(trustLog!=null){
            
            if(RESP_SUCCESS==resp_code){
                //更新账户表
                if(trustLog.getAmountId()!=null){
                    Map<String,Object> updateObj=Maps.newHashMap();
                    updateObj.put("id", trustLog.getAmountId());
                    updateObj.put("acc_balance", balance);
                    this.update(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, updateObj);
                }
            }
            updateTrustLog(trustLog,resp_code, resp_desc, "回调完毕");
        }
    }
    
    /**
     * 开户后刷新余额
     * @param companyId
     * @throws Exception
     */
    private void afterOpenBank(Long companyId) throws Exception{
//    	Thread afterOpenBankThread =new Thread(new Runnable() {
//			@Override
//			public void run() {
				try {
					trustApiUtil.qcard(companyId);
				} catch (Exception e) {
					logger.error(e);
				}
//			}
//		});
//    	afterOpenBankThread.start();
    }
    
    /**
     * 
     * 处理账号回调
     * @param
     * @throws Exception
     * @author likf
     */
    @SuppressWarnings("rawtypes")
	private void openBankCallback(Map data) throws Exception{
        //更新接口记录
        String trn_id=MapUtils.getString(data, "trn_id");
        Integer resp_code=MapUtils.getInteger(data, "resp_code");
        String resp_desc=MapUtils.getString(data, "resp_desc");
        
        String account=MapUtils.getString(data, "acc_account");

        String openName=MapUtils.getString(data, "acc_name");
        String company=MapUtils.getString(data, "company");
        String openFullName=openName+" "+company;
        String businessNo=MapUtils.getString(data, "business_no");
        //TODO
        TrustLog trustLog=getTrustLog(trn_id, TYPE_REGISTER);
        String openBank="民生银行";
        if(trustLog!=null){
            
            if(RESP_SUCCESS==resp_code){
                QueryItem queryItem=new QueryItem();
                queryItem.setFields("id");
                queryItem.setWhere(Where.eq("business_lic_no", businessNo));
                Map companyId=this.getOneByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
                
                if(companyId!=null&&companyId.get("id")!=null){
                    Map accountId = BaseInfoUtils.getCompAccountMap(companyId.get("id"));
                    //更新账户表
                    if(accountId!=null&&accountId.get("id")!=null){
                        Map<String,Object> updateObj=Maps.newHashMap();
                        updateObj.put("id", accountId.get("id"));
                        updateObj.put("account", account);
                        updateObj.put("open_name", openName);   
                        updateObj.put("open_bank", openBank);   
                        updateObj.put("open_full_name", openFullName);
                        this.update(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, updateObj);
                        
                        afterOpenBank(MapUtils.getLong(companyId,"id"));
                    }
                }
            }
            updateTrustLog(trustLog,resp_code, resp_desc, "回调完毕");
        }
    }
    
    /**
     * 
     * 划拨回调
     * @param data
     * @author likf
     * @throws Exception 
     */
    private void transferCallback(Map data) throws Exception{
      //更新接口记录
        String trn_id=MapUtils.getString(data, "trn_id");
        Integer resp_code=MapUtils.getInteger(data, "resp_code");
        String resp_desc=MapUtils.getString(data, "resp_desc");
        String txn_type=MapUtils.getString(data, "txn_type");
        BigDecimal amount=new BigDecimal(MapUtils.getString(data, "amount"));
        String ids = MapUtils.getString(data, "ids");
        
        if(StringUtils.isBlank(txn_type)){
            throw new DyWebException("资金划拨-交易类型 未设置");
        }
        
        TrustLog trustLog=getTrustLog(trn_id, TYPE_TRANSFER);
        if(trustLog!=null){
            // 金额校验
            if(trustLog.getAmount().compareTo(amount)!=0){
                updateTrustLog(trustLog,resp_code, resp_desc, "金额校验错误:请求金额"+trustLog.getAmount()+"响应金额:"+amount);
                return;
            }
            
            if("0".equals(txn_type)){//放款
                //处理成功
                if(RESP_SUCCESS==resp_code){
                    Long procInstId=trustLog.getAmountId();
                    workflowUtil.submit(procInstId, "放款成功", true,null);
                }else{
                    //不处理
                }
            }else if("5".equals(txn_type)){//保证金页面回调
            	LoanDepositLog loanDepositLog = new LoanDepositLog();
            	loanDepositLog.setDebitId(trustLog.getAmountId());
            	loanDepositLog.setId(Long.valueOf(ids));
				agpurSpaModule.payDeposit(loanDepositLog , false);
            }else if("1".equals(txn_type)){//还款 页面回调
                if(RESP_SUCCESS==resp_code){
                    Long amountId=trustLog.getAmountId();
                    // 判断是否可以提前还款
            		boolean b = false;
            		Object errorCode =null;
            		if(trustLog.getAdditionalParams()!=null&&trustLog.getAdditionalParams().equals(String.valueOf(ProdBusinessTypeEnum.B2B.getIndex()))){
            		    b = commonBussUtil.repayAhead(amountId.toString()) == ScConstants.REPAY_AHEAD_YES;
            		    errorCode = scBussService.repayPeriod(amountId, b,false);
            		    if(errorCode==null&&b){
                            addMoneyDetail(amountId);
                        }
            		}else if(trustLog.getAdditionalParams()!=null&&trustLog.getAdditionalParams().equals(String.valueOf(ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex()))){
            		    BigDecimal principal=new BigDecimal(MapUtils.getString(data, "principal"));
            		    Long pledgeId = warehouseReceiptModule.repayWH(amountId,principal, trustLog.getCreateTime(),false);
            		    if(pledgeId != null){
            		    	WarehousePledge pledge=bussModule.getById(pledgeId, SCModule.WAREHOUSE, SCFunction.WAREHOUSE_PLEDGE,WarehousePledge.class);
            		    	warehouseReceiptModule.rePledge(ids,pledge,null);
            		    }
            		}else if(trustLog.getAdditionalParams()!=null&&trustLog.getAdditionalParams().equals(String.valueOf(ProdBusinessTypeEnum.AGENTPUR.getIndex()))){
            			String contents = trustLog.getReturnContents();
            			String[] strings = contents.split("#@#");
            			AgpurTakeGoods goods = JsonUtils.fromJson(strings[0], AgpurTakeGoods.class);
            			List<AgpurTakeGoodsDetail> takeGoodsDetails = JsonUtils.jsonToArrayList(strings[1], AgpurTakeGoodsDetail.class);
            			AgpurTakeGoodsRepay repay = JsonUtils.fromJson(strings[2], AgpurTakeGoodsRepay.class);
            			agpurSpaModule.redeemOne(goods, repay, takeGoodsDetails,false);
            		}else{
                        Map<String, Object> money = JsonUtils.json2Map(trustLog.getFormContents());
                        BigDecimal totalAmount = new BigDecimal(money.get("totalAmount").toString());
                        // 非足额还款/足额还款
                        errorCode = reciveBillModule.billRepay(amountId, totalAmount, false);
            		}
                }else{
                    //不处理
                }
            }
            
            updateTrustLog(trustLog,resp_code, resp_desc, "回调完毕");
        }
        
        //放款
        //还款
    }
    
    private void addMoneyDetail(Long period_id) throws Exception{
    	FundLoanRepayPeriod period = this.getById(period_id, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD,
				FundLoanRepayPeriod.class);
		if(period == null)return;
    	Long debitId = period.getDebitId();
    	Map<String, Object> map = Maps.newHashMap(); 
    	map.put("allAmount", BigDecimal.ZERO);
		BigDecimal sum = repayAheadMoney(debitId.toString(), map);
    	//获取信贷记录表信息
        LoanDebitRecord record =this.getById(debitId, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD, LoanDebitRecord.class);
        if(record == null) return;
		//用户账号
        Long companyId=record.getCompanyId(); 
        AccAccount user = BaseInfoUtils.getCompAccountEntity(companyId);
        if(user == null)return;
        AccAccount capitalAcc = BaseInfoUtils.getCompAccountEntity(record.getCapitalId());
        if(capitalAcc == null)return;
        moneyService.transfer(user.getId(), capitalAcc.getId(), sum, AccConstants.CAP_TURN_TYPE_TQ,record);
    }
    
    private BigDecimal repayAheadMoney(String id, Map<String, Object> viewData) throws Exception {
		// 判断是否可以提前还款
		QueryItem qitem = new QueryItem(Where.eq("id", id));
		LoanDebitRecord debit = this.getOneByEntity(qitem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD,
				LoanDebitRecord.class);
		if (debit.getBusinessType() == ScConstants.CONTRACT_TYPE_B2B) {
			QueryItem queryItem = new QueryItem(Where.eq("debit_id", id));
			FundLoanRepay repay = this.getOneByEntity(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAY,
					FundLoanRepay.class);
			QueryItem queryPeriod = new QueryItem(Where.eq("debit_id", id));
			List<FundLoanRepayPeriod> period = this.getListByEntity(queryPeriod, SCModule.FUND,
					SCFunction.FUND_LOAN_REPAYPERIOD, FundLoanRepayPeriod.class);

			QueryItem queryProduct = new QueryItem(Where.eq("id", debit.getProductId()));
			ProdProductInfo product = this.getOneByEntity(queryProduct, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO,
					ProdProductInfo.class);
			QueryItem queryB2B = new QueryItem(Where.eq("product_id", product.getId()));
			ProdProductB2B b2b = this.getOneByEntity(queryB2B, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B,
					ProdProductB2B.class);
			if (b2b != null) {
				Long d = debit.getContractStartTime();// 必定在交易周期内
				Date date = DateUtil.dateParse(d);
				int checkStart = b2b.getCheckStartDay();
				int checkEnd = b2b.getCheckEndDay();
				int settleStart = b2b.getSettleStartDay();
				int settleEnd = b2b.getSettleEndDay();
				int checkMonth = b2b.getCheckMonthType();
				Calendar c = Calendar.getInstance();
				c.setTime(date);
				int x = c.get(Calendar.MONTH);
				c.add(Calendar.MONTH, checkMonth - 1);
				c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), checkStart);
				Date checkStartDate = c.getTime();
				c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), checkEnd);
				Date checkEndDate = c.getTime();
				c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), settleStart);
				Date settleStartDate = c.getTime();
				c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), settleEnd);
				Date settleEndDate = c.getTime();
				Date now = new Date();
				if (checkStartDate.getTime() > now.getTime()) {// 在产品设置的核账期之前还款为提前还款
					// 如果开启提前还款罚息
					if (b2b.getInterestPenaltyStatus() == AccConstants.STATUS_OPEN) {
						BigDecimal interestStart = b2b.getInterestPenaltyStartRate();
						BigDecimal interestEnd = b2b.getInterestPenaltyEndRate();
						int day = b2b.getInterestPenaltyDay();
						int days = DateUtil.daysBetween(date, new Date());
						BigDecimal interestBefore = BigDecimal.ZERO;
						if (days <= day) {
							interestBefore = debit.getLoanAmount().multiply(interestStart.divide(new BigDecimal(100)));
							viewData.put("beforeInterest", interestBefore);
						} else {
							interestBefore = debit.getLoanAmount().multiply(interestEnd.divide(new BigDecimal(100)));
							viewData.put("beforeInterest", interestBefore);
						}
						// 重新计算利息
						Long today = DateUtil.convert(DateUtil.dateFormat(new Date()));
						int interestDay = DateUtil.daysBetween(DateUtil.dateParse(debit.getContractStartTime()),
								DateUtil.dateParse(today)) + 1;
						// 到今天为止的利息
						BigDecimal interestAmount = debit.getLoanApr().divide(new BigDecimal(100))
								.multiply(debit.getLoanAmount()).multiply(new BigDecimal(interestDay));
						// 总利息为利息+提前还款罚息
						BigDecimal sum = interestAmount.add(interestBefore);
						// 如果已经提前还款则更新还款表和还款分期表
						BigDecimal allAmount = new BigDecimal(viewData.get("allAmount").toString()).add(interestBefore);
						viewData.put("allAmount", allAmount);
						if(repay.getStatus() == AccConstants.CREDIT_RECORD_ADVANCE_REPAY){
							repay.setAmountTotal(allAmount);
							repay.setAmountYes(allAmount);
							this.update(SCModule.FUND, SCFunction.FUND_LOAN_REPAY, repay);
							
							FundLoanRepayPeriod  period1 = period.get(0);
							period1.setAmount(allAmount);
							period1.setAmountYes(allAmount);
							this.update(SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD, period1);
						}
						return interestBefore;
					}
				}
			}
		}
		return BigDecimal.ZERO;
	}
    
    private TrustLog getTrustLog(String trn_id,int action){
      //一个单号只处理一次 防止重复回调
        QueryItem queryItem =new QueryItem();
        queryItem.setWhere(Where.eq("order_id", trn_id));
        queryItem.setWhere(Where.eq("type", action));
        queryItem.setWhere(Where.eq("trust_status", 0));
        TrustLog trustLog=null;
        try {
            trustLog=this.getOneByEntity(queryItem, SCModule.TRUST, SCFunction.TRUST_LOG, TrustLog.class);
            
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return trustLog;
    }
    
    /**
     * 
     * 更新日志记录
     * @param trustLog
     * @param resp_code
     * @param resp_desc
     * @param operateMessage
     * @throws Exception
     * @author likf
     */
    private void updateTrustLog(TrustLog trustLog,Integer resp_code,String resp_desc,String operateMessage) throws Exception{
        trustLog.setReturnTime(DateUtil.getCurrentTime());
        trustLog.setReturnContents(resp_desc);
        trustLog.setReturnIp(IpUtil.ipStrToLong(this.getRemoteIp()));
        trustLog.setReturnMessage(resp_desc);//提示信息
        
        trustLog.setLocalMessage(operateMessage);
        //trustLog.setAmountType(amountType);
//        if(amount!=null)
//            trustLog.setAmount(amount);
        //trustLog.setAmountId(amountId);
        //trustLog.setAdditionalParams(additionalParams);
        if(RESP_SUCCESS==resp_code){
            trustLog.setTrustStatus(1);//处理成功
        }else{
            trustLog.setTrustStatus(2);//处理失败
        }
        
        try {
            this.update( SCModule.TRUST, SCFunction.TRUST_LOG, trustLog);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 转出回调(授信与企业提现)
     * @param data
     * @author likf
     * @throws Exception 
     */
    private void transferOutCallback(Map data) throws Exception{
        //更新接口记录
        String trn_id=MapUtils.getString(data, "trn_id");
        Integer resp_code=MapUtils.getInteger(data, "resp_code");
        String resp_desc=MapUtils.getString(data, "resp_desc");
        BigDecimal amount=new BigDecimal(MapUtils.getString(data, "amount"));
        
        TrustLog trustLog=getTrustLog(trn_id, TYPE_TRANSFER_OUT);
        if(trustLog!=null){
            //金额校验
            if(trustLog.getAmount().compareTo(amount)!=0){
                updateTrustLog(trustLog,resp_code, resp_desc, "金额校验错误:请求金额"+trustLog.getAmount()+"响应金额:"+amount);
//                return;
            }
            //更新账户信息
            //更新资金流水
            //付款账款
            String payer_account=MapUtils.getString(data, "payer_account");
            QueryItem queryItem =new QueryItem();
            queryItem.setWhere(Where.eq("account", payer_account));
            AccAccount outAccount = null;
            try {
                outAccount = this.getOneByEntity(queryItem, SCModule.ACCOUNT,SCFunction.ACC_ACCOUNT, AccAccount.class);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            //收款账户
            String inBankCardNo=MapUtils.getString(data, "payee_account");
            
            //处理成功
            if(RESP_SUCCESS==resp_code){
                if(outAccount!=null){
                    moneyService.transferOut(outAccount, inBankCardNo, amount,AccConstants.CAP_TURN_TYPE_TO,null);
                    
                    queryItem=new QueryItem();
                    queryItem.setFields("id");
                    queryItem.setWhere(Where.eq("flow_num", trn_id));
                    MoneyWithdrawalsRecord record=this.getOneByEntity(queryItem, SCModule.MONEY,SCFunction.MONEY_WITHDRAWALS_RECORD,MoneyWithdrawalsRecord.class);
                    record.setStatus(1);
                    record.setUpdateTime(DateUtil.getCurrentTime());
                    this.update(SCModule.MONEY,SCFunction.MONEY_WITHDRAWALS_RECORD,record);
                 } 
            }
            
            updateTrustLog(trustLog,resp_code, resp_desc, "回调完毕");
        }
        
    }
    
    /**
     * 批量转账回调
     * @param data
     * @author likf
     * @throws Exception 
     */
    private void batTransferCallback(Map data) throws Exception{
    	//更新接口记录
    	String trn_id=MapUtils.getString(data, "trn_id");
    	Integer resp_code=MapUtils.getInteger(data, "resp_code");
    	String resp_desc=MapUtils.getString(data, "resp_desc");
    	String txn_type=MapUtils.getString(data, "txn_type");
    	BigDecimal amount=new BigDecimal(MapUtils.getString(data, "totalAmount"));
    	
    	TrustLog trustLog=getTrustLog(trn_id, TYPE_TRANSFER_OUT);
    	if(trustLog!=null){
    		//金额校验
    		if(trustLog.getAmount().compareTo(amount)!=0){
    			updateTrustLog(trustLog,resp_code, resp_desc, "金额校验错误:请求金额"+trustLog.getAmount()+"响应金额:"+amount);
//                return;
    		}

    		if("1".equals(txn_type)){//还款 页面回调
    			if(trustLog.getAdditionalParams()!=null&&trustLog.getAdditionalParams().equals(String.valueOf(ProdBusinessTypeEnum.AGENTPUR.getIndex()))){
        			String contents = trustLog.getReturnContents();
        			String[] strings = contents.split("#@#");
        			AgpurTakeGoods goods = JsonUtils.fromJson(strings[0], AgpurTakeGoods.class);
        			List<AgpurTakeGoodsDetail> takeGoodsDetails = JsonUtils.jsonToArrayList(strings[1], AgpurTakeGoodsDetail.class);
        			List<AgpurTakeGoodsRepay> takeGoodsRepays = JsonUtils.jsonToArrayList(strings[2], AgpurTakeGoodsRepay.class);
        			agpurSpaModule.redeemAny(goods,takeGoodsDetails,takeGoodsRepays,false);
        		}
    		}
    		
    		updateTrustLog(trustLog,resp_code, resp_desc, "回调完毕");
    	}
    	
    }
    
    /**
     * 
     * 资管回调
     * @return
     * @throws Exception
     * @author likf
     */
    @RequestMapping(method=RequestMethod.POST)
    @ResponseBody
    public String post(String sign,String timestamp,String nonce,String data,String org_code) throws Exception {
        
        Map result=messageEncryptUtil.decryptJson(sign, timestamp, nonce, data,org_code);
        String action=(String) result.get("action");
        try{
            if(action.equals(TrustActionEnum.ACTION_REGISTER.getIndex())){
                openBankCallback(result);
            }else if(action.equals(TrustActionEnum.ACTION_QCARD.getIndex())){
                accAccountCallback(result);
            }else if(action.equals(TrustActionEnum.ACTION_TRANSFER.getIndex())){
                transferCallback(result);
            }else if(action.equals(TrustActionEnum.ACTION_BAT_TRANSFER.getIndex())){
            	batTransferCallback(result);
            }else if(action.equals(TrustActionEnum.ACTION_TRANSFER_OUT.getIndex())){
                transferOutCallback(result);
            }else{
                return "error";
            }
        }catch(Exception e){
            e.printStackTrace();
        }
       
        return "success";
    }
    
}
