package com.dy.sc.admin.controller.product;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.SendAlertType;
import com.dy.sc.entity.enumeration.Status;
import com.dy.sc.entity.schedule.ScheSendMsg;
import com.dy.sc.entity.schedule.ScheTriggerInfo;
import com.google.common.collect.Maps;

/**
 * 业务提醒
 * 
 * @ClassName: ScheSendMsgController Copyright (c) 2017 厦门帝网信息科技
 * @author likf@diyou.cn
 * @date 2017年8月4日 下午3:45:01
 * @version v1.0
 * 
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * </pre>
 */
@Controller
@RequestMapping("/product/alertConfig/")
public class AlertConfigController extends AdminBaseController {

    /**
     * 列表
     * 
     * @return
     * @throws Exception
     */
    @RequestMapping("list/{type}")
    public ModelAndView list(@PathVariable("type")int type) throws Exception {
        TableHeader tableHeader = new TableHeader();
        
        if(type==SendAlertType.COMMON.getIndex()){
            tableHeader.setNames(new String[] { "id","trigger_time", "receiver_type", "send_type", "status" });
            tableHeader.setTexts(new String[] { "ID", "触发时间","触发对象","触发方式","状态" });
            tableHeader.setTypes(new String[] { "int", "", "", "" ,""});
            tableHeader.setOptionTypes(new String[] { "", "trigger_time_c", "receiver_type", "" ,"status"});
            tableHeader.setFilters(new String[] { "", "", "", "","" });
        }else{
            tableHeader.setNames(new String[] { "id","trigger_name","business_id", "trigger_point", "trigger_time", "status" });
            tableHeader.setTexts(new String[] { "ID","提醒名称", "业务类型:business_type", "触发节点:trigger_point", "触发时间:trigger_time","状态:status" });
        }

        Tool tool = new Tool();
        tool.setList(buildTools());

//        Search search = new Search();
//        search.setNames(new String[] { "name" });
//        search.setTexts(new String[] { "合同名称" });
//        search.setTypes(new String[] { "text" });

        PageStructure data = PageUtil.createTablePageStructure("product/alertConfig/listData/"+type,
            "id",
            tableHeader,
            tool,
            null);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取业务类型数据
     * 
     * @param page
     * @param limit
     * @param search
     * @param name 业务名称
     * @param code 业务编码
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("listData/{type}")
    public DyResponse listData(Integer page, Integer limit, String search, String name,@PathVariable("type")int type) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        //queryItem.setFields(" id, name, business_type_id, create_time, update_time ");
        if(type==SendAlertType.COMMON.getIndex()){
            queryItem.setWhere(Where.eq("send_alert_type", SendAlertType.COMMON.getIndex()));
        }else if(type==SendAlertType.BUSINESS.getIndex()){
            queryItem.setWhere(Where.eq("send_alert_type", SendAlertType.BUSINESS.getIndex()));
        }else{
            return null;
        }
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("name", search));
        }
        if (StringUtils.isNotBlank(name)) {
            queryItem.setWhere(Where.likeAll("name", name));
        }
        queryItem.setOrders("id desc");
        Page<Map> recordPage = this.getPageByMap(queryItem, SCModule.SCHEDULE, SCFunction.SCHE_SEND_MSG);
        if(type==SendAlertType.COMMON.getIndex()&&recordPage.getItems()!=null&&recordPage.getItems().size()>0){
            this.idToName(recordPage.getItems(), SCModule.SCHEDULE, SCFunction.SCHE_TRIGGER_INFO, "id#send_msg_id:receiver_type,send_type");
            Map<String, String> sendTypeOptions=DictUtils.getOptionsMap("send_type");
            for(Map item:recordPage.getItems()){
                if(item.get("send_type")!=null)
                    item.put("send_type", translateSendType(item.get("send_type").toString().split(","), sendTypeOptions));
            }
        }else if(type==SendAlertType.BUSINESS.getIndex()){
        	 for(Map item:recordPage.getItems()){
        		 if(MapUtils.getInteger(item,"business_id") == 0){
        			 item.put("business_id", "全部类型");
        		 }
        	 }
        }
        
        return createSuccessJsonResonse(recordPage);
    }
    
    /**
     * 
     * 将编码转字符串
     * @param sendTypes  1,2,3
     * @param sendTypeOptions
     * @return
     * @author likf
     */
    private String translateSendType(String[] sendTypes,Map<String,String> sendTypeOptions){
        StringBuffer sb=new StringBuffer();
        for(int i=0;i<sendTypes.length;i++){
            sb.append(sendTypeOptions.get(sendTypes[i]));
            if(i!=sendTypes.length-1){
                sb.append(",");
            }
        }
        return sb.toString();
    }
    
    /**
     * 添加业务类型
     * 
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "add/{type}")
    public ModelAndView add(@PathVariable("type")int type) throws Exception {
        
        Map<String,Object> formData=Maps.newHashMap();
        
        formData.put("sendAlertType", type);
        formData.put("status", Status.OPEN.getIndex());
        Map<String, Object> data = PageUtil.createFormPageStructure("product/alertConfig/save", null,formData);
        data.put("businessTypeIdOption", DictUtils.getOptionsInt("business_type"));
        data.put("triggerPointOption", DictUtils.getOptionsInt("trigger_point"));
        data.put("triggerTimeOption", DictUtils.getOptionsInt("trigger_time"));
        data.put("statusOption", DictUtils.getOptionsInt("status"));
        data.put("receiverTypeOption", DictUtils.getOptionsInt("receiver_type"));
        data.put("sendTypeOption", DictUtils.getOptions("send_type"));
        return createSuccessModelAndView("product/alertConfig/edit"+type, JsonUtils.object2JsonString(data));
    }

    /**
     * 保存新增业务类型
     * 
     * @param businessType
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "save")
    public DyResponse save(ScheSendMsg sendMsg, HttpServletRequest request,String triggers) throws Exception {
        //sendMsg.setSendAlertType(TemplateType.BUSINESS.getIndex());
        
        ArrayList<Map> list=JsonUtils.jsonToArrayList(triggers, Map.class);
        if(list==null||list.size()==0){
            return createErrorJsonResonse("请添加触发内容");
        }
        DyResponse sendMsgResp=this.insert(SCModule.SCHEDULE, SCFunction.SCHE_SEND_MSG, sendMsg);
        
        for(Map trigger:list){
            ScheTriggerInfo item=new ScheTriggerInfo();
            Float receiverType=Float.parseFloat(trigger.get("receiverType").toString());
            item.setReceiverType(receiverType.intValue());
            item.setSendContent(trigger.get("sendContent").toString());
            item.setSendMsgId(sendMsgResp.getId());
            item.setSendType(StringUtils.join((List)trigger.get("sendType"),",").replaceAll(".0", ""));
            this.insert(SCModule.SCHEDULE, SCFunction.SCHE_TRIGGER_INFO, item);
        }
        
        return createSuccessJsonResonse(null, "添加成功！");
    }

    /**
     * 编辑业务类型
     * 
     * @param id
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "edit")
    public ModelAndView edit(Long id) throws Exception {
        QueryItem queryItem = new QueryItem(Where.eq("id", id));
        queryItem.setFields("id,trigger_name as triggerName, business_id as businessId, send_alert_type as sendAlertType,trigger_point as triggerPoint,trigger_time as triggerTime,trigger_time_day as triggerTimeDay,status");
        Map entity = this.getOneByMap(queryItem, SCModule.SCHEDULE, SCFunction.SCHE_SEND_MSG);
        
        queryItem = new QueryItem(Where.eq("send_msg_id", id));
        queryItem.setFields("id,send_msg_id as sendMsgId,receiver_type as receiverType,send_type as sendType,send_content as sendContent");
        List<Map> triggers=this.getListByEntity(queryItem, SCModule.SCHEDULE, SCFunction.SCHE_TRIGGER_INFO, Map.class);
        for(Map trigger:triggers){
            trigger.put("sendType", trigger.get("sendType").toString().split(","));
        }
        entity.put("triggers", triggers);
        int triggerTime=Integer.parseInt(entity.get("triggerTime").toString());
        if(triggerTime==3){//之后
            entity.put("triggerTimeDay1",entity.get("triggerTimeDay"));
            entity.remove("triggerTimeDay");
        }
        if(triggerTime==1){//当天
            entity.remove("triggerTimeDay");
        }
        
        entity.put("triggerTimeLabel", DictUtils.getDictLabel(entity.get("triggerTime"), "trigger_time_c"));
        Map<String, Object> data = PageUtil.createFormPageStructure("product/alertConfig/update",null,entity);
        data.put("businessTypeIdOption", DictUtils.getOptionsInt("business_type"));
        data.put("triggerPointOption", DictUtils.getOptionsInt("trigger_point"));
        data.put("triggerTimeOption", DictUtils.getOptionsInt("trigger_time"));
        data.put("statusOption", DictUtils.getOptionsInt("status"));
        data.put("receiverTypeOption", DictUtils.getOptionsInt("receiver_type"));
        data.put("sendTypeOption", DictUtils.getOptions("send_type"));
        Object type=entity.get("sendAlertType");
        return createSuccessModelAndView("product/alertConfig/edit"+type, JsonUtils.object2JsonString(data));
    }

    /**
     * 更新业务类型
     * 
     * @param businessType
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update")
    public DyResponse update(ScheSendMsg sendMsg, HttpServletRequest request,String triggers) throws Exception {
        
        ArrayList<Map> list=JsonUtils.jsonToArrayList(triggers, Map.class);
        if(list==null||list.size()==0){
            return createErrorJsonResonse("请添加触发内容");
        }
        QueryItem queryItem = new QueryItem(Where.eq("send_msg_id", sendMsg.getId()));
        List<ScheTriggerInfo> triggersList=this.getListByEntity(queryItem, SCModule.SCHEDULE, SCFunction.SCHE_TRIGGER_INFO, ScheTriggerInfo.class);
        for(ScheTriggerInfo trigger:triggersList){
            this.deleteById(trigger.getId(), SCModule.SCHEDULE, SCFunction.SCHE_TRIGGER_INFO);
        }
        for(Map trigger:list){
            ScheTriggerInfo item=new ScheTriggerInfo();
            Float receiverType=Float.parseFloat(trigger.get("receiverType").toString());
            item.setReceiverType(receiverType.intValue());
            item.setSendContent(trigger.get("sendContent").toString());
            item.setSendMsgId(sendMsg.getId());
            item.setSendType(StringUtils.join((List)trigger.get("sendType"),",").replaceAll(".0", ""));
            this.insert(SCModule.SCHEDULE, SCFunction.SCHE_TRIGGER_INFO, item);
        }
        this.update(SCModule.SCHEDULE, SCFunction.SCHE_SEND_MSG, sendMsg);
        return createSuccessJsonResonse(null, "更新成功！");
    }

    @ResponseBody
    @RequestMapping(value="delete",method=RequestMethod.POST)
    public DyResponse delete(Long id) throws Exception {
        if(id!=null){
            QueryItem queryItem = new QueryItem(Where.eq("send_msg_id", id));
            List<ScheTriggerInfo> triggers=this.getListByEntity(queryItem, SCModule.SCHEDULE, SCFunction.SCHE_TRIGGER_INFO, ScheTriggerInfo.class);
            for(ScheTriggerInfo trigger:triggers){
                this.deleteById(trigger.getId(), SCModule.SCHEDULE, SCFunction.SCHE_TRIGGER_INFO);
            }
            this.deleteById(id, SCModule.SCHEDULE, SCFunction.SCHE_SEND_MSG);
        }
        return createSuccessJsonResonse(null,"删除成功");
    }
}
