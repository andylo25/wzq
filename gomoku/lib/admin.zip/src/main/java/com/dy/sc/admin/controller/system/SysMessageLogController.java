
/**
 * Copyright cuiwm
 */
package com.dy.sc.admin.controller.system;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DateFormatType;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.enumeration.MessageType;

/**
 * 站内信记录
 * @author cuiwm
 */
@Controller
@RequestMapping(value = "sys/messageLog")
public class SysMessageLogController extends AdminBaseController {
	
	@Override
	protected DateFormatType getDateFormatType() {
		return DateFormatType.DATETIME;
	}
	
	/**
     * 构建列表结构:站内信记录
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id","name","title","contents","status","create_time:datetime"});
		tableHeader.setTexts(new String[]{"ID","接收人","标题","内容","状态:send_status","添加时间"});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"title"});
		search.setTexts(new String[]{"消息标题"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("sys/messageLog/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 获取列表数据:站内信记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("listData")
	public DyResponse getListData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,name,tpl_id,title,contents,status,create_time");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("title", search));
		}
		// 其他过滤条件
		queryItem.getWhere().add(Where.eq("message_type", MessageType.INFORMATION.getIndex()));
		queryItem.setOrders("id desc");
		
		Page<Map> pagem = getPageByMap(queryItem, Module.SYSTEM, Function.MESSAGE_LOG);
 		//this.idToName(pagem.getItems(), Module.SYSTEM, Function.SYS_ADMIN, "member_id:real_name"); // 关联转换
 //		dataConvert(pagem); // 数据转换
		
		return createSuccessJsonResonse(pagem);
	}


}