package com.dy.sc.admin.controller.credit;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.*;
import com.dy.ia.entity.common.Company;
import com.dy.ia.entity.common.FlowProcInst;
import com.dy.sc.bussmodule.utils.CommonLoanUtil;
import com.dy.sc.entity.constant.SCFlow;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.credit.CreCompanyLimit;
import com.dy.sc.entity.credit.CreLimitLog;
import com.dy.sc.entity.customer.CusGradeInfo;
import com.dy.sc.entity.enumeration.*;
import com.dy.sc.entity.product.ProdBusinessType;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/credit/limit")
public class CreCompanyLimitController extends AdminBaseController {

    /**
     * 公司授信额度
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "list")
    public ModelAndView limitList() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "company_name", "company_role_type", "credit_limit", "unused_limit", "used_limit", "start_time", "end_time", "check_status", "creater_name", "dept_name", "create_time"});
        tableHeader.setTexts(new String[]{"ID", "企业名称", "企业类型:company_role_type", "额度总额", "未占用额度", "已占用额度", "生效日", "到期日", "状态", "经办人", "所属部门", "操作日期"});
        tableHeader.setTypes(new String[]{"int", "", "", "", "", "", "date", "date", "", "", "", ""});

        Tool tool = new Tool();
        tool.setList(buildTools());
        Search search = new Search();
        search.setNames(new String[]{"company_name"});
        search.setTexts(new String[]{"企业名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("credit/limit/listData", "credit/limit/view", "id", tableHeader, tool, search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 授信额度数据
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "listData")
    public DyResponse limitListData(Integer page, Integer limit, String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
//		queryItem.setWhere(Where.eq("check_status", ScConstants.LIMIT_PASS));
        if (StringUtils.isNotBlank(search)) {
            QueryItem query = new QueryItem(Where.likeAll("company_name", search));
            List<Company> companies = this.getListByEntity(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
            List<Long> ids = new ArrayList();
            for (Company company : companies) {
                ids.add(company.getId());
            }
            queryItem.setWhere(Where.in("company_id", ids));
        }
        queryItem.setWhere(Where.eq("business_type_id", ScConstants.CONTRACT_TYPE_ALL));
        queryItem.setOrders("create_time desc");
        Page<Map> rlt = getPageByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name as creater_name,dept_name");
        this.idToName(rlt.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name,company_role_type");
        for (Map item : rlt.getItems()) {
            // 计算额度汇总
            BigDecimal creditLimit = BigDecimal.ZERO;
            BigDecimal unusedLimit = BigDecimal.ZERO;
            BigDecimal usedLimit = BigDecimal.ZERO;
            QueryItem query = new QueryItem(Where.eq("company_id", item.get("company_id").toString()));
            query.setWhere(Where.notEq("business_type_id", ScConstants.CONTRACT_TYPE_ALL));
            List<CreCompanyLimit> companyLimits = this.getListByEntity(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
            for(CreCompanyLimit companyLimit : companyLimits){
                creditLimit = companyLimit.getCreditLimit().add(creditLimit);
                unusedLimit = companyLimit.getUnusedLimit().add(unusedLimit);
                usedLimit = companyLimit.getUsedLimit().add(usedLimit);
            }
            item.put("credit_limit", creditLimit);
            item.put("unused_limit", unusedLimit);
            item.put("used_limit", usedLimit);
            Integer status = Integer.valueOf(item.get("check_status").toString());
            item.put("check_status", status == CheckStatus.CHECK_PASS.getIndex() ? "审批通过" : (status == CheckStatus.CHECK_TODO.getIndex() ? "审批中" : "驳回"));
        }
        return createSuccessJsonResonse(dataConvert(rlt, "limit_type", "create_time"));
    }

    /**
     * 新增页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "add", method = RequestMethod.GET)
    public ModelAndView add(Long id) throws Exception {

        List<FormField> formFieldList = null;//new ArrayList<>();
        Map<String, Object> formData = Maps.newHashMap();
        List<Option> options = Lists.newArrayList();
        options.add(new Option(4, "授信企业"));
        options.add(new Option(5, "核心企业"));
        formData.put("company_role_type", options);
        Map<String, Object> data = PageUtil.createFormPageStructure("credit/limit/save?compId=" + (id == null ? -1 : id), formFieldList, formData);
        return createSuccessModelAndView("credit/limit/add", JsonUtils.object2JsonString(data));
    }

    /**
     * 未添加限额的产品类型
     *
     * @return
     * @throws Exception
     * @author likf
     */
    @ResponseBody
    @RequestMapping(value = "limitBussType", method = RequestMethod.POST)
    public DyResponse limitBussType(Long id) throws Exception {
        //排除已添加的
        QueryItem queryLimit = QueryItem.builder().field("business_type_id").where("company_id", id).build();
        List<Map> creLimits = this.getListByMap(queryLimit, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);

        String ids = DyStringUtils.join(creLimits, "business_type_id", ",");
        // 业务类型
        QueryItem query = new QueryItem();
        query.setFields("id value, name text");
        if (StringUtils.isNotBlank(ids)) {
            query.setWhere(Where.notIn("id", ids));
        } else {
            query.setWhere(Where.eq("del_flag", 0));
        }
        return createSuccessJsonResonse(this.getListByMap(query, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE));
    }

    /**
     * 保存
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "save", method = RequestMethod.POST)
    public DyResponse save(CreCompanyLimit limit, Long compId, Double riskLimit) throws Exception {
        if (limit.getCreditLimit() == null || limit.getCreditLimit().compareTo(BigDecimal.ZERO) <= 0) {
            return this.createErrorJsonResonse("金额不能为0");
        }
        if (compId != -1) {
            limit.setCompanyId(compId);
        }
        limit.setUnusedLimit(limit.getCreditLimit());// 全部设置为未占用
        QueryItem query = new QueryItem(Where.eq("company_id", limit.getCompanyId()));
        query.setWhere(Where.eq("business_type_id", limit.getBusinessTypeId()));
        CreCompanyLimit creLimit = this.getOneByEntity(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        if (creLimit != null) {
            return this.createErrorJsonResonse("该额度类型已添加");
        }
        //总额度不能超过风险限额
        query = QueryItem.builder().field("sum(credit_limit) total").where("company_id", limit.getCompanyId()).build();
        Map totalMap = this.getOneByMap(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        Double total = MapUtils.getDouble(totalMap, "total", 0D) + limit.getCreditLimit().doubleValue();
        if (riskLimit != null && riskLimit > 0 && total.compareTo(riskLimit) > 0) {
            return createErrorJsonResonse("总的额度金额:" + NumberUtils.format(total) + "已超过风险限额");
        }

        limit.setCheckStatus(ScConstants.LIMIT_CHECKING);
//	    QueryItem item = new QueryItem(Where.eq("company_id", limit.getCompanyId()));
//	    item.setWhere(Where.eq("business_type_id", limit.getBusinessTypeId()));
//	    CreCompanyLimit compLimit = this.getOneByEntity(item, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);

//	    if(compLimit == null){
        DyResponse resp = this.insert(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);
//	    }else{
//	    	limit.setCreditLimit(limit.getCreditLimit().add(compLimit.getCreditLimit()));
//	    	limit.setUnusedLimit(compLimit.getUnusedLimit().add(limit.getCreditLimit()));
//	    	limit.setId(compLimit.getId());
//	    	this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);
//	    }
        Company company = this.getById(limit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
//	    FlowProcInst procInst = this.startFlow(SCFlow.FLOW_LIMIT_ADD, limit.getCompanyId() + "_" + limit.getBusinessTypeId(), "合同录入", this.getRemoteIp(), resp.getId().toString(),company.getCompanyName());

        String msg = "额度申请";
        workFlowUtil.startFlowPub(SCFlow.FLOW_LIMIT_ADD, msg, msg, company.getId(), resp.getId().toString(), company.getCompanyName(), String.valueOf(limit.getCreditLimit()));

        return createSuccessJsonResonse(null, "添加成功");
    }

    /**
     * 编辑更新页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "edit")
    public ModelAndView edit(Long id) throws Exception {

        List<FormField> formFieldList = null;//new ArrayList<>();

        Map limit = this.getById(id, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        limit.put("company_type", "授信企业");
        limit.put("business_type", this.getById(limit.get("business_type_id").toString(), SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE).get("name"));
        limit.put("company_name", this.getById(limit.get("company_id").toString(), SCModule.SYSTEM, SCFunction.SYS_COMPANY).get("company_name"));
        Map<String, Object> data = PageUtil.createFormPageStructure("credit/limit/update", formFieldList, limit);

        return createSuccessModelAndView("credit/limit/add", JsonUtils.object2JsonString(data));
    }

    private void addLimitLog(CreCompanyLimit limit, CreCompanyLimit oldLimit) throws Exception {
        CreLimitLog log = new CreLimitLog();
        log.setCompanyId(limit.getCompanyId());
        log.setBusinessTypeId(limit.getBusinessTypeId());
        log.setCreditLimit(oldLimit.getCreditLimit().add(limit.getCreditLimit()));
        log.setActionType(ActionTypeEnum.CHANGE.getIndex());
        log.setTradeAmount(limit.getCreditLimit());
        log.setBalanceAmount(oldLimit.getUnusedLimit());
        this.insert(SCModule.CREDIT, SCFunction.CRE_LIMIT_LOG, log);
    }

    /**
     * 更新
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public DyResponse update(CreCompanyLimit limit, Double riskLimit) throws Exception {
        CreCompanyLimit oldLimit = this.getById(limit.getId(), SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
//		if(limit.getCreditLimit().compareTo(oldLimit.getUsedLimit()) < 0){
//			return this.createErrorJsonResonse("额度金额不能小于已占用额度");
//		}
        oldLimit.setRemark(limit.getRemark());
        this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, oldLimit);
        //总额度不能超过风险限额
//        QueryItem query=QueryItem.builder().field("sum(credit_limit) total").where("company_id", limit.getCompanyId())
//                .where(Where.notEq("id", limit.getId())).build();
//        Map totalMap=this.getOneByMap(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
//        Double total=MapUtils.getDouble(totalMap, "total",0D)+limit.getCreditLimit().doubleValue();
//        if(riskLimit!=null&&riskLimit>0&&total.compareTo(riskLimit)>0){
//            return createErrorJsonResonse("总的额度金额:"+NumberUtils.format(total)+"已超过风险限额");
//        }

//		limit.setCheckStatus(ScConstants.LIMIT_CHECKING);
//		limit.setUnusedLimit(limit.getCreditLimit().subtract(limit.getUsedLimit()));
//		this.addLimitLog(limit, oldLimit);
//	    if(limit.getId()!=null){
//	        DyResponse resp = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);
////	        TreeUtils.clearDeptCache();
//	        Company company = this.getById(limit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
////		    FlowProcInst procInst = this.startFlow(SCFlow.FLOW_LIMIT_EDIT, oldLimit.getCompanyId() + "_" + oldLimit.getBusinessTypeId(), "额度修改", this.getRemoteIp(), oldLimit.getId().toString(),company.getCompanyName());
//			// 自动审批
////			while (procInst.getAutoSubmit() == WorkflowUtil.AUTO_SUBMIT && procInst.getFlowStatus() == AccConstants.FLOW_STATUS_APRVING) {
////				procInst = workFlowUtil.submitLoanRequest(procInst.getId(), "自动审批", true);
////			}
//	    }
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 额度信息
     *
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "view")
    public ModelAndView view(Long id) throws Exception {
        Map limit = createLimitView(id);
        return createSuccessModelAndView("credit/limitinfo", JsonUtils.object2JsonString(limit));
    }

    private Map<String, Object> createLimitView(Object id) throws Exception {
        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("id", id));
        Map limit = this.getOneByMap(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        limit.put("companyName", this.getById(limit.get("company_id").toString(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class).getCompanyName());
        limit.put("looped", DictUtils.getDictLabel(limit.get("looped").toString(), "looped"));
        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("company_id", limit.get("company_id")));
        queryItem.setWhere(Where.notEq("business_type_id", 0));
        List<Map> companyLimits = this.getListByMap(queryItem, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        BigDecimal total = BigDecimal.ZERO;
        BigDecimal unused = BigDecimal.ZERO;
        BigDecimal used = BigDecimal.ZERO;
        for (Map companyLimit : companyLimits) {
            total = total.add(new BigDecimal(companyLimit.get("credit_limit").toString()));
            unused = unused.add(new BigDecimal(companyLimit.get("unused_limit").toString()));
            used = used.add(new BigDecimal(companyLimit.get("used_limit").toString()));
            if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_RECEIVE) {
                companyLimit.put("name", "应收账款");
            } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_B2B) {
                companyLimit.put("name", "b2b平台类");
            } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
                companyLimit.put("name", "仓单");
            } else if (Integer.valueOf(companyLimit.get("business_type_id").toString()) == ScConstants.CONTRACT_TYPE_AGPUR) {
                companyLimit.put("name", "代采");
            }
        }
        limit.put("credit_limit", total);
        limit.put("unused_limit", unused);
        limit.put("used_limit", used);
        limit.put("changeList", companyLimits);
        limit.put("changeType", "view");
        // 审批记录
        List<Map> flows = CommonLoanUtil.getFlowList(id.toString(), "limit_edit");
        List<Map> flows1 = CommonLoanUtil.getFlowList(id.toString(), "limit_add");
        if(flows != null){
            flows.addAll(flows1);
            limit.put("flowList", flows);
        }else {
            limit.put("flowList", flows1);
        }

        limit.put("startTime", DateUtil.dateFormat(limit.get("start_time")));
        limit.put("endTime", DateUtil.dateFormat(limit.get("end_time")));
        query = QueryItem.builder().where("company_id", limit.get("company_id")).where("grade_status", GradeStatus.VALID.getIndex()).build();
        CusGradeInfo cusGradeInfo=this.getOneByEntity(query, SCModule.CUSTOMER, SCFunction.CUS_GRADE_INFO,CusGradeInfo.class);
        if(cusGradeInfo != null) {
            limit.put("totalPoint", cusGradeInfo.getTotalPoint());
            limit.put("gradeDate", cusGradeInfo.getGradeDate());
            limit.put("riskLimit", cusGradeInfo.getRiskLimit());
        }
        Integer status = Integer.valueOf(limit.get("check_status").toString());
        limit.put("status", status == ScConstants.LIMIT_PASS ? "审批通过" : (status == ScConstants.LIMIT_CHECKING ? "审批中" : "驳回"));
        Company company = this.getById(limit.get("company_id").toString(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        limit.put("companyType", DictUtils.getDictLabel(company.getCompanyRoleType(),"company_role_type"));
        if(limit.get("create_uid") != null){
            // 客户经理
            Map creater = this.getById(limit.get("create_uid").toString(), SCModule.SYSTEM, SCFunction.SYS_ADMIN);
            if(creater!=null){
                limit.put("creater", creater.get("real_name"));
                limit.put("creater_dept", creater.get("dept_name"));
            }
        }
        return limit;
    }

    /**
     * 删除
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "delCredit", method = RequestMethod.POST)
    public DyResponse del(Long id) throws Exception {
        if (id != null) {
            CreCompanyLimit companyLimit = this.getById(id, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
            if(companyLimit.getCheckStatus() != CheckStatus.CHECK_REJECT.getIndex()){
                return createErrorJsonResonse("该状态不能删除");
            }
            QueryItem queryItem = new QueryItem(Where.eq("company_id", companyLimit.getCompanyId()));
            List<CreCompanyLimit> companyLimits = this.getListByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
            for(CreCompanyLimit limit : companyLimits) {
                this.deleteById(limit.getId(), SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
            }
        }
        return createSuccessJsonResonse(null, "删除成功");
    }

    /**
     * 编辑更新页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "changeLimit/{type}")
    public ModelAndView addLimit(@PathVariable("type") String type, Long id) throws Exception {

        List<FormField> formFieldList = new ArrayList<>();
        CreCompanyLimit limit = this.getById(id, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);

        Company company = this.getById(limit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        formFieldList.add(FormField.builder().name("companyName").text("客户名称").verify("required")
                .type("span").remarks(company.getCompanyName()).name(id.toString()).build());

        ProdBusinessType business = this.getById(limit.getBusinessTypeId(), SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class);

        formFieldList.add(FormField.builder().name("businessTypeId").text("额度类型").verify("required")
                .type("span").remarks(business.getName()).name(id.toString()).build());
        formFieldList.add(FormField.builder().name("creditLimit").verify("required").text("额度金额").build());

        Map<String, Object> data = PageUtil.createFormPageStructure("credit/limit/change?type=" + type, formFieldList, limit);

        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "change", method = RequestMethod.POST)
    public DyResponse change(CreCompanyLimit limit, String type) throws Exception {
        if (limit.getCreditLimit().compareTo(BigDecimal.ZERO) <= 0) {
            return this.createErrorJsonResonse("额度需大于0");
        }
        CreCompanyLimit oldLimit = this.getById(limit.getId(), SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        if (type.equals("decrease")) {
            if (oldLimit.getUnusedLimit().compareTo(limit.getCreditLimit()) < 0) {
                return this.createErrorJsonResonse("可用额度不足");
            }
            oldLimit.setCreditLimit(oldLimit.getCreditLimit().subtract(limit.getCreditLimit()));
            oldLimit.setUnusedLimit(oldLimit.getUnusedLimit().subtract(limit.getCreditLimit()));
            DyResponse resp = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, oldLimit);
            this.addLimitLog(limit, oldLimit);
//			return this.createErrorJsonResonse("额度金额不能小于已占用额度");
        }
//		limit.setCheckStatus(ScConstants.LIMIT_CHECKING);
//		limit.setUnusedLimit(limit.getCreditLimit().subtract(limit.getUsedLimit()));

        if (limit.getId() != null) {
//	        DyResponse resp = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);
//	        TreeUtils.clearDeptCache();
            Company company = this.getById(limit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
            String msg = "额度修改" + (type.equals("increase") ? "（增加）" : "（减少）");
            workFlowUtil.startFlowPub(SCFlow.FLOW_LIMIT_EDIT, msg, msg, company.getId(), oldLimit.getId().toString(), company.getCompanyName(), String.valueOf(limit.getCreditLimit()));
        }
        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 新增页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "addCredit", method = RequestMethod.GET)
    public ModelAndView addCredit(Long id) throws Exception {
        List<FormField> formFieldList = new ArrayList<>();
        // 额度管理处添加
        QueryItem queryItem = new QueryItem();
        List<Where> whereList = new ArrayList<Where>();
        addWhereCondition(whereList, "company_role_type", LIKE_ALL, CompanyRoleType.COMPANY_CREDIT.getIndex());
        queryItem.setWhere(whereList);
        List<Company> companies = this.getListByEntity(queryItem, SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);

        List<FormOption> options1 = new ArrayList<>();
        for (Company company : companies) {
            options1.add(new FormOption(company.getCompanyName(), company.getId().toString()));
        }
        formFieldList.add(FormField.builder().name("companyId").text("客户名称").verify("required")
                .type("select").options(options1).build());

        Map<String, Object> formData = Maps.newHashMap();
        formData.put("companies", options1);
        formData.put("creditLimit", 0);

        //排除已添加的
        QueryItem queryLimit = new QueryItem(Where.eq("company_id", id));
        List<CreCompanyLimit> creLimits = this.getListByEntity(queryLimit, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        String ids = "";
        for (CreCompanyLimit creLimit : creLimits) {
            ids += creLimit.getBusinessTypeId() + ",";
        }

//		formFieldList.add(FormField.builder().name("looped").text("是否循环").type("radio").options("status").build());
        formFieldList.add(FormField.builder().name("remark").text("备注").build());

        Map<String, Object> data = PageUtil.createFormPageStructure("credit/limit/saveCredit?compId=" + id, formFieldList, formData);
        return createSuccessModelAndView("credit/limit/addedit", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "saveCredit", method = RequestMethod.POST)
    public DyResponse saveCredit(CreCompanyLimit limit, BigDecimal bill, BigDecimal b2b, BigDecimal wh, BigDecimal agpur,
                                 Long companyId, Double riskLimit) throws Exception {
        Company company = this.getById(limit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        Integer type = company.getBlacklistType();
        if(type != null && type == BlacklistTypeEnum.FORBIDDEN.getIndex()){
            return this.createErrorJsonResonse("该用户属于禁止类用户，不能继续进行操作！");
        }
        QueryItem queryLimit = new QueryItem(Where.eq("company_id", limit.getCompanyId()));
        List<CreCompanyLimit> creLimits = this.getListByEntity(queryLimit, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        if(creLimits.size() > 0){
            return this.createErrorJsonResonse("已申请额度");
        }
        if (limit.getCreditLimit() == null || limit.getCreditLimit().compareTo(BigDecimal.ZERO) <= 0) {
            return this.createErrorJsonResonse("金额不能为0");
        }
        limit.setCompanyId(companyId);
        limit.setUnusedLimit(limit.getCreditLimit());// 全部设置为未占用

        //总额度不能超过风险限额
        QueryItem query = QueryItem.builder().field("sum(credit_limit) total").where("company_id", limit.getCompanyId()).build();
        Map totalMap = this.getOneByMap(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        Double total = MapUtils.getDouble(totalMap, "total", 0D) + limit.getCreditLimit().doubleValue();
        if (riskLimit != null && riskLimit > 0 && total.compareTo(riskLimit) > 0) {
            return createErrorJsonResonse("总的额度金额:" + NumberUtils.format(total) + "已超过风险限额");
        }
        limit.setBusinessTypeId(Long.valueOf(ScConstants.CONTRACT_TYPE_ALL));
        limit.setCheckStatus(ScConstants.LIMIT_CHECKING);
        DyResponse  resp;
        // 插入额度汇总
        DyResponse respLimit = this.insert(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);

        // 插入分项额度
        bill = (bill == null ? BigDecimal.ZERO : bill);
        limit.setCreditLimit(bill);
        limit.setUnusedLimit(bill);
        limit.setBusinessTypeId(Long.valueOf(ScConstants.CONTRACT_TYPE_RECEIVE));
        resp = this.insert(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);

        b2b = (b2b == null ? BigDecimal.ZERO : b2b);
        limit.setCreditLimit(b2b);
        limit.setUnusedLimit(b2b);
        limit.setBusinessTypeId(Long.valueOf(ScConstants.CONTRACT_TYPE_B2B));
        resp = this.insert(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);

        wh = (wh == null ? BigDecimal.ZERO : wh);
        limit.setCreditLimit(wh);
        limit.setUnusedLimit(wh);
        limit.setBusinessTypeId(Long.valueOf(ScConstants.CONTRACT_TYPE_WAREHOUSE));
        resp = this.insert(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);

        agpur = (agpur == null ? BigDecimal.ZERO : agpur);
        limit.setCreditLimit(agpur);
        limit.setUnusedLimit(agpur);
        limit.setBusinessTypeId(Long.valueOf(ScConstants.CONTRACT_TYPE_AGPUR));
        resp = this.insert(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);

        String change = "" + bill + ":" + b2b + ":" + wh + ":" +agpur;
        String msg = "额度申请";
        workFlowUtil.startFlowPub(SCFlow.FLOW_LIMIT_ADD, msg, msg, company.getId(), respLimit.getId().toString(), company.getCompanyName(), change);

        return createSuccessJsonResonse(null, "添加成功");
    }

    /**
     * 编辑页面
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "editCredit", method = RequestMethod.GET)
    public ModelAndView editCredit(Long id) throws Exception {
        CreCompanyLimit limit = this.getById(id, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        List<FormField> formFieldList = new ArrayList<>();
        Company company = this.getById(limit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);

        Map<String, Object> formData = Maps.newHashMap();
        formData.put("companyName", company.getCompanyName());

        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("company_id", limit.getCompanyId()));
        List<CreCompanyLimit> companyLimits = this.getListByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        BigDecimal creditLimit = BigDecimal.ZERO;
        for(CreCompanyLimit companyLimit : companyLimits) {
            if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_RECEIVE) {
                formData.put("bill", companyLimit.getCreditLimit());
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_B2B){
                formData.put("b2b", companyLimit.getCreditLimit());
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_WAREHOUSE){
                formData.put("wh", companyLimit.getCreditLimit());
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_AGPUR){
                formData.put("agpur", companyLimit.getCreditLimit());
            }
            if(companyLimit.getBusinessTypeId().intValue() != ScConstants.CONTRACT_TYPE_ALL) {
                creditLimit = creditLimit.add(companyLimit.getCreditLimit());
            }
        }
        for(CreCompanyLimit companyLimit : companyLimits) {
            if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_ALL){
                formData.put("creditLimit", creditLimit);
            }
        }
        formData.put("startTime", DateUtil.dateFormat(limit.getStartTime()));
        formData.put("endTime", DateUtil.dateFormat(limit.getEndTime()));
        formData.put("remark", limit.getRemark());
        QueryItem query=QueryItem.builder().where("company_id", limit.getCompanyId()).where("grade_status", GradeStatus.VALID.getIndex()).build();
        CusGradeInfo cusGradeInfo=this.getOneByEntity(query, SCModule.CUSTOMER, SCFunction.CUS_GRADE_INFO,CusGradeInfo.class);
        if(cusGradeInfo != null) {
            formData.put("totalPoint", cusGradeInfo.getTotalPoint());
            formData.put("gradeDate", cusGradeInfo.getGradeDate());
            formData.put("riskLimit", cusGradeInfo.getRiskLimit());
        }

        formFieldList.add(FormField.builder().verify("required").name("creditLimit").text("额度金额").build());
//		formFieldList.add(FormField.builder().name("looped").text("是否循环").type("radio").options("status").build());
        formFieldList.add(FormField.builder().name("remark").text("备注").build());

        Map<String, Object> data = PageUtil.createFormPageStructure("credit/limit/saveEditCredit?id=" + id, formFieldList, formData);
        return createSuccessModelAndView("credit/limit/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "saveEditCredit", method = RequestMethod.POST)
    public DyResponse saveEditCredit(CreCompanyLimit limit, BigDecimal bill, BigDecimal b2b, BigDecimal wh, BigDecimal agpur,
                                     Long id, Double riskLimit) throws Exception {
        CreCompanyLimit creCompanyLimit = this.getById(id, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        Company company = this.getById(creCompanyLimit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        Integer type = company.getBlacklistType();
        if(type != null && type == BlacklistTypeEnum.FORBIDDEN.getIndex()){
            return this.createErrorJsonResonse("该用户属于禁止类用户，不能继续进行操作！");
        }

        if(creCompanyLimit.getCheckStatus() != CheckStatus.CHECK_REJECT.getIndex()){
            return createErrorJsonResonse("该状态不可更改");
        }
        QueryItem queryLimit = new QueryItem(Where.eq("company_id", creCompanyLimit.getCompanyId()));
        List<CreCompanyLimit> creLimits = this.getListByEntity(queryLimit, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        if (limit.getCreditLimit() == null || limit.getCreditLimit().compareTo(BigDecimal.ZERO) <= 0) {
            return this.createErrorJsonResonse("金额不能为0");
        }

        //总额度不能超过风险限额
        QueryItem query = QueryItem.builder().field("sum(credit_limit) total").where("company_id", limit.getCompanyId()).build();
        Map totalMap = this.getOneByMap(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        Double total = MapUtils.getDouble(totalMap, "total", 0D) + limit.getCreditLimit().doubleValue();
        if (riskLimit != null && riskLimit > 0 && total.compareTo(riskLimit) > 0) {
            return createErrorJsonResonse("总的额度金额:" + NumberUtils.format(total) + "已超过风险限额");
        }

        DyResponse respLimit = new DyResponse();
        DyResponse resp = new DyResponse();
        limit.setCheckStatus(ScConstants.LIMIT_CHECKING);
        for(CreCompanyLimit companyLimit : creLimits) {
            if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_RECEIVE) {
                bill = (bill == null ? BigDecimal.ZERO : bill);
                companyLimit.setCreditLimit(bill);
                companyLimit.setUnusedLimit(bill);
                resp = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, companyLimit);
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_B2B){
                b2b = (b2b == null ? BigDecimal.ZERO : b2b);
                companyLimit.setCreditLimit(b2b);
                companyLimit.setUnusedLimit(b2b);
                resp = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, companyLimit);
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_WAREHOUSE){
                wh = (wh == null ? BigDecimal.ZERO : wh);
                companyLimit.setCreditLimit(wh);
                companyLimit.setUnusedLimit(wh);
                resp = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, companyLimit);
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_AGPUR){
                agpur = (agpur == null ? BigDecimal.ZERO : agpur);
                companyLimit.setCreditLimit(agpur);
                companyLimit.setUnusedLimit(agpur);
                resp = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, companyLimit);
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_ALL){
                limit.setId(companyLimit.getId());
                // 插入额度汇总
                respLimit = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);
                respLimit.setId(companyLimit.getId());
            }
        }

        String change = "" + bill + ":" + b2b + ":" + wh + ":" +agpur;
        String msg = "额度申请";
        workFlowUtil.startFlowPub(SCFlow.FLOW_LIMIT_ADD, msg, msg, company.getId(), respLimit.getId().toString(), company.getCompanyName(), change);

        return createSuccessJsonResonse(null, "修改成功");
    }

    /**
     * 额度变更
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "changeCredit", method = RequestMethod.GET)
    public ModelAndView changeCredit(Long id) throws Exception {
        CreCompanyLimit limit = this.getById(id, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        List<FormField> formFieldList = new ArrayList<>();
        Company company = this.getById(limit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);

        Map<String, Object> formData = Maps.newHashMap();
        formData.put("companyName", company.getCompanyName());

        QueryItem queryItem = new QueryItem();
        queryItem.setWhere(Where.eq("company_id", limit.getCompanyId()));
        List<CreCompanyLimit> companyLimits = this.getListByEntity(queryItem, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        BigDecimal creditLimit = BigDecimal.ZERO;
        for(CreCompanyLimit companyLimit : companyLimits) {
            if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_RECEIVE) {
                formData.put("bill", companyLimit.getUnusedLimit());
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_B2B){
                formData.put("b2b", companyLimit.getUnusedLimit());
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_WAREHOUSE){
                formData.put("wh", companyLimit.getUnusedLimit());
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_AGPUR){
                formData.put("agpur", companyLimit.getUnusedLimit());
            }
            if(companyLimit.getBusinessTypeId().intValue() != ScConstants.CONTRACT_TYPE_ALL) {
                creditLimit = creditLimit.add(companyLimit.getCreditLimit());
            }
        }
        for(CreCompanyLimit companyLimit : companyLimits) {
            if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_ALL){
                formData.put("creditLimit", creditLimit);
            }
        }
        formData.put("startTime", DateUtil.dateFormat(limit.getStartTime()));
        formData.put("endTime", DateUtil.dateFormat(limit.getEndTime()));
        formData.put("remark", limit.getRemark());
        QueryItem query=QueryItem.builder().where("company_id", limit.getCompanyId()).where("grade_status", GradeStatus.VALID.getIndex()).build();
        CusGradeInfo cusGradeInfo=this.getOneByEntity(query, SCModule.CUSTOMER, SCFunction.CUS_GRADE_INFO,CusGradeInfo.class);
        if(cusGradeInfo != null) {
            formData.put("totalPoint", cusGradeInfo.getTotalPoint());
            formData.put("gradeDate", cusGradeInfo.getGradeDate());
            formData.put("riskLimit", cusGradeInfo.getRiskLimit());
        }

        formFieldList.add(FormField.builder().verify("required").name("creditLimit").text("额度金额").build());
//		formFieldList.add(FormField.builder().name("looped").text("是否循环").type("radio").options("status").build());
        formFieldList.add(FormField.builder().name("remark").text("备注").build());

        Map<String, Object> data = PageUtil.createFormPageStructure("credit/limit/saveChangeCredit?id=" + id, formFieldList, formData);
        return createSuccessModelAndView("credit/limit/change", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "saveChangeCredit", method = RequestMethod.POST)
    public DyResponse saveChangeCredit(CreCompanyLimit limit, BigDecimal bill1, BigDecimal b2b1, BigDecimal wh1, BigDecimal agpur1,
                                     Double riskLimit, Long id, int changeType1, int changeType2, int changeType3, int changeType4) throws Exception {
        CreCompanyLimit creCompanyLimit = this.getById(id, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        Company company = this.getById(creCompanyLimit.getCompanyId(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, Company.class);
        Integer type = company.getBlacklistType();
        if(type != null && type == BlacklistTypeEnum.FORBIDDEN.getIndex()){
            return this.createErrorJsonResonse("该用户属于禁止类用户，不能继续进行操作！");
        }

        if(creCompanyLimit.getCheckStatus() != CheckStatus.CHECK_PASS.getIndex()){
            return createErrorJsonResonse("该状态不可更改");
        }
        QueryItem queryLimit = new QueryItem(Where.eq("company_id", creCompanyLimit.getCompanyId()));
        List<CreCompanyLimit> creLimits = this.getListByEntity(queryLimit, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, CreCompanyLimit.class);
        if (limit.getCreditLimit() == null || limit.getCreditLimit().compareTo(BigDecimal.ZERO) <= 0) {
            return this.createErrorJsonResonse("金额不能为0");
        }

        //总额度不能超过风险限额
        QueryItem query = QueryItem.builder().field("sum(credit_limit) total").where("company_id", limit.getCompanyId()).build();
        Map totalMap = this.getOneByMap(query, SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT);
        Double total = MapUtils.getDouble(totalMap, "total", 0D) + limit.getCreditLimit().doubleValue();
        if (riskLimit != null && riskLimit > 0 && total.compareTo(riskLimit) > 0) {
            return createErrorJsonResonse("总的额度金额:" + NumberUtils.format(total) + "已超过风险限额");
        }

        DyResponse respLimit = new DyResponse();
//        limit.setCheckStatus(ScConstants.LIMIT_CHECKING);
        for(CreCompanyLimit companyLimit : creLimits) {
            if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_RECEIVE) {
                bill1 = (bill1 == null ? BigDecimal.ZERO : bill1);
                if(changeType1 == ScConstants.CREDIT_DECREASE) {
                    companyLimit.setCreditLimit(companyLimit.getCreditLimit().subtract(bill1));
                    companyLimit.setUnusedLimit(companyLimit.getUnusedLimit().subtract(bill1));
                    this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, companyLimit);
                }
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_B2B){
                b2b1 = (b2b1 == null ? BigDecimal.ZERO : b2b1);
                if(changeType2 == ScConstants.CREDIT_DECREASE) {
                    companyLimit.setCreditLimit(companyLimit.getCreditLimit().subtract(b2b1));
                    companyLimit.setUnusedLimit(companyLimit.getUnusedLimit().subtract(b2b1));
                    this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, companyLimit);
                }
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_WAREHOUSE){
                wh1 = (wh1 == null ? BigDecimal.ZERO : wh1);
                if(changeType3 == ScConstants.CREDIT_DECREASE) {
                    companyLimit.setCreditLimit(companyLimit.getCreditLimit().subtract(wh1));
                    companyLimit.setUnusedLimit(companyLimit.getUnusedLimit().subtract(wh1));
                    this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, companyLimit);
                }
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_AGPUR){
                agpur1 = (agpur1 == null ? BigDecimal.ZERO : agpur1);
                if(changeType4 == ScConstants.CREDIT_DECREASE) {
                    companyLimit.setCreditLimit(companyLimit.getCreditLimit().subtract(agpur1));
                    companyLimit.setUnusedLimit(companyLimit.getUnusedLimit().subtract(agpur1));
                    this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, companyLimit);
                }
            }else if(companyLimit.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_ALL){
                limit.setId(companyLimit.getId());
                // 更新额度汇总
                respLimit = this.update(SCModule.CREDIT, SCFunction.CRE_COMPANY_LIMIT, limit);
                respLimit.setId(companyLimit.getId());
            }
        }
        String change = changeType1 + "," + bill1 + ":" + changeType2 + "," + b2b1 + ":" + changeType3 + "," + wh1 + ":" + changeType4 + "," +agpur1;
        String msg = "额度变更";
        workFlowUtil.startFlowPub(SCFlow.FLOW_LIMIT_EDIT, msg, msg, company.getId(), respLimit.getId().toString(), company.getCompanyName(), change);

        return createSuccessJsonResonse(null, "提交成功，额度变更进入审批");
    }
}