package com.dy.sc.admin.controller.customer;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;

@Controller
@RequestMapping("/customer/bankcard/")
public class BankCardController extends AdminBaseController {

    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id","account_name","bank_name_type","area_id","account","create_time"});
        tableHeader.setTexts(new String[]{"ID", "开户名","开户银行","开户所在地","银行卡卡号","添加时间"});
        tableHeader.setTypes(new String[]{"int","", "","","",""});
        tableHeader.setOptionTypes(new String[]{"","", "bank_code","areas","",""});
        
        Tool tool = new Tool();
        tool.setList(buildTools());
        
        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"企业名称"});
        search.setTypes(new String[]{"text"});
        PageStructure data = PageUtil.createTablePageStructure("customer/bankcard/listData", "id", tableHeader,tool,search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
     * 
     * 列表数据
     * @param page
     * @param limit
     * @param search
     * @param type 0-公告管理 1-新闻公告
     * @return
     * @throws Exception
     * @author likf
     */
    @SuppressWarnings({"rawtypes" })
    @ResponseBody
    @RequestMapping(value="listData",method=RequestMethod.POST)
    public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("*");
        if(StringUtils.isNotBlank(search)){
            queryItem.setWhere(Where.in("company_id", this.getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", search)));
        }
        queryItem.setOrders("create_time desc");
        Page<Map> pageData=getPageByMap(queryItem, SCModule.ACCOUNT, SCFunction.ACC_BANK_CARD);
        List<Map> listData=pageData.getItems();
        if(listData!=null&&listData.size()>0){
            this.idToName(listData, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
            dataConvert(listData, null, "create_time");
        }
        return createSuccessJsonResonse(pageData);
    }
    
}
