package com.dy.sc.admin.controller.insidelimit;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

@Controller
@RequestMapping("/insidelimit/applyrecord")
public class InsideLimitApplyRecordController extends AdminBaseController {

    /**
     * 临时额度申请记录
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "list")
    public ModelAndView templimit() throws Exception {

        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "dept_name", "apply_limit", "reason", "pass_limit", "remark", "create_time", "status", "pass_user", "pass_date"});
        tableHeader.setTexts(new String[]{"ID", "用户名", "申请额度", "申请原因", "通过额度", "审核备注", "添加时间", "状态", "审核人员", "审核时间"});
        tableHeader.setTypes(new String[]{"", "", "", "", "", "", "datetime", "", "", "datetime"});
        tableHeader.setOptionTypes(new String[]{"", "", "", "", "", "", "", "flow_status", "", ""});
        tableHeader.setFilters(new String[]{"", "select", "", "", "", "", "", "select", "", "multi_date"});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"dept_name"});
        search.setTexts(new String[]{"部门名称"});
        search.setTypes(new String[]{"text"});

        PageStructure data = PageUtil.createTablePageStructure("insidelimit/applyrecord/listData", "id", tableHeader, tool, search);

        return createSuccessModelAndView("common/table", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取数据:临时额度申请记录
     *
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "listData")
    public DyResponse templimitData(Integer page, Integer limit, String search, String pass_date, String user_id, String status) throws Exception {

        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields("id,dept_id,dept_name,apply_limit,pass_limit,remark,reason,create_time,status,pass_user,pass_date");
        if (StringUtils.isNotBlank(status)) {
            queryItem.setWhere(Where.eq("status", status));
        }
        if (StringUtils.isNotBlank(user_id)) {
            queryItem.setWhere(Where.eq("dept_id", user_id));
        }
        if (StringUtils.isNotBlank(pass_date)) {
            queryItem.setWhere(this.addDateWhereCondition(null, "pass_date", pass_date));
        }
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.in("dept_id", this.getIdsLike(SCModule.SYSTEM, SCFunction.SYS_DEPT, "dept_name", search)));
        }

        queryItem.setOrders("id desc");

        Page<Map> page2 = getPageByMap(queryItem, SCModule.INSIDELIMIT, SCFunction.APPLY_RECORD);
        return createSuccessJsonResonse(dataConvert(page2));
    }


}