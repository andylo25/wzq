package com.dy.sc.admin.controller.content;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.common.SysSystemSitepage;
import com.dy.sc.entity.constant.ScConstants;
import com.google.common.collect.Maps;

/**
 * 导航管理
 */
@Controller
@RequestMapping("content/nav")
public class NavigationController extends AdminBaseController {
	/**
	 * 导航管理列表结构渲染
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="list")
	public ModelAndView getPageInfo() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "name", "router", "type", "status", "sort_index", "is_main_nav", "is_foot_nav"});
		tableHeader.setTexts(new String[]{"ID", "名称", "url", "类别:nav_type", "状态:status", "排序", "是否显示顶部:common_status", "是否显示底部:common_status"});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
//		tool.setUrls(new String[]{"content/nav/addPage", "content/nav/addUrl", "content/nav/addList", "content/nav/addContents", "content/nav/addCategory", "content/nav/editfields", "content/nav/delsubmit"});
		PageStructure data = PageUtil.createTablePageStructure("content/nav/listData", "id", tableHeader,tool, null);
		
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 导航列表
	 * @param current_page
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="listData")
	public DyResponse getPageData (Integer current_page) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setOrders("pid,sort_index");
		queryItem.setFields("id,pid,name,router,type,status,sort_index,recommend,is_main_nav,is_foot_nav");
		List<Map> items = getListByMap(queryItem, Module.SYSTEM, Function.SYS_SITEPAGE);
		
		//树形数据构造
		List<Map> cList = null;
		List<Map> pList = new ArrayList<Map>();
		Map<Object, List> map = new HashMap<Object, List>();
		
		if(items == null) items = new ArrayList<Map>();
		for(int i=0;i<items.size();i++) {
			Map<String, Object> temp = items.get(i);
			Map<String, Object> next = items.get(i>=items.size()-1 ? i : i + 1);
			
			Integer pid = (Integer)temp.get("pid");
			if(pid == 0) {
				pList.add(temp);
				continue;
			}
			
			if(map.get(pid) == null) cList = new ArrayList();
			else cList = (List) map.get(pid);
			if(temp.get("pid").equals(next.get("pid")) && i < items.size() - 1)
				temp.put("name", "　　├" + temp.get("name").toString());
			else
				temp.put("name", "　　└" + temp.get("name").toString());
			cList.add(temp);
			map.put(pid, cList);
		}
		
		List resultList = new ArrayList();
		for(Map temp : pList) {
			resultList.add(temp);
			if(map.get(temp.get("id")) != null)
				resultList.addAll(map.get(temp.get("id")));
		}
		
		Page page = new Page();
		page.setEpage(999);
		page.setPage(1);
		page.setTotal_items(resultList.size());
		page.setItems(resultList);
		
		return createSuccessJsonResonse(page);
	}
	
	/**
	 * 新增功能页
	 */
	@RequestMapping(value="addPage")
	public ModelAndView addPage() throws Exception {
		Map<String,Object> formData = Maps.newHashMap();
		formData.put("type", ScConstants.NAV_TYPE_0);
		Map<String, Object> data = PageUtil.createFormPageStructure("content/nav/save", getPageStructure(ScConstants.NAV_TYPE_0),formData);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 功能页页面结构构造
	 * @return
	 */
	private List<FormField> getPageStructure(int type) {
		List<FormField> formFieldList = new ArrayList<FormField>();
		
		FormField formField = new FormField();
		formField.setName("name");
		formField.setText("名称");
		formField.setVerify("required");
		formField.setNotice("命名功能页的导航名称");
		formFieldList.add(formField);
		
		formField = new FormField();
		formField.setName("description");
		formField.setText("描述");
		formField.setVerify("required");
		formField.setType("textarea");
		formField.setNotice("配置页面关键字");
		formFieldList.add(formField);
		
		formField = new FormField();
		formField.setName("pid");
		formField.setText("上级");
		formField.setVerify("required");
		formField.setType("select");
		formField.setNotice("配置一级功能导航则上级选择“网站”；要是配置二级导航则上级选择对应的一级导航栏目");
		formField.setOptions(DictUtils.getOptions("nav_tree"));
		formFieldList.add(formField);
		
		if(type == ScConstants.NAV_TYPE_0){
			formField = new FormField();
			formField.setName("router");
			formField.setText("功能");
			formField.setVerify("required");
			formField.setType("select");
			formField.setNotice("功能选择对应的功能下拉选项");
			formField.setOptions(DictUtils.getOptions("nav_func"));
			formFieldList.add(formField);
		}else{
			formField = new FormField();
			formField.setName("router");
			formField.setText("地址");
			formField.setVerify("required");
			formField.setNotice("添加要链接的地址");
			formFieldList.add(formField);
		}
		
		formField = new FormField();
		formField.setName("status");
		formField.setVerify("required");
		formField.setNotice("选择'显示'则前台显示该功能页,隐藏则不显示");
		formField.setText("状态");
		formField.setType("radio");
		formField.setOptions(DictUtils.getOptions("status"));
		formFieldList.add(formField);
		
		List<Option> showHideStatus = DictUtils.getOptions("common_status");
		formField = new FormField();
		formField.setName("isMainNav");
		formField.setVerify("required");
		formField.setNotice("选择'显示'则前台显示该功能页,隐藏则不显示");
		formField.setText("是否显示顶部");
		formField.setType("radio");
		formField.setOptions(showHideStatus);
		formFieldList.add(formField);
		
		formField = new FormField();
		formField.setName("isFootNav");
		formField.setVerify("required");
		formField.setNotice("选择'显示'则前台显示该功能页,隐藏则不显示");
		formField.setText("是否显示底部");
		formField.setType("radio");
		formField.setOptions(showHideStatus);
		formFieldList.add(formField);
		
		formField = new FormField();
		formField.setName("sortIndex");
		formField.setNotice("排序表示该功能页在前台显示的位置,排序数值越小则显示的位置越靠前");
		formField.setText("排序");
		formField.setVerify("required,inter");
		formFieldList.add(formField);
		
		formField = new FormField();
		formField.setName("isBlank");
		formField.setVerify("required");
		formField.setNotice("选择'是'则点击该功能页栏目,打开新窗口显示该功能页,'否'则覆盖在原来的页面打开显示");
		formField.setText("是否新页面显示");
		formField.setType("radio");
		formField.setOptions(DictUtils.getOptions("common_status"));
		formFieldList.add(formField);
		
		if(type == ScConstants.NAV_TYPE_3){
//			formField = new FormField();
//			formField.setName("recommend");
//			formField.setVerify("required");
//			formField.setText("首页推荐");
//			formField.setType("radio");
//			formField.setOptions(DictUtils.getOptions("common_status"));
//			formFieldList.add(formField);
		}
		if(type == ScConstants.NAV_TYPE_2){
			formField = new FormField();
			formField.setName("contents");
			formField.setVerify("required");
			formField.setText("发送内容");
			formField.setType("ueditor");
			formFieldList.add(formField);
		}
		
		return formFieldList;
	}

	/**
	 * 新增功能页保存
	 */
	@ResponseBody
	@RequestMapping(value="save", method=RequestMethod.POST)
	public DyResponse save(SysSystemSitepage sitepage) throws Exception {
		//非空校验
		String errorMsg = validate(sitepage, sitepage.getType());
		if(StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
		
		return this.insert(Module.SYSTEM, Function.SYS_SITEPAGE, sitepage);
	}
	
	/**
	 * 新增Url导航
	 */
	@RequestMapping(value="addUrl")
	public ModelAndView addUrl() throws Exception {
		Map<String,Object> formData = Maps.newHashMap();
		formData.put("type", ScConstants.NAV_TYPE_4);
		Map<String, Object> data = PageUtil.createFormPageStructure("content/nav/save", getPageStructure(ScConstants.NAV_TYPE_4),formData);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 新增单页列表
	 */
	@RequestMapping(value="addList")
	public ModelAndView addList() throws Exception {
		Map<String,Object> formData = Maps.newHashMap();
		formData.put("type", ScConstants.NAV_TYPE_1);
		Map<String, Object> data = PageUtil.createFormPageStructure("content/nav/save", getPageStructure(ScConstants.NAV_TYPE_1),formData);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	
	/**
	 * 新增页面
	 */
	@RequestMapping(value="addContents")
	public ModelAndView addContents() throws Exception {
		Map<String,Object> formData = Maps.newHashMap();
		formData.put("type", ScConstants.NAV_TYPE_2);
		Map<String, Object> data = PageUtil.createFormPageStructure("content/nav/save", getPageStructure(ScConstants.NAV_TYPE_2),formData);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 新增文章分类
	 */
	@RequestMapping(value="addCategory")
	public ModelAndView addCategory() throws Exception {
		Map<String,Object> formData = Maps.newHashMap();
		formData.put("type", ScConstants.NAV_TYPE_3);
		Map<String, Object> data = PageUtil.createFormPageStructure("content/nav/save", getPageStructure(ScConstants.NAV_TYPE_3),formData);
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 编辑
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="editfields")
	public ModelAndView editNav(Long id, Long editid) throws Exception {
		SysSystemSitepage formData = this.getById(id, Module.SYSTEM, Function.SYS_SITEPAGE,SysSystemSitepage.class);
		
		//判断类型，显示不同页面
		List<FormField> formFieldList = getPageStructure(formData.getType());
		
		Map<String, Object> data = PageUtil.createFormPageStructure("content/nav/editsubmit", formFieldList,formData);
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 编辑保存
	 */
	@ResponseBody
	@RequestMapping(value="editsubmit", method=RequestMethod.POST)
	public DyResponse editsubmit(SysSystemSitepage sitepage) throws Exception {
		//非空校验
		String errorMsg = validate(sitepage, sitepage.getType());
		if(StringUtils.isNotEmpty(errorMsg)) return createErrorJsonResonse(errorMsg);
		
		return this.update(Module.SYSTEM, Function.SYS_SITEPAGE, sitepage);
	}
	
	/**
	 * (新增/编辑)非空校验
	 * @param map
	 * @return
	 */
	private String validate(Object obj, Integer integer) {
		String[] texts = null;
		String[] columns = null;
		if(integer == ScConstants.NAV_TYPE_0) {
			texts = new String[]{"名称", "描述", "上级", "功能", "状态", "顶部显示", "底部显示", "排序", "是否新页面显示"};
			columns = new String[]{"name", "description", "pid", "router", "status", "isMainNav", "isFootNav", "sortIndex", "isBlank"};
//		} else if(integer == ScConstants.NAV_TYPE_3) {
//			texts = new String[]{"名称", "描述", "上级", "地址", "状态", "顶部显示", "底部显示", "排序", "是否新页面显示", "首页推荐"};
//			columns = new String[]{"name", "description", "pid", "router", "status", "isMainNav", "isFootNav", "sortIndex", "isBlank", "recommend"};
		} else {
			texts = new String[]{"名称", "描述", "上级", "地址", "状态", "顶部显示", "底部显示", "排序", "是否新页面显示"};
			columns = new String[]{"name", "description", "pid", "router", "status", "isMainNav", "isFootNav", "sortIndex", "isBlank"};
		}
		
		return this.validateNull(obj, columns, texts);
	}
	
	/**
	 * 删除
	 */
	@ResponseBody
	@RequestMapping(value="delsubmit", method=RequestMethod.POST)
	public DyResponse delSubmit(Long id) throws Exception {
		List<Map> resultList = getListByMap(new QueryItem(new Where("pid", id)), Module.SYSTEM, Function.SYS_SITEPAGE);
		if(resultList != null && resultList.size() > 0)
			return createErrorJsonResonse("存在子菜单，不可删除");
		
		return this.deleteById(id, Module.SYSTEM, Function.SYS_SITEPAGE);
	}
}