package com.dy.sc.admin.controller.system;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.cz.IPSeeker;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.service.SystemService;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.ia.entity.custom.SitepageTree;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;

/**
 * 登录记录
 */
@Controller
@RequestMapping("/system")
public class LoginLogController extends AdminBaseController {
	
	@Autowired
	SystemService systemService;
	
	/**
	 * 登录记录页面结构渲染
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/admin/loginLog")
	public ModelAndView getAgreementInfo() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "admin_name","add_time","add_ip","addr","status"});
		tableHeader.setTexts(new String[]{"ID", "用户名","登录时间","登录ip","登录地址","登录状态"});
		tableHeader.setFilters(new String[]{"","","multi_date","","",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"memberName"});
		search.setTexts(new String[]{"用户名"});
		search.setTypes(new String[]{"text"});
		
		Map<String, List<Option>> map = new HashMap<String, List<Option>>();
//		map.put("plat", optionUtil.getPlat());
		search.setOptionMap(map);
		PageStructure data = PageUtil.createTablePageStructure("system/loginLog/listdata", "id", tableHeader, tool, search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 登录记录列表数据检索
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="/loginLog/listdata")
	public DyResponse getAgreementPageData(Integer page,Integer limit,String search,String add_time,Integer plat) throws Exception{
		if(plat == null) plat = 2;
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setOrders("add_time desc");
		
		List<Where> whereList = new ArrayList<Where>();
		if(plat == 1){//前台
			addWhereCondition(whereList, "member_name", LIKE_ALL, search);
		}else{
			addWhereCondition(whereList, "admin_name", LIKE_ALL, search);
		}
		if(StringUtils.isNotBlank(add_time)){
			this.addDateWhereCondition(whereList, "add_time",add_time);
		}
		queryItem.setWhere(whereList);
		Page pageObj = null;
		pageObj = (Page) dataConvert(getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_LOGINLOG), "status:login_status", "add_time",null,null,"add_ip");
		List<Map> list = pageObj.getItems();
		if(list != null && list.size() > 0){
			for(Map map : list){
				map.put("member_name", map.get("admin_name"));
				if(StringUtils.isBlank((String)map.get("addr"))){
					map.put("addr", IPSeeker.getInstance().getAddress((String) map.get("add_ip")));
				}
			}
		}
		return createSuccessJsonResonse(pageObj);
	}
	
}