package com.dy.sc.admin.controller.buss;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.RequestUtil;
import com.dy.sc.bussmodule.loan.LoanModule;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.bussmodule.utils.CommonLoanUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.CreditRecordType;
import com.dy.sc.entity.product.ProdProductInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Controller
@RequestMapping("/credit")
public class BussAllRecordController extends AdminBaseController {
	
	@Autowired
	private LoanModule loanModule;
	@Autowired
	CommonBussUtil commonBussUtil;
	/**
	 * 获取所有信贷记录
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/record/{type}")
	public ModelAndView getTypeList(@PathVariable("type") int type) throws Exception {
		TableHeader tableHeader = new TableHeader();
		//if(type==CreditRecordType.ALL.getIndex()){//全部状态格式化与其他不一样
			tableHeader.setNames(new String[]{"id", "company_name","loan_contract_no","pay_bill_type","loan_amount","business_type_id","product_name","contract_start_time","contract_end_time","loan_apr","loan_repay_type","capital_name","status","sales_uid","dept_name","create_time"});
			tableHeader.setTexts(new String[]{"ID","客户名称", "信贷合同号","出账方式","合同金额","业务类型","产品名称","生效日","到期日","利率(%)","还款方式","放款方","状态","客户经理","所属机构","提交时间"});
			tableHeader.setTypes(new String[]{"int","", "","","number","","","date","date","","","","","","","datetime"});
			tableHeader.setFilters(new String[]{"","input", "input","","","select","select","","multi_date","","select","","select","select","","multi_date"});
			tableHeader.setOptionTypes(new String[]{"","", "","pay_bill_type","","business_type","sc_product","","","","loan_repay_type","","sc_credit_record_status","manager","",""});
			
//		}else if(type==CreditRecordType.RECOVERING.getIndex()){//还款中
//		}else if(type==CreditRecordType.RECOVERED.getIndex()){//还完
//		}else{//其他
//		}
//		Tool tool = new Tool();
//		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"信贷编号"});
		search.setTypes(new String[]{"text"});
		
		PageStructure data = PageUtil.createTablePageStructure("credit/record/listData/"+type,"credit/allrecord/view","id", tableHeader,null,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	public static final String TYPE_CREDIT_RECORD="creditRecord";
	
	/**
	 * 信贷记录编辑页
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/toEdit")
	public ModelAndView toEdit(Long id,String type) throws Exception {
		List<FormField> formFieldList = new ArrayList<FormField>();
		
//		formFieldList.add(FormField.builder().name("companyName").text("企业名称").verify("required").build());
//		formFieldList.add(FormField.builder().name("basicPermitNo").text("基本户核准号").verify("required").build());
//		formFieldList.add(FormField.builder().name("generalBank").text("一般户开户行").verify("required").build());
//		formFieldList.add(FormField.builder().name("generalAccount").text("一般户账户").verify("required").build());
//		formFieldList.add(FormField.builder().name("companyLicense").text("统一社会信用代码").verify("required").build());
//		formFieldList.add(FormField.builder().name("companyAddress").text("注册地址").verify("required").build());
//		formFieldList.add(FormField.builder().name("companyWorkAddress").text("办公地址").verify("required").build());
//		formFieldList.add(FormField.builder().name("legalName").text("法人姓名").verify("required").build());
//		formFieldList.add(FormField.builder().name("legalCardType").text("证件类型").verify("required").build());
//		formFieldList.add(FormField.builder().name("legalCardNo").text("证件号码").verify("required").build());
//		formFieldList.add(FormField.builder().name("legalPhoneNumber").text("手机号码").verify("required").build());
//		formFieldList.add(FormField.builder().name("contactName").text("联系人姓名").verify("required").build());
//		formFieldList.add(FormField.builder().name("contactCardType").text("证件类型").verify("required").build());
//		formFieldList.add(FormField.builder().name("contactCardNo").text("证件号码").verify("required").build());
//		formFieldList.add(FormField.builder().name("contactPhoneNumber").text("手机号码").verify("required").build());
//		formFieldList.add(FormField.builder().name("financialName").text("财务姓名").verify("required").build());
//		formFieldList.add(FormField.builder().name("financialCardType").text("证件类型").verify("required").build());
//		formFieldList.add(FormField.builder().name("financialCardNo").text("证件号码").verify("required").build());
//		formFieldList.add(FormField.builder().name("financialPhoneNumber").text("手机号码").verify("required").build());
		
		Map<String, Object> record =this.getById(id, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
		Map<String, Object> company =this.getById(record.get("company_id").toString(), SCModule.SYSTEM, SCFunction.SYS_COMPANY);
		record.put("loan_type", record.get("loan_type").toString());
		record.put("loan_repay_type", record.get("loan_repay_type").toString());
		record.put("loan_fee_type", record.get("loan_fee_type").toString());
		record.put("contract_start_time", DateUtil.dateFormat(record.get("contract_start_time")));
		record.put("contract_end_time", DateUtil.dateFormat(record.get("contract_end_time")));
		//
		Map<String,Object> formdata=Maps.newHashMap();
		formdata.put("record", record);
		formdata.put("company", company);
		formdata.put("loan_type", DictUtils.getOptions("loan_type"));
		formdata.put("repay_type", DictUtils.getOptions("repay_type"));
		formdata.put("loan_fee_type", DictUtils.getOptions("loan_fee_type"));
		formdata.put("cred_type", DictUtils.getOptions("cred_type"));//身份类型
		Map<String, Object> data = PageUtil.createFormPageStructure("credit/update", formFieldList,formdata);
		
		return createSuccessModelAndView("credit/edit", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 信贷记录编辑页
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/update")
	public DyResponse update(HttpServletRequest request) throws Exception {
		Map<String,Object> data = RequestUtil.getRequestMap(request);
		
		Map<String,Object> record=Maps.newHashMap();
		Map<String,Object> company=Maps.newHashMap();
		for(Map.Entry<String, Object> item:data.entrySet()){
			if(item.getKey().startsWith("record[")){
				String key=item.getKey().substring(7,item.getKey().indexOf("]"));
				record.put(key, item.getValue());
			}else if(item.getKey().startsWith("company[")){
				String key=item.getKey().substring(8,item.getKey().indexOf("]"));
				company.put(key, item.getValue());
			}
		}
		
		Long userId=this.getUserId();
		record.put("contract_start_time", DateUtil.convert(DateUtil.dateParse((String)record.get("contract_start_time"))));
		record.put("contract_end_time", DateUtil.convert(DateUtil.dateParse((String)record.get("contract_end_time"))));
		record.put("update_uid", userId);
		record.put("update_time", DateUtil.getCurrentTime());
		
		company.put("update_uid", userId);
		company.put("update_time",  DateUtil.getCurrentTime());
		
		this.update(SCModule.SYSTEM, SCFunction.SYS_COMPANY, company);
		this.update(SCModule.FUND, SCFunction.FUND_CREDIT_RECORD, record);
		return createSuccessJsonResonse(null,"修改成功");
	}  
	
	/**
	 * 获取所有信贷记录数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping("/record/listData/{type}")
	public DyResponse listData(Integer page,Integer limit,String search,Long product_name,
			String loan_contract_no,String company_license,String company_name
			,String loan_repay_type,Long sales_uid,String create_time,String status,String next_repay_time,
			Long product_id,Long business_type_id,String contract_end_time,@PathVariable("type") int type) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		if(type==CreditRecordType.CHECKING.getIndex()){
			queryItem.setWhere(Where.in("status","0,2"));
		}else if(type==CreditRecordType.LENDING.getIndex()){
			queryItem.setWhere(Where.in("status","8,4"));
		}else if(type==CreditRecordType.RECOVERING.getIndex()){
			queryItem.setWhere(Where.eq("status","5"));
		}else if(type==CreditRecordType.RECOVERED.getIndex()){
			queryItem.setWhere(Where.eq("status","6"));
			if(StringUtils.isNotBlank(next_repay_time)){
				queryItem.setWhere(Where.in("id", getIdsFromRepay(next_repay_time, page == null ? 1 : page, limit == null ? 20 : limit)));
			}
		}else if(type==CreditRecordType.NOT_PASS.getIndex()){
			queryItem.setWhere(Where.eq("status","-1"));
		}else if(type==CreditRecordType.FAILURE.getIndex()){
			queryItem.setWhere(Where.eq("status","9"));
		}else{
			List<Integer> notTypes = Lists.newArrayList();
			notTypes.add( AccConstants.CREDIT_RECORD_STATUS_REQUEST_FIRST_TRIAL);
			notTypes.add( AccConstants.CREDIT_RECORD_STATUS_REQUEST_FIRST_TRIAL_REJECT);
			notTypes.add( AccConstants.CREDIT_RECORD_STATUS_REQUEST_FIRST_TRIAL_PASS);
			queryItem.setWhere(Where.notIn("status", notTypes));
		}
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("loan_contract_no", search));
		}//String name,String contract_end_time
		if(product_id!=null){
			ProdProductInfo prodProductInfo = this.getById(product_id, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
			if(prodProductInfo.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_B2B){
				QueryItem query = new QueryItem();
				query.setWhere(Where.eq("business_type_id", ScConstants.CONTRACT_TYPE_B2B));
				List<ProdProductInfo> productInfos = this.getListByEntity(query, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
				List<Long> list = Lists.newArrayList();
				for(ProdProductInfo info : productInfos){
					list.add(info.getId());
				}
				queryItem.setWhere(Where.in("product_id", list));
			}else{
				queryItem.setWhere(Where.eq("product_id",product_id));
			}
        }
		if(product_name != null){
			ProdProductInfo prodProductInfo = this.getById(product_name, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
			List<Object> ids = null;
			if(prodProductInfo.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_B2B){
				ids = this.getIdsEq(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "business_type_id", ScConstants.CONTRACT_TYPE_B2B);
			}else{
				ids = this.getIdsEq(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "name", prodProductInfo.getName());
			}
			if(prodProductInfo != null){
				queryItem.setWhere(Where.in("product_id", ids));
			}
		}
		if(business_type_id != null){
			queryItem.setWhere(Where.eq("business_type", business_type_id));
		}
		if(StringUtils.isNotBlank(contract_end_time)){
		    queryItem.setWhere(this.addDateWhereCondition(null, "contract_end_time", contract_end_time));
		}
		if(StringUtils.isNotBlank(loan_contract_no)){
			queryItem.setWhere(Where.likeAll("loan_contract_no", loan_contract_no));
		}
		if(StringUtils.isNotBlank(company_license)){
			queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_license", company_license)));
		}
		if(StringUtils.isNotBlank(company_name)){
			queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", company_name)));
		}
		if(sales_uid!=null){
			queryItem.setWhere(Where.eq("sales_uid", sales_uid));
		}
		if(StringUtils.isNotBlank(loan_repay_type)){
			queryItem.setWhere(Where.eq("loan_repay_type", loan_repay_type));
		}
		if(StringUtils.isNotBlank(create_time)){
			queryItem.setWhere(this.addDateWhereCondition(null, "create_time",create_time));
		}
		if(StringUtils.isNotBlank(status)){
			queryItem.setWhere(Where.eq("status", status));
		}
		queryItem.setOrders("create_time desc");

		Page recordPage=this.getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
	    List<Map> data=recordPage.getItems();
	    if(data!=null&& data.size()>0){
	    	this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name");
	    	this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "capital_id:company_name as capital_name");
	    	this.idToName(data, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "product_id:business_type_id,name as product_name");
	    	this.idToName(data, SCModule.SYSTEM, SCFunction.SYS_ADMIN, "sales_uid:dept_name");
	    	 for (Map map : data) {
	    			if(type==CreditRecordType.RECOVERING.getIndex()){
		    			String debit_id = map.get("id").toString();
		    			Map<String,Object> repay = getRepayByid(debit_id); 
		    			if(repay!=null){
		    				map.put("amount_total", repay.get("amount_total"));
			    			map.put("expire_time", DateUtil.dateFormat(repay.get("expire_time")));    			
			    			int days=DateUtil.daysBetween(DateUtil.getCurrentDate(),DateUtil.dateParse(Long.valueOf(repay.get("expire_time").toString())));	    			
			    			//逾期
			    			if(days<0){
			    				map.put("status",7); 
			    				map.put("left_days","0天");  
			    			}else{
			    				map.put("left_days",days+"天");  
			    			}
		    			}
	    			}else if(type==CreditRecordType.RECOVERED.getIndex()){
		    			String debit_id = map.get("id").toString();
		    			Map<String,Object> repay = getRepayByid(debit_id); 
	    				map.put("amount_total", repay.get("amount_total"));
		    			map.put("transfer_total", repay.get("transfer_total"));
		    			map.put("interest_yes", repay.get("interest_yes"));
		    			map.put("amount_yes", repay.get("amount_yes"));
		    			map.put("expire_time", DateUtil.dateFormat(repay.get("expire_time")));    
		    			map.put("next_repay_time", repay.get("next_repay_time")); 	    				
	    			}else if(type == CreditRecordType.FAILURE.getIndex()){
	    			}
	    			
	 		}
	    }
	    //recordPage=(Page) dataConvert(recordPage,null,"create_time");
		return createSuccessJsonResonse(recordPage);
	}
	
	/**
	 * 根据companyId查出company
	 * @throws Exception 
	 */
	private Map<String,Object> getCompanyById(String companyId) throws Exception{
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("id", companyId));
		Map<String,Object> company = this.getOneByMap(item, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
		return company;
	}
	
	/**
	 * 根据userid查出user
	 * @throws Exception 
	 */
	private Map<String,Object> getUserByid(String userid) throws Exception{
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("id", userid));
		Map<String,Object> user = this.getOneByMap(item, SCModule.SYSTEM, SCFunction.SYS_ADMIN);
		return user;
	}
	/**
	 * 根据record查进程表
	 * @throws Exception 
	 */
	private List<Map> getFlowByid(Object instId) throws Exception{
		if(instId!=null){
			QueryItem item = new QueryItem();
			item.getWhere().add(Where.eq("proc_inst_id", instId));
			List<Map>commentList= this.getListByMap(item, SCModule.FLOW, SCFunction.FLOW_COMMENT);
			return commentList;
		}
		return null;
	}
	/**
	 * 根据record_id查出请款情况
	 * @throws Exception 
	 */
	private Map<String,Object> getFundLoanrequestByid(String recordId) throws Exception{
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("debit_id", recordId));
		Map<String,Object> loanRequest = this.getOneByMap(item, SCModule.FUND, SCFunction.FUND_LOAN_REQUEST);
		return loanRequest;
	}
	
	private Map<String,Object> getProductInfo(Object productId) throws Exception{
	    QueryItem item = new QueryItem();
	    item.setFields("name as product_name,business_type_name,business_type_id");
        item.getWhere().add(Where.eq("id", productId));
        Map<String,Object> product = this.getOneByMap(item, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO);
        return product;
	}
	
	private Map<String,Object> getLoanRequest(Object id) throws Exception{
        QueryItem item = new QueryItem();
        item.setFields("id,pledge_contract_no,protocol_file,sign_time");
        item.getWhere().add(Where.eq("id", id));
        Map<String,Object> product = this.getOneByMap(item, SCModule.LOAN, SCFunction.LOAN_REQUEST);
        return product;
    }
	
    // @RequestMapping(value="/allrecord/view")
    // public ModelAndView allRecordView(Long id) throws Exception {
    // //信贷记录
    // QueryItem item = new QueryItem();
    // item.getWhere().add(Where.eq("id", id));
    // Map<String,Object> record = this.getOneByMap(item, SCModule.FUND,
    // SCFunction.FUND_CREDIT_RECORD);
    // //业务员
    // Map<String,Object> user=getUserByid(record.get("sales_uid").toString());
    //
    // //请款情况表
    // Map<String,Object>
    // fundLoanRequest=getFundLoanrequestByid(record.get("id").toString());
    //
    // Map<String, Object> result = new HashMap<String, Object>();
    // //放款方
    // record.put("capital_name", BaseInfoUtils.getCompanyName(MapUtils.getLong(
    // record,"capital_id")));
    // record.put("company_name",
    // BaseInfoUtils.getCompanyName(MapUtils.getLong(record, "company_id")));
    //
    // result.put("product", getProductInfo(record.get("product_id")));
    //
    // Integer businessType=MapUtils.getInteger(record, "business_type");
    // if(businessType==ProdBusinessTypeEnum.RECEIVE_BILL.getIndex()||businessType==ProdBusinessTypeEnum.B2B.getIndex()){
    // Map<String,Object> loanRequest= getLoanRequest(record.get("loan_id"));
    // result.put("loanRequest", loanRequest);
    // }else
    // if(businessType==ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex()){
    // Map warehousePledge=this.getById((Serializable)record.get("loan_id"),
    // SCModule.WAREHOUSE,SCFunction.WAREHOUSE_PLEDGE);
    // result.put("warehousePledge", warehousePledge);
    // //不显示借款用途
    // record.remove("loan_usage");
    // }else if(businessType==ProdBusinessTypeEnum.AGENTPUR.getIndex()){
    // record.remove("loan_usage");
    // Map<String,Object> spa=this.getById((Serializable)record.get("loan_id"),
    // SCModule.AGPUR,SCFunction.SPA);
    // result.put("spa", spa);
    // }
    //
    // //审核情况进程表
    // if(record.get("proc_inst_id")!=null){
    // List<Map>checkList=getFlowByid(record.get("proc_inst_id").toString());
    // result.put("checkList", checkList);
    // }
    //
    // //请款情况进程表
    // if(fundLoanRequest!=null){
    // result.put("fundLoanRequest", fundLoanRequest);
    // result.put("requestList",
    // getFlowByid(MapUtils.getLong(fundLoanRequest,"proc_inst_id")));
    // }
    // //计算费用
    // record.put("loan_fee_value_total", RepayUtil.calcShowFeeAmount(record));
    // LoanUtil.setOverdueFee(record);
    //
    // record = (Map<String, Object>)
    // dataConvert(record,"loan_fee_type,loan_repay_type:loan_repay_type,loan_type:loan_type,status:credit_record_status,pay_bill_type,loan_usage",
    // "create_time");
    //
    // // 附件
    // String did = (String) record.get("doc_id");
    // this.getDocuments(result, MapUtils.getString(record, "doc_id"));
    //
    // if(businessType == ScConstants.CONTRACT_TYPE_B2B){
    // getProtocols(result, record.get("id"),businessType);
    // }else if(businessType == ScConstants.CONTRACT_TYPE_WAREHOUSE){
    // getProtocols(result, record.get("loan_id"),
    // ScConstants.PROTO_TYPE_WH_LOAN, null,businessType);
    // }else{
    // getProtocols(result, record.get("loan_id"),businessType);
    // }
    // result.put("record", record);
    // result.put("user", user);
    // result.put("btype", businessType);
    // result.put("showTopBtn", false);
    // getViewMenu(result);
    // ModelAndView view = new ModelAndView("buss/allRecord");
    // view.addObject("data", JsonUtils.object2JsonString(result));
    // return view;
    // }
	
     @RequestMapping(value = { "/allrecord/view" })
     public String AllRecordView(Long id) throws Exception {
	     Map<String, Object> debit = this.getById(id, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD,"id,loan_id,business_type");
	     Integer businessType = MapUtils.getInteger(debit, "business_type");
	     if(businessType  == ScConstants.CONTRACT_TYPE_B2B){
	    	 return "redirect:viewNew/"+businessType+"?id="+id;
	     }
	     return "redirect:viewNew/"+businessType+"?id="+debit.get("loan_id");
     }

	/**
     * 借贷信息
     * 
     * @param id
     * @param type
     *            1应收 2b2b 3仓单 4代采
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/allrecord/viewNew/{type}")
	public ModelAndView AllRecordViewNew(Long id,@PathVariable("type") int bussType,Long flowInstId,Boolean fromTodo) throws Exception {
		Map<String,Object> result =loanModule.allRecordViewNewData(id, bussType, fromTodo, flowInstId);
		result.put("id", id);
		result.put("flowInstId", flowInstId);
		getViewMenu(result);
		
		ModelAndView view = new ModelAndView("buss/allRecord_new");
		view.addObject("data", JsonUtils.object2JsonString(result));
		return view;
	}
	
	
	@ResponseBody
	@RequestMapping(value="/record/documentView")
	public ModelAndView documentView(Long id) throws Exception {
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("id", id));
		Map<String,Object> record = this.getOneByMap(item, SCModule.FUND, SCFunction.FUND_CREDIT_RECORD);
		String did = (String) record.get("doc_id");
		Map<String, Object> result = new HashMap<String, Object>();
		if(StringUtils.isNotBlank(did)){
			QueryItem queryItem = new QueryItem(Where.in("id", did));
			List<Map> list = this.getListByMap(queryItem, SCModule.SYSTEM,SCFunction.SYS_DOCUMENT);
			this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_ADMIN, "create_uid:real_name");
			record.put("documents", list);
		}
		Map<String,Object> user=getUserByid(record.get("sales_uid").toString());
		result.put("user", user);
		result.put("record", record);
		ModelAndView view = new ModelAndView("buss/documents");
		view.addObject("loanContent", JsonUtils.object2JsonNoEscaping(result));
		return view;
	}
	
	/**
	 * 根据回款日期获取回款记录
	 * 
	 * @param value  回款时间段
	 * @param pageNo 第几页
	 * @param limit  页数
	 * @return
	 * @throws Exception
	 */
	private List<Object> getIdsFromRepay(String value,Integer pageNo,Integer limit) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(pageNo);
		queryItem.setLimit(limit); 
		queryItem.setFields("debit_id");
		queryItem.setWhere(this.addDateWhereCondition(null, "next_repay_time", value));
		List<Map> ents = this.getListByMap(queryItem, SCModule.FUND,SCFunction.FUND_LOAN_REPAY);
		List<Object> ids = Lists.newArrayList();
		if(ents != null){
			for(Map s:ents){
				ids.add(s.get("debit_id").toString());
			}
		}
		return ids;
	}
	
	/**
	 * 根据recordId查出repay
	 * @throws Exception 
	 */
	private Map<String,Object> getRepayByid(String debit_id) throws Exception{
		QueryItem item = new QueryItem();
		item.getWhere().add(Where.eq("debit_id", debit_id));
		Map<String,Object> repay = this.getOneByMap(item, SCModule.FUND, SCFunction.FUND_LOAN_REPAY);
		return repay;
	}
	
	/**
	 * 合同列表(电子协议/附件)
	 * @param id
	 * @param bussType
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="protocol/{type}",method=RequestMethod.GET)
    public ModelAndView viewProtocol(Long id,@PathVariable("type")int bussType,Long flowInstId,Boolean fromTodo) throws Exception {
		Map<String,Object> result = Maps.newHashMap();
        Map<String,Object> formData=Maps.newHashMap();
        getProtocols(formData, id, -1, null,bussType);
        CommonLoanUtil.getHeaderByBusiness(formData, id, bussType);
        
        result.put("form_data", formData);
        result.put("id", id);
        result.put("flowInstId", flowInstId);
        
        getViewMenu(result);
        return createSuccessModelAndView("buss/protocol", JsonUtils.object2JsonString(result));
    }
	
	/**
	 * 审核记录
	 * @param id
	 * @param bussType
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="checkList/{type}",method=RequestMethod.GET)
    public ModelAndView checkList(Long id,@PathVariable("type")int bussType,Long flowInstId,Boolean fromTodo) throws Exception {
		Map<String,Object> result = Maps.newHashMap();
        Map<String,Object> formData=Maps.newHashMap();
        formData.put("checkLists",getFlowList(id, bussType));
        
        CommonLoanUtil.getHeaderByBusiness(formData, id, bussType);
        result.put("form_data", formData);
        result.put("id", id);
        result.put("flowInstId", flowInstId);
        getViewMenu(result);
        return createSuccessModelAndView("buss/checkList", JsonUtils.object2JsonString(result));
    }
}