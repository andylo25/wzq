package com.dy.sc.admin.controller.product;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Option;
import com.dy.core.entity.Page;
import com.dy.core.entity.SysDict;
import com.dy.core.entity.form.DetailItem;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.ArrayUtils;
import com.dy.core.utils.Converter;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.DyStringUtils;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.ListUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.RequestUtil;
import com.dy.ia.entity.enumeration.CompanyStatus;
import com.dy.sc.bussmodule.loan.LoanModule;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.bussmodule.utils.CommonBussUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.CommonStatus;
import com.dy.sc.entity.enumeration.CompanyRoleType;
import com.dy.sc.entity.enumeration.DelFlag;
import com.dy.sc.entity.enumeration.LoanFeeType;
import com.dy.sc.entity.enumeration.MortgageType;
import com.dy.sc.entity.enumeration.OverdueRateType;
import com.dy.sc.entity.enumeration.ProdBusinessTypeEnum;
import com.dy.sc.entity.loan.LoanDebitRecord;
import com.dy.sc.entity.loan.LoanRequest;
import com.dy.sc.entity.loan.OverdueRateValue;
import com.dy.sc.entity.product.ProdBusinessType;
import com.dy.sc.entity.product.ProdFeeValue;
import com.dy.sc.entity.product.ProdProductB2B;
import com.dy.sc.entity.product.ProdProductInfo;
import com.dy.sc.entity.product.ProdProductWarehouse;
import com.dy.sc.entity.product.ProdTemplate;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * @author likaijun@diyou.cn
 * @version v1.0
 *          <p>
 *          <pre>
 *          修改人                修改时间        版本        修改内容
 *          ---------------------------------------------------------
 *          likaijun
 *                   </pre>
 * @ClassName: ProductController.java 产品模块 Controller Copyright (c) 2015
 * 厦门帝网信息科技
 * @date 2017年7月4日上午10:38:20
 */
@Controller
@RequestMapping("/prod/product/")
public class ProductController extends AdminBaseController {
    @Autowired
    CommonBussUtil commonBussUtil;
    @Autowired
    LoanModule loanModule;
    /**
     * 获取所有产品记录
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
        TableHeader tableHeader = new TableHeader();
        tableHeader.setNames(new String[]{"id", "businessType", "loan_amount", "mortgage_time",
                "repayType", "status"});
        tableHeader.setTexts(new String[]{"产品名称", "业务类型", "借款金额", "借款期限", "还款方式", "状态"});
        tableHeader.setTypes(new String[]{"", "", "", "", "", "", ""});

        tableHeader.setOptionTypes(new String[]{"sc_product", "", "", "", "", "status"});
        tableHeader.setFilters(new String[]{"select", "", "", "", "", "select"});

        Tool tool = new Tool();
        tool.setList(buildTools());

        Search search = new Search();
        search.setNames(new String[]{"search"});
        search.setTexts(new String[]{"产品名称"});
        search.setTypes(new String[]{"text"});

        PageStructure data = PageUtil.createTablePageStructure("prod/product/listData", "prod/product/viewDetail", "id", tableHeader, tool,
                search);
        return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }

    /**
     * 获取所有产品记录数据
     *
     * @param page
     * @param limit
     * @param search
     * @param name        产品名称
     * @param productType 业务类型
     * @param repayType   还款方式
     * @param status      状态
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping("listData")
    public DyResponse listData(Integer page, Integer limit, String search, Long id, String repayType, String status)
            throws Exception {
        QueryItem queryItem = new QueryItem();
        queryItem.setPage(page == null ? 1 : page);
        queryItem.setLimit(limit == null ? 20 : limit);
        queryItem.setFields(
                " id, business_type_id, name, loan_amount_start, loan_amount_end, mortgage_type, mortgage_time_start, mortgage_time_end, delay_day_start, delay_day_end, repay_type_id, status ");
        if (StringUtils.isNotBlank(search)) {
            queryItem.setWhere(Where.likeAll("name", search));
        }
        if (id != null) {
            queryItem.setWhere(Where.eq("id", id));
        }
        // if(StringUtils.isNotBlank(productType)){
        // queryItem.setWhere(Where.eq("product_type", productType));
        // }
        if (StringUtils.isNotBlank(status)) {
            queryItem.setWhere(Where.eq("status", status));
        }
        queryItem.setWhere(Where.eq("del_flag", 0));
        queryItem.setOrders(" create_time desc");
        Page recordPage = this.getPageByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO);
        List<Map> data = recordPage.getItems();
        if (data != null && data.size() > 0) {
            this.idToName(data, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE,
                    "business_type_id:name as businessType");
            List<Integer> repayIds = Lists.newArrayList();
            // this.idToName(data, SCModule.FUND, SCFunction.FUND_REPAYTYPE,
            // "repay_type_id:name as repayType");
            for (Map map : data) {
                // 质押类型
                String mortgageType = map.get("mortgage_type").toString();
                // 融资金额

                String loanAmountStart = map.get("loan_amount_start") != null
                        ? NumberUtils.format((BigDecimal) map.get("loan_amount_start")) : "0.00";
                String loanAmountEnd = map.get("loan_amount_end") != null
                        ? NumberUtils.format((BigDecimal) map.get("loan_amount_end")) : "0.00";
                // 质押期限
                String mortgageTimeStart = map.get("mortgage_time_start") != null
                        ? map.get("mortgage_time_start").toString() : "0";
                String mortgageTimeEnd = map.get("mortgage_time_end") != null ? map.get("mortgage_time_end").toString()
                        : "0";
//				// 宽限期
//				String delayDayStart = map.get("delay_day_start") != null ? map.get("delay_day_start").toString() : "0";
//				String delayDayEnd = map.get("delay_day_end") != null ? map.get("delay_day_end").toString() : "0";
                // 还款方式ID，逗号分割
                String repayTypeId = map.get("repay_type_id") != null ? map.get("repay_type_id").toString() : null;
                // 期限单位
                String unit = "个月";
                if (StringUtils.isNotBlank(mortgageType)) {
                    if (MortgageType.DAY.getIndex() == Integer.parseInt(mortgageType)) {// 按天
                        unit = "天";
                    }
                }
                if (StringUtils.isBlank(loanAmountStart)) {
                    loanAmountStart = "0.00";
                }
                if (StringUtils.isBlank(loanAmountEnd)) {
                    loanAmountEnd = "0.00";
                }
                if (StringUtils.isBlank(mortgageTimeStart)) {
                    mortgageTimeStart = "0";
                }
                if (StringUtils.isBlank(mortgageTimeEnd)) {
                    mortgageTimeEnd = "0";
                }
//				if (StringUtils.isBlank(delayDayStart)) {
//					delayDayStart = "0";
//				}
//				if (StringUtils.isBlank(delayDayEnd)) {
//					delayDayEnd = "0";
//				}

                if (StringUtils.isNotBlank(repayTypeId)) {
                    String[] repayTypeIds = repayTypeId.split(",");
                    for (String ryId : repayTypeIds) {
                        Integer rt = Integer.parseInt(ryId);
                        if (!repayIds.contains(rt)) {
                            repayIds.add(rt);
                        }
                    }
                }
                map.put("loan_amount", loanAmountStart + "-" + loanAmountEnd + "元");
                map.put("mortgage_time", mortgageTimeStart + "-" + mortgageTimeEnd + unit);
//				map.put("delay_day", delayDayStart + "-" + delayDayEnd + "天");
                // map.put("repay_type", repayTypeStr);

            }
            // 还款方式id是逗号分割的，列表结果要、号隔开，idToName不支持，另外处理
            QueryItem repayTypeQuery = new QueryItem();
            repayTypeQuery.getWhere().add(Where.in("id", repayIds));
            // repayTypeQuery.getWhere().add(Where.eq("del_flag", 0));
            repayTypeQuery.setFields(" id, name ");
            List<Map> types = this.getListByMap(repayTypeQuery, SCModule.FUND, SCFunction.FUND_REPAYTYPE);
            for (Map map : data) {
                String repayTypeId = map.get("repay_type_id") != null ? map.get("repay_type_id").toString() : null;
                // 还款方式
                String repayTypeStr = "";
                if (StringUtils.isNotBlank(repayTypeId)) {
                    String[] repayTypeIds = repayTypeId.split(",");
                    for (String ryId : repayTypeIds) {
                        Integer rt = Integer.parseInt(ryId);
                        for (Map<String, Object> type : types) {
                            if (Integer.parseInt(type.get("id").toString()) == rt) {
                                repayTypeStr += type.get("name").toString() + "、";
                            }
                        }
                    }
                    // 去掉最后一个"、"
                    if (StringUtils.isNotBlank(repayTypeStr)) {
                        repayTypeStr = repayTypeStr.substring(0, repayTypeStr.length() - 1);
                    }
                }
                map.put("repayType", repayTypeStr);
            }
        }
        return createSuccessJsonResonse(recordPage);
    }

    /**
     * 根据id获取还款方式
     *
     * @param repayTypeId
     * @return
     * @throws Exception
     */
    private Map<String, Object> getRepayTypeById(Long repayTypeId) throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("id", repayTypeId));
        item.setFields(" id, name, contents, status ");
        Map<String, Object> repayType = this.getOneByMap(item, SCModule.FUND, SCFunction.FUND_REPAYTYPE);
        return repayType;
    }

    /**
     * 还款方式复选框
     *
     * @return
     * @throws Exception
     */
    private List<Map> getRepayTypes(int type) throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("status", 1));
        item.getWhere().add(Where.eq("business_type", type));
        item.setFields(" id as value, name as text");
        List<Map> repayTypes = this.getListByMap(item, SCModule.FUND, SCFunction.FUND_REPAYTYPE);
        return repayTypes;
    }

    /**
     * 核心企业复选框
     *
     * @return
     * @throws Exception
     */
    private List<Map> getCoreCompanys() throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("company_role_type", CompanyRoleType.COMPANY_CORE.getIndex()));
        item.getWhere().add(Where.eq("del_flag", 0));
        item.setFields(" id as value, company_name as text");
        List<Map> comps = this.getListByMap(item, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        return comps;
    }

    /**
     * 根据id获取业务类型
     *
     * @param businessTypeId
     * @return
     * @throws Exception
     */
    private Map<String, Object> getBusinessTypeById(Long businessTypeId) throws Exception {
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("id", businessTypeId));
        item.setFields(" id, name, code ");
        Map<String, Object> businessType = this.getOneByMap(item, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        return businessType;
    }

    /**
     * 业务类型下拉
     *
     * @return
     * @throws Exception
     */
    private List<Map> getBusinessTypes() throws Exception {
        QueryItem item = new QueryItem();
        item.setFields(" id, name, code ");
        List<Map> businessTypes = this.getListByMap(item, SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE);
        return businessTypes;
    }

    /**
     * 添加产品
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "add")
    public ModelAndView add() throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        Map<String, Object> formdata = Maps.newHashMap();
        List<ProdFeeValue> feeValues = Lists.newArrayList();
        feeValues.add(new ProdFeeValue());
        formdata.put("feeValues", feeValues);
        formdata.put("businessTypeId", ScConstants.CONTRACT_TYPE_RECEIVE);
        formdata.put("autoReqFlag", ScConstants.BOOL_FLAG_NO);
        formdata.put("useCreditLimit", ScConstants.BOOL_FLAG_NO);
        formdata.put("mortgageType", MortgageType.DAY.getIndex());
        formdata.put("warehouseInterestMode", 0);
        formdata.put("status", 1);
        formdata.put("dataChannel", 0);
        formdata.put("depositType", 0);
        formdata.put("overdueRateType", OverdueRateType.PRINCIPAL.getIndex());
        formdata.put("overdueType", OverdueRateType.PRINCIPAL.getIndex());
        formdata.put("overdueStatus", 1);
        formdata.put("overdueFeeStatus", 1);
        formdata.put("loanFeeStatus", 1);
        formdata.put("loanFeeType", 2);
        formdata.put("interestModeType", 0);
        formdata.put("interestPenaltyStatus", 0);

        Map<String, Object> data = PageUtil.createFormPageStructure("prod/product/save", formFieldList, formdata);
        data.putAll(getProductFromData());
        return createSuccessModelAndView("product/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 界面上的下拉、单选、字典值
     *
     * @return
     * @throws Exception
     */
    private Map<String, Object> getProductFromData() throws Exception {
        Map<String, Object> formdata = Maps.newHashMap();
        List<Map> repayTypes = getRepayTypes(ScConstants.CONTRACT_TYPE_RECEIVE);
        List<Map> repayTypesAG = getRepayTypes(ScConstants.CONTRACT_TYPE_AGPUR);
        List<Map> repayTypesB2B = getRepayTypes(ScConstants.CONTRACT_TYPE_B2B);
        List<Map> businessTypes = getBusinessTypes();
        // 业务类型
        formdata.put("businessTypes", businessTypes);
        // 状态
        formdata.put("statusList", DictUtils.getOptionsInt("status"));
        formdata.put("interest_mode_type", DictUtils.getOptionsInt("interest_mode_type"));
        formdata.put("order_status", DictUtils.getOptionsInt("order_status"));
        // 是否
        formdata.put("common_status", DictUtils.getOptionsInt("common_status"));
        formdata.put("data_channel", DictUtils.getOptionsInt("data_channel"));
        // 还款方式
        formdata.put("repayTypes", repayTypes);
        formdata.put("repayTypesAG", repayTypesAG);
        formdata.put("repayTypesB2B", repayTypesB2B);
        // 质押期限类型
        formdata.put("mortgage_type", DictUtils.getOptionsInt("mortgage_type"));
        // formdata.put("services_fee_type",
        // DictUtils.getOptions("services_fee_type"));
        // formdata.put("overdue_type", DictUtils.getOptions("overdue_type"));
        // 按比例类型
        formdata.put("overdue_rate_type", DictUtils.getOptionsInt("overdue_rate_type"));
        formdata.put("warehouse_interest_mode", DictUtils.getOptionsInt("warehouse_interest_mode"));

        formdata.put("companys", getCompanys());
        formdata.put("coreCompanys", getCoreCompanys());
        
        formdata.put("prod_fee_item", DictUtils.getDictList("prod_fee_item"));
        return formdata;
    }

    /**
     * 校验产品名称是否已经存在
     *
     * @param name
     * @param id
     * @return
     * @throws Exception
     */
    private boolean isPorductExists(String name, Long id) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields(" count(1) as count ");
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "name", name);
        this.addWhereCondition(where, "del_flag", 0);
        query.setWhere(where);
        // 编辑时，排除当前数据
        if (id != null) {
            query.getWhere().add(Where.notEq("id", id));
        }
        Map<String, Object> result = this.getOneByMap(query, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO);
        if (result != null && result.size() > 0 && Integer.parseInt(result.get("count").toString()) > 0) {
            return true;
        }
        return false;
    }

    /**
     * 保存新增产品
     *
     * @param product
     * @param repayTypeIds
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "save")
    public DyResponse save(HttpServletRequest request, ProdProductInfo product, ProdProductB2B b2b,
                           BigDecimal loanFixedValue, Integer overdueFeeStatus, @RequestParam(value = "repayTypeIds[]",
            required = false) String[] repayTypeIds, String coreIds, @RequestParam("feeValues") String feeValues) throws Exception {
        if (isPorductExists(product.getName(), null)) {
            return createErrorJsonResonse("产品名称已存在，不能新增，请重新输入！");
        }
        if (repayTypeIds == null || repayTypeIds.length <= 0) {
            return createErrorJsonResonse("请至少选择一种还款方式！");
        }
        if (ScConstants.CONTRACT_TYPE_RECEIVE == product.getBusinessTypeId() && StringUtils.isBlank(coreIds)) {// 应收账款
            return createErrorJsonResonse("请至少选择一个核心企业！");
        }
        product.setStatus("1");
        QueryItem query = new QueryItem(Where.eq("business_type_id", ScConstants.CONTRACT_TYPE_B2B));
        query.getWhere().add(Where.eq("del_flag", DelFlag.NOT_DELETE.getIndex()));
        ProdProductInfo pro = this.getOneByEntity(query, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO,
                ProdProductInfo.class);
        if (product.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_B2B && pro != null) {
            return createErrorJsonResonse("B2B产品已添加，不能再添加！");
        }

        // 设置相关属性
        buildProd(product, loanFixedValue, overdueFeeStatus, repayTypeIds, coreIds);

        // 获取最大利率
        BigDecimal maxLoanApr = null;
        List<ProdFeeValue> items = null;
        if (product.getBusinessTypeId() != ScConstants.CONTRACT_TYPE_AGPUR) {
            items = JsonUtils.jsonToList(feeValues, ProdFeeValue[].class);
            maxLoanApr = BigDecimal.ZERO;
            if (CollectionUtils.isNotEmpty(items)) {
                for (ProdFeeValue item : items) {
                    if (NumberUtils.greaterThan(item.getLoanApr(), maxLoanApr)) {
                        maxLoanApr = item.getLoanApr();
                    }
                }
            }
        }
        if (maxLoanApr != null) {
            product.setLoanAprStart(maxLoanApr);
        }

        DyResponse response = this.insert(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);
        product.setRootVersion(response.getId());
        this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);
        if (product.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_B2B) {
            b2b.setProductId(response.getId());
            this.insert(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B, b2b);
        } else if (product.getBusinessTypeId() == ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex()) {
            insertProdProductWarehouse(request, response.getId());
        }

        // 保存产品前台显示
        if (items != null && items.size() > 0) {
            for (ProdFeeValue prodFeeValue : items) {
                prodFeeValue.setProductId(product.getId());
                if (prodFeeValue.getLoanFeeValue() != null) {
                    if (product.getLoanFeeType() == LoanFeeType.SCALE.getIndex()) {
                        prodFeeValue
                                .setLoanFeeValue(NumberUtils.div(prodFeeValue.getLoanFeeValue(), new BigDecimal(100)));
                    }
                }
                if (prodFeeValue.getLoanApr() != null) {
                    prodFeeValue.setLoanApr(NumberUtils.div(prodFeeValue.getLoanApr(), new BigDecimal(100)));
                }
                prodFeeValue.setProductId(product.getId());
                this.insert(SCModule.PRODUCT, SCFunction.PROD_FEE_VALUE, prodFeeValue);
            }
        }

        return createSuccessJsonResonse(null, "添加成功！");
    }

    /**
     * 插入产品-仓单
     *
     * @param request
     * @param productId
     * @throws Exception
     * @author likf
     */
    private void insertProdProductWarehouse(HttpServletRequest request, Long productId) throws Exception {
        Long loanDayStart = RequestUtil.getLong(request, "loanDayStart");
        Long loanDayEnd = RequestUtil.getLong(request, "loanDayEnd");
        String interestPenaltyRate = RequestUtil.getString(request, "interestPenaltyRate");
        Integer interestPenaltyStatus = RequestUtil.getInteger(request, "interestPenaltyStatus");
        ProdProductWarehouse productWarehouse = new ProdProductWarehouse();
        if (StringUtils.isNotBlank(interestPenaltyRate)) {
            productWarehouse.setInterestPenaltyRate(new BigDecimal(interestPenaltyRate));
        }
        productWarehouse.setInterestPenaltyStatus(interestPenaltyStatus);
        if (loanDayStart != null) {
            productWarehouse.setLoanDayStart(loanDayStart);
        }
        if (loanDayEnd != null) {
            productWarehouse.setLoanDayEnd(loanDayEnd);
        }
        productWarehouse.setProductId(productId);
        productWarehouse.setWarehouseInterestMode(RequestUtil.getInteger(request, "warehouseInterestMode"));
        this.insert(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_WAREHOUSE, productWarehouse);
    }

    /**
     * 编辑产品
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "edit")
    public ModelAndView edit(Long id) throws Exception {
        List<FormField> formFieldList = new ArrayList<FormField>();
        Map<String, Object> formdata = Maps.newHashMap();
        QueryItem item = new QueryItem();
        item.getWhere().add(Where.eq("id", id));
        ProdProductInfo product = this.getOneByEntity(item, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO,
                ProdProductInfo.class);
        product.setFlowConf(null);
        Map<String, Object> productMap = (Map<String, Object>) new DataConvertUtil(product, false).convert();
        formdata.putAll(productMap);
        formdata.put("id", product.getId());
        // 服务费处理
        if (product.getLoanFeeType() == LoanFeeType.FIXED.getIndex()) {
            formdata.put("loanFixedValue", product.getLoanFeeValue());
            formdata.put("loanFeeValue", null);
        } else {
            formdata.put("loanFeeValue", NumberUtils.mul(product.getLoanFeeValue(), new BigDecimal(100)));
        }
        // 年利率处理
        if (product.getLoanAprStart() != null) {
            formdata.put("loanAprStart", product.getLoanAprStart());
        }
        if (product.getLoanAprEnd() != null) {
            formdata.put("loanAprEnd", product.getLoanAprEnd());
        }
        // 最高融资比例
        if (product.getMaxFinanceRate() != null) {
            formdata.put("maxFinanceRate", NumberUtils.mul(product.getMaxFinanceRate(), new BigDecimal(100)));
        }
        // 逾期扣费比例
        // if (product.getOverdueRateValue() != null) {
        // formdata.put("overdueRateValue",
        // NumberUtils.mul(product.getOverdueRateValue(), new BigDecimal(100)));
        // }
        // 逾期服务费
        if (product.getOverdueType() == 0) {
            formdata.put("overdueFeeStatus", 0);
        } else {
            formdata.put("overdueFeeStatus", 1);
        }
        List<SysDict> feeDict = DictUtils.getDictList("prod_fee_item");
        formdata.put("prod_fee_item", feeDict);
        formdata.put("fees", loanModule.getFormFees(product.getProdFeeId()));

        // 还款方式
        if (StringUtils.isNotBlank(product.getRepayTypeId())) {
            if (product.getBusinessTypeId() == 1) {
                formdata.put("repayTypeIds", product.getRepayTypeId());
            } else {
                String[] repayTypeIds = product.getRepayTypeId().split(",");
                int[] intValues = new int[repayTypeIds.length];
                for (int i = 0; i < repayTypeIds.length; i++) {
                    intValues[i] = Integer.parseInt(repayTypeIds[i]);
                }
                formdata.put("repayTypeIds", intValues);
            }
        }
        // 核心企业
        if (StringUtils.isNotBlank(product.getCoreCompanyIds())) {
            String[] ids = product.getCoreCompanyIds().split(",");
            long[] values = new long[ids.length];
            for (int i = 0; i < ids.length; i++) {
                values[i] = Long.parseLong(ids[i]);
            }
            formdata.put("coreIds", ids[0]);
        }
        // 前台显示
        QueryItem feeQuery = new QueryItem();
        feeQuery.setFields("id,loan_day,loan_apr,loan_fee_value");
        feeQuery.getWhere().add(Where.eq("product_id", id));
        feeQuery.getWhere().add(Where.eq("del_flag", 0));
        List<ProdFeeValue> feeValues = this.getListByEntity(feeQuery, SCModule.PRODUCT, SCFunction.PROD_FEE_VALUE,
                ProdFeeValue.class);
        if (feeValues != null && feeValues.size() > 0) {
            for (ProdFeeValue pfv : feeValues) {
                if (pfv.getLoanFeeValue() != null) {
                    if (product.getLoanFeeType() == LoanFeeType.SCALE.getIndex()) {
                        pfv.setLoanFeeValue(NumberUtils.mul(pfv.getLoanFeeValue(), new BigDecimal(100)));
                    }
                }
                if (pfv.getLoanApr() != null) {
                    pfv.setLoanApr(NumberUtils.mul(pfv.getLoanApr(), new BigDecimal(100)));
                }
            }
            formdata.put("feeValues", feeValues);
        } else {
            feeValues = Lists.newArrayList();
            feeValues.add(new ProdFeeValue());
            formdata.put("feeValues", feeValues);
        }
        if (product.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_B2B) {
            QueryItem query = new QueryItem();
            query.getWhere().add(Where.eq("product_id", id));
            ProdProductB2B b = this.getOneByEntity(query, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B,
                    ProdProductB2B.class);
            if (b != null) {
                Map<String, Object> b2bMap = (Map<String, Object>) new DataConvertUtil(b, false).convert();
                b2bMap.put("settleMonthType", b2bMap.get("settleMonthType").toString());
                b2bMap.put("checkMonthType", b2bMap.get("checkMonthType").toString());
                b2bMap.put("tradeEndType", b2bMap.get("tradeEndType").toString());
                b2bMap.put("tradeStartType", b2bMap.get("tradeStartType").toString());
                formdata.putAll(b2bMap);
                formdata.put("id", product.getId());
                formdata.put("interestPenaltyStatus", String.valueOf(formdata.get("interestPenaltyStatus")));
            }
        } else if (product.getBusinessTypeId() == ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex()) {
            QueryItem query = new QueryItem();
            query.getWhere().add(Where.eq("product_id", id));
            query.setWhere(Where.eq("del_flag", 0));
            ProdProductWarehouse productWarehouse = this.getOneByEntity(query, SCModule.PRODUCT,
                    SCFunction.PROD_PRODUCT_WAREHOUSE, ProdProductWarehouse.class);
            if (productWarehouse != null) {
                Map<String, Object> tempMap = (Map<String, Object>) new DataConvertUtil(productWarehouse, false).convert();
                tempMap.remove("id");
                formdata.putAll(tempMap);
            }
        }
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/product/update", formFieldList, formdata);
        data.putAll(getProductFromData());
        return createSuccessModelAndView("product/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 更新产品
     *
     * @param product
     * @param repayTypeIds
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "update")
    public DyResponse update(HttpServletRequest request, ProdProductInfo product, ProdProductB2B b2b,
                             BigDecimal loanFixedValue, Integer overdueFeeStatus, @RequestParam(value = "repayTypeIds[]", required = false) String[] repayTypeIds,
                             String coreIds, @RequestParam("feeValues") String feeValues) throws Exception {
        if (isPorductExists(product.getName(), product.getId())) {
            return createErrorJsonResonse("产品名称已存在，不能更新，请重新输入！");
        }
        if ((b2b.getInterestPenaltyDay() != null || b2b.getInterestPenaltyStartRate()!=null||b2b.getInterestPenaltyEndRate()!=null)) {
            if ((b2b.getInterestPenaltyDay() == null || b2b.getInterestPenaltyStartRate() == null
                    || b2b.getInterestPenaltyEndRate() == null)) {
                return createErrorJsonResonse("提前还款罚息数据不完整！");
            }else{
                b2b.setInterestPenaltyStatus(CommonStatus.TRUE.getIndex());
            }
        }
        //如果提前还款罚息有填,校验
        if (repayTypeIds == null || repayTypeIds.length <= 0) {
            return createErrorJsonResonse("请至少选择一种还款方式！");
        }
        List<ProdFeeValue> items = JsonUtils.jsonToList(feeValues, ProdFeeValue[].class);
        if (ScConstants.CONTRACT_TYPE_RECEIVE == product.getBusinessTypeId()) {
            if (StringUtils.isBlank(coreIds)) {
                return createErrorJsonResonse("请至少选择一个核心企业！");
            }

            if (CollectionUtils.isEmpty(items)) {
                return createErrorJsonResonse("请至少填写一项年利率及服务费！");
            }
        }
        QueryItem qItem = new QueryItem();
        qItem.setWhere(Where.eq("product_id", product.getId()));
        qItem.setFields("id");
        qItem.setLimit(1);
        List<LoanDebitRecord> requests = this.getListByEntity(qItem, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD,
                LoanDebitRecord.class);
        boolean used = false;
        if (requests != null && requests.size() > 0) {// 没被引用过则直接更新，不生成新版本
            used = true;
        }

        Long newProductId = 0L;
        ProdProductInfo productOld = null;
        // if(product.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_B2B){
        productOld = this.getById(product.getId(), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO,
                ProdProductInfo.class);

        if (used) {
            // 保留历史版本
            // productOld.setDelFlag(1);
            Long oldP = productOld.getId();
            product.setRootVersion(productOld.getRootVersion());
            // 插入新产品
            this.insert(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, productOld);
            newProductId = productOld.getId();

            // 老版本不动,标志为删除
            productOld.setDelFlag(1);
            productOld.setId(oldP);
            this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, productOld);
        }
        // }
        // 设置相关属性
        buildProd(product, loanFixedValue, overdueFeeStatus, repayTypeIds, coreIds);

        if (used) {
            product.setId(newProductId);
        }
        this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);

        if (product.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_B2B) {
            QueryItem query = new QueryItem(Where.eq("product_id", productOld.getId()));
            // query.setFields("id");
            ProdProductB2B b = this.getOneByEntity(query, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B,
                    ProdProductB2B.class);
            Long b2bOld = b.getId();
            if (b != null && used) {
                // 插入新版本
                // b.setProductId(newProductId);
                this.insert(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B, b);

                // 更新新版本
                b2b.setId(b.getId());
                b2b.setProductId(newProductId);
                this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B, b2b);
                // 老版本备份
                b.setDelFlag(1);
                b.setId(b2bOld);
                this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B, b);

                QueryItem qitem = new QueryItem(Where.eq("business_type", ScConstants.CONTRACT_TYPE_B2B));
                List<LoanRequest> reqs = this.getListByEntity(qitem, SCModule.LOAN, SCFunction.LOAN_REQUEST,
                        LoanRequest.class);
                for (LoanRequest req : reqs) {
                    req.setProductId(newProductId);
                    this.update(SCModule.LOAN, SCFunction.LOAN_REQUEST, req);
                }
            }
            if (!used) {// 没被引用直接更新
                b2b.setId(b.getId());
                this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B, b2b);
                this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);
            }
        } else if (product.getBusinessTypeId() == ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex()) {
            QueryItem query = new QueryItem(Where.eq("product_id", productOld.getId()));
            query.setWhere(Where.eq("del_flag", 0));
            ProdProductWarehouse prodProductWarehouseOld = this.getOneByEntity(query, SCModule.PRODUCT,
                    SCFunction.PROD_PRODUCT_WAREHOUSE, ProdProductWarehouse.class);
            if (used) {
                // 老版本备份
                ProdProductWarehouse updateObj = new ProdProductWarehouse();
                updateObj.setDelFlag(1);
                updateObj.setId(prodProductWarehouseOld.getId());
                this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_WAREHOUSE, updateObj);
                // 插入新版本
                insertProdProductWarehouse(request, newProductId);
            } else {
                Long loanDayStart = RequestUtil.getLong(request, "loanDayStart");
                Long loanDayEnd = RequestUtil.getLong(request, "loanDayEnd");
                String interestPenaltyRate = RequestUtil.getString(request, "interestPenaltyRate");
                Integer interestPenaltyStatus = RequestUtil.getInteger(request, "interestPenaltyStatus");
                ProdProductWarehouse productWarehouse = new ProdProductWarehouse();
                if (StringUtils.isNotBlank(interestPenaltyRate)) {
                    productWarehouse.setInterestPenaltyRate(new BigDecimal(interestPenaltyRate));
                }
                productWarehouse.setInterestPenaltyStatus(interestPenaltyStatus);
                if (loanDayStart != null) {
                    productWarehouse.setLoanDayStart(loanDayStart);
                }
                if (loanDayEnd != null) {
                    productWarehouse.setLoanDayEnd(loanDayEnd);
                }
                productWarehouse.setId(prodProductWarehouseOld.getId());
                productWarehouse.setProductId(productOld.getId());
                productWarehouse.setWarehouseInterestMode(RequestUtil.getInteger(request, "warehouseInterestMode"));
                this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_WAREHOUSE, productWarehouse);
                this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);
            }
        } else {
            if (used) {
                product.setId(newProductId);
            } else {
                product.setId(productOld.getId());
            }
            product.setLoanAprStart(items.get(0).getLoanApr());
            product.setLoanAprEnd(items.get(items.size() - 1).getLoanApr());
            this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);
        }
        Long pid = productOld.getId();

        if ((product.getBusinessTypeId() == ScConstants.CONTRACT_TYPE_RECEIVE
                || product.getBusinessTypeId() == ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex())) {
            // 将原来的费用记录全部删除，重新保存
            deleteFeeValuesByProductId(pid);
            if (CollectionUtils.isNotEmpty(items)) {
                for (ProdFeeValue item : items) {
                    if (used) {
                        item.setProductId(newProductId);
                    } else {
                        item.setProductId(pid);
                    }
                    if (item.getLoanFeeValue() != null) {
                        if (product.getLoanFeeType() == LoanFeeType.SCALE.getIndex()) {
                            item.setLoanFeeValue(NumberUtils.div(item.getLoanFeeValue(), new BigDecimal(100)));
                        }
                    }
                    if (item.getLoanApr() != null) {
                        item.setLoanApr(NumberUtils.div(item.getLoanApr(), new BigDecimal(100)));
                    }
                    this.insert(SCModule.PRODUCT, SCFunction.PROD_FEE_VALUE, item);
                }
            }
        }
        return createSuccessJsonResonse(null, "更新成功！");
    }

    private void buildProd(ProdProductInfo product, BigDecimal loanFixedValue, Integer overdueFeeStatus,
                           String[] repayTypeIds, String coreIds) throws Exception {
        // 服务费处理
        if (product.getLoanFeeType() == LoanFeeType.FIXED.getIndex()) {
            product.setLoanFeeValue(loanFixedValue);
        } else {
            BigDecimal b = NumberUtils.div(product.getLoanFeeValue(), new BigDecimal(100));
            product.setLoanFeeValue(b);
        }
        // 年利率处理
        if (product.getLoanAprStart() != null) {
            product.setLoanAprStart(product.getLoanAprStart());
        }
        if (product.getLoanAprEnd() != null) {
            product.setLoanAprEnd(product.getLoanAprEnd());
        }
        // 最高融资比例
        if (product.getMaxFinanceRate() != null) {
            product.setMaxFinanceRate(NumberUtils.div(product.getMaxFinanceRate(), new BigDecimal(100)));
        }
        // 逾期扣费比例
        // if (product.getOverdueRateValue() != null) {
        // product.setOverdueRateValue(NumberUtils.div(product.getOverdueRateValue(),
        // new BigDecimal(100)));
        // }
        // 逾期服务费
        if (overdueFeeStatus == 0) {
            product.setOverdueType(0);
            product.setOverdueValue(BigDecimal.ZERO);
        }
        // 还款方式
        String repapyTypes = StringUtils.join(repayTypeIds, ",");
        product.setRepayTypeId(repapyTypes);
        QueryItem queryItem = new QueryItem(Where.in("id", repayTypeIds));
        queryItem.setFields("name");
        List<Map> list = this.getListByMap(queryItem, SCModule.FUND, SCFunction.FUND_REPAYTYPE);
        product.setRepayTypeDesc(StringUtils.join(ListUtils.getByKey(list, "name"), "、"));
        // 核心企业
        product.setCoreCompanyIds(coreIds);

        ProdBusinessType bussinessType = this.getById(product.getBusinessTypeId(), SCModule.PRODUCT,
                SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class, "id,name");
        product.setBusinessTypeName(bussinessType.getName());
    }

    /**
     * 根据产品id删除产品前台显示数据
     *
     * @param productId 产品id
     * @throws Exception
     */
    private void deleteFeeValuesByProductId(Long productId) throws Exception {
        QueryItem item = new QueryItem();
        item.setFields("id,del_flag");
        item.getWhere().add(Where.eq("product_id", productId));
        item.getWhere().add(Where.eq("del_flag", 0));
        List<Map> feeValues = this.getListByMap(item, SCModule.PRODUCT, SCFunction.PROD_FEE_VALUE);
        if (CollectionUtils.isNotEmpty(feeValues)) {
            for (Map feeValue : feeValues) {
                this.deleteById(MapUtils.getLong(feeValue, "id"), SCModule.PRODUCT, SCFunction.PROD_FEE_VALUE);
            }
        }
    }

    private List<Map> getCompanys() throws Exception {
        QueryItem compnayQuery = new QueryItem();
        compnayQuery.setFields("id,company_name");
        compnayQuery.getWhere().add(Where.eq("del_flag", 0));
        compnayQuery.getWhere().add(Where.eq("status", CompanyStatus.ACTIVE.getIndex()));
        compnayQuery.getWhere().add(Where.eq("company_role_type", CompanyRoleType.COMPANY_CAPITAL_SIDE.getIndex()));
        return this.getListByMap(compnayQuery, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
    }

    /**
     * 根据ID获取产品信息
     *
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "getOne")
    public DyResponse getOne(Long id) throws Exception {
        ProdProductInfo prod = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
        Map<String, Object> prodMap = new DataConvertUtil(prod, false).convert(Map.class);
        prodMap.put("fees", loanModule.getFormFees(prod.getProdFeeId()));
        return createSuccessJsonResonse(prodMap);
    }

    /**
     * 配置审批流程
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping("confFlow")
    public ModelAndView confFlow(Long id) throws Exception {
        Map<String, Object> productInfo = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, "id,business_type_id,flow_conf");
        productInfo.put("businessTypeId", productInfo.remove("business_type_id"));
        String flowConf = (String) productInfo.remove("flow_conf");
        productInfo.putAll(ArrayUtils.fromParamString(flowConf, "flowConf_"));
        List<FormField> formFieldList = new ArrayList<>();
        String stepKey = "buss_step_" + productInfo.get("businessTypeId");
        List<SysDict> sysDicts = DictUtils.getDictList(stepKey);
        for (int i = 0; i < sysDicts.size(); i++) {
            SysDict dict = sysDicts.get(i);
            if (StringUtils.isNotBlank(dict.getRemarks())) {
                formFieldList.add(FormField.builder().type("title").text(dict.getLabel()).build());
                if(productInfo.get("businessTypeId").toString().equals("4") && dict.getValue().equals("1")){
                	formFieldList.add(FormField.builder().name("flowConf_" + dict.getRemarks()).text("审批流").type("select").verify("required").options(DictUtils.getOptions("flow_proc_info")).build());
                }else{
                	formFieldList.add(FormField.builder().name("flowConf_" + dict.getRemarks()).text("审批流").type("select").options(DictUtils.getOptions("flow_proc_info")).build());
                }
            }
        }
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/product/saveConfFlow", formFieldList, productInfo);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    /**
     * 保存审批流程
     *
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("saveConfFlow")
    public DyResponse saveConfFlow(HttpServletRequest request, ProdProductInfo product) throws Exception {
        Map<String, Object> map = RequestUtil.getRequestMap(request);
        String stepKey = "buss_step_" + product.getBusinessTypeId();
        List<SysDict> sysDicts = DictUtils.getDictList(stepKey);
        Map<String, String> flowConf = Maps.newHashMap();
        for (int i = 0; i < sysDicts.size(); i++) {
            SysDict dict = sysDicts.get(i);
            if (StringUtils.isNotBlank(dict.getRemarks())) {
                String conf = (String) map.get("flowConf_" + dict.getRemarks());
                if (StringUtils.isNotBlank(conf)) {
                    flowConf.put(dict.getRemarks(), conf);
                }
            }
        }
        product.setFlowConf(DyStringUtils.toParamStr(flowConf));
        this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);
        return createSuccessJsonResonse(null, "配置成功");
    }

    /**
     * 开启
     *
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("enable")
    public DyResponse enable(ProdProductInfo product) throws Exception {
        product.setStatus(String.valueOf(AccConstants.STATUS_OPEN));
        this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);
        return createSuccessJsonResonse(null, "开启成功");
    }

    /**
     * 关闭
     *
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("disable")
    public DyResponse disable(ProdProductInfo product) throws Exception {
        product.setStatus(String.valueOf(AccConstants.STATUS_CLOSE));
        this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, product);
        return createSuccessJsonResonse(null, "关闭成功");
    }

    @RequestMapping(value = "addProtocol")
    public ModelAndView addProtocol(Long id) throws Exception {
        List<FormField> formFieldList = Lists.newArrayList();
        ProdProductInfo product = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);

        formFieldList.add(FormField.builder().name("name").text("合同名称").verify("required").build());
        String stepKey = "buss_step_" + product.getBusinessTypeId();
        String include = "";
        if (product.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_RECEIVE) {
            include += "1";
        } else if (product.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_B2B) {
            include += "1";
        } else if (product.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_WAREHOUSE) {
            include += "1,4,5,6,7";
        } else if (product.getBusinessTypeId().intValue() == ScConstants.CONTRACT_TYPE_AGPUR) {
            include += "1";
        }
        List<Option> opts = DictUtils.getOptions(stepKey, include);
        formFieldList.add(FormField.builder().name("businessType").br("br").text("业务类型").type("span").build());
        formFieldList.add(FormField.builder().name("productName").br("br").text("产品名称").type("span").build());
        formFieldList.add(FormField.builder().name("signNode").text("签署节点").type("select").verify("required").options(opts).br("br").build());
        if (product.getBusinessTypeId() == ProdBusinessTypeEnum.B2B.getIndex()) {
            formFieldList.add(FormField.builder().name("signTarget1").text("签署对象").type("checkbox").options("sign_target_b2b").br("br").build());
        } else {
            formFieldList.add(FormField.builder().name("signTarget1").text("签署对象").type("checkbox").options("sign_target").br("br").build());
        }
        formFieldList.add(FormField.builder().name("signType1").text("签署类型").type("select").verify("required").options("sign_type_1").br("br").build());
        formFieldList.add(FormField.builder().name("signDesc").text("签署描述").br("br").build());
        formFieldList.add(FormField.builder().name("content").text("模板内容").br("br").type("ueditor").verify("required").build());
        formFieldList.add(FormField.builder().name("content").text("业务字段").br("br").type("texturl").build());
        Map<String, Object> formStruct = Maps.newHashMap();
        formStruct.put("productName", product.getName());
        formStruct.put("businessType", this.getById(product.getBusinessTypeId(), SCModule.PRODUCT, SCFunction.PROD_BUSINESS_TYPE, ProdBusinessType.class).getName());
        Map<String, Object> data = PageUtil.createFormPageStructure("prod/product/saveProtocol?productId=" + id, formFieldList, formStruct);
        return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
    }

    @ResponseBody
    @RequestMapping(value = "saveProtocol")
    public DyResponse saveProtocol(String signTarget1, ProdTemplate template, HttpServletRequest request) throws Exception {
        if(StringUtils.isBlank(signTarget1)){
        	return createErrorJsonResonse("请选择至少两个签署方");
        }
        String[] signTarget = signTarget1.split(",");
        if (signTarget.length < 2) {
            return createErrorJsonResonse("请选择至少两个签署方");
        }
        ProdProductInfo prodProductInfo = this.getById(template.getProductId(), SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, ProdProductInfo.class);
        template.setBusinessTypeId(prodProductInfo.getBusinessTypeId());
        template.setCode("0099");
        template.setSignTarget(signTarget1);
        template.setProdTemplateType(99);
        template.setContent(request.getParameter("content"));
        this.insert(SCModule.PRODUCT, SCFunction.PROD_TEMPLATE, template);

        prodProductInfo.setReleaseStatus(ScConstants.RELEASE_STATUS_YES);
        this.update(SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO, prodProductInfo);
        return createSuccessJsonResonse(null, "新增电子合同成功");
    }

    /**
     * 返回借贷合同需要的费率信息
     *
     * @param id
     * @return
     * @throws Exception
     */
    @PostMapping("getProductFees")
    @ResponseBody
    public DyResponse getProductFees(Long id) throws Exception {
        Map prod = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO);
        Map<String, Object> result = Maps.newHashMap();
        //服务费
        result.put("loanFeeStatus", prod.get("loan_fee_status"));
        Object loanFeeStatus = prod.get("loan_fee_status");
        if (loanFeeStatus != null) {
            if (loanFeeStatus.toString().equals("1")) {
                if (Integer.parseInt(prod.get("loan_fee_type").toString()) == LoanFeeType.FIXED.getIndex()) {// 固定费用
                    result.put("loanFeeType", "按固定费用");
                    result.put("loanFeeValue", Double.parseDouble(prod.get("loan_fee_value").toString()));
                } else {
                    result.put("loanFeeType", "按固定比例（%）");
                    result.put("loanFeeValue", Double.parseDouble(prod.get("loan_fee_value").toString()) * 100);
                }

                result.put("loanFeeType", prod.get("loan_fee_type"));
            }
        }
        //逾期罚息
        result.put("overdueStatus", prod.get("overdue_status"));
        Object overdueStatus = prod.get("overdue_status");
        if (overdueStatus != null) {
            if ("1".equals(overdueStatus.toString())) {
                result.put("overdueTypeVal", prod.get("overdue_type"));
                if ("1".equals(prod.get("overdue_type"))) {// 免费
                    result.put("overdueType", "免费");
                } else {
                    Map<String, Object> overdue = Maps.newHashMap();
                    List<Option> overdueOpt = DictUtils.getOptions("overdue_rate_type");
                    for (Option opt2 : overdueOpt) {
                        overdue.put(opt2.getValue().toString(), opt2);
                    }
                    result.put("overdueRateValue", Double.parseDouble(prod.get("overdue_rate_value").toString()) * 100);
                    result.put("overdueRateType", prod.get("overdue_rate_type").toString());
                    result.put("overdueType", "按比例");
                    result.put("overdueRateType", overdueOpt);
                }
            }
        }
        result.put("productName", prod.get("name"));
        return createSuccessJsonResonse(result);
    }

    /**
     * 侧滑查看
     *
     * @param id
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "viewDetail")
    public ModelAndView viewDetail(Long id) throws Exception {

        Map formStruct = Maps.newHashMap();
        Map formData = Maps.newHashMap();
        formStruct.put("form_data", formData);
        formStruct.put("id", id);

        // 产品 // 额度
        Map productInfo = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO);
        Integer businessType = MapUtils.getInteger(productInfo, "business_type_id");

        productInfo.put("loan_amount", NumberUtils.format((BigDecimal) productInfo.get("loan_amount_start")) + "~" + NumberUtils.format((BigDecimal) productInfo.get("loan_amount_end")));

        Integer depositType = MapUtils.getInteger(productInfo, "deposit_type");
        if (depositType != null)
            productInfo.put("deposit_type",
                    DictUtils.getDictLabel(MapUtils.getInteger(productInfo, "deposit_type"), "deposit_type"));

        Integer mortgage_time_start = MapUtils.getInteger(productInfo, "mortgage_time_start");
        if (mortgage_time_start != null)
            productInfo.put("mortgage_time", mortgage_time_start + "-"
                    + (productInfo.get("mortgage_time_end") == null ? "0" : productInfo.get("mortgage_time_end"))
            );
        productInfo.put("delay_day", productInfo.get("delay_day_start") == null ? "0" : productInfo.get("delay_day_start") + "-" + productInfo.get("delay_day_end") == null ? "0" : productInfo.get("delay_day_end"));
        // productInfo.put("loan_apr", NumberUtils.format((BigDecimal)
        // productInfo.get("loan_apr_start")) + "%");
        productInfo.put("use_credit_limit", DictUtils.getDictLabel(productInfo.get("use_credit_limit"), "common_status"));
        productInfo.put("auto_req_flag", DictUtils.getDictLabel(productInfo.get("use_credit_limit"), "common_status"));
        productInfo.put("data_channel", DictUtils.getDictLabel(productInfo.get("data_channel"), "data_channel"));
        // productInfo.put("loan_fee", buildFeeShow(productInfo));
        String overdues = MapUtils.getString(productInfo, "overdue_rate_value");
        if (StringUtils.isNoneBlank(overdues)) {
            productInfo.put("overdue_rate_value", JsonUtils.jsonToArrayList(overdues, OverdueRateValue.class));
        }
        productInfo.put("mortgage_type",
                DictUtils.getDictLabel(MapUtils.getInteger(productInfo, "mortgage_type"), "mortgage_type"));
        productInfo.put("core_company", BaseInfoUtils.getCompanyNames((String) productInfo.get("core_company_ids")));
        productInfo.put("captCompany", BaseInfoUtils.getCompanyName(Converter.toLong(productInfo.get("company_id"))));
        if (businessType == ProdBusinessTypeEnum.AGENTPUR.getIndex()) {
            productInfo.put("min_finance_rate", productInfo.get("min_finance_rate") != null
                    ? NumberUtils.format((BigDecimal) productInfo.get("min_finance_rate")) + "%" : null);
        } else if (businessType == ProdBusinessTypeEnum.B2B.getIndex()) {
            QueryItem queryItem = QueryItem.builder().where("product_id", id).build();
            Map productB2b = this.getOneByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_B2B);
            productB2b.remove("id");
            productB2b.put("order_status",
                    DictUtils.getDictLabel(MapUtils.getInteger(productB2b, "order_status"), "order_status"));
            productB2b.put("interest_mode_type", DictUtils
                    .getDictLabel(MapUtils.getInteger(productB2b, "interest_mode_type"), "interest_mode_type"));
            productB2b.put("loan_apr_start", NumberUtils
                    .format(NumberUtils.mul((BigDecimal) productB2b.get("day_interest"), new BigDecimal(360))));

            // 交易周期 核账日期 结算日期
            String tradeTime = String.format("%s%d号-%s%d号",
                    DictUtils.getDictLabel(MapUtils.getInteger(productB2b, "trade_start_type"), "month_type"),
                    MapUtils.getInteger(productB2b, "trade_start_day"),
                    DictUtils.getDictLabel(MapUtils.getInteger(productB2b, "trade_end_type"), "month_type"),
                    MapUtils.getInteger(productB2b, "trade_end_day"));
            productB2b.put("trade_time", tradeTime);
            String checkTime = String.format("%s%d号-%d号",
                    DictUtils.getDictLabel(MapUtils.getInteger(productB2b, "check_month_type"), "month_type"),
                    MapUtils.getInteger(productB2b, "check_start_day"),
                    MapUtils.getInteger(productB2b, "check_end_day"));
            productB2b.put("check_time", checkTime);
            String settleTime = String.format("%s%d号-%d号",
                    DictUtils.getDictLabel(MapUtils.getInteger(productB2b, "settle_month_type"), "month_type"),
                    MapUtils.getInteger(productB2b, "settle_start_day"),
                    MapUtils.getInteger(productB2b, "settle_end_day"));
            productB2b.put("settle_time", settleTime);
            productInfo.putAll(productB2b);
        }
        formData.put("prod", productInfo);

        // 费用
        List<Map> feeItems = this.getListByMap(
                QueryItem.builder().where(Where.in("id", productInfo.get("prod_fee_id"))).build(), SCModule.PRODUCT,
                SCFunction.PROD_FEE_ITEM);
        formData.put("feeItems", feeItems);

        // 前台利息 逾期罚息
        QueryItem feeQuery = new QueryItem();
        feeQuery.setFields("id,loan_day,loan_apr,loan_fee_value");
        feeQuery.getWhere().add(Where.eq("product_id", id));
        feeQuery.getWhere().add(Where.eq("del_flag", 0));
        List<Map> feeValues = this.getListByMap(feeQuery, SCModule.PRODUCT, SCFunction.PROD_FEE_VALUE);
        formData.put("feeValues", feeValues);

        formData.put("id", id);

        // 经办人
        Map creater = this.getById(MapUtils.getLong(productInfo, "create_uid"), SCModule.SYSTEM, Function.SYS_ADMIN);
        if (creater != null) {
            formData.put("creater", creater.get("real_name"));
            formData.put("creater_dept", creater.get("dept_name"));
        }

        formStruct.put("title", FormField.builder().name("prod.name").text("产品名称").build());
        List<FormField> dss = Lists.newArrayList();
        dss.add(FormField.builder().name("creater").text("创建人").build());
        dss.add(FormField.builder().name("creater_dept").text("所属部门").build());
        dss.add(FormField.builder().name("prod.create_time").text("创建时间").type("datetime").build());
        formStruct.put("dss", dss);

        List<DetailItem> dcs = Lists.newArrayList();
        DetailItem detailItem = DetailItem.create("基本信息");
        List<FormField> items = Lists.newArrayList();
        items.add(FormField.builder().name("prod.name").text("产品名称").build());
        items.add(FormField.builder().name("prod.business_type_name").text("业务类型").build());

        if (productInfo.get("max_finance_rate") != null)
            items.add(FormField.builder().name("prod.max_finance_rate")
                    .text(businessType == ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex() ? "最高抵/质押率" : "最高融资比例")
                    .type("percent").build());
        items.add(FormField.builder().name("prod.repay_type_desc").text("还款方式").build());
        items.add(FormField.builder().name("prod.loan_amount").text("借款金额范围").build());
        if (mortgage_time_start != null)
            items.add(FormField.builder().name("prod.mortgage_time").text("借款期限(天)").build());
        if (businessType == ProdBusinessTypeEnum.AGENTPUR.getIndex()) {
            items.add(FormField.builder().name("prod.min_finance_rate").text("保证金缴交比例").build());
            items.add(FormField.builder().name("prod.deposit_type").text("保证金释放方式").build());
        }
        if (businessType == ProdBusinessTypeEnum.B2B.getIndex()) {
            items.add(FormField.builder().name("prod.daily_max_amount").text("单日最高限额(元)").build());
            items.add(FormField.builder().name("prod.order_status").text("可融资订单状态").build());
            // items.add(FormField.builder().name("prod.").text("不可融资产品类型").build());
            items.add(FormField.builder().name("prod.trade_time").text("交易周期").build());
            items.add(FormField.builder().name("prod.check_time").text("核账日期").build());
            items.add(FormField.builder().name("prod.settle_time").text("结算日期").build());
            items.add(FormField.builder().name("prod.interest_mode_type").text("计息模式").build());
        }

        items.add(FormField.builder().name("prod.auto_req_flag").text("是否自动请款").build());
        if (businessType == ProdBusinessTypeEnum.RECEIVE_BILL.getIndex()) {
            items.add(FormField.builder().name("prod.data_channel").text("应收账款数来源").build());
            items.add(FormField.builder().name("prod.core_company").text("指定核心企业").build());
        }
        items.add(FormField.builder().name("prod.captCompany").text("资金方").build());
        items.add(FormField.builder().name("prod.description").text("产品说明").build());

        detailItem.items(items);
        dcs.add(detailItem);

        List<FormField> itemsED = Lists.newArrayList();
        itemsED.add(FormField.builder().name("prod.use_credit_limit").text("是否需要授信额度").build());
        dcs.add(DetailItem.create("额度").items(itemsED));

        // List<FormField> itemsLL = Lists.newArrayList();
        // itemsLL.add(FormField.builder().name("prod.loan_apr").text("年利率").build());
        // dcs.add(DetailItem.create("利率").items(itemsLL));

        // List<FormField> itemsFY = Lists.newArrayList();
        // itemsFY.add(FormField.builder().name("prod.loan_fee").text("服务费").build());
        // itemsFY.add(FormField.builder().name("prod.overdue").text("逾期罚息").build());
        // dcs.add(DetailItem.create("费用信息").items(itemsFY));

        // List<FormField> itemsQT = Lists.newArrayList();
        // dcs.add(DetailItem.create("前台显示").type("front").items(itemsQT));

        // List<FormField> feeFields = Lists.newArrayList();
        // feeFields.add(FormField.builder().name("formula"))
        // dcs.add(DetailItem.create("费用").type("table").name("feeItems").items(itemsQT));

        formStruct.put("dcs", dcs);
        this.getViewMenu(formStruct);
        return createSuccessModelAndView("product/rightDialog", JsonUtils.object2JsonString(formStruct));

    }


    private String buildFeeShow(Map productInfo) {
        Integer fst = MapUtils.getInteger(productInfo, "loan_fee_status");
        Integer ft = MapUtils.getInteger(productInfo, "loan_fee_type");
        if (fst == 0 || ft == 0) {
            return "关闭";
        }
        String typeStr = "";
        if (ft == 1) {
            typeStr = "按固定费用:" + NumberUtils.format(NumberUtils.mul((BigDecimal) productInfo.get("loan_fee_value"), NumberUtils.ONE_HUNDRED)) + "元";
        } else if (ft == 2) {
            typeStr = "按服务费率：借款金额*" + NumberUtils.format(NumberUtils.mul((BigDecimal) productInfo.get("loan_fee_value"), NumberUtils.ONE_HUNDRED)) + "%";
        }

        return typeStr;
    }

    /**
     * 侧滑查看合同
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "viewContract")
    public ModelAndView viewContract(Long id) throws Exception {
        Map formStruct = Maps.newHashMap();
        Map formData = Maps.newHashMap();
        formStruct.put("form_data", formData);
        formStruct.put("id", id);

        formData.put("id", id);
        Map productInfo = this.getById(id, SCModule.PRODUCT, SCFunction.PROD_PRODUCT_INFO);
        formData.put("prod", productInfo);
        QueryItem queryItem = new QueryItem(Where.in("product_id", commonBussUtil.getProductIds(id)));
        queryItem.setWhere(Where.eq("prod_template_type", 99));
        List<Map> cons = this.getListByMap(queryItem, SCModule.PRODUCT, SCFunction.PROD_TEMPLATE);
        this.idToName(cons, SCModule.SYSTEM, Function.SYS_ADMIN, "create_uid:real_name,dept_name");
        dataConvert(cons, "sign_node:buss_step_" + productInfo.get("business_type_id") + ",sign_type1:sign_type_1");
        formData.put("cons", cons);

        // 经办人
        Map creater = this.getById(MapUtils.getLong(productInfo, "create_uid"), SCModule.SYSTEM, Function.SYS_ADMIN);
        if (creater != null) {
            formData.put("creater", creater.get("real_name"));
            formData.put("creater_dept", creater.get("dept_name"));
        }

        formStruct.put("title", FormField.builder().name("prod.name").text("产品名称").build());
        List<FormField> dss = Lists.newArrayList();
        dss.add(FormField.builder().name("creater").text("创建人").build());
        dss.add(FormField.builder().name("creater_dept").text("所属部门").build());
        dss.add(FormField.builder().name("prod.create_time").text("创建时间").type("datetime").build());
        formStruct.put("dss", dss);

        List<DetailItem> dcs = Lists.newArrayList();
        List<FormField> items = Lists.newArrayList();
        items.add(FormField.builder().name("id").text("序号").build());
        items.add(FormField.builder().name("name").text("合同名称").build());
        items.add(FormField.builder().name("sign_node").text("签署节点").build());
        items.add(FormField.builder().name("sign_type1").text("签署方式").build());
        items.add(FormField.builder().name("real_name").text("创建人").build());
        items.add(FormField.builder().name("dept_name").text("所属部门").build());
        items.add(FormField.builder().name("create_time").text("创建时间").type("datetime").build());
        items.add(FormField.builder().name("id").text("操作").type("action").build());
        dcs.add(DetailItem.create("合同模板").name("cons").type("table").items(items));
        formStruct.put("dcs", dcs);
        this.getViewMenu(formStruct);
        return createSuccessModelAndView("common/rightDialog", JsonUtils.object2JsonString(formStruct));
    }
}