package com.dy.sc.admin.interceptor;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.utils.Constant;
import com.dy.core.utils.HttpInvoker;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.RequestUtil;
import com.dy.ia.entity.common.OrgUser;
import com.dy.ia.entity.common.Role;
import com.dy.sc.entity.constant.AdminConstants;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

@Component
public class CommonInterceptor extends HandlerInterceptorAdapter {

	@Value("${test.on:false}")
	private Boolean test;
	@Value("${dy.js.type:src}")
	private String js_type_;

	// IP黑名单
	private String blackListIp = "null";
	
	private static final String NO_INTERCEPTOR_PATH = "/check/.+";

	@Autowired
	private HttpInvoker httpInvokerUtil;

	// TODO 自动登录 待删除
	private void autoLogin(HttpServletRequest request) throws Exception {

		// sysCache.reloadMenu();
		String username = "sc";
		String password = "123";
		QueryItem queryItem = new QueryItem(new Where("username", username));
		// queryItem.setWhere(Where.eq("type", 1));
		// queryItem.setFields("id,role,username,real_name as realName,role_name
		// as roleName,password,phone,email,status,lastlogin_time as
		// lastloginTime,dept_id as deptId,dept_name as deptName");
		OrgUser user = null;
		try {
			user = httpInvokerUtil.getOne(queryItem, SCModule.SYSTEM, SCFunction.SYS_ADMIN, OrgUser.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// OrgUser user = this.getOneByEntity(queryItem, Module.SYSTEM,
		// Function.SYS_ADMIN, OrgUser.class);
		request.getSession().setAttribute(Constant.SESSION_USER, user);

		// session加入权限，可以访问的路劲
		Set<String> roles = Sets.newHashSet();
		QueryItem query = new QueryItem(Where.in("id", user.getRole()));
		query.setFields("auth");
		List<Role> roleList = httpInvokerUtil.getList(query, SCModule.SYSTEM, SCFunction.SYS_ROLE, Role.class);
		for (Role role : roleList) {
			if (StringUtils.isNotBlank(role.getAuth())) {
				roles.addAll(Arrays.asList(role.getAuth().split(",")));
			}
		}
		QueryItem q = new QueryItem(Where.notIn("id", roles));
		q.setFields("id,url");
		List<Map> menus = httpInvokerUtil.getList(q, SCModule.SYSTEM, SCFunction.SYS_MENU);
		List<String> unauth = Lists.newArrayList();
		for (Map menu : menus) {
			unauth.add((String) menu.get("url"));
		}
		request.getSession().setAttribute(AdminConstants.USER_RIGHT_NO, unauth);
		request.getSession().setAttribute(AdminConstants.USER_RIGHT_IDS, roles);

		// 加入Shiro身份验证
		Subject subject = SecurityUtils.getSubject();
		UsernamePasswordToken token = new UsernamePasswordToken(username, password);
		try {
			subject.login(token);
		} catch (AuthenticationException e) {
			// logger.error("shiro 登录异常",e);
		}
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String path = request.getServletPath();
		if ("/common/noaccess".equals(path))
			return true;

		if (StringUtils.isNotBlank(blackListIp) && blackListIp.contains(RequestUtil.getRemoteIp())) {
			response.sendRedirect(request.getContextPath() + "/common/noaccess");
			return false;
		}

		// 判断请求是否需要拦截
		if (path.matches(Constant.NO_INTERCEPTOR_PATH) || path.matches(NO_INTERCEPTOR_PATH))
			return true;

		// TODO 自动登录
		if (test && request.getSession().getAttribute(Constant.SESSION_USER) == null) {
			autoLogin(request);
			return true;
		}

		for (String newPath : list) {
			if (path.matches(newPath)) {
				return true;
			}
		}

		// 判断用户是否登陆，未登陆就返回到登录页面
		if (request.getSession().getAttribute(Constant.SESSION_USER) == null) {
			sendResult(request, response);
			return false;
		}

		if (path.equals("/"))
			return true;
		// 如果已经登录则判断是否有权限访问
		List<String> unauth = (List<String>) request.getSession().getAttribute(AdminConstants.USER_RIGHT_NO);
		if (unauth != null && unauth.contains(path.substring(1))) {
			// sendResult(request, response);
			response.sendRedirect(
					request.getContextPath() + "/system/public/permissionDenied?path=" + path.substring(1));
			return false;
		}

		return true;
	}

	private void sendResult(HttpServletRequest request, HttpServletResponse response) throws IOException {
		if (isAjax(request)) {
			DyResponse dyResponse = new DyResponse();
			dyResponse.setStatus(DyResponse.LOGINERR);
			PrintWriter printWriter = response.getWriter();
			printWriter.print(JsonUtils.object2JsonString(dyResponse));
			printWriter.close();
		} else {
			response.sendRedirect(request.getContextPath() + "/system/public/login");
		}
	}

	private boolean isAjax(HttpServletRequest request) {
		return "application/x-www-form-urlencoded".equals(request.getHeader("Content-Type"))
				&& request.getMethod().equals("POST");
	}

	/**
	 * 免拦截的url
	 */
	public static List<String> list = new ArrayList<String>();
	static {
		// 管理员
		list.add("/org/role/listData");
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		if(modelAndView == null)return;
		modelAndView.addObject("js_type_", js_type_);
		super.postHandle(request, response, handler, modelAndView);
	}

}
