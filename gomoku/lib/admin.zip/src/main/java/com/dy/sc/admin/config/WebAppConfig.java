package com.dy.sc.admin.config;

import org.springframework.boot.web.servlet.view.velocity.EmbeddedVelocityViewResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.dy.sc.admin.interceptor.CommonInterceptor;

@Configuration
public class WebAppConfig extends WebMvcConfigurerAdapter{
	
	/**
     * 配置拦截器
     * @param registry
     */
    public void addInterceptors(InterceptorRegistry registry) {
    	registry.addInterceptor(commonInterceptor()).addPathPatterns("/**");
	}
    
    @Bean
    public CommonInterceptor commonInterceptor(){
        return new CommonInterceptor();
    }
    
    /**
     * 使用velocity
     * @return
     */
    @Bean
	public EmbeddedVelocityViewResolver viewResolver(EmbeddedVelocityViewResolver velocityViewResolver) {
    	return velocityViewResolver;
	}
    
    
}