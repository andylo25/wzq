package com.dy.sc.admin.controller.system;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.enumeration.DictType;
import com.dy.sc.entity.system.Dict;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * @ClassName: DictTypeController.java 
 * @Description: TODO 
 * Copyright (c) 2015
 * 厦门帝网信息科技
 * @author diyou@diyou.cn
 * @date 2017年7月14日上午9:19:11 
 * @version v1.0
 * <pre>
 * 修改人                修改时间        版本        修改内容                    
 * ---------------------------------------------------------
 * diyou 
 * </pre>
 */	
@Controller
@RequestMapping("/sys/dict/")
public class DictController extends AdminBaseController{

    /**
     * 列表
     * @return
     * @throws Exception
     */
    @RequestMapping(value="list",method=RequestMethod.GET)
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "description","type","label","value","sort","create_time"});
		tableHeader.setTexts(new String[]{"ID", "联动名称", "后台组值", "联动显示", "联动值", "排序", "添加时间"});
		tableHeader.setTypes(new String[]{"int","","","","","","datetime"});
		tableHeader.setOptionTypes(new String[]{"","","","","","",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"search"});
		search.setTexts(new String[]{"联动名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("sys/dict/listData", "id", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 列表数据
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({"rawtypes" })
    @ResponseBody
	@RequestMapping(value="listData",method=RequestMethod.POST)
	public DyResponse listData(Integer page,Integer limit,String search) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("id,description,type,label,value,sort,create_time");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.likeAll("description", search));
		}
		queryItem.setWhere(Where.eq("dict_type",DictType.CHILD.getIndex()));
		queryItem.setWhere(Where.eq("del_flag",0));
		queryItem.setOrders("id");
		Page<Map> pageData=getPageByMap(queryItem, SCModule.SYSTEM, SCFunction.SYS_DICT);
		return createSuccessJsonResonse(pageData);
	}
	
	/**
	 * 编辑新增页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="add",method=RequestMethod.GET)
	public ModelAndView add() throws Exception {		
		List<FormField> formFieldList = Lists.newArrayList();
		Map<String,Object> formdata=getFromData();
		List<Dict> dicts=Lists.newArrayList(); 
		dicts.add(new Dict());
		formdata.put("dicts", dicts);
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/dict/save", formFieldList,formdata);
		return createSuccessModelAndView("system/editDict", JsonUtils.object2JsonString(data));
	}

	/**
	 * 界面上的下拉、单选、字典值
	 * @return
	 * @throws Exception
	 */
	private Map<String,Object> getFromData() throws Exception{		
		Map<String,Object> formdata=Maps.newHashMap();
		//状态
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("id,description,type");
		queryItem.setWhere(Where.eq("dict_type",DictType.PARENT.getIndex()));
		queryItem.setWhere(Where.eq("del_flag",0));
		List<Map> dictTypes = this.getListByMap(queryItem , SCModule.SYSTEM, SCFunction.SYS_DICT);
		formdata.put("dictTypes", dictTypes);
		return formdata;
	}
	
	private Map<String,Object> getDictByType(String type) throws Exception{		
		QueryItem queryItem = new QueryItem();
		queryItem.setFields("id,description,type");
		queryItem.setWhere(Where.eq("dict_type",DictType.PARENT.getIndex()));
		queryItem.setWhere(Where.eq("del_flag",0));
		queryItem.setWhere(Where.eq("type",type));
		return this.getOneByMap(queryItem , SCModule.SYSTEM, SCFunction.SYS_DICT);
	}
	
    /**
     * 校验同一组内是否存在重复值
     * @param type
     * @param id
     * @return
     * @throws Exception
     */
    private boolean isValueExists(String type,String value,Long id) throws Exception {
        QueryItem query = new QueryItem();
        query.setFields(" count(1) as count ");
        List<Where> where = new ArrayList<Where>();
        this.addWhereCondition(where, "type", type);
        this.addWhereCondition(where, "del_flag", 0);
        this.addWhereCondition(where, "dict_type", DictType.CHILD.getIndex());
        this.addWhereCondition(where, "value", value);
        query.setWhere(where);
        //编辑时，排除当前数据
        if(id!=null){       	
        	query.getWhere().add(Where.notEq("id", id));
        }
        Map<String, Object> result = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_DICT);
        if(result!=null&&result.size()>0&&Integer.parseInt(result.get("count").toString())>0){
            return true;
        }
        return false;
    }
	
	/**
	 * 保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="save",method=RequestMethod.POST)
	public DyResponse save(String type, @RequestParam("dicts") String dicts) throws Exception {
		Map<String,Object> parent=getDictByType(type);
		List<Dict> items = JsonUtils.jsonToList(dicts, Dict[].class);
		if(CollectionUtils.isNotEmpty(items)){
			for(Dict dict:items){
		        if (isValueExists(type,dict.getValue(),null)) {
		            return createErrorJsonResonse("该联动名称内存在相同的值，不能新增，请重新输入！");
		        }
				dict.setDescription(parent.get("description").toString());
				dict.setType(parent.get("type").toString());
				dict.setDictType(DictType.CHILD.getIndex());
				this.insert(SCModule.SYSTEM, SCFunction.SYS_DICT, dict);
			}
		}
		return createSuccessJsonResonse(null,"添加成功");
	}
	
	/**
	 * 编辑更新页面
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
    @RequestMapping(value="edit")
	public ModelAndView edit(Long id) throws Exception {
		List<FormField> formFieldList = Lists.newArrayList();
		Map<String,Object> formdata=getFromData();
		List<Dict> dicts=Lists.newArrayList(); 		
		Dict entity = this.getById(id , SCModule.SYSTEM, SCFunction.SYS_DICT,Dict.class);
		dicts.add(entity);
		formdata.put("id", id);
		formdata.put("type", entity.getType());
		formdata.put("dicts", dicts);
		Map<String, Object> data = PageUtil.createFormPageStructure("sys/dict/update", formFieldList,formdata);		
		return createSuccessModelAndView("system/editDict", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 更新
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="update",method=RequestMethod.POST)
	public DyResponse update(Long id, String type, @RequestParam("dicts") String dicts) throws Exception {
		Map<String,Object> parent=getDictByType(type);
		List<Dict> items = JsonUtils.jsonToList(dicts, Dict[].class);
		Dict dict=items.get(0);
        if (isValueExists(type,dict.getValue(),id)) {
            return createErrorJsonResonse("该联动名称内存在相同的值，不能新增，请重新输入！");
        }		
		dict.setId(id);
		dict.setDescription(parent.get("description").toString());
		dict.setType(parent.get("type").toString());
	    this.update(SCModule.SYSTEM, SCFunction.SYS_DICT,dict);
		return createSuccessJsonResonse(null,"修改成功");
	}
	
	/**
	 * 删除
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="delete",method=RequestMethod.POST)
	public DyResponse delete(Long id) throws Exception {
		Map<String,Object> dict=Maps.newHashMap();
		dict.put("id", id);
		dict.put("del_flag", AccConstants.DELETE_FLAG);
        this.update(SCModule.SYSTEM, SCFunction.SYS_DICT, dict);
		return createSuccessJsonResonse(null,"删除成功");
	}
    
}