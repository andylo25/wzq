package com.dy.sc.admin.controller.buss;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.form.FormOption;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.RequestUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.google.common.collect.Lists;

@Controller
@RequestMapping("/loan")
public class BussLoanTypeController extends AdminBaseController {
	/**
	 * 获取借款类型
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/loantype/list")
	public ModelAndView getTypeList() throws Exception {
		TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "loan_name","status","repay_type"});
		tableHeader.setTexts(new String[]{"ID", "借款类型","状态","还款方式"});
		tableHeader.setTypes(new String[]{"int","", "",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());

		PageStructure data = PageUtil.createTablePageStructure("loan/loantype/listData", "id", tableHeader,tool,null);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取借款类型数据
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/loantype/listData")
	public DyResponse getLoanTypeListData(Integer page,Integer limit) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		queryItem.setOrders("id");	
		return createSuccessJsonResonse(dataConvert(getPageByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOANTYPE),"status:status,repay_type:repay_type"));
	}
	
	/**
	 * 编辑新增页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/loantype/toAdd")
	public ModelAndView toAdd() throws Exception {
		
		List<FormField> formFieldList = buidFormField();
		
		Map<String, Object> data = PageUtil.createFormPageStructure("loan/loantype/save", formFieldList);
		
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(data));
		/*String debit_id="1";
		Object errorCode =bussService.transferMoney(debit_id);
		DyResponse response = null;
		if(errorCode != null && StringUtils.isNotEmpty(errorCode.toString())) {
			response = createErrorJsonResonse(getMessage(errorCode.toString()));
		} else {
			response = createSuccessJsonResonse(null, getMessage("tranfer.success"));
		}
		String aa="123132";
		return createSuccessModelAndView("common/add", JsonUtils.object2JsonString(null));*/
	}

	private List<FormField> buidFormField() throws Exception {
		List<FormField> formFieldList = new ArrayList<>();
		formFieldList.add(FormField.builder().name("loan_name").text("类型名称").verify("required").build());
		
		List<FormOption> repayTypeOption = new ArrayList<>();
//		repayTypeOption.add(new FormOption("先息后本", "1"));
//		repayTypeOption.add(new FormOption("到期还本还息", "2"));
		QueryItem queryItem = new QueryItem(Where.eq("status", 1));
		queryItem.setFields("id,name");
	    List<Map> repayTypes = null;
		repayTypes = this.getListByMap(queryItem , SCModule.FUND, SCFunction.FUND_REPAYTYPE);
	    if(repayTypes!=null){
	    	for(Map item:repayTypes){
	    		repayTypeOption.add(new FormOption(item.get("name").toString(), item.get("id").toString()));
		    }
	    }
		formFieldList.add(FormField.builder().name("repay_type").text("还款方式").type("checkbox").options(repayTypeOption).build());

		List<FormOption> options = new ArrayList<>();
		options.add(new FormOption("是", "1"));
		options.add(new FormOption("否", "0"));
		formFieldList.add(FormField.builder().name("status").text("是否开启").type("radio").options(options ).build());
		return formFieldList;
	}
	
	/**
	 * 保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/loantype/save")
	public DyResponse saveLoanType(HttpServletRequest request) throws Exception {
		Map<String, Object> paramMap = RequestUtil.getRequestMap(request);
		String [] repay_types=(String[]) paramMap.get("repay_type[]");	
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < repay_types.length; i++){
		 sb. append(repay_types[i]+",");
		}
		String s = sb.toString();
		s=s.substring(0, s.length()-1);
		paramMap.put("repay_type", s);
		paramMap.remove("repay_type[]");
		this.insert(SCModule.FUND, SCFunction.FUND_LOANTYPE, paramMap);
		return createSuccessJsonResonse(null,"添加成功");
	}
	
	/**
	 * 筛选未禁用字段
	 * @param formFieldList
	 * @param repay_type
	 * @return
	 */
	private String[] filterRepayType(List<FormField> formFieldList,String[] repay_type){
		List<String> result=Lists.newArrayList();
		for(FormField formField:formFieldList){
			if("repay_type".equals(formField.getName())){
				for(Object option:formField.getOptions()){
					FormOption opt=(FormOption) option;
					for(String repayType:repay_type){
						if(opt.getValue().equals(repayType)){
							result.add(repayType);
						}
					}
				}
				break;
			}
		}
		return result.toArray(new String[result.size()]);
	}
	
	/**
	 * 编辑更新页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/loantype/toEdit")
	public ModelAndView toEdit(Long id) throws Exception {
		List<FormField> formFieldList = buidFormField();	
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("id,loan_name,repay_type,status");
		Map<String, Object> loanTypeMap = this.getOneByMap(queryItem , SCModule.FUND, SCFunction.FUND_LOANTYPE);
		String repayType=loanTypeMap.get("repay_type").toString();
		String[] repay_type=repayType.split(",");
		loanTypeMap.put("repay_type", filterRepayType(formFieldList,repay_type));
		
		Map<String, Object> data = PageUtil.createFormPageStructure("loan/loantype/update", formFieldList,loanTypeMap);	
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}
	/**
	 * 编辑保存
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/loantype/update")
	public DyResponse updateLoanType(HttpServletRequest request) throws Exception {
		Map<String, Object> paramMap = RequestUtil.getRequestMap(request);
		Object value = paramMap.get("repay_type[]");
		if(value instanceof String[]) {
			String [] repay_types=(String[]) paramMap.get("repay_type[]");	
			StringBuffer sb = new StringBuffer();
			for(int i = 0; i < repay_types.length; i++){
			 sb. append(repay_types[i]+",");
			}
			String s = sb.toString();
			s=s.substring(0, s.length()-1);
			paramMap.put("repay_type", s);
			paramMap.remove("repay_type[]");			
		}
		else{
			paramMap.remove("repay_type[]");	
			paramMap.put("repay_type",value);
		}
		this.update(SCModule.FUND, SCFunction.FUND_LOANTYPE, paramMap);
		return createSuccessJsonResonse(null,"修改成功");
	}
	
	
	
	
	
	
	
	
}