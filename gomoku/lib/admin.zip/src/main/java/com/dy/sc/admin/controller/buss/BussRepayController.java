package com.dy.sc.admin.controller.buss;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.form.FormField;
import com.dy.core.utils.DataConvertUtil;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.RepayUtil;
import com.dy.sc.bussmodule.loan.LoanModule;
import com.dy.sc.bussmodule.utils.BaseInfoUtils;
import com.dy.sc.bussmodule.utils.CommonLoanUtil;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.constant.ScConstants;
import com.dy.sc.entity.enumeration.ProdBusinessTypeEnum;
import com.dy.sc.entity.enumeration.RepaymentTypeEnum;
import com.dy.sc.entity.fund.FundLoanRepay;
import com.google.common.collect.Maps;

/**
 * 还款管理
 * @author cuiwm
 */
@Controller
@RequestMapping("/credit")
public class BussRepayController extends AdminBaseController {
    
    /**
     * 全部还款
     */
    // private static final int TYPE_ALL=1;
    // /**
    // * 逾期未还
    // */
    // private static final int TYPE_OVERDUE_NOTREPAY=2;
    // /**
    // * 逾期已还
    // */
    // private static final int TYPE_OVERDUE_PAYED=3;
    //
    // /**
    // * 待还款明细
    // */
    // private static final int TYPE_NO_PAY=4;
    // /**
    // * 已还款明细
    // */
    // private static final int TYPE_PAYED=5;
    // /**
    // * 转坏账
    // */
    // private static final int TYPE_BAD_DEBT=6;
    
    @Autowired
    private LoanModule loanModule;
    
    private List<FormField> buidFormField() {
        List<FormField> formFieldList = new ArrayList<>();
        formFieldList.add(FormField.builder().name("company_name").text("客户名称").type("span").build());
        formFieldList.add(FormField.builder().name("loan_contract_no").text("借贷合同号").type("span").build());
        //formFieldList.add(FormField.builder().name("period_no").text("还款期数").type("span").build());
        formFieldList.add(FormField.builder().name("repay_time").text("到期日").type("span").build());
        formFieldList.add(FormField.builder().name("principal").text("未还本金").type("span").build());
        formFieldList.add(FormField.builder().name("repayAmount").text("还款本金").type("input").verify("required").build());
        
        formFieldList.add(FormField.builder().name("interest").text("还款利息").type("span").build());
        formFieldList.add(FormField.builder().name("overdue_fee").text("逾期罚息").type("span").build());
        formFieldList.add(FormField.builder().name("amount").text("还款总额").type("span").build());
        formFieldList.add(FormField.builder().name("accBalance").text("账户余额").type("span").build());
        return formFieldList;
    }
    
    /**
     * 请求回款
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/repay/viewByBuss/{type}")
    public ModelAndView viewByBuss(Long id,@PathVariable("type")int bussType) throws Exception{
    	Map<String,Object> debit=CommonLoanUtil.getDebitMapByLoanId(id, bussType);
    	QueryItem queryItem=QueryItem.builder().where("debit_id", MapUtils.getLong(debit,"id")).build();
    	//仓单只有一条还款记录
    	if(bussType==ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex()){
            FundLoanRepay repay = this.getOneByEntity(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAY,
                    FundLoanRepay.class);
    		String savePath="warehouse/warehouseLoan/repay";
    		return repayViewDataWithoutPeriod(repay, debit,bussType,savePath);
    	}else{
    		Map<String, Object> period=this.getOneByMap(queryItem, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
    		return repayViewData(period, debit,bussType);
    	}
	}
    

    @SuppressWarnings("unchecked")
    private ModelAndView repayViewDataWithoutPeriod(FundLoanRepay loanRepay, Map<String, Object> debit,
            Integer businessType, String savePath) throws Exception {
        Map<String, Object> repay = new DataConvertUtil(loanRepay, false, false).convert(Map.class);
    	List<FormField> formFieldList = null;
        // 扣除已还金额
        BigDecimal principal = new BigDecimal(repay.get("principal_total").toString())
                .subtract(new BigDecimal(repay.get("principal_yes").toString()));
        repay.put("principal", principal);
        BigDecimal interest = RepayUtil.calInterestAnyTime(debit, repay);
        repay.put("interest", interest);

        Object debitId = repay.get("debit_id");
        repay.put("repay_time", repay.get("expire_time"));
        repay.put("id", debitId);

        //当已还款
        Object lastDateObj = repay.get("repay_time_yes");

        int overdue_days = RepayUtil.calOverdueDaysAnyTime(MapUtils.getLong(repay, "overdue_fee_pay_date"),
                MapUtils.getLong(debit, "contract_end_time"));
        BigDecimal overdueFee=null;
        if(overdue_days>0){
            repay.put("overdue_days", overdue_days);
            if (lastDateObj == null || NumberUtils.greaterThanZero(principal)) {
                overdueFee = RepayUtil.calOverdueFeeAnyTime(debit.get("overdue_rate_value").toString(),
                        (BigDecimal) repay.get("principal_total"), (BigDecimal) repay.get("principal_yes"),
                        overdue_days);
            }
        }else{
        	overdueFee=BigDecimal.ZERO;
        }
        BigDecimal fee = RepayUtil.calFeeRepay(loanRepay, debit);
        repay.put("overdue_fee", overdueFee);
        repay.put("fee", fee);
        
        repay.put("company_name", debit.get("company_name"));
        repay.put("repay_time", DateUtil.dateFormat(repay.get("repay_time")));
        
        Map<String, Object> account = BaseInfoUtils.getCompAccountMap(debit.get("company_id"));
        repay.put("accBalance", MapUtils.getDouble(account, "acc_balance"));
        
        Map<String, Object> pageData = PageUtil.createFormPageStructure(savePath, formFieldList, repay);
        pageData.put("br", true);
        
        return createSuccessModelAndView("warehouse/repay/add", JsonUtils.object2JsonString(pageData));
    }
    
    private ModelAndView repayViewData(Map<String, Object> period,Map<String,Object> debit,Integer businessType) throws Exception{
    	List<FormField> formFieldList = null;
        // 扣除已还金额
        period.put("principal", new BigDecimal(period.get("principal").toString()).subtract(new BigDecimal(period.get("principal_yes").toString())));
        period.put("interest", new BigDecimal(period.get("interest").toString()).subtract(new BigDecimal(period.get("interest_yes").toString())));
        period.put("amount", new BigDecimal(period.get("amount").toString()).subtract(new BigDecimal(period.get("amount_yes").toString())));
        //当已还款
        Object lastDateObj=period.get("repay_time_yes");
        Date lastDate;
        if(lastDateObj!=null){
            lastDate= DateUtil.dateParse(Long.valueOf(lastDateObj.toString()));
        }else{
            lastDate=DateUtil.getCurrentDate();
        }
        BigDecimal notPay = new BigDecimal(period.get("amount").toString());
        // 未还清
        if(notPay.compareTo(BigDecimal.ZERO) > 0){
        	lastDate=DateUtil.getCurrentDate();
        }
        int overdue_days=DateUtil.daysBetween(DateUtil.dateParse(Long.valueOf(period.get("repay_time").toString())),lastDate);     
        if(overdue_days>0){
        	period.put("overdue_days", overdue_days);
            if(lastDateObj==null || notPay.compareTo(BigDecimal.ZERO )> 0){
            	debit.put("loan_amount", notPay);
                period.put("overdue_fee",
                        ((BigDecimal) period.get("overdue_fee")).add(RepayUtil.calOverdueFeeAnyTime(
                                debit.get("overdue_rate_value").toString(), (BigDecimal) period.get("principal"),
                                (BigDecimal) period.get("principal_yes"), overdue_days)));
            }
        }  
        period.put("amount", new BigDecimal(period.get("amount").toString()).add(new BigDecimal(period.get("overdue_fee").toString())));
        Map<String, Object> debitRecord = this.getById((Serializable) period.get("debit_id"), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD,"company_id");
        
        QueryItem query = new QueryItem();
        query.setFields("company_name");
        query.setWhere(Where.eq("id", debitRecord.get("company_id")));
        Map<String, Object> company = this.getOneByMap(query, SCModule.SYSTEM, SCFunction.SYS_COMPANY);
        period.put("company_name", company.get("company_name"));
        period.put("repay_time", DateUtil.dateFormat(period.get("repay_time")));
        period.put("repayAmount", period.get("amount"));
        String savePath=null;
        String viewName=null;
//        if(businessType!=null&&ProdBusinessTypeEnum.WAREHOUSE_RECEIPT.getIndex()==businessType){
//        	savePath="warehouse/warehouseLoan/repay";
//        	viewName="warehouse/repay/add";
//        }else{
        	formFieldList = buidFormField();
        	savePath="credit/repay";
        	viewName="common/edit"; 
//        }
        Map<String, Object> data = PageUtil.createFormPageStructure(savePath, formFieldList,period);
        data.put("br", true);
        return createSuccessModelAndView(viewName, JsonUtils.object2JsonString(data));
    }
    
    /**
     * 请求回款
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/repay/view")
    public ModelAndView repayView(Long id) throws Exception {
        QueryItem query = new QueryItem();
        query.setWhere(Where.eq("id", id));
        Map<String, Object> period = this.getOneByMap(query, SCModule.FUND, SCFunction.FUND_LOAN_REPAYPERIOD);
        Map record = this.getById(period.get("debit_id").toString(), SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD);
        return repayViewData(period, record,null);
    }
    
    /**
     * 保存回款
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value="/repay/save")
    public DyResponse saveRepay(Long id,String memo,BigDecimal repayAmount,String repayTime) throws Exception {
    	loanModule.billBack(id, memo, RepaymentTypeEnum.REPAY.getIndex(), repayAmount, null);
        return createSuccessJsonResonse(null,"还款成功");
    }
    
	/**
	 * 还款侧滑信息
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="/recovering/recoverview")
	public ModelAndView recoverview(Long id) throws Exception {		
		//信贷记录
        Map<String, Object> debit = this.getById(id, SCModule.LOAN, SCFunction.LOAN_DEBIT_RECORD,"id,loan_id,business_type");
        ModelAndView view = new ModelAndView("redirect:/credit/allrecord/viewNew/"+debit.get("business_type"));
	     Integer businessType = MapUtils.getInteger(debit, "business_type");
	     if(businessType  == ScConstants.CONTRACT_TYPE_B2B){
	    	 view.addObject("id", id);
	     }else{
	    	 view.addObject("id", debit.get("loan_id"));
	     }
        return view;
        
        
//        FundLoanRepay fundLoanRepay = this.getOneByEntity(QueryItem.builder().where("debit_id", id).build(),
//                SCModule.FUND, SCFunction.FUND_LOAN_REPAY, FundLoanRepay.class);
//        loanModule.getRepayViewData(fundLoanRepay, result, record);
//        
//        Map<String, Object> result=Maps.newHashMap();
//        record.put("contract_start_time",DateUtil.dateFormat(record.get("contract_start_time")));
//        record.put("contract_end_time",DateUtil.dateFormat(record.get("contract_end_time")));
//        dataConvert(record,"loan_fee_type,loan_repay_type:repay_type,loan_type:loan_type,status:credit_record_status", "create_time");
//        result.put("record", record);
//        
//        getViewMenu(result);
//        ModelAndView view = new ModelAndView("buss/recoverRecord");
//        return view.addObject("loanContent", JsonUtils.object2JsonNoEscaping(result));
        
	}

}