package com.dy.sc.admin.controller.capital;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.constant.Function;
import com.dy.core.constant.Module;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.RowLink;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.service.ReportService;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.excel.ExportExcel;
import com.google.common.collect.Lists;

/**
 * 平台资金统计
 * @author cuiwm
 *
 */
@Controller
@RequestMapping("platcap/report")
public class PlatCapitalReport extends AdminBaseController{
	
	@Autowired
	ReportService reportService;

	/**
     * 构建界面结构:平台资金统计
     * @return
     * @throws Exception
     */
    @RequestMapping("list")
    public ModelAndView list() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "rep_date","total_income","total_pay"});
		tableHeader.setTexts(new String[]{"ID", "月份","总收入金额","总支出金额"});
//		tableHeader.setFilters(new String[]{"","multi_date", "","","","select","","","","","input",""});
		
		List<RowLink> rowLink=Lists.newArrayList();
		rowLink.add(new RowLink("收入统计明细","platcap/report/detail/1/list"));
		rowLink.add(new RowLink("支出统计明细","platcap/report/detail/0/list"));
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"month"});
		search.setTexts(new String[]{"开始时间"});
		search.setTypes(new String[]{"multi_date"});
		PageStructure data = PageUtil.createTablePageStructure("platcap/report/listData", "", tableHeader,tool,search);
		data.setRowLink(rowLink);
		data.setRowLinkTitle("操作");
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 获取数据:平台资金统计
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("listData")
	public DyResponse listData(Integer page,Integer limit,String date_start,String date_end) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setWhere(Where.between("rep_date", date_start, date_end));
		queryItem.setWhere(Where.eq("rec_category", AccConstants.REC_TYPE_PLAT));
		queryItem.setWhere(Where.eq("detail_type", -1));
		queryItem.setFields("id,rep_date,uid,total_income,total_pay");
		queryItem.setOrders("id");
		Page<Map> page2 = getPageByMap(queryItem, Module.REPORT, Function.REP_MONTH_CAPITAL);
		return createSuccessJsonResonse(dataConvert(page2));
	}
	
	/**
	 * 构建界面结构:查看收入支出统计明细
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("detail/{dir}/list")
	public ModelAndView detailList(@PathVariable("dir") int dir,String id) throws Exception {
		TableHeader tableHeader = new TableHeader();
		
		if(dir == AccConstants.TXN_DIR_IN){
			tableHeader.setNames(new String[]{"detail_type", "total_income"});
			tableHeader.setTexts(new String[]{"类型:cap_detail_type", "总收入金额"});
		}else{
			tableHeader.setNames(new String[]{"detail_type", "total_pay"});
			tableHeader.setTexts(new String[]{"类型:cap_detail_type", "总支出金额"});
		}
		
		Tool tool = new Tool();
		tool.setUrl("platcap/report/1/exportExcel");
		tool.setText("导出");
		tool.setType("commonbatchdownload");
		
		PageStructure data = PageUtil.createTablePageStructure("platcap/report/detail/"+dir+"/listData?id="+id, "", tableHeader,tool,null);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:查看收入支出统计明细
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("detail/{dir}/listData")
	public DyResponse detailListData(@PathVariable("dir") int dir,String id,Integer page,Integer limit) throws Exception {
		QueryItem queryItem = new QueryItem(Where.eq("id", id));
		queryItem.setFields("uid,rep_date");
		Map rep = getOneByMap(queryItem, Module.REPORT, Function.REP_MONTH_CAPITAL);
		
		queryItem = new QueryItem(Where.eq("rep_date", rep.get("rep_date")));
		queryItem.setWhere(Where.notEq("detail_type", "-1"));
		queryItem.setWhere(Where.eq("txn_dir", dir));
		queryItem.setFields("id,detail_type,total_income,total_pay");
		queryItem.setOrders("id");
		Page<Map> page2 = getPageByMap(queryItem, Module.REPORT, Function.REP_MONTH_CAPITAL);
		return createSuccessJsonResonse(dataConvert(page2));
	}
	
	/**
	 * 生成上月月报
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("insert")
	public DyResponse insert() throws Exception {
		
		reportService.createLastMonthCapReport(DateUtil.dateShortFormat(DateUtil.addMonth(new Date(), -1)).substring(0, 6));
//		reportService.createLastMonthCapReport(DateUtil.getCurrentDateStr().substring(0, 6));
		return createSuccessJsonResonse(null,"生成成功");
	}
	
	/**
	 * 导出excel
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="{type}/exportExcel")
	public String exportExcel(HttpServletResponse response,@PathVariable("type") int type,String id) throws Exception{
		String title = "";
		ExportExcel excel = null;
		if(type == 0){//总统计
			title = "总统计记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID", "月份","总收入金额","总支出金额"});
			excel.setFieldNames(new String[]{"id", "rep_date","total_income","total_pay"});
		}else {//分类统计
			title = "分类统计记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"类型", "总收入金额"});
			excel.setFieldNames(new String[]{"detail_type", "total_pay"});
		}
		
		QueryItem queryItem = new QueryItem(Where.in("id", id));
		queryItem.setFields("id,detail_type,total_income,total_pay");
		queryItem.setOrders("id desc");
		List<Map> items = (List<Map>) dataConvert(getListByMap(queryItem, Module.REPORT, Function.REP_MONTH_CAPITAL),"detail_type:cap_detail_type");
		excel.setDataList(items);
		excel.write(response, title+".xlsx");
		
		return null;
	}
	
}
