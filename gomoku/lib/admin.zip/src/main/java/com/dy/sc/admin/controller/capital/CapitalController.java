package com.dy.sc.admin.controller.capital;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.dy.core.constant.AccConstants;
import com.dy.core.controller.AdminBaseController;
import com.dy.core.dao.query.QueryItem;
import com.dy.core.dao.query.Where;
import com.dy.core.entity.DyResponse;
import com.dy.core.entity.Page;
import com.dy.core.entity.form.FormField;
import com.dy.core.entity.table.PageStructure;
import com.dy.core.entity.table.Search;
import com.dy.core.entity.table.TableHeader;
import com.dy.core.entity.table.Tool;
import com.dy.core.utils.DateUtil;
import com.dy.core.utils.DictUtils;
import com.dy.core.utils.GenNumUtil;
import com.dy.core.utils.JsonUtils;
import com.dy.core.utils.NumberUtils;
import com.dy.core.utils.PageUtil;
import com.dy.core.utils.excel.ExportExcel;
import com.dy.ia.entity.common.AccAccount;
import com.dy.ia.entity.common.CapRechargeRecord;
import com.dy.sc.entity.constant.SCFunction;
import com.dy.sc.entity.constant.SCModule;
import com.dy.sc.entity.money.MoneyCapitalDetail;

@Controller
@RequestMapping("/capital")
public class CapitalController extends AdminBaseController{

	/**
     * 构建界面结构:资金明细
     * @return
     * @throws Exception
     */
    @RequestMapping("detail/list")
    public ModelAndView detailList() throws Exception {
    	TableHeader tableHeader = new TableHeader();
		tableHeader.setNames(new String[]{"id", "create_time","company_name","txn_type","amount_in","amount_out","remark"});
		tableHeader.setTexts(new String[]{"ID", "交易时间","企业名称","交易类型","收入","支出","备注"});
		tableHeader.setTypes(new String[]{"","datetime", "","","number","number",""});
		tableHeader.setOptionTypes(new String[]{"","", "","cap_detail_type","","",""});
		tableHeader.setFilters(new String[]{"","multi_date", "input","select","","",""});
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"comName"});
		search.setTexts(new String[]{"企业名称"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("capital/detail/listData", "", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
    }
    
    /**
	 * 获取数据:资金明细
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("detail/listData")
	public DyResponse detailListData(Integer page,Integer limit,String search,String company_name,String txn_type,String otherName,String create_time) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setFields("*");
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", search)));
		}
		if(StringUtils.isNotBlank(company_name)){
		    queryItem.setWhere(Where.in("company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", company_name)));
		}
		if(StringUtils.isNotBlank(otherName)){
			queryItem.setWhere(Where.in("other_company_id", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_name", otherName)));
		}
		if(StringUtils.isNotBlank(txn_type)){
			queryItem.setWhere(Where.eq("txn_type", txn_type));
		}
		if(StringUtils.isNotBlank(create_time)){
			queryItem.setWhere(this.addDateWhereCondition(null, "create_time",create_time));
		}
		queryItem.setOrders("id desc");
		Page<Map> page2 = getPageByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_DETAIL);
		this.idToName(page2.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name as company_name");
		this.idToName(page2.getItems(), SCModule.SYSTEM, SCFunction.SYS_COMPANY, "other_company_id:company_name as otherName");
		return createSuccessJsonResonse(dataConvert(page2));
	}
	
	/**
	 * 导出excel:交易明细
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="detail/exportExcel")
	public String exportDetail(HttpServletResponse response,String id) throws Exception{
		QueryItem queryItem = new QueryItem(Where.in("id", id));
		queryItem.setFields("id,flow_num,company_id,other_company_id,account,txn_type,deal_amount,amount_in,amount_out,other_account,remark,create_time");
		List<Map> list = (List<Map>) dataConvert(getListByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_DETAIL),"txn_type:MONEY_DETAIL_type","create_time");
		
		this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "company_id:company_name as company_name");
		this.idToName(list, SCModule.SYSTEM, SCFunction.SYS_COMPANY, "other_company_id:company_name as otherName");
		
		String title = "交易明细_"+DateUtil.getCurrentTimeStr();
		ExportExcel excel = new ExportExcel(title, new String[]{"ID", "交易日期时间","流水号","账号","企业名称","交易类型","操作金额","收入","支出","对方账号","对方名称","备注"});
		excel.setFieldNames(new String[]{"id", "create_time","flow_num","account","company_name","txn_type","deal_amount","amount_in","amount_out","other_account","otherName","remark"});
		excel.setDataList(list);
		excel.write(response, title+".xlsx");
		return null;
	}
	
	/**
	 * 构建界面结构:充值记录,0-平台，2-客户
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("rechargerec/list/{rect}")
	public ModelAndView rechargerecList(@PathVariable("rect") String t) throws Exception {
		TableHeader tableHeader = new TableHeader();
		if(StringUtils.equals(t, "2")){
			tableHeader.setNames(new String[]{"id", "create_time","flow_num","username","real_name","txn_type","deal_amount","counter_fee","real_amount","rechar_status"});
			tableHeader.setTexts(new String[]{"ID", "交易日期时间","流水号","用户名","企业名称","类型","充值金额","充值手续费","实际到账金额","充值状态"});
			tableHeader.setTypes(new String[]{"","datetime", "","","","","number","number","number",""});
			tableHeader.setOptionTypes(new String[]{"","", "","","","recharge_type","","","","rechar_status"});
			tableHeader.setFilters(new String[]{"","multi_date", "","","input","","","","",""});
		}else{
			tableHeader.setNames(new String[]{"id", "create_time","flow_num","txn_type","deal_amount","counter_fee","real_amount","rechar_status"});
			tableHeader.setTexts(new String[]{"ID", "交易日期时间","流水号","类型","充值金额","充值手续费","实际到账金额","充值状态"});
			tableHeader.setTypes(new String[]{"","datetime", "","","number","number","number",""});
			tableHeader.setOptionTypes(new String[]{"","", "","recharge_type","","","","rechar_status"});
			tableHeader.setFilters(new String[]{"","multi_date", "","","","","",""});
		}
		
		Tool tool = new Tool();
		tool.setList(buildTools());
		
		Search search = new Search();
		search.setNames(new String[]{"account"});
		search.setTexts(new String[]{"流水号"});
		search.setTypes(new String[]{"text"});
		PageStructure data = PageUtil.createTablePageStructure("capital/rechargerec/listData/"+t, "", tableHeader,tool,search);
		return createSuccessModelAndView("common/table_single", JsonUtils.object2JsonString(data));
	}
	
	/**
	 * 获取数据:充值记录
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("rechargerec/listData/{rect}")
	public DyResponse rechargerecListData(@PathVariable("rect") String t,Integer page,Integer limit,String search,String real_name,String create_time) throws Exception {
		QueryItem queryItem = new QueryItem();
		queryItem.setPage(page == null ? 1 : page);
		queryItem.setLimit(limit == null ? 20 : limit);
		queryItem.setWhere(Where.eq("rec_category", t));
		if(StringUtils.equals(t, "2")){
			queryItem.setFields("id,flow_num,uid,counter_fee,txn_type,deal_amount,real_amount,rechar_status,create_time");
			if(StringUtils.isNotBlank(real_name)){
				queryItem.setWhere(Where.in("uid", getIdsLike(SCModule.SYSTEM, SCFunction.SYS_ADMIN, "real_name", real_name)));
			}
		}else{
			queryItem.setFields("id,flow_num,counter_fee,txn_type,deal_amount,real_amount,rechar_status,create_time");
		}
		if(StringUtils.isNotBlank(search)){
			queryItem.setWhere(Where.like("flow_num", "%"+search+"%"));
		}
		if(StringUtils.isNotBlank(create_time)){
			queryItem.setWhere(this.addDateWhereCondition(null, "create_time",create_time));
		}
		queryItem.setOrders("id desc");
		Page<Map> page2 = getPageByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_RECHARGE_RECORD);
		if(StringUtils.equals(t, "2")){
			this.idToName(page2.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "uid:username,real_name");
		}
		
		return createSuccessJsonResonse(dataConvert(page2));
	}
	
	/**
	 * 手动充值页面
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="recharge/toPlatRecharge")
	public ModelAndView toPlatRecharge() throws Exception {
		AccAccount account = this.getById(AccConstants.PLAT_ACCOUNT_ID, SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);
		List<FormField> formFieldList = new ArrayList<>();
		formFieldList.add(FormField.builder().name("totalAvali").text("可授信金额").type("span").build());
		
		formFieldList.add(FormField.builder().name("id").text("开户行").type("select").options("open_bank").verify("required").build());
		
//		formFieldList.add(FormField.builder().name("account").text("账号").type("span").build());
		
		formFieldList.add(FormField.builder().name("rechargeAmount").text("充值金额").verify("required").build());
		
		Map<String,Object> formData = new HashMap<>();
		formData.put("totalAvali", NumberUtils.round(account.getAccBalance())+" 元");
		Map<String, Object> data = PageUtil.createFormPageStructure("capital/recharge/platRecharge", formFieldList,formData);
		
		return createSuccessModelAndView("common/edit", JsonUtils.object2JsonString(data));
	}

	/**
	 * 手动充值
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value="recharge/platRecharge")
	public DyResponse platRecharge(AccAccount accAccount,@Param("rechargeAmount") BigDecimal rechargeAmount) throws Exception {
		
		if(accAccount.getId() == null)return createErrorJsonResonse("请选择充值的账户！");
		if(!NumberUtils.greaterThanZero(rechargeAmount))return createErrorJsonResonse("充值金额必须大于0！");
		accAccount = this.getById(accAccount.getId(), SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, AccAccount.class);
		accAccount.setAccBalance(NumberUtils.add(accAccount.getAccBalance(),rechargeAmount));
		
		this.update(SCModule.ACCOUNT, SCFunction.ACC_ACCOUNT, accAccount);
		
		String flowNum = GenNumUtil.genNum("PTCZ");
		insertDetail(accAccount, null, rechargeAmount, flowNum, AccConstants.CAP_DETAIL_TYPE_CZ,true);
		
		// 插入平台充值记录
		CapRechargeRecord record = new CapRechargeRecord();
		record.setDealAmount(rechargeAmount);
		record.setFlowNum(flowNum);
		record.setRealAmount(rechargeAmount);
		record.setRecharStatus(AccConstants.RECH_STATUS_SUCC);
		record.setRecCategory(AccConstants.REC_TYPE_PLAT);
		record.setTxnType(AccConstants.RECHAR_TYPE_MANUAL);
		record.setAccId(accAccount.getId());
//		record.setCounterFee(NumberUtils.mul(rechargeAmount,new BigDecimal(0.001)));
//		record.setRemark(remark);
		
		this.insert(SCModule.MONEY, SCFunction.MONEY_RECHARGE_RECORD, record);
		
		return createSuccessJsonResonse(null,"充值成功");
	}
	
	// 插入交易明细(平台充值)
	private void insertDetail(AccAccount accAccount,AccAccount toAccAccount, BigDecimal amount, String flowNum,int txnType, boolean isIn) throws Exception {
		if(accAccount != null){
			MoneyCapitalDetail detail = new MoneyCapitalDetail();
			detail.setAccount(accAccount.getAccount());
			detail.setDealAmount(amount);
			detail.setFlowNum(flowNum);
			if(isIn){
				detail.setAmountIn(amount);
				detail.setTxnDir(AccConstants.TXN_DIR_IN);
			}else{
				detail.setAmountOut(amount);
				detail.setTxnDir(AccConstants.TXN_DIR_OUT);
			}
			if(toAccAccount != null){
				detail.setOtherAccount(toAccAccount.getAccount());
			}
			detail.setCompanyId(accAccount.getCompanyId());
			detail.setBalance(accAccount.getAccBalance());
			if(txnType == AccConstants.CAP_DETAIL_TYPE_CZSXF){
				detail.setRemark(MessageFormat.format("充值手续费{0}元",amount));
			}else{
				detail.setRemark(MessageFormat.format("通过{0}支付充值{1}元",DictUtils.getDictLabel("1", "recharge_back"),amount));
			}
			detail.setTxnType(txnType);
			this.insert(SCModule.MONEY, SCFunction.MONEY_DETAIL, detail);
		}
	}

	/**
	 * 导出excel:充值记录
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="rechargerec/exportExcel/{type}")
	public String exportExcel(HttpServletResponse response,@PathVariable("type") String type,String id) throws Exception{
		QueryItem queryItem = new QueryItem(Where.in("id", id));
		String title = "";
		ExportExcel excel = null;
		if("2".equals(type)){
			title = "客户充值记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID", "交易日期时间","流水号","用户名","企业名称","类型","充值金额","充值手续费","实际到账金额","充值状态"});
			excel.setFieldNames(new String[]{"id", "create_time","flow_num","username","real_name","txn_type","deal_amount","counter_fee","real_amount","rechar_status"});
		}else{
			title = "平台充值记录_"+DateUtil.getCurrentTimeStr();
			excel = new ExportExcel(title, new String[]{"ID", "交易日期时间","流水号","类型","充值金额","充值手续费","实际到账金额","充值状态"});
			excel.setFieldNames(new String[]{"id", "create_time","flow_num","txn_type","deal_amount","counter_fee","real_amount","rechar_status"});
		}
		Page<Map> page = (Page<Map>) dataConvert(getPageByMap(queryItem, SCModule.MONEY, SCFunction.MONEY_RECHARGE_RECORD),"txn_type:recharge_type,rechar_status","create_time");
		if(StringUtils.equals(type, "2")){
			this.idToName(page.getItems(), SCModule.SYSTEM, SCFunction.SYS_ADMIN, "uid:username,real_name");
		}
		excel.setDataList(page.getItems());
		excel.write(response, title+".xlsx");
		
		return null;
	}
	

}